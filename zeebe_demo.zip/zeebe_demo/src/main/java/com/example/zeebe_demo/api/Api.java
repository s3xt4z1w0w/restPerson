package com.example.zeebe_demo.api;

import com.example.zeebe_demo.worker.Worker;
import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.response.ProcessInstanceEvent;
import io.camunda.zeebe.client.api.response.ProcessInstanceResult;
import io.camunda.zeebe.client.api.worker.JobWorker;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.Map;

@RestController
@RequestMapping("/api/zeebe")
public class Api {

    private final Logger log = LogManager.getLogger(getClass());

    private final ZeebeClient zeebeClient;

    public Api(@Qualifier("zeebeClientLifecycle") ZeebeClient zeebeClient) {
        this.zeebeClient = zeebeClient;
    }

    @PostMapping("/{name}")
    public ResponseEntity<?> callProcess(@PathVariable String name) {
        log.info("start :{}", name);

        ProcessInstanceEvent join = zeebeClient.newCreateInstanceCommand()
                .bpmnProcessId("ZeebeLocal")
                .latestVersion()
                .variables(Map.of("name", name))
                .send()
                .join();

        log.info("end: {}", name);
        return ResponseEntity.ok(join);
    }
}
