package com.example.zeebe_demo.worker;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.client.api.worker.JobHandler;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class Worker {

    private final Logger log = LogManager.getLogger(getClass());

    @JobWorker(type = "do-foo")
    public void foo(@VariablesAsType Object data) throws InterruptedException {
        log.info("do-foo start: {}", data);
        Thread.sleep(4500);
        log.info("do-foo end: {}", data);
    }

    @JobWorker(type = "do-bar")
    public void bar(@VariablesAsType Object data) throws InterruptedException {
        log.info("do-bar start: {}", data);
        Thread.sleep(4500);
        log.info("do-bar end: {}", data);
    }
}
