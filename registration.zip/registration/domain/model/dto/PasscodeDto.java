package kz.eubank.registration.domain.model.dto;

import java.util.Date;

public record PasscodeDto(Long id,
                          Long userId,
                          String status,
                          String hash,
                          String salt,
                          String deviceId,
                          Date dateCreated,
                          int invalidUses) {
}
