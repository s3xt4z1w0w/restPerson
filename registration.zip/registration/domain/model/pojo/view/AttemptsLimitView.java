package kz.eubank.registration.domain.model.pojo.view;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttemptsLimitView {

    private String type;
    private int count;
}
