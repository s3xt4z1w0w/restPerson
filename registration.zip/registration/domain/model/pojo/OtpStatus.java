package kz.eubank.registration.domain.model.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OtpStatus {

    private String id;
    private String title;
}
