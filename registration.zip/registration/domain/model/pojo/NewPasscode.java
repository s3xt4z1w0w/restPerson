package kz.eubank.registration.domain.model.pojo;

import lombok.*;
import java.util.Date;

@Builder
@Setter
@Getter
public class NewPasscode {

    private Long id;
    private Long userId;
    private String status;
    private String hash;
    private String deviceId;
    private Date dateCreated;
    private int invalidUses;

}