package kz.eubank.registration.domain.model.mapper;

import kz.eubank.registration.domain.model.dto.AttemptsLimitDto;
import kz.eubank.registration.domain.model.pojo.view.AttemptsLimitView;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AttemptsLimitMapper {

    AttemptsLimitMapper INSTANCE = Mappers.getMapper(AttemptsLimitMapper.class);

    List<AttemptsLimitDto> toDtoList(List<AttemptsLimitView> attemptsLimitViews);

    AttemptsLimitDto toDto(AttemptsLimitView attemptsLimitView);
}
