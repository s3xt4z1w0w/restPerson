package kz.eubank.registration.domain.model.mapper;

import kz.eubank.registration.domain.model.dto.DMZVerificationOtpDto;
import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.model.pojo.DMZVerificationOtp;
import kz.eubank.registration.domain.model.pojo.OtpStatus;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface DMZVerificationOtpMapper {

    DMZVerificationOtpMapper INSTANCE = Mappers.getMapper(DMZVerificationOtpMapper.class);

    DMZVerificationOtpDto toDto(DMZVerificationOtp dmzVerificationOtp);

    DMZVerificationOtp toEntity(DMZVerificationOtpDto dmzVerificationOtpDto);

    default String otpStatus2String(OtpStatus otpStatus) {
        return otpStatus != null ? otpStatus.getId() : null;
    }

    default OtpStatus string2OtpStatus(String status) {
        if (status != null) {
            OtpStatus otpStatus = new OtpStatus();
            otpStatus.setId(status);
            return otpStatus;
        }
        return null;
    }

    default Long dmzVerification2Long(DMZVerification dmzVerification) {
        return dmzVerification != null ? dmzVerification.getId() : null;
    }

    default DMZVerification long2DmzVerification(Long id) {
        if (id != null) {
            return DMZVerification.builder()
                    .id(id)
                    .build();
        }
        return null;
    }
}
