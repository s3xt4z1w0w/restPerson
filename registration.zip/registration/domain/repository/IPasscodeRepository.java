package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.Passcode;

public interface IPasscodeRepository {

    void save(Passcode passcode);
    void changeStatus(String status, String deviceId);

}
