package kz.eubank.registration.domain.util;

public class ObjectUtil {

    public static boolean isNotNull(Object o) {
        return o != null;
    }
}
