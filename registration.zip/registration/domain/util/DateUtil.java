package kz.eubank.registration.domain.util;

import java.util.Calendar;
import java.util.Date;

public class DateUtil {

    public static Date currentDate() {
        return new Date();
    }

    public static Date addMinutesToCurrentDate(long minutes) {
        var date = Calendar.getInstance();
        var timeInSecs = date.getTimeInMillis();
        return new Date(timeInSecs + (minutes * 60 * 1000));
    }
}
