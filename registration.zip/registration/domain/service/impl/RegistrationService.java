package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.service.*;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static kz.eubank.registration.domain.util.ObjectUtil.isNotNull;

@Service
@RequiredArgsConstructor
public class RegistrationService implements IRegistrationService {

    private final static String SMS = "SSMS";
    private static final String IIN = "VIIN";
    private final static String BIO = "VBIO";

    private final AppProperties appProperties;
    private final IWhiteListAuthorizationService whiteListAuthorizationService;
    private final IDMZVerificationService dmzVerificationService;
    private final IAttemptsLimitService attemptsLimitService;
    private final IUserDefineRouteService userDefineRouteService;

    @Override
    public Map<String, Object> defineRoute(String phoneNumber) {
        var result = new HashMap<String, Object>();

        var user = userDefineRouteService.getUserDefineRouteByMobilePhone(phoneNumber);
        if (isNotNull(user)) {
            result.put("iin", user.iin());
            result.put("isExist", true);
            result.put("isResident", user.isResident());
            return result;
        }
        result.put("isExist", false);
        return result;
    }

    @Override
    public Map<String, Object> checkWhiteList(String phoneNumber) {
        var result = new HashMap<String, Object>();
        var whiteList = whiteListAuthorizationService.getWhiteListByPhoneNumber(phoneNumber);
        if (isNotNull(whiteList)) {
            result.put("whiteList", whiteList);
            result.put("isWhiteList", true);
            return result;
        }
        result.put("isWhiteList", false);
        return result;
    }

    @Override
    public Map<String, Object> checkLimits(String phoneNumber) {
        var result = new HashMap<String, Object>();
        if (dmzVerificationService.getVerificationLimitCountByMobilePhone(phoneNumber) > appProperties.getVerificationLimitCount()) {
            result.put("error", SelfErrorCode.E_BS_901);
            return result;
        }

        var limits = attemptsLimitService.getLimitsCountByMobilePhone(phoneNumber);
        for (var limit : limits) {
            if (SMS.equals(limit.type()) && limit.count() > appProperties.getLimitByTypeCount(SMS) ||
                    BIO.equals(limit.type()) && limit.count() > appProperties.getLimitByTypeCount(BIO) ||
                    IIN.equals(limit.type()) && limit.count() > appProperties.getLimitByTypeCount(IIN)) {
                result.put("error", SelfErrorCode.E_BS_901);
                return result;
            }
        }
        return result;
    }

    @Override
    public Map<String, Object> checkSessionExistence(String phoneNumber) {
        var result = new HashMap<String, Object>();
        var notFinishedSession = dmzVerificationService.getNotFinishedSessionByMobilePhone(phoneNumber);
        if (isNotNull(notFinishedSession)) {
            result.put("sessionId", notFinishedSession.sessionId());
            result.put("isNotFinishedSession", true);
            result.put("route", "NTFC");
            return result;
        }
        result.put("isNotFinishedSession", false);
        return result;
    }
}
