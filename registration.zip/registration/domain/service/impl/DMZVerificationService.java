package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.dto.DMZVerificationDto;
import kz.eubank.registration.domain.model.mapper.DMZVerificationMapper;
import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.model.pojo.RouteStatus;
import kz.eubank.registration.domain.model.pojo.RouteType;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.service.IDMZVerificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static kz.eubank.registration.domain.util.DateUtil.addMinutesToCurrentDate;
import static kz.eubank.registration.domain.util.DateUtil.currentDate;
import static kz.eubank.registration.domain.util.UUIDUtil.getRandomUUID;

@Service
@RequiredArgsConstructor
public class DMZVerificationService implements IDMZVerificationService {

    private final IDMZVerificationRepository dmzVerificationRepository;

    @Override
    public Map<String, Object> createDMZVerification(String route, String phoneNumber, String deviceId, String iin,
                                                     String versionFront, String frontEnd) {
        //TODO optimize method params
        var result = new HashMap<String, Object>();

        var sessionId = getRandomUUID();


        result.put("sessionId", sessionId);
        return result;
    }

    @Override
    public int getVerificationLimitCountByMobilePhone(String phoneNumber) {
        return dmzVerificationRepository.getVerificationLimitCountByMobilePhone(phoneNumber);
    }

    @Override
    public DMZVerificationDto getNotFinishedSessionByMobilePhone(String phoneNumber) {
        var dmzVerification = dmzVerificationRepository.getNotFinishedSessionByMobilePhone(phoneNumber);
        return DMZVerificationMapper.INSTANCE.toDto(dmzVerification.orElse(null));
    }
}
