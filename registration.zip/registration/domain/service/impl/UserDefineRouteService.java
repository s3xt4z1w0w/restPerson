package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.dto.UserDefineRouteDto;
import kz.eubank.registration.domain.model.mapper.UserDefineRouteMapper;
import kz.eubank.registration.domain.repository.view.IUserDefineRouteViewRepository;
import kz.eubank.registration.domain.service.IUserDefineRouteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserDefineRouteService implements IUserDefineRouteService {

    private final IUserDefineRouteViewRepository userDefineRouteViewRepository;

    @Override
    public UserDefineRouteDto getUserDefineRouteByMobilePhone(String phoneNumber) {
        var userDefineRoute = userDefineRouteViewRepository.getUserDefineRouteByMobilePhone(phoneNumber);
        return UserDefineRouteMapper.INSTANCE.toDto(userDefineRoute.orElse(null));
    }
}
