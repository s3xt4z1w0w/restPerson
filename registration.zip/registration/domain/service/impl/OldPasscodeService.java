package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.dto.WhiteListAuthorizationDto;
import kz.eubank.registration.domain.model.pojo.Passcode;
import kz.eubank.registration.domain.model.pojo.PasscodeStatus;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.repository.IPasscodeRepository;
import kz.eubank.registration.domain.service.IPasscodeService;
import kz.eubank.registration.domain.util.CommonUtil;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import static kz.eubank.registration.domain.util.DateUtil.currentDate;

@Service
@Qualifier("oldPasscode")
@RequiredArgsConstructor
public class OldPasscodeService implements IPasscodeService {
    private final IPasscodeRepository passcodeRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;
    @Override
    public void saveWhiteListPasscode(WhiteListAuthorizationDto whiteListAuthorizationDto, String deviceId) {
    }

    @Override
    public void savePasscode(String dmzSessionId, String password) {
        String deviceId = dmzVerificationRepository.findDeviceId(dmzSessionId);
        long userId = dmzVerificationRepository.findUserIdByIin(dmzSessionId);

        String salt = CommonUtil.salt();
        String hash = CommonUtil.sha64(salt + password);
        PasscodeStatus passcodeStatus = new PasscodeStatus();
        passcodeStatus.setId("ACTV");

        if (deviceId == null) throw new SelfException(SelfErrorCode.E_BS_901, "SessionID not found: " + dmzSessionId);
        if (userId == 0) throw new SelfException(SelfErrorCode.E_BS_901, "UserId through sessionId not found: " + dmzSessionId);

        changeStatusPasscode("BUPR", deviceId);

        Passcode passcode = Passcode.builder()
                        .userId(userId)
                        .salt(salt)
                        .hash(hash)
                        .deviceId(deviceId)
                        .status(passcodeStatus)
                        .dateCreated(currentDate())
                        .build();
        passcodeRepository.save(passcode);
    }

    @Override
    public boolean validatePasscode(String password, String storedPassword) {
        return false;
    }

    @Override
    public void changeStatusPasscode(String status, String deviceId) {
        passcodeRepository.changeStatus(status, deviceId);
    }
}
