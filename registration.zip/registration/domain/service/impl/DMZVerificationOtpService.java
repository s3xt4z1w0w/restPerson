package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.dto.DMZVerificationOtpDto;
import kz.eubank.registration.domain.model.mapper.DMZVerificationOtpMapper;
import kz.eubank.registration.domain.model.pojo.DMZVerificationOtp;
import kz.eubank.registration.domain.model.pojo.OtpStatus;
import kz.eubank.registration.domain.repository.IDMZVerificationOtpRepository;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.service.IDMZVerificationOtpService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import static kz.eubank.registration.domain.util.CommonUtil.randomNumber;
import static kz.eubank.registration.domain.util.CommonUtil.sha64;
import static kz.eubank.registration.domain.util.DateUtil.addMinutesToCurrentDate;
import static kz.eubank.registration.domain.util.DateUtil.currentDate;

@Service
@RequiredArgsConstructor
public class DMZVerificationOtpService implements IDMZVerificationOtpService {

    private final IDMZVerificationOtpRepository dmzVerificationOtpRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;

    @Override
    public String generateSmsCode(String sessionId) {
        return randomNumber(4);
    }

    @Override
    public void saveDMZVerificationOtp(String generatedCode, String sessionId) {
        var dmzVerification = dmzVerificationRepository.findBySessionId(sessionId)
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_DB_600));
        var otpStatus = new OtpStatus();
        otpStatus.setId("SEND");

        var dmzVerificationOtp = DMZVerificationOtp.builder()
                .dmzVerification(dmzVerification)
                .otpStatus(otpStatus)
                .createdDate(currentDate())
                .expiredDate(addMinutesToCurrentDate(10 /*TODO ask time*/))
                .codeHash(sha64(generatedCode))
                .countValidation(0)
                .build();
        dmzVerificationOtpRepository.save(dmzVerificationOtp);
    }

    @Override
    public DMZVerificationOtpDto getActualOtpBySessionId(String sessionId) {
        var optDmzVerificationOtp = dmzVerificationOtpRepository.getActualOtpBySessionId(sessionId);
        return DMZVerificationOtpMapper.INSTANCE.toDto(optDmzVerificationOtp.orElse(null));
    }

    @Override
    public void incrementCountValidation(DMZVerificationOtpDto dmzVerificationOtpDto) {
        var dmzVerificationOtp = DMZVerificationOtpMapper.INSTANCE.toEntity(dmzVerificationOtpDto);
        dmzVerificationOtp.setCountValidation(dmzVerificationOtp.getCountValidation() + 1);
        dmzVerificationOtpRepository.save(dmzVerificationOtp);
    }
}
