package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.service.IAttemptsLimitService;
import kz.eubank.registration.domain.service.IDMZVerificationAttemptsService;
import kz.eubank.registration.domain.service.IDMZVerificationOtpService;
import kz.eubank.registration.domain.service.ISmsService;
import kz.eubank.registration.infrastructure.config.AppProperties;
import kz.eubank.registration.infrastructure.repository.grpc.PushSmsGatewayRepositoryImpl;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static kz.eubank.registration.domain.util.CommonUtil.sha64;
import static kz.eubank.registration.domain.util.ObjectUtil.isNotNull;

@Service
@RequiredArgsConstructor
public class SmsService implements ISmsService {

    private static final String SMS = "SSMS";
    private final AppProperties appProperties;
    private final IAttemptsLimitService attemptsLimitService;
    private final IDMZVerificationOtpService dmzVerificationOtpService;
    private final PushSmsGatewayRepositoryImpl pushSmsGatewayRepository;
    private final IDMZVerificationAttemptsService dmzVerificationAttemptsService;

    @Override
    public Map<String, Object> sendSms(String phoneNumber, String sessionId) {
        var result = new HashMap<String, Object>();

        // Check limits for current day
        var smsAttempt = attemptsLimitService.getLimitsCountByMobilePhoneAndType(phoneNumber, SMS);
        if (isNotNull(smsAttempt) && smsAttempt.count() > appProperties.getLimitByTypeCount(SMS)) {
            result.put("error", SelfErrorCode.E_BS_901);
            return result;
        }

        //Generate and save code
        var generatedCode = dmzVerificationOtpService.generateSmsCode(sessionId);
        dmzVerificationOtpService.saveDMZVerificationOtp(generatedCode, sessionId);

        //Send sms
        var smsContent = appProperties.getSendSmsContent(generatedCode);
        var message = pushSmsGatewayRepository.sendSms(phoneNumber, smsContent, "1234");
        result.put("generatedCode", generatedCode);

        // Blocking counter
        if (message != null) {
            dmzVerificationAttemptsService.fixSend(sessionId);
        }
        return result;
    }

    @Override
    public Map<String, Object> checkSms(String sessionId, String clientCode, int count) {
        var result = new HashMap<String, Object>();
        int countInt = 0;
        String code = "1234";
        System.out.println("code: " + clientCode);

        if (clientCode.equals(code)) {
            result.put("isSmsChecked", true);
            return result;
        }
        countInt=count;
        countInt++;
        result.put("isSmsChecked", false);

        result.put("count", (int)countInt);
        return result;
    }
}
