package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.pojo.DMZVerificationAttempts;
import kz.eubank.registration.domain.repository.IDMZVerificationAttemptsRepository;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.service.IDMZVerificationAttemptsService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import static kz.eubank.registration.domain.util.DateUtil.currentDate;

@Service
@RequiredArgsConstructor
public class DMZVerificationAttemptsService implements IDMZVerificationAttemptsService {

    private final IDMZVerificationAttemptsRepository dmzVerificationAttemptsRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;

    @Override
    public void fixSend(String sessionId) {
        var dmzVerification = dmzVerificationRepository.findBySessionId(sessionId)
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_DB_600));

        var dmzVerificationAttempts = DMZVerificationAttempts.builder()
                .createdDate(currentDate())
                .mobilePhone(dmzVerification.getMobilePhone())
                .type("SSMS")
                .isPasscodeSet(true)
                .dmzVerification(dmzVerification)
                .build();
        dmzVerificationAttemptsRepository.save(dmzVerificationAttempts);
    }
}
