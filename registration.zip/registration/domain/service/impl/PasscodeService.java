package kz.eubank.registration.domain.service.impl;

import kz.eubank.registration.domain.model.dto.WhiteListAuthorizationDto;
import kz.eubank.registration.domain.model.pojo.NewPasscode;
import kz.eubank.registration.domain.model.pojo.Passcode;
import kz.eubank.registration.domain.model.pojo.PasscodeStatus;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.domain.repository.IPasscodeRepository;
import kz.eubank.registration.domain.repository.INewPasscodeRepository;
import kz.eubank.registration.domain.service.IHashService;
import kz.eubank.registration.domain.service.IPasscodeService;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import static kz.eubank.registration.domain.util.DateUtil.currentDate;

@Service
@Qualifier("passcode")
@RequiredArgsConstructor
public class PasscodeService implements IPasscodeService {

    private final IPasscodeRepository passcodeRepository;
    private final IDMZVerificationRepository dmzVerificationRepository;
    private final INewPasscodeRepository newPasscodeRepository;
    private final IHashService hashService;

    @Override
    public void saveWhiteListPasscode(WhiteListAuthorizationDto whiteListAuthorizationDto, String deviceId) {
        //TODO save best practice
        PasscodeStatus passcodeStatus = new PasscodeStatus();
        passcodeStatus.setId("ACTV");

        Passcode passcode = Passcode.builder()
                .userId(whiteListAuthorizationDto.userId())
                .status(passcodeStatus)
                .hash(whiteListAuthorizationDto.hash())
                .salt(whiteListAuthorizationDto.salt())
                .deviceId(deviceId)
                .dateCreated(currentDate())
                .build();
        passcodeRepository.save(passcode);
    }

    @Override
    public void savePasscode(String dmzSessionId, String pin) {
        String deviceId = dmzVerificationRepository.findDeviceId(dmzSessionId);
        long userId = dmzVerificationRepository.findUserIdByIin(dmzSessionId);

        if (deviceId == null) throw new SelfException(SelfErrorCode.E_BS_901, "SessionID not found: " + dmzSessionId);
        if (userId == 0) throw new SelfException(SelfErrorCode.E_BS_901, "UserId through sessionId not found: " + dmzSessionId);

        changeStatusPasscode("BUPR", deviceId);
        String hashPasscode = hashService.getHash(pin);
        NewPasscode passcode = NewPasscode.builder()
                .hash(hashPasscode)
                .deviceId(deviceId)
                .userId(userId)
                .status("ACTV")
                .build();
        newPasscodeRepository.save(passcode);
    }

    @Override
    public boolean validatePasscode(String dmzSessionId, String pin) {
        String storedHash =  newPasscodeRepository.findHash(dmzSessionId);
        return hashService.validatePasscode(pin, storedHash);
    }

    @Override
    public void changeStatusPasscode(String status, String deviceId) {
        newPasscodeRepository.changeStatus(status, deviceId);
    }
}
