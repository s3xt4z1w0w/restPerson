package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.dto.UserDefineRouteDto;

public interface IUserDefineRouteService {

    UserDefineRouteDto getUserDefineRouteByMobilePhone(String phoneNumber);
}
