package kz.eubank.registration.domain.service;

public interface IHashService {
    String getHash(String password);
    boolean validatePasscode(String originalPassword, String storedPassword);
}
