package kz.eubank.registration.domain.service;

import java.util.Map;

public interface IRegistrationService {

    Map<String, Object> defineRoute(String phoneNumber);

    Map<String, Object> checkWhiteList(String phoneNumber);

    Map<String, Object> checkLimits(String phoneNumber);

    Map<String, Object> checkSessionExistence(String phoneNumber);
}
