package kz.eubank.registration.domain.service;

public interface IDMZVerificationAttemptsService {

    void fixSend(String sessionId);
}
