package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.dto.AttemptsLimitDto;

import java.util.List;

public interface IAttemptsLimitService {

    List<AttemptsLimitDto> getLimitsCountByMobilePhone(String phoneNumber);

    AttemptsLimitDto getLimitsCountByMobilePhoneAndType(String phoneNumber, String type);
}
