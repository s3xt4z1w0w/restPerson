package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.entity.DMZVerification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface DMZVerificationHiberRepository extends JpaRepository<DMZVerification, Long> {

    @Query(nativeQuery = true,
            value = """
                    select count(*)
                    from DMZVerification v
                    where v.MobilePhone = :mobilePhone
                    and format(v.DateCreated, 'yyyy-MM-dd') = format(GETDATE(), 'yyyy-MM-dd')
                    """)
    int getVerificationLimitCountByMobilePhone(String mobilePhone);

    @Query(nativeQuery = true,
            value = """
                    select *
                      from DMZVerification v
                     where v.MobilePhone = :mobilePhone
                       and v.RouteStatus_IDREF = 'VSCS'
                       and getdate() between v.DateCreated and v.DateExpired
                    """)
    Optional<DMZVerification> getNotFinishedSessionByMobilePhone(String mobilePhone);

    Optional<DMZVerification> findBySessionId(String sessionId);

    @Query(value = "SELECT v.deviceId FROM DMZVerification v WHERE v.sessionId = :sessionId")
    String findDeviceId(String sessionId);

    @Query(nativeQuery = true,
            value = """
                    SELECT [User].USER_ID FROM dbo.[DMZVerification]
                    JOIN dbo.[Person] ON Person.IIN =  dbo.[DMZVerification].Iin
                    JOIN dbo.[User] ON [User].Person_IDREF  = [Person].Person_ID
                    WHERE DMZVerification.SessionId = :sessionId
            """)
    long findUserIdByIin(String sessionId);
}
