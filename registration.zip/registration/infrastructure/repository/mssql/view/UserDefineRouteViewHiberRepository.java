package kz.eubank.registration.infrastructure.repository.mssql.view;

import kz.eubank.registration.infrastructure.entity.view.UserDefineRouteView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface UserDefineRouteViewHiberRepository extends JpaRepository<UserDefineRouteView, String> {

    @Query(nativeQuery = true,
            value = """
                    Select m.MobilePhone, p.IIN, p.IsResident
                    from MobilePhone m
                    join AuthSMS aus on aus.MobilePhone_IDREF = m.MobilePhone_ID
                    join map_User_AuthTool ua on ua.AuthTool_IDREF = aus.AuthTool_IDREF
                    join [User] u on u.User_ID = ua.User_IDREF
                    join Person p on p.Person_ID = u.Person_IDREF
                    join AuthTool atu on atu.AuthTool_ID = ua.AuthTool_IDREF
                    where atu.AuthToolStatus_IDREF in ('ACTV','BLAE')
                    and m.MobilePhone = :mobilePhone
                    """)
    Optional<UserDefineRouteView> getUserDefineRouteByMobilePhone(String mobilePhone);
}
