package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.DMZVerificationAttempts;
import kz.eubank.registration.domain.repository.IDMZVerificationAttemptsRepository;
import kz.eubank.registration.infrastructure.entity.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.DMZVerificationAttemptsHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@RequiredArgsConstructor
public class DMZVerificationAttemptsRepository implements IDMZVerificationAttemptsRepository {

    private final DMZVerificationAttemptsHiberRepository dmzVerificationAttemptsHiberRepository;

    @Override
    public void save(DMZVerificationAttempts dmzVerificationAttempts) {
        var entity = BaseMapper.INSTANCE.toEntity(dmzVerificationAttempts);
        dmzVerificationAttemptsHiberRepository.save(entity);
    }
}
