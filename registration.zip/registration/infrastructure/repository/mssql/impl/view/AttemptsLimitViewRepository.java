package kz.eubank.registration.infrastructure.repository.mssql.impl.view;

import kz.eubank.registration.domain.model.pojo.view.AttemptsLimitView;
import kz.eubank.registration.domain.repository.view.IAttemptsLimitViewRepository;
import kz.eubank.registration.infrastructure.entity.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.view.AttemptsLimitViewHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Primary
@Component
@RequiredArgsConstructor
public class AttemptsLimitViewRepository implements IAttemptsLimitViewRepository {

    private final AttemptsLimitViewHiberRepository attemptsLimitViewHiberRepository;

    @Override
    public List<AttemptsLimitView> getLimitsCountByMobilePhone(String mobilePhone) {
        return attemptsLimitViewHiberRepository.getLimitsCountByMobilePhone(mobilePhone)
                .stream()
                .map(BaseMapper.INSTANCE::toDomain)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<AttemptsLimitView> getLimitsCountByMobilePhoneAndType(String mobilePhone, String type) {
        return attemptsLimitViewHiberRepository.getLimitsCountByMobilePhoneAndType(mobilePhone, type)
                .map(BaseMapper.INSTANCE::toDomain);
    }
}
