package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.entity.Passcode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;

public interface PasscodeHiberRepository extends JpaRepository<Passcode, Long> {

    @Transactional
    @Modifying
    @Query(nativeQuery = true,
            value = """
                    UPDATE NewPassCode SET PasscodeStatus_IDREF = :status WHERE DeviceID = :deviceId AND PasscodeStatus_IDREF = 'ACTV'
            """)
    void changeStatus(String status, String deviceId);
}
