package kz.eubank.registration.infrastructure.repository.grpc;

import io.grpc.StatusRuntimeException;
import kz.eubank.grpc.EubServiceGenericPushSmsGateway;
import kz.eubank.grpc.PushSmsGrpc;
import kz.eubank.registration.infrastructure.util.MetadataUtil;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import lombok.RequiredArgsConstructor;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PushSmsGatewayRepositoryImpl {

    @GrpcClient("smsGateWay")
    private PushSmsGrpc.PushSmsBlockingStub stub;

    public String sendSms(String phoneNumber, String message, String correlationId) {
        try {
            var response = stub
                    .withInterceptors(MetadataUtil.newCorrelationIdInterceptor(correlationId))
                    .sendSms(EubServiceGenericPushSmsGateway.SendSmsRequest
                            .newBuilder()
                            .setPhones(phoneNumber)
                            .setMessage(message)
                            .setSenderName("Smartbank")
                            .build());
            return response.getMessage();
        } catch (StatusRuntimeException e) {
            throw new SelfException(SelfErrorCode.E_EX_700);
        }
    }
}
