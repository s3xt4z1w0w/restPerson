package kz.eubank.registration.infrastructure.util;

import io.grpc.ClientInterceptor;
import io.grpc.Metadata;
import io.grpc.stub.MetadataUtils;

import java.util.Objects;

public class MetadataUtil {

    public static ClientInterceptor newCorrelationIdInterceptor(String correlationId) {
        if (Objects.isNull(correlationId)) {
            correlationId = "";
        }
        Metadata headers = new Metadata();
        Metadata.Key<String> key = Metadata.Key.of("X-Correlation-Id", Metadata.ASCII_STRING_MARSHALLER);
        headers.put(key, correlationId);
        return MetadataUtils.newAttachHeadersInterceptor(headers);
    }
}
