package kz.eubank.registration.infrastructure.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@ConfigurationProperties(prefix = "kz.eubank.registration")
@ComponentScan("kz.eubank.registration.infrastructure.config")
@EnableJpaRepositories("kz.eubank.registration.infrastructure.repository")
@EntityScan("kz.eubank.registration.infrastructure.entity")
public class AppConfig {
}
