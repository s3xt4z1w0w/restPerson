package kz.eubank.registration.infrastructure.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "DMZVerificationOtp")
@Builder
public class DMZVerificationOtp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DMZVerificationOtp_ID")
    private Long id;

    @Column(name = "DateCreated")
    private Date createdDate;

    @OneToOne
    @JoinColumn(name = "OtpStatus_IDREF")
    private OtpStatus otpStatus;

    @Column(name = "DateExpired")
    private Date expiredDate;

    @Column(name = "CodeHash")
    private String codeHash;

    @ManyToOne
    @JoinColumn(name = "DMZVerification_IDREF")
    private DMZVerification dmzVerification;

    @Column(name = "CountValidation")
    private int countValidation;
}
