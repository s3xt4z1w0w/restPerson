package kz.eubank.registration.infrastructure.entity;

import lombok.Getter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Entity
@Table(name = "WhiteListAuthorization")
public class WhiteListAuthorization {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "WhiteListAuthorization_ID")
    private Long id;

    @Column(name = "MobilePhone")
    private String mobilePhone;

    @Column(name = "Hash")
    private String hash;

    @Column(name = "Salt")
    private String salt;

    @Column(name = "User_IDREF")
    private Long userId;

    @Column(name = "isActiv")
    private boolean isActive;

    @Column(name = "DateValid")
    private Date dateValid;
}
