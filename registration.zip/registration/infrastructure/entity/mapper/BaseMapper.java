package kz.eubank.registration.infrastructure.entity.mapper;

import kz.eubank.registration.domain.model.pojo.*;
import kz.eubank.registration.domain.model.pojo.view.AttemptsLimitView;
import kz.eubank.registration.domain.model.pojo.view.UserDefineRouteView;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface BaseMapper {

    BaseMapper INSTANCE = Mappers.getMapper(BaseMapper.class);

    AttemptsLimitView toDomain(kz.eubank.registration.infrastructure.entity.view.AttemptsLimitView entity);

    UserDefineRouteView toDomain(kz.eubank.registration.infrastructure.entity.view.UserDefineRouteView entity);

    DMZVerification toDomain(kz.eubank.registration.infrastructure.entity.DMZVerification entity);

    DMZVerificationAttempts toDomain(kz.eubank.registration.infrastructure.entity.DMZVerificationAttempts entity);

    DMZVerificationOtp toDomain(kz.eubank.registration.infrastructure.entity.DMZVerificationOtp entity);

    OtpStatus toDomain(kz.eubank.registration.infrastructure.entity.OtpStatus entity);

    Passcode toDomain(kz.eubank.registration.infrastructure.entity.Passcode entity);

    PasscodeStatus toDomain(kz.eubank.registration.infrastructure.entity.PasscodeStatus entity);

    RouteStatus toDomain(kz.eubank.registration.infrastructure.entity.RouteStatus entity);

    RouteType toDomain(kz.eubank.registration.infrastructure.entity.RouteType entity);

    WhiteListAuthorization toDomain(kz.eubank.registration.infrastructure.entity.WhiteListAuthorization entity);

    kz.eubank.registration.infrastructure.entity.view.AttemptsLimitView toEntity(AttemptsLimitView domain);

    kz.eubank.registration.infrastructure.entity.view.UserDefineRouteView toEntity(UserDefineRouteView domain);

    kz.eubank.registration.infrastructure.entity.DMZVerification toEntity(DMZVerification domain);

    kz.eubank.registration.infrastructure.entity.DMZVerificationAttempts toEntity(DMZVerificationAttempts domain);

    kz.eubank.registration.infrastructure.entity.DMZVerificationOtp toEntity(DMZVerificationOtp domain);

    kz.eubank.registration.infrastructure.entity.OtpStatus toEntity(OtpStatus domain);

    kz.eubank.registration.infrastructure.entity.Passcode toEntity(Passcode domain);
    kz.eubank.registration.infrastructure.entity.NewPasscode toEntity(NewPasscode newPasscode);

    kz.eubank.registration.infrastructure.entity.PasscodeStatus toEntity(PasscodeStatus domain);

    kz.eubank.registration.infrastructure.entity.RouteStatus toEntity(RouteStatus domain);

    kz.eubank.registration.infrastructure.entity.RouteType toEntity(RouteType domain);

    kz.eubank.registration.infrastructure.entity.WhiteListAuthorization toEntity(WhiteListAuthorization domain);
}
