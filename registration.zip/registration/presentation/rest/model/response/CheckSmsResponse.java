package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckSmsResponse extends BaseResponseBody {

    public CheckSmsResponse(String nextStep) {
        super(nextStep);
    }
}
