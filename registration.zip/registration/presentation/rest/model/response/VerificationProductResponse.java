package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VerificationProductResponse extends BaseResponseBody {

    public VerificationProductResponse(String nextStep) {
        super(nextStep);
    }
}
