package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SendOtpDigitalDocumentResponse extends BaseResponseBody {

    public SendOtpDigitalDocumentResponse(String nextStep) {
        super(nextStep);
    }
}
