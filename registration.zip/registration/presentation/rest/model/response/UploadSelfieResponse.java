package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UploadSelfieResponse extends BaseResponseBody {

    public UploadSelfieResponse(String nextStep) {
        super(nextStep);
    }
}
