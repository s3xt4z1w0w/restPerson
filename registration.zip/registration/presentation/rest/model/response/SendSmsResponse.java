package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SendSmsResponse extends BaseResponseBody {

    public SendSmsResponse(String nextStep) {
        super(nextStep);
    }
}
