package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorTextResponse extends BaseResponseBody {

    private String title;
    private String description;
    private String buttonText;

    public ErrorTextResponse(String nextStep, String title, String description, String buttonText) {
        super(nextStep);
        this.title = title;
        this.description = description;
        this.buttonText = buttonText;
    }
}
