package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseResponseBody {

    private String nextStep;

    public BaseResponseBody(String nextStep) {
        this.nextStep = nextStep;
    }
}
