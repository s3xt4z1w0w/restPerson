package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UploadDigitalDocumentResponse extends BaseResponseBody {

    public UploadDigitalDocumentResponse(String nextStep) {
        super(nextStep);
    }
}
