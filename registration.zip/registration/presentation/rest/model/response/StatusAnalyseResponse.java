package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatusAnalyseResponse extends BaseResponseBody {

    public StatusAnalyseResponse(String nextStep) {
        super(nextStep);
    }
}
