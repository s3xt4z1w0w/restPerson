package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VerificationBirthDateResponse extends BaseResponseBody {

    public VerificationBirthDateResponse(String nextStep) {
        super(nextStep);
    }
}
