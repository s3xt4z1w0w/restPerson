package kz.eubank.registration.presentation.rest.exception;

public enum SelfErrorCode {

    E_VD_400("error.validate.annotation_validate"),                     //ANNOTATION 400-499

    E_SM_500("error.system.json-to-object"),                            //SYSTEM 500-599
    E_SM_501("error.system.object-to-json"),

    E_DB_600("error.db.object-not-found"),                              //DB 600-699
    E_DB_601("error.db.result-more-than-expect"),
    E_DB_602("error.db.exec.procedure"),
    E_DB_603("error.incorrect.field"),

    E_EX_700("error.external.response-error"),                          //EXTERNAL 700-799
    E_EX_701("error.external.system-not-available"),

    E_LG_800("error.logical.file-is-not-complete"),                     //LOGICAL 800-899
    E_LG_801("error.logical.data-is-not-correct"),

    E_BS_901("error.business.limit-exceeded");                                     //BUSINESS 900-999

    private final String message;

    SelfErrorCode(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
