package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.ISmsExecution;
import kz.eubank.registration.presentation.rest.model.response.APIResponse;
import kz.eubank.registration.presentation.rest.model.response.CheckSmsResponse;
import kz.eubank.registration.presentation.rest.model.response.SendSmsResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("sms")
@RequiredArgsConstructor
@Tag(name = "СМС", description = "SmsController")
public class SmsController {

    private final ISmsExecution execution;

    @Operation(summary = "Отправка СМС", description = "sendSms")
    @PostMapping("send")
    public ResponseEntity<?> sendSms(@RequestHeader("User-Agent") String userAgent,
                                     @RequestHeader String language,
                                     @RequestHeader String authorization) {
        var result = execution.sendSms(authorization);
        return new ResponseEntity<>(new SendSmsResponse("CheckSms"), OK);
    }

    @Operation(summary = "Проверка СМС", description = "checkSms")
    @Parameters({
            @Parameter(name = "code", description = "code", required = true)
    })
    @PostMapping("check")
    public APIResponse<Object> checkSms(@RequestHeader("User-Agent") String userAgent,
                                                   @RequestHeader String language,
                                                   @RequestHeader String authorization,
                                                   @RequestBody String code) {

        return execution.checkSms(authorization, code);
    }
}
