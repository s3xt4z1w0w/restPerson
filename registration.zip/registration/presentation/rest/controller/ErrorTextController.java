package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.presentation.rest.model.response.ErrorTextResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("errorText")
@RequiredArgsConstructor
@Tag(name = "Ошибки", description = "ErrorTextController")
public class ErrorTextController {

    @Operation(summary = "Получение ошибки", description = "getErrorText")
    @GetMapping
    public ResponseEntity<?> getErrorText(@RequestHeader("User-Agent") String userAgent,
                                          @RequestHeader String language,
                                          @RequestHeader String authorization) {
        var result =
                new ErrorTextResponse("DefineRoute", "Title", "Description", "Main Page");
        return new ResponseEntity<>(result, OK);
    }
}
