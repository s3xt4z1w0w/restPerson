package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.presentation.rest.model.response.Document;
import kz.eubank.registration.presentation.rest.model.response.DocumentListResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("documentList")
@RequiredArgsConstructor
@Tag(name = "Список документов", description = "DocumentListController")
public class DocumentListController {

    @Operation(summary = "Получение документов", description = "getDocumentList")
    @GetMapping
    public ResponseEntity<?> getDocumentList(@RequestHeader("User-Agent") String userAgent,
                                             @RequestHeader String language,
                                             @RequestHeader String authorization) {
        var docList =
                List.of(new Document("docName", "docType", "base64", "formatBase64"),
                        new Document("docName2", "docType2", "base64", "formatBase64"));
        return new ResponseEntity<>(new DocumentListResponse(docList), OK);
    }
}
