package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.VerificationBirthDateResponse;
import kz.eubank.registration.presentation.rest.model.response.VerificationIINResponse;
import kz.eubank.registration.presentation.rest.model.response.VerificationProductResponse;

import java.util.Date;

public interface IVerificationExecution {

    VerificationIINResponse verificationIIN(String sessionId, String iin);

    VerificationBirthDateResponse verificationBirthDate(String sessionId, Date birthDate);

    VerificationProductResponse verificationProduct(String sessionId, String iin, String productNumber);
}
