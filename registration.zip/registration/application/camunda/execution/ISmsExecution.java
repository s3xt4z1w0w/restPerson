package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.APIResponse;
import kz.eubank.registration.presentation.rest.model.response.BaseResponseBody;
import kz.eubank.registration.presentation.rest.model.response.CheckSmsResponse;
import kz.eubank.registration.presentation.rest.model.response.SendSmsResponse;

public interface ISmsExecution {

    SendSmsResponse sendSms(String sessionId);

    APIResponse<Object> checkSms(String sessionId, String code);
}
