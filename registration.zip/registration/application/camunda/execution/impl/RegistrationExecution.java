package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IRegistrationExecution;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import kz.eubank.registration.presentation.rest.model.response.APIResponse;
import kz.eubank.registration.presentation.rest.model.response.DefineRouteResponse;
import kz.eubank.registration.presentation.rest.util.Element2StepUtil;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class RegistrationExecution implements IRegistrationExecution {

    private final ProcessEngine engine;

    @Override
    public APIResponse<Object> defineRoute(String phoneNumber, String deviceId) {
        APIResponse<Object> response = new APIResponse<>();
        System.out.println("Synchronize request start");
        var process = engine.getRuntimeService()
                .createProcessInstanceByKey("registrationa")
                .setVariable("phoneNumber", phoneNumber)
                .setVariable("deviceId", deviceId)
                //TODO get versionFront and frontEnd
                .setVariable("versionFront", "1.0.344.735")
                .setVariable("frontEnd", "ANDP")
                .executeWithVariablesInReturn();
        System.out.println("Synchronize request end");
        var sessionId = (String) process.getVariables().get("sessionId");
        System.out.println("sessionId: " + sessionId);

        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getName();
        System.out.println(taskDefinitionKey);
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
        return response.successResponse(new DefineRouteResponse(taskDefinitionKey, sessionId));
    }
}
