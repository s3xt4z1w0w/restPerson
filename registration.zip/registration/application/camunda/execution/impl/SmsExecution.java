package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.ISmsExecution;
import kz.eubank.registration.presentation.rest.exception.ErrorDto;
import kz.eubank.registration.presentation.rest.model.response.*;
import kz.eubank.registration.presentation.rest.util.Element2StepUtil;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class SmsExecution implements ISmsExecution {

    private final ProcessEngine engine;

    @Override
    public SendSmsResponse sendSms(String sessionId) {
        var task = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult();
        engine.getTaskService().complete(task.getId());
        var generatedCode = engine.getRuntimeService()
                .getVariable(task.getExecutionId(), "generatedCode");

        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getTaskDefinitionKey();
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
        return new SendSmsResponse(nextStep);
    }

    @Override
    public APIResponse<Object> checkSms(String sessionId, String code) {
        APIResponse<Object> objectAPIResponse = new APIResponse<>();
        var task = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult();
        engine.getRuntimeService().setVariable(task.getExecutionId(), "clientCode", code);
        engine.getTaskService().complete(task.getId());
        Map<String, Object> test = new HashMap<>();
        //test.put("ClientCode", code);
        //var check = engine.getTaskService().completeWithVariablesInReturn(task.getId(), null, false);
        var isSmsChecked = (boolean) engine.getRuntimeService().getVariable(task.getExecutionId(), "isSmsChecked");
        var count = (int) engine.getRuntimeService().getVariable(task.getExecutionId(), "count");
        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getTaskDefinitionKey();
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
       // int countInt = Integer.parseInt(count);
        System.out.println(isSmsChecked);
        //System.out.println("isSmsChecked: " + test1);
        System.out.println("count: "+count);
        if (isSmsChecked) {
            return objectAPIResponse.successResponse(new CheckSmsResponse(nextStep));
        } else if (count > 4) {
            return objectAPIResponse.errorResponse("FAILED", "you many many time used abyzer: " + count);
        } else {
            return objectAPIResponse.errorResponse("FAILED", "you idiot not correct input code: " + count);
        }
    }
}
