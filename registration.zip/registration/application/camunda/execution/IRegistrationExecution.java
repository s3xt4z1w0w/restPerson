package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.APIResponse;
import kz.eubank.registration.presentation.rest.model.response.DefineRouteResponse;

public interface IRegistrationExecution {

    APIResponse<Object> defineRoute(String phoneNumber, String deviceId);
}
