package kz.eubank.registration.application.camunda.execution;

public interface IPasscodeExecution {

    Boolean createPasscode(String sessionId, String passcode);
}
