package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.domain.service.IRegistrationService;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DefineRouteDelegate implements JavaDelegate {

    private final IRegistrationService registrationService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var phoneNumber = (String) execution.getVariable("phoneNumber");
        System.out.println("Synchronize request half");
        execution.setVariables(registrationService.defineRoute(phoneNumber));
        if (execution.getVariable("error") != null) {
            throw new BpmnError((String) execution.getVariable("error"));
        }
    }
}
