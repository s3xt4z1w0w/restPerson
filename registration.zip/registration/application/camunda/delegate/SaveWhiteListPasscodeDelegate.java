package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.domain.model.dto.WhiteListAuthorizationDto;
import kz.eubank.registration.domain.service.IPasscodeService;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SaveWhiteListPasscodeDelegate implements JavaDelegate {
    private final IPasscodeService passcodeService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var route = execution.getVariable("currentRoute");
        var whiteList = (WhiteListAuthorizationDto) execution.getVariable("whiteList");
        var deviceId = (String) execution.getVariable("deviceId");
        execution.setVariable("route", route);

        passcodeService.saveWhiteListPasscode(whiteList, deviceId);
    }
}
