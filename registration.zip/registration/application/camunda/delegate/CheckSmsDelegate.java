package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.domain.service.ISmsService;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CheckSmsDelegate implements JavaDelegate {

    private final ISmsService smsService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var clientCode = (String) execution.getVariable("clientCode");
        var sessionId = (String) execution.getVariable("sessionId");
        var count = execution.getVariable("count");
        if (count == null) {
            count = "0";
        }
        int countInt;
        if (count instanceof String) {
            countInt = Integer.parseInt((String) count);
        } else {
            countInt = (int) count;
        }

        execution.setVariables(smsService.checkSms(sessionId, clientCode, countInt));
    }
}
