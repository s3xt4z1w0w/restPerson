package kz.smart.core.pushworker.andorid;

import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.auth.oauth2.AccessToken;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ExecutorService;

@Service
public class FCMInitializer {

    @Value("${app.firebase-configuration-file}")
    private String firebaseConfigPath;

    @Value("${app.proxy.host}")
    private String HOST;

    @Value("${app.proxy.port}")
    private int PORT;

    private GoogleCredentials googleCred;
    private final Logger logger = LoggerFactory.getLogger(FCMInitializer.class);
    private final ExecutorService executorService = Executors.newVirtualThreadPerTaskExecutor();

    @PostConstruct
    public void initFirebase() throws IOException {
        Authenticator.setDefault(new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("alibek", "s3xt4z1".toCharArray());
            }
        });
        System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");

        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(HOST, PORT));
        HttpTransport httpTransport = new NetHttpTransport.Builder().setProxy(proxy).build();

        googleCred = GoogleCredentials.fromStream(new ClassPathResource(firebaseConfigPath).getInputStream())
                .createScoped(Arrays.asList(
                        "https://www.googleapis.com/auth/firebase.database",
                        "https://www.googleapis.com/auth/userinfo.email"
                ));

        FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(googleCred)
                .setHttpTransport(httpTransport)
                .build();

        if (FirebaseApp.getApps().isEmpty()) {
            FirebaseApp.initializeApp(options);
        }
    }

    public void sendMessageToToken(NotificationRequest request) {
        executorService.submit(() -> {
            try {
                refreshTokenIfExpired();

                Message message = Message.builder()
                        .setToken(request.getToken())
                        .setNotification(Notification.builder()
                                .setTitle(request.getTitle())
                                .setBody(request.getBody())
                                .build())
                        .build();

                String response = FirebaseMessaging.getInstance().sendAsync(message).get();
                System.out.println("Successfully sent message: " + response);
            } catch (IOException | ExecutionException | InterruptedException e) {
                logger.error("Failed to send message due to authentication error", e);
                throw new RuntimeException("Failed to send message due to authentication error", e);
            }
        });
    }

    private void refreshTokenIfExpired() throws IOException {
        AccessToken token = googleCred.getAccessToken();
        if (token == null || token.getExpirationTime().getTime() <= System.currentTimeMillis()) {
            googleCred.refreshIfExpired();
            token = googleCred.getAccessToken();
            logger.info("New token: " + token.getTokenValue());
        }
    }
}
