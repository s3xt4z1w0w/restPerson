package com.example.pushnotification.application.controller;

import com.eatthepath.pushy.apns.ApnsClient;
import com.eatthepath.pushy.apns.ApnsClientBuilder;
import com.eatthepath.pushy.apns.PushNotificationResponse;
import com.eatthepath.pushy.apns.util.SimpleApnsPushNotification;
import com.eatthepath.pushy.apns.util.TokenUtil;
import com.google.auth.oauth2.AccessToken;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

@RestController
@RequestMapping("/api/push")
public class PushController {

    @PostMapping("send")
    public ResponseEntity<?> sendPush(@RequestBody SendPushRequest sendPushRequest) {
        try {
            FileInputStream serviceAccountStream = new FileInputStream("C:\\Users\\reolitic\\Desktop\\work\\PushNotification\\src\\main\\resources\\new-smartbank-firebase-adminsdk-xwn0e-13780cd4e4.json");
            GoogleCredentials credentials = ServiceAccountCredentials.fromStream(serviceAccountStream)
                    .createScoped(Collections.singleton("https://www.googleapis.com/auth/firebase.messaging"));

            // Обновите токен доступа
            credentials.refreshIfExpired();
            AccessToken token = credentials.getAccessToken();

            // Выведите JWT токен
            System.out.println("JWT token: " + token.getTokenValue());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("sendIos")
    public ResponseEntity<?> sendIos() throws IOException {
        String certPath = "C:\\Users\\reolitic\\Desktop\\work\\PushNotification\\src\\main\\resources\\DevPush.p12";
        String bundleId = "com.tallium.eubank.smartbank";
        String deviceToken = "9d6bb7da3463cbf46a23039653baae39ed77d89e31d69e7551efe0ea0738150a";

        ApnsClient apnsClient = new ApnsClientBuilder()
                .setApnsServer(ApnsClientBuilder.DEVELOPMENT_APNS_HOST) // Для production
                .setClientCredentials(new File(certPath),"")
                .build();

        String payload = "{\"aps\":{\"alert\":\"Hello, world!\"}}";

        SimpleApnsPushNotification pushNotification = new SimpleApnsPushNotification(
                TokenUtil.sanitizeTokenString(deviceToken), bundleId, payload);

        Future<PushNotificationResponse<SimpleApnsPushNotification>> sendNotificationFuture =
                apnsClient.sendNotification(pushNotification);

        try {
            PushNotificationResponse<SimpleApnsPushNotification> pushNotificationResponse =
                    sendNotificationFuture.get();

            if (pushNotificationResponse.isAccepted()) {
                System.out.println("Push notification accepted by APNs gateway.");
            } else {
                System.out.println("Notification rejected by the APNs gateway: " +
                        pushNotificationResponse.getRejectionReason());

                if (pushNotificationResponse.getTokenInvalidationTimestamp() != null) {
                    System.out.println("\t…and the token is invalid as of " +
                            pushNotificationResponse.getTokenInvalidationTimestamp());
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            System.err.println("Failed to send push notification.");
            e.printStackTrace();
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

}

