package com.example.pushnotification.application.controller;

public record DeviceTokenRequest(Long userId,
                                 String token,
                                 String deviceSerial,
                                 String deviceModel,
                                 String osVersion,
                                 String appVersion) {
}
