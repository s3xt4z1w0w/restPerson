package com.example.pushnotification.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/device-tokens")
public class DeviceTokenController {


    @PostMapping
    public ResponseEntity<?> saveToken(@RequestBody DeviceTokenRequest request) {
        System.out.println(request);
//        deviceTokenService.saveOrUpdateToken(request.getUserId(), request.getToken());
        return ResponseEntity.ok("Token saved or updated");
    }
}

