package com.example.pushnotification.application.controller;

public record SendPushRequest(String deviceToken, String message) {
}
