package com.example.pushnotification.redis;

import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class RedisKeyExpirationListener {

    @Bean
    RedisMessageListenerContainer keyExpirationListenerContainer(RedisConnectionFactory connectionFactory) {
        RedisMessageListenerContainer listenerContainer = new RedisMessageListenerContainer();
        listenerContainer.setConnectionFactory(connectionFactory);
        listenerContainer.addMessageListener(messageListener(), new PatternTopic("__keyevent@1__:expired"));
        return listenerContainer;
    }

    @Bean
    MessageListenerAdapter messageListener() {
        return new MessageListenerAdapter(new RedisKeyExpirationMessageListener());
    }

    private class RedisKeyExpirationMessageListener implements MessageListener {
        @Override
        public void onMessage(Message message, byte[] pattern) {
            String expiredKey = message.toString();
            if (expiredKey.startsWith("push:card:balance:")) { // Проверка ключа на соответствие шаблону
                System.out.println("Expired key: " + expiredKey);
                // Здесь добавьте логику для обработки истекшего ключа, например, отправка сообщения через другой канал
            }
        }
    }
}
