package eub.loans.fistools.jsmintegration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class RequestObj {
    @JsonProperty("person")
    private ClientModel person;
    @JsonProperty("application")
    private Application application;
    @JsonProperty("loan")
    private Loan loan;
    @JsonProperty("dealer")
    private Dealer dealer;
    @JsonProperty("tariff")
    private String tariff;
    @JsonProperty("selectedRates")
    private List<SelectedRate> selectedRates;
    @JsonProperty("additionalServices")
    private List <AdditionalServices> additionalServices;
    @JsonProperty("insurance")
    private List <Insurance> insurances;
    @JsonProperty("soborrows")
    private List <ClientModel> soborrows;
    @JsonProperty("spouse")
    private ClientModel spouse;

    public ClientModel getPerson() {
        return person;
    }

    public void setPerson(ClientModel person) {
        this.person = person;
    }

    public Application getApplication() {
        return application;
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public Dealer getDealer() {
        return dealer;
    }

    public void setDealer(Dealer dealer) {
        this.dealer = dealer;
    }

    public String getTariff() {
        return tariff;
    }

    public void setTariff(String tariff) {
        this.tariff = tariff;
    }

    public List<SelectedRate> getSelectedRates() {
        return selectedRates;
    }

    public void setSelectedRates(List<SelectedRate> selectedRates) {
        this.selectedRates = selectedRates;
    }

    public List<AdditionalServices> getAdditionalServices() {
        return additionalServices;
    }

    public void setAdditionalServices(List<AdditionalServices> additionalServices) {
        this.additionalServices = additionalServices;
    }

    public List<Insurance> getInsurances() {
        return insurances;
    }

    public void setInsurances(List<Insurance> insurances) {
        this.insurances = insurances;
    }

    public List<ClientModel> getSoborrows() {
        return soborrows;
    }

    public void setSoborrows(List<ClientModel> soborrows) {
        this.soborrows = soborrows;
    }

    public ClientModel getSpouse() {
        return spouse;
    }

    public void setSpouse(ClientModel spouse) {
        this.spouse = spouse;
    }



}
