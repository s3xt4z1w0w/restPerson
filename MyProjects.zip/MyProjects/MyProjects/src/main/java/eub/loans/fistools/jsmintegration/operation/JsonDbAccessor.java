package eub.loans.fistools.jsmintegration.operation;

import java.sql.*;
import java.util.ArrayList;

public class JsonDbAccessor {
    public static final String URL = "${spring.datasource.url}";
    public static final String USER = "${spring.datasource.username}";  // Замените на ваше имя пользователя PostgreSQL
    public static final String PASSWORD = "${spring.datasource.password}";  // Замените на ваш пароль PostgreSQL
    private  Connection connection;
    public JsonDbAccessor() throws SQLException {
        connect();
    }

    private void connect() throws SQLException {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public  String[] getJSON() throws SQLException {
        ArrayList <String> JSONlist = new ArrayList<>();

        String query = "SELECT * FROM w5b_test_jdbc WHERE status_export = 'new'";
        try (
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query)
        ) {
            while (resultSet.next()) {
                JSONlist.add(resultSet.getString("json_text"));

            }
        }

        String[] JSONarr = (String[]) JSONlist.toArray(new String[JSONlist.size()]);
        return JSONarr;
    }
    public void setPosted() throws SQLException {
        String query = "UPDATE w5b_test_jdbc SET status_export = 'Posted' WHERE status_export = 'new'";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            int rowsUpdated = statement.executeUpdate();
        }
    }

    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

//
}
