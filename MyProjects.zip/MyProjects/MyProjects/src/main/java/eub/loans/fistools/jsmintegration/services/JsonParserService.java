package eub.loans.fistools.jsmintegration.services;

import eub.loans.fistools.jsmintegration.model.*;
import eub.loans.fistools.jsmintegration.operation.*;
import org.springframework.stereotype.Service;

import java.sql.SQLException;

@Service
public class JsonParserService {
    private final JSMLogging jsmLogging;
    private final UpdateFIS updateFIS;

    public JsonParserService(JSMLogging jsmLogging, UpdateFIS updateFIS) {
        this.jsmLogging = jsmLogging;
        this.updateFIS = updateFIS;
    }

    public void parseJson(String json) throws SQLException {
        System.out.println(json);
        String jsmId = jsmLogging.getJSONS(json);
        RequestObj req = RequestParsing.getRequest(json);;
        updateFIS.setUpdate(req );
        jsmLogging.setPosted(jsmId);
//        updateFIS.close();
    }
}
