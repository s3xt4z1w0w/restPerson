package eub.loans.fistools.jsmintegration.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.sql.SQLException;

@Service
public class KafkaConsumerService {
    private final JsonParserService jsonParserService;
    @Autowired
    public KafkaConsumerService(
        JsonParserService jsonParserService
    ) {
        this.jsonParserService = jsonParserService;
    }

    @KafkaListener(
        topics = "${kafka.topic.name}",
        groupId = "${spring.kafka.consumer.group-id}"
    )
    public void consume(String message) throws SQLException {
        jsonParserService.parseJson(message);           //todo название метода не очевидна))) под капотом транзакция в БД и запись в еще один БД а название невинное...)
    }
}
