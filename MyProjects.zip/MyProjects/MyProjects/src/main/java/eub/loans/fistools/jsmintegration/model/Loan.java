package eub.loans.fistools.jsmintegration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Loan {
    @JsonProperty("repaymentMethod")
    private String repaymentMethod;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("paymentDay")
    private String paymentDay;
    @JsonProperty("term")
    private int term;
    @JsonProperty("monthlyPayment")
    private double monthlyPayment;
    @JsonProperty("loanAmount")
    private double loanAmount;
    @JsonProperty("loanAmountWithInsurance")
    private double loanAmountWithInsurance;
    @JsonProperty("loanType")
    private String loanType;

    public String getRepaymentMethod() {
        return repaymentMethod;
    }

    public void setRepaymentMethod(String repaymentMethod) {
        this.repaymentMethod = repaymentMethod;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPaymentDay() {
        return paymentDay;
    }

    public void setPaymentDay(String paymentDay) {
        this.paymentDay = paymentDay;
    }

    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }

    public double getMonthlyPayment() {
        return monthlyPayment;
    }

    public void setMonthlyPayment(double monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public double getLoanAmountWithInsurance() {
        return loanAmountWithInsurance;
    }

    public void setLoanAmountWithInsurance(double loanAmountWithInsurance) {
        this.loanAmountWithInsurance = loanAmountWithInsurance;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    @Override
    public String toString() {
        return "Loan{" +
                "repaymentMethod='" + repaymentMethod + '\'' +
                ", currency='" + currency + '\'' +
                ", paymentDay='" + paymentDay + '\'' +
                ", term=" + term +
                ", monthlyPayment=" + monthlyPayment +
                ", loanAmount=" + loanAmount +
                ", loanAmountWithInsurance=" + loanAmountWithInsurance +
                ", loanType='" + loanType + '\'' +
                '}';
    }
}
