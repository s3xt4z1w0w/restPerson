package eub.loans.fistools.jsmintegration.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Application {
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;
    @JsonProperty("firstPaymentDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate firstPaymentDate;
    @JsonProperty("financeDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate financeDate;
    private String financialConsultant;
    @JsonProperty("loanNumber")
    private String applicationNumber;
    @JsonProperty("applicationNumber")
    private String loanNumber;
    @JsonProperty("rsId")
    private String rsIdentificator;
    @JsonProperty("fullLoanAmount")
    private double fullLoanAmount;
    @JsonProperty("term")
    private int term;
    @JsonProperty("monthlyPayment")
    private double monthlyPayment;
    @JsonProperty("repaymentScheduleType")
    private String repaymentScheduleType;
    @JsonProperty("repaymentMethod")
    private String repaymentMethod;
    @JsonProperty("loanType")
    private String loanType;
    @JsonProperty("status")
    private String status;

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDate getFirstPaymentDate() {
        return firstPaymentDate;
    }

    public void setFirstPaymentDate(LocalDate firstPaymentDate) {
        this.firstPaymentDate = firstPaymentDate;
    }

    public LocalDate getFinanceDate() {
        return financeDate;
    }

    public void setFinanceDate(LocalDate financeDate) {
        this.financeDate = financeDate;
    }

    public String getFinancialConsultant() {
        return financialConsultant;
    }

    public void setFinancialConsultant(String financialConsultant) {
        this.financialConsultant = financialConsultant;
    }

    public String getApplicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(String applicationNumber) {
        this.applicationNumber = applicationNumber;
    }

    public String getRsIdentificator() {
        return rsIdentificator;
    }

    public void setRsIdentificator(String rsIdentificator) {
        this.rsIdentificator = rsIdentificator;
    }

    public double getFullLoanAmount() {
        return fullLoanAmount;
    }

    public void setFullLoanAmount(double fullLoanAmount) {
        this.fullLoanAmount = fullLoanAmount;
    }

    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }

    public double getMonthlyPayment() {
        return monthlyPayment;
    }

    public void setMonthlyPayment(double monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

    public String getRepaymentScheduleType() {
        return repaymentScheduleType;
    }

    public void setRepaymentScheduleType(String repaymentScheduleType) {
        this.repaymentScheduleType = repaymentScheduleType;
    }

    public String getRepaymentMethod() {
        return repaymentMethod;
    }

    public void setRepaymentMethod(String repaymentMethod) {
        this.repaymentMethod = repaymentMethod;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLoanNumber() {
        return loanNumber;
    }

    public void setLoanNumber(String loanNumber) {
        this.loanNumber = loanNumber;
    }

    @Override
    public String toString() {
        return "Application{" +
                "createdAt=" + createdAt +
                ", firstPaymentDate=" + firstPaymentDate +
                ", financeDate=" + financeDate +
                ", financialConsultant='" + financialConsultant + '\'' +
                ", applicationNumber='" + applicationNumber + '\'' +
                ", rsIdentificator='" + rsIdentificator + '\'' +
                ", fullLoanAmount=" + fullLoanAmount +
                ", term=" + term +
                ", monthlyPayment=" + monthlyPayment +
                ", repaymentScheduleType='" + repaymentScheduleType + '\'' +
                ", repaymentMethod='" + repaymentMethod + '\'' +
                ", loanType='" + loanType + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
