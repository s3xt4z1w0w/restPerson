package eub.loans.fistools.jsmintegration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Dealer {
    @JsonProperty("name")
    private String name;
    @JsonProperty("bin")
    private String bin;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    @Override
    public String toString() {
        return "Dealer{" +
                "name='" + name + '\'' +
                ", bin='" + bin + '\'' +
                '}';
    }
}
