
package eub.loans.fistools.jsmintegration.operation;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.*;

@Component
public class JSMLogging {

    @Value("${spring.datasource.url}")
    private  String URL;

    @Value("${spring.datasource.username}")
    private  String USER;

    @Value("${spring.datasource.password}")
    private  String PASSWORD;
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }


    public String getJSONS (String json) throws SQLException {
        try {
            String insertQuery = "INSERT INTO f5t_jsm_logging (json_text, status, createddate) VALUES (?, ?, CURRENT_TIMESTAMP) RETURNING id";
            try (PreparedStatement statement = getConnection().prepareStatement(insertQuery)) {
                statement.setString(1, json);
                statement.setString(2, "new");
                ResultSet rs = statement.executeQuery();
                if (rs.next()) {
                    return rs.getString("id");

                } else {
                    throw new SQLException("Failed to insert LOGGING.");
                }
            }
        } catch (SQLException err) {
            err.printStackTrace();
            throw new SQLException(err);
        }
    }
    public void setPosted (String logId) {
        String updateQuery = "UPDATE f5t_jsm_logging SET status = ? WHERE id = ?";
        try (PreparedStatement statement = getConnection().prepareStatement(updateQuery)) {
            statement.setString(1, "Posted");
            statement.setString(2, logId);
            statement.executeUpdate();
        } catch (SQLException err) {
            err.printStackTrace();
        }
    }
}
