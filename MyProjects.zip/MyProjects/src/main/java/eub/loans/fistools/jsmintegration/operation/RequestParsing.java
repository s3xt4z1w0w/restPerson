package eub.loans.fistools.jsmintegration.operation;

import com.fasterxml.jackson.databind.ObjectMapper;
import eub.loans.fistools.jsmintegration.model.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;


public class RequestParsing {
    public static RequestObj getRequest (String s) throws JSONException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();
        RequestObj req = new RequestObj();
        try {
            req = objectMapper.readValue(s, RequestObj.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return req;
    }

    public static String getJSONFromFile (String filePath) throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line);
            }
        }
        return content.toString();
    }

}
