package eub.loans.fistools.jsmintegration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Address {
    /**
     *                 "AddressType": "адрес_регистрации",
     *                 "country" : " Республика Казахстан",
     *                 "postCode" : "040000",
     *                 "Region": " Алматинская область",
     *                 "regionType" : "область_область",
     *                 "regionCode" : "614837103",
     *                 "District": "Илийский район",
     *                 "districtType" :"район_район",
     *                 "districtCode" : "614837103",
     *                 "City": "Каскелен",
     *                 "citytype" : "населенный_пункт_город",
     *                 "cityCode" : "614837103",
     *                 "StreetType": "бульвар",
     *                 "Street": "Абылайхан",
     *                 "HouseNumber": "55",
     *                 "Apartment": "1"
     */
    @JsonProperty("addressType")
    private String addresstype;
    @JsonProperty("country")
    private String country;
    @JsonProperty("postCode")
    private String postCode;
    @JsonProperty("region")
    private String region;
    @JsonProperty("regionType")
    private String regionType;
    @JsonProperty("regionCode")
    private String regionCode;
    @JsonProperty("district")
    private String district;
    @JsonProperty("districtType")
    private String districtType;
    @JsonProperty("districtCode")
    private String districtCode;
    @JsonProperty("city")
    private String city;
    @JsonProperty("cityType")
    private String cityType;
    @JsonProperty("cityCode")
    private String cityCode;
    @JsonProperty("streetType")
    private String streetType;
    @JsonProperty("street")
    private String street;
    @JsonProperty("houseNumber")
    private String houseNumber;
    @JsonProperty("apartment")
    private String apartmentNumber;

    public String getAddresstype() {
        return addresstype;
    }

    public void setAddresstype(String addresstype) {
        this.addresstype = addresstype;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getRegionType() {
        return regionType;
    }

    public void setRegionType(String regionType) {
        this.regionType = regionType;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getDistrictType() {
        return districtType;
    }

    public void setDistrictType(String districtType) {
        this.districtType = districtType;
    }

    public String getDistrictCode() {
        return districtCode;
    }

    public void setDistrictCode(String districtCode) {
        this.districtCode = districtCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityType() {
        return cityType;
    }

    public void setCityType(String cityType) {
        this.cityType = cityType;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getStreetType() {
        return streetType;
    }

    public void setStreetType(String streetType) {
        this.streetType = streetType;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getApartmentNumber() {
        return apartmentNumber;
    }

    public void setApartmentNumber(String apartmentNumber) {
        this.apartmentNumber = apartmentNumber;
    }

    @Override
    public String toString() {
        return "Address{" +
                "addresstype='" + addresstype + '\'' +
                ", country='" + country + '\'' +
                ", postCode='" + postCode + '\'' +
                ", region='" + region + '\'' +
                ", regionType='" + regionType + '\'' +
                ", regionCode='" + regionCode + '\'' +
                ", district='" + district + '\'' +
                ", districtType='" + districtType + '\'' +
                ", districtCode='" + districtCode + '\'' +
                ", city='" + city + '\'' +
                ", cityType='" + cityType + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", streetType='" + streetType + '\'' +
                ", street='" + street + '\'' +
                ", houseNumber='" + houseNumber + '\'' +
                ", apartmentNumber='" + apartmentNumber + '\'' +
                '}';
    }
}
