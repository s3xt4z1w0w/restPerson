package eub.loans.fistools.jsmintegration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AdditionalServices {
    /**
     *             "code": "0", // Код страховки в Core Системе
     *             "amount": 1154250, // Сумма страховки
     *             "partnerComission": 2000 // Комиссия партнера за страховку
     */

    @JsonProperty("code")
    private String code;
    @JsonProperty("amount")
    private int amount;
    @JsonProperty("partnerComission")
    private int partnerComission;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getPartnerComission() {
        return partnerComission;
    }

    public void setPartnerComission(int partnerComission) {
        this.partnerComission = partnerComission;
    }

    @Override
    public String toString() {
        return "AdditionalServices{" +
                "code='" + code + '\'' +
                ", amount=" + amount +
                ", partnerComission=" + partnerComission +
                '}';
    }
}
