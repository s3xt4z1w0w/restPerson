package eub.loans.fistools.jsmintegration.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientModel {
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleName")
    private String fatherName;
    @JsonProperty("iin")
    private String iin;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("maritalStatus")
    private String maritalStatus;
    @JsonProperty("children")
    private int childrensCount;
    @JsonProperty("dependents")
    private int dependentsCount;
    @JsonProperty("birthDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate birthDate;
    @JsonProperty("resident")
    private boolean isResident;
    @JsonProperty("rezidenceCountry")
    private String residenceCountry;
    @JsonProperty("citizenship")
    private String citizenshipCountry;
    @JsonProperty("birthCountry")
    private String birthCountry;
    @JsonProperty("photo")
    private byte[] clientPhoto;
    @JsonProperty("language")
    private String speakLanguage;
    @JsonProperty("clientRSId")
    private String clientRSId;
    @JsonProperty("addresses")
    private List<Address> addresses;
    @JsonProperty("documents")
    private List <Documents> documents;
    @JsonProperty("contacts")
    private List <Contacts> contacts;


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public int getChildrensCount() {
        return childrensCount;
    }

    public void setChildrensCount(int childrensCount) {
        this.childrensCount = childrensCount;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public boolean isResident() {
        return isResident;
    }

    public void setResident(boolean resident) {
        isResident = resident;
    }

    public String getResidenceCountry() {
        return residenceCountry;
    }

    public void setResidenceCountry(String residenceCountry) {
        this.residenceCountry = residenceCountry;
    }

    public String getCitizenshipCountry() {
        return citizenshipCountry;
    }

    public void setCitizenshipCountry(String citizenshipCountry) {
        this.citizenshipCountry = citizenshipCountry;
    }

    public String getBirthCountry() {
        return birthCountry;
    }

    public void setBirthCountry(String birthCountry) {
        this.birthCountry = birthCountry;
    }

    public String getSpeakLanguage() {
        return speakLanguage;
    }

    public void setSpeakLanguage(String speakLanguage) {
        this.speakLanguage = speakLanguage;
    }

    public String getClientRSId() {
        return clientRSId;
    }

    public void setClientRSId(String clientRSId) {
        this.clientRSId = clientRSId;
    }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    public List<Documents> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Documents> documents) {
        this.documents = documents;
    }

    public List<Contacts> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contacts> contacts) {
        this.contacts = contacts;
    }

    public byte[] getClientPhoto() {
        return clientPhoto;
    }

    public void setClientPhoto(byte[] clientPhoto) {
        this.clientPhoto = clientPhoto;
    }
    public int getDependentsCount() {
        return dependentsCount;
    }

    public void setDependentsCount(int dependentsCount) {
        this.dependentsCount = dependentsCount;
    }
}

