package eub.loans.fistools.jsmintegration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Contacts {
    /**
     *                 "contactType" : "личный",
     *                 "devicetype" : "мобильный_телефон",
     *                 "contactValue" : "+77777777777",
     *                 "contactPerson" : "",
     *                 "relationType" : ""
     */
    @JsonProperty("contactType")
    private String contactType;
    @JsonProperty("deviceType")
    private String deviceType;
    @JsonProperty("contactValue")
    private String contactValue;
    @JsonProperty("contactPerson")
    private String contactPerson;
    @JsonProperty("relationType")
    private String relationType;

    public String getContactType() {
        return contactType;
    }

    public void setContactType(String contactType) {
        this.contactType = contactType;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getContactValue() {
        return contactValue;
    }

    public void setContactValue(String contactValue) {
        this.contactValue = contactValue;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getRelationType() {
        return relationType;
    }

    public void setRelationType(String relationType) {
        this.relationType = relationType;
    }

    @Override
    public String toString() {
        return "Contacts{" +
                "contactType='" + contactType + '\'' +
                ", deviceType='" + deviceType + '\'' +
                ", contactValue='" + contactValue + '\'' +
                ", contactPerson='" + contactPerson + '\'' +
                ", relationType='" + relationType + '\'' +
                '}';
    }
}
