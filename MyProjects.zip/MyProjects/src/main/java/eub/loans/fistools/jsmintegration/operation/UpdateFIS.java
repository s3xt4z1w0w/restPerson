package eub.loans.fistools.jsmintegration.operation;

import eub.loans.fistools.jsmintegration.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.List;


@Component
public class UpdateFIS {

    @Value("${spring.datasource.url}")
    private  String URL;
    @Value("${spring.datasource.username}")
    private  String USER;
    @Value("${spring.datasource.password}")
    private  String PASSWORD;  // Замените на ваш пароль PostgreSQL


    public void setUpdate (RequestObj req) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            connection.setAutoCommit(false);
            try {



                String personId = SetPerson(connection, req.getPerson());
                String AnketaId = setAnketa(connection, req.getPerson(), personId);
                setApplication(connection, req, personId, AnketaId);
                setImage(connection, req.getPerson(), personId, AnketaId);
                if (req.getSpouse() != null) setSpouseFL(connection, req.getSpouse(), personId, AnketaId);
                List <ClientModel> soborrows = req.getSoborrows();
                if (soborrows.size() > 0) {
                    for (ClientModel soborrow : soborrows) {
                        setSoborrow(connection, soborrow, AnketaId);
                    }
                }
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                System.out.println("Transaction rolled back due to error.");
                e.printStackTrace();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private String setAnketa(Connection connection, ClientModel person, String personId) throws SQLException {
        String query = "INSERT INTO f5t_anketa (" +
                "familija, " +
                "imja, " +
                "otchestvo, " +
                "iin, " +
                "pol, " +
                "fio, " +
                "data_rozhdenija, " +
                "createddate, " +
                "mesto_rozhdenija, " +
                "tip_ankety, " +
                "semejnoe_polozhenie, " +
                "kolichestvo_izhdivencev, " +
                "kolichestvo_detej, " +
                "strana_rezidentstva, " +
                "strana_rojdenija, " +
                "jazyk_obwenija, klient" +
                ") VALUES (" +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "CURRENT_TIMESTAMP, " +
                "?, " +
                "?, " +
                "?, ?, ?, (SELECT id FROM f5t_obwee_strana WHERE kod_a2 = ? AND aktualnost LIMIT 1), (SELECT id FROM f5t_obwee_strana WHERE kod_a2 = ? AND aktualnost LIMIT 1), ?, ?) RETURNING id";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, person.getLastName());
            statement.setString(2, person.getFirstName());
            statement.setString(3, person.getFatherName());
            statement.setString(4, person.getIin());
            statement.setString(5, person.getGender());
            statement.setString(6, person.getLastName() + " " + person.getFirstName() + " " + person.getFatherName());
            statement.setDate(7, Date.valueOf(person.getBirthDate()));
            statement.setString(8, person.getBirthCountry());
            statement.setString(9, "Заемщик");
            statement.setString(10, person.getMaritalStatus());
            statement.setInt(11, person.getDependentsCount());
            statement.setInt(12, person.getChildrensCount());
            statement.setString(13, person.getResidenceCountry());
            statement.setString(14, person.getBirthCountry());
            statement.setString(15, person.getSpeakLanguage());
            statement.setString(16, personId);

            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String anketaId = rs.getString("id");
                setPersonAdditionals(connection, person, personId, anketaId);
                setCitizenship(connection, person.getCitizenshipCountry(), personId, anketaId);
                return anketaId;
            } else {
                throw new SQLException("Failed to insert Anketa.");
            }
        }
    }

    private String SetPerson (Connection connection, ClientModel person) throws SQLException {
        String selectQuery = "SELECT id FROM f5t_fizicheskoe_lico WHERE iin = ?";
        try (PreparedStatement selectStatement = connection.prepareStatement(selectQuery)) {
            selectStatement.setString(1, person.getIin());
            ResultSet rs = selectStatement.executeQuery();
            if (rs.next()) {
                String personId = rs.getString("id");
                String updateQuery = "UPDATE f5t_fizicheskoe_lico SET familija = ?, imja = ?, otchestvo = ?, fio = ?, iin = ?, data_rozhdenija = ?, pol = ?, kolichestvo_izhdivencev = ?, kolichestvo_detej = ?, semejnoe_polozhenie = ?, rezident = ?, mesto_rozhdenija = ?, strana_rojdeniya = (SELECT id FROM f5t_obwee_strana WHERE kod_a2 = ? AND aktualnost LIMIT 1), strana_rezidentstva = (SELECT id FROM f5t_obwee_strana WHERE kod_a2 = ? AND aktualnost LIMIT 1), jazyk_obwenija = ?, vneshnij_id1 = ?, update_date = CURRENT_TIMESTAMP WHERE iin = ?";
                try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                    updateStatement.setString(1, person.getLastName());
                    updateStatement.setString(2, person.getFirstName());
                    updateStatement.setString(3, person.getFatherName());
                    updateStatement.setString(4, person.getLastName() + " " + person.getFirstName() + " " + person.getFatherName());
                    updateStatement.setString(5, person.getIin());
                    updateStatement.setDate(6, Date.valueOf(person.getBirthDate()));
                    updateStatement.setString(7, person.getGender());
                    updateStatement.setInt(8, person.getDependentsCount());
                    updateStatement.setInt(9, person.getChildrensCount());
                    updateStatement.setString(10, person.getMaritalStatus());
                    updateStatement.setBoolean(11, person.isResident());
                    updateStatement.setString(12, person.getBirthCountry());
                    updateStatement.setString(13, person.getBirthCountry());
                    updateStatement.setString(14, person.getResidenceCountry());
                    updateStatement.setString(15, person.getSpeakLanguage());
                    updateStatement.setString(16, person.getClientRSId());
                    updateStatement.setString(17, person.getIin());
                    updateStatement.executeUpdate();
                }
                return personId;
            } else {
                String insertQuery = "INSERT INTO f5t_fizicheskoe_lico (createddate, familija, imja, otchestvo, fio, iin, data_rozhdenija, pol, kolichestvo_izhdivencev, kolichestvo_detej, semejnoe_polozhenie, rezident, mesto_rozhdenija, strana_rojdeniya, strana_rezidentstva, jazyk_obwenija, vneshnij_id1) VALUES (CURRENT_TIMESTAMP, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, (SELECT id FROM f5t_obwee_strana WHERE kod_a2 = ? AND aktualnost LIMIT 1), (SELECT id FROM f5t_obwee_strana WHERE kod_a2 = ? AND aktualnost LIMIT 1), ?, ?) RETURNING id";
                try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                    insertStatement.setString(1, person.getLastName());
                    insertStatement.setString(2, person.getFirstName());
                    insertStatement.setString(3, person.getFatherName());
                    insertStatement.setString(4, person.getLastName() + " " + person.getFirstName() + " " + person.getFatherName());
                    insertStatement.setString(5, person.getIin());
                    insertStatement.setDate(6, Date.valueOf(person.getBirthDate()));
                    insertStatement.setString(7, person.getGender());
                    insertStatement.setInt(8, person.getDependentsCount());
                    insertStatement.setInt(9, person.getChildrensCount());
                    insertStatement.setString(10, person.getMaritalStatus());
                    insertStatement.setBoolean(11, person.isResident());
                    insertStatement.setString(12, person.getBirthCountry());
                    insertStatement.setString(13, person.getBirthCountry());
                    insertStatement.setString(14, person.getResidenceCountry());
                    insertStatement.setString(15, person.getSpeakLanguage());
                    insertStatement.setString(16, person.getClientRSId());
                    rs = insertStatement.executeQuery();
                    if (rs.next()) {
                        return rs.getString("id");
                    } else {
                        throw new SQLException("Failed to insert customer.");
                    }
                }
            }
        }
    }
    private void setPersonAdditionals (Connection connection, ClientModel person, String personId, String AnketaId) throws SQLException {
        List <Address> addresses = person.getAddresses();
        if (addresses.size() > 0) {
            for (Address address : addresses) {
                setAddress(connection, address, personId, AnketaId);
            }
        }
        List <Documents> documents = person.getDocuments();
        if (documents.size() > 0) {
            for (Documents doc : documents) {
                setDocuments(connection, doc, personId, AnketaId, person.isResident());
            }
        }
        List <Contacts> contacts = person.getContacts();
        if (contacts.size() > 0) {
            for (Contacts contact : contacts) {
                setContacts(connection, contact, personId, AnketaId);
            }
        }
    }
    private void setAddress(Connection connection, Address adr, String personId, String anketaId) throws SQLException {
        String query = "INSERT INTO f5t_obwee_adres (tip_adresa, pochtovyj_indeks, kod_regiona, nazvanie_regiona, tip_regiona, rajon_oblasti, kod_rajona_oblasti, tip_rajona_oblasti, aktualnost, naselennyj_punkt, tip_naselennogo_punkta, kod_naselennogo_punkta, ulica, tip_ulicy, nomer_doma, nomer_kvartiry, nazvanie_strany, anketa, fiz_lico, adres_strokoj) VALUES (?, ?, ?, ?, ?, ?, ?, ?, true, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, adr.getAddresstype());
            statement.setString(2, adr.getPostCode());
            statement.setString(3, adr.getRegionCode());
            statement.setString(4, adr.getRegion());
            statement.setString(5, adr.getRegionType());
            statement.setString(6, adr.getDistrict());
            statement.setString(7, adr.getDistrictCode());
            statement.setString(8, adr.getDistrictType());
            statement.setString(9, adr.getCity());
            statement.setString(10, adr.getCityType());
            statement.setString(11, adr.getCityCode());
            statement.setString(12, adr.getStreet());
            statement.setString(13, adr.getStreetType());
            statement.setString(14, adr.getHouseNumber());
            statement.setString(15, adr.getApartmentNumber());
            statement.setString(16, adr.getCountry());
            statement.setString(17, anketaId);
            statement.setString(18, personId);
            statement.setString(19, adr.getPostCode() + ", " + adr.getCountry() + ", " + adr.getRegion() + " " + adr.getRegionType() + ", " + adr.getDistrict() + " " + adr.getDistrictType() + ", " + adr.getCityType() + " " + adr.getCity() + ", " + adr.getStreetType() + " " + adr.getStreet() + ", " + adr.getHouseNumber() + " " + adr.getApartmentNumber());
            statement.executeUpdate();
        }
    }
    private void setContacts(Connection connection, Contacts contact, String personId, String anketaId) throws SQLException {
        String query = "INSERT INTO f5t_obwee_kontakt (aktualnost, znachenie, tip_kontakta, kontaktnoe_lico, tip_otnoshenija, tip_ustrojstva, anketa, fiz_lico) VALUES (true, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, contact.getContactValue());
            statement.setString(2, contact.getContactType());
            statement.setString(3, contact.getContactPerson());
            statement.setString(4, contact.getRelationType());
            statement.setString(5, contact.getDeviceType());
            statement.setString(6, anketaId);
            statement.setString(7, personId);
            statement.executeUpdate();
        }
    }
    private void setDocuments(Connection connection, Documents doc, String personId, String anketaId, boolean isResident) throws SQLException {
        String query = "INSERT INTO f5t_obwee_dokument (" +
                "anketa, " +
                "fiz_lico, " +
                "javljaetsja_dul, " +
                "tip_dokumenta, " +
                "serija, " +
                "osnovnoj, " +
                "aktualnost, " +
                "rezident, " +
                "organ_vydachi, " +
                "data_vydachi, " +
                "nomer, " +
                "srok_dejstvija" +
                ") VALUES (" +
                "?, " +
                "?, " +
                "true, " +
                "?, " +
                "?, " +
                "true, " +
                "true,?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, anketaId);
            statement.setString(2, personId);
            statement.setString(3, doc.getDocumentType());
            statement.setString(4, doc.getDocumentSerial());
            statement.setBoolean(5, isResident);
            statement.setString(6, doc.getIssuingAuthority());
            statement.setDate(7, Date.valueOf(doc.getDateOfIssue()));
            statement.setString(8, doc.getDocumentNumber());
            statement.setDate(9, Date.valueOf(doc.getExpirationDate()));
            statement.executeUpdate();
        }
    }
    private String setDealer(Connection connection, Dealer dealer) throws SQLException{
        String selectQuery = "SELECT id FROM f5t_partnery_partner WHERE naimenovanie = ?";
        try (PreparedStatement selectStatement = connection.prepareStatement(selectQuery)) {
            selectStatement.setString(1, dealer.getName());
            ResultSet rs = selectStatement.executeQuery();
            if (!rs.next()) {
                String insertQuery = "INSERT INTO f5t_partnery_partner (naimenovanie) VALUES (?) RETURNING id";
                try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                    insertStatement.setString(1, dealer.getName());
                    rs = insertStatement.executeQuery();
                    if (rs.next()) {
                        return rs.getString("id");
                    } else {
                        throw new SQLException("Failed to insert Dealer.");
                    }
                }
            } else {
                return rs.getString("id");
            }
        }
    }
    private String setTariff(Connection connection, String tariff) throws SQLException {
        String selectQuery = "SELECT id FROM f5t_shema_kredito_acky WHERE naimenovanie = ?";
        try (PreparedStatement selectStatement = connection.prepareStatement(selectQuery)) {
            selectStatement.setString(1, tariff);
            ResultSet rs = selectStatement.executeQuery();
            if (!rs.next()) {
                String query = "INSERT INTO f5t_shema_kredito_acky (naimenovanie) VALUES (?) RETURNING id";
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setString(1, tariff);
                    rs = statement.executeQuery();
                    if (rs.next()) {
                        return rs.getString("id");
                    } else {
                        throw new SQLException("Failed to insert Tariff.");
                    }
                }
            } else {
                return rs.getString("id");
            }
        }
    }
    private void setApplication(Connection connection, RequestObj req, String personId, String anketaId) throws SQLException {
        String query = "INSERT INTO f5t_zajavka (" +
                "createddate, " +
                "data_vremja_zavedenija, " +
                "data_pervogo_pogashenija, " +
                "nomer_zajavki, " +
                "author, " +
                "polnaya_summa_zajma, " +
                "srok, " +
                "summa_ezhemesjachnogo_platezha, " +
                "tip_grafika_pogashenija, " +
                "zaemwik, " +
                "sposob_pogashenija, " +
                "iin, " +
                "client_full_name, " +
                "status_zajavki, " +
                "outlet, " +
                "shema_kreditovanija, " +
                "tip_kredita, " +
                "valjuta" +
                ") VALUES (" +
                "CURRENT_TIMESTAMP, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " + //sotrudnik
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " + //person
                "?, " + //sposob pogashenija
                "?, " +
                "?, " +
                "?, " + //status zajavki
                "?, " + //dealer
                "?, " +
                "(SELECT id FROM f5t_tip_kredita WHERE kod = ?), " +
                "?)" +
                "RETURNING id"; //valjuta
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            String dealerId = setDealer(connection, req.getDealer());
            String tariffId = setTariff(connection, req.getTariff());
            Application app = req.getApplication();
            Loan loan = req.getLoan();
            ClientModel person = req.getPerson();
            statement.setTimestamp(1, Timestamp.valueOf(app.getCreatedAt()));
            if (app.getFirstPaymentDate() != null) {
                statement.setDate(2, Date.valueOf(app.getFirstPaymentDate()));
            } else {
                statement.setDate(2, null);
            }
            statement.setString(3, app.getApplicationNumber());
            statement.setString(4, app.getFinancialConsultant());
            statement.setDouble(5, app.getFullLoanAmount());
            statement.setInt(6, app.getTerm());
            statement.setDouble(7, app.getMonthlyPayment());
            statement.setString(8, app.getRepaymentScheduleType());
            statement.setString(9, personId);
            statement.setString(10, app.getRepaymentMethod());
            statement.setString(11, person.getIin());
            statement.setString(12, person.getLastName() + " " + person.getFirstName() + " " + person.getFatherName());
            statement.setString(13, app.getStatus());
            statement.setString(14, dealerId);
            statement.setString(15, tariffId);
            statement.setString(16, app.getLoanType());
            statement.setString(17, loan.getCurrency());
            ResultSet rs = statement.executeQuery();
            String appId;
            if (rs.next()) {
                appId = rs.getString("id");
                setLoan(connection,req, appId, dealerId, tariffId, anketaId, personId);
            } else {
                throw new SQLException("Failed to insert Dealer.");
            }



        }
    }
    //
    private void setLoan(Connection connection, RequestObj req, String appId, String dealerId, String tariffId, String anketaId, String personId) throws SQLException {
        Loan loan = req.getLoan();
        Application app = req.getApplication();
        ClientModel person = req.getPerson();
        String query = "INSERT INTO f5t_kredit (" +
                "createddate, " +
                "zajavka, " +
                "torgovaja_tochka, " +
                "shema_kreditovanija, " +
                "anketa, " +
                "data_vydachi, " +
                "data_platezha, " +
                "srok_kredita, " +
                "sotrudnik, " +
                "tip_kredita, " +
                "valjuta, " +
                "summa_kredita, " +
                "summa_kredita_so_strahovkoj, " +
                "summa_ezhemesjachnogo_platezha, " +
                "edinica_izmerenija_sroka_kredita, " +
                "istochnik_pogashenija" +
                ") VALUES (" +
                "CURRENT_TIMESTAMP, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "(SELECT id FROM f5t_tip_kredita WHERE kod = ?), " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?) " +
                "RETURNING id";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, appId);
            statement.setString(2, dealerId);
            statement.setString(3, tariffId);
            statement.setString(4, anketaId);
            if (app.getFinanceDate() != null) {
                statement.setDate(5, Date.valueOf(app.getFinanceDate()));
            } else {
                statement.setDate(5, null);
            }
            if (loan.getPaymentDay() != null) {
                statement.setInt(6, Integer.parseInt(loan.getPaymentDay()));
            } else {
                statement.setInt(6, java.sql.Types.INTEGER);
            }
            statement.setInt(7, loan.getTerm());
            statement.setString(8, app.getFinancialConsultant());
            statement.setString(9, loan.getLoanType());
            statement.setString(10, loan.getCurrency());
            statement.setDouble(11, loan.getLoanAmount());
            statement.setDouble(12, loan.getLoanAmountWithInsurance());
            statement.setDouble(13, loan.getMonthlyPayment());
            statement.setString(14, "месяц");
            statement.setString(15, loan.getRepaymentMethod());
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String loanId = rs.getString("id");
                setProcessKredit(connection, req, anketaId, loanId, personId);
                List <SelectedRate> selectedRates = req.getSelectedRates();
                if (selectedRates.size() != 0) {
                    for (SelectedRate selectedRate : selectedRates) {
                        setSelectedRates(connection, selectedRate, loanId);
                    }
                }
                List <Insurance> insurances = req.getInsurances();
                if (insurances.size() != 0) {
                    for (Insurance ins : insurances) {
                        setInsurane(connection, ins, loanId);
                    }
                }
                List <AdditionalServices> additionalServices = req.getAdditionalServices();
                if (additionalServices.size() != 0) {
                    for (AdditionalServices additionalService : additionalServices) {
                        setAdditionals(connection, additionalService, loanId);
                    }
                }
                String anketaUpdateQuery = "UPDATE f5t_anketa SET kredit = ? WHERE id = ?";
                try (PreparedStatement updateStatement = connection.prepareStatement(anketaUpdateQuery)) {
                    updateStatement.setString(1, loanId);
                    updateStatement.setString(2, anketaId);
                    updateStatement.executeUpdate();
                }
            }
        }
    }
    private void setProcessKredit (Connection connection, RequestObj req, String anketaId, String loanId, String personId) throws SQLException{
        Application app = req.getApplication();
        Loan loan = req.getLoan();
        String query = "INSERT INTO f5t_process_tovar_an3i (" +
                "anketa, " +
                "kredit, " +
                "klient, " +
                "loan_type" +
                ") VALUES (" +
                "?, " +
                "?, " +
                "?, " +
                "(SELECT id FROM f5t_tip_kredita WHERE kod = ?))";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, anketaId);
            statement.setString(2, loanId);
            statement.setString(3, personId);
            statement.setString(4, loan.getLoanType());
            statement.executeUpdate();
            if (app.getFinanceDate() != null)
                setDBZ(connection, app, loanId);
        }
    }
    //
    private void setDBZ (Connection connection, Application app, String loanId) throws SQLException {
        String query = "INSERT INTO f5t_dogovor_banko_akvb (" +
                "createddate, " +
                "kredit, " +
                "nomer_dogovora, " +
                "data_podpisanija_dogovora" +
                ") VALUES (" +
                "CURRENT_TIMESTAMP, " +
                "?, " +
                "?, " +
                "?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, loanId);
            statement.setString(2, app.getApplicationNumber());
            statement.setDate(3, Date.valueOf(app.getFinanceDate()));
            statement.executeUpdate();
        }
    }
    private void setInsurane(Connection connection, Insurance ins, String loanId) throws SQLException {
        String query = "INSERT INTO f5t_vybrannaja_st_au3m (createddate, aktualnost, summa, refund_amount, kredit) VALUES (CURRENT_TIMESTAMP, true, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDouble(1, ins.getAmount());
            statement.setDouble(2, ins.getPartnerComission());
            statement.setString(3, loanId);
            statement.executeUpdate();
        }
    }
    private void setAdditionals(Connection connection, AdditionalServices additional, String loanId) throws SQLException {
        String query = "INSERT INTO f5t_vybrannaja_do_aeq8 (createddate, aktualnost, summa, refund_amount, kredit) VALUES (CURRENT_TIMESTAMP, true, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDouble(1, additional.getAmount());
            statement.setDouble(2, additional.getPartnerComission());
            statement.setString(3, loanId);
            statement.executeUpdate();
        }
    }
    private void setSelectedRates(Connection connection, SelectedRate rate, String loanId) throws SQLException {
        String query = "INSERT INTO f5t_selected_rate (" +
                "createddate, " +
                "rate_value, " +
                "min_initial_fee, " +
                "max_initial_fee, " +
                "valid_from, " +
                "valid_to, " +
                "credit, " +
                "rate_type, " +
                "is_actual" +
                ") VALUES (" +
                "CURRENT_TIMESTAMP, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "?, " +
                "true)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, rate.getRate());
            statement.setDouble(2, rate.getFromDownAmount());
            statement.setDouble(3, rate.getTillDownAmount());
            statement.setInt(4, rate.getFromMonth());
            statement.setInt(5, rate.getTillMonth());
            statement.setString(6, loanId);
            statement.setString(7, "проценты");
            statement.executeUpdate();
        }
    }

    private void setSpouseFL (Connection connection, ClientModel spouse, String personId, String anketaid) throws SQLException {
        String spouseId = SetPerson(connection, spouse);
        String updateSpouse = "UPDATE f5t_fizicheskoe_lico SET suprug_a = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(updateSpouse)) {
            statement.setString(1, spouseId);
            statement.setString(2, personId);
            statement.executeUpdate();
            setSpouseAnketa(connection, spouse, spouseId);
        }
    }
    //
    private void setSpouseAnketa(Connection connection, ClientModel spouse, String spouseId) throws SQLException {
        String query = "UPDATE f5t_anketa SET suprug = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            String anketaId = setAnketa(connection, spouse, spouseId);
            statement.setString(1, anketaId);
            statement.setString(2, spouseId);
            statement.executeUpdate();
            setImage(connection, spouse, spouseId, anketaId);
        }
    }
    //
    private void setSoborrow (Connection connection, ClientModel soborrow, String anketaId) throws SQLException {
        String query = "INSERT INTO f5t_sozaemwik (createddate, aktualnost, anketa, zaemwik) VALUES (CURRENT_TIMESTAMP, true, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            String soborrowId = SetPerson(connection, soborrow);
            statement.setString(1, setAnketa(connection, soborrow, soborrowId));
            statement.setString(2, anketaId);
            statement.executeUpdate();
            setImage(connection, soborrow, soborrowId, anketaId);
        }
    }
    //
    private void setImage (Connection connection, ClientModel person, String personId, String anketaId) throws SQLException {
        String query = "INSERT INTO f5t_obwee_soderzhimoe (createddate, dannye, nazvanie, opisanie) VALUES (CURRENT_TIMESTAMP, ?, ?, ?) RETURNING id";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setBytes(1, person.getClientPhoto());
            statement.setString(2, "Фото клиента");
            statement.setString(3, "Фото клиента JSM " + person.getIin());
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String imageId = rs.getString("id");
                addImageFL(connection, imageId, personId);
                addImageAnketa(connection, imageId, anketaId);
            }
        }
    }
    private void addImageFL (Connection connection, String imageId, String personId) throws SQLException {
        String query = "UPDATE f5t_fizicheskoe_lico SET foto = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, imageId);
            statement.setString(2, personId);
            statement.executeUpdate();
        }
    }
    private void addImageAnketa (Connection connection, String imageId, String anketaId) throws SQLException {
        String query = "UPDATE f5t_anketa SET foto = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, imageId);
            statement.setString(2, anketaId);
            statement.executeUpdate();
        }
    }

    private void setCitizenship (Connection connection, String citizenshipCountry, String personId, String anketaId) throws SQLException {
        String query = "INSERT f5t_grazhdanstvo (createddate, aktualnost, anketa, fiz_lico, strana) VALUES (CURRENT_TIMESTAMP, true, ?, ?, (SELECT id FROM f5t_obwee_strana WHERE kod_a2 = ? AND aktualnost LIMIT 1))";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, anketaId);
            statement.setString(2, personId);
            statement.setString(3, citizenshipCountry);
        }
    }


}