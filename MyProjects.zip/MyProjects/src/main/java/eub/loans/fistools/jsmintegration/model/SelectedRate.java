package eub.loans.fistools.jsmintegration.model;

public class SelectedRate {
    /**
     *             "rate": 26,  // Размер
     *             "fromDownAmount": 0, //Мин первоначальный взнос
     *             "tillDownAmount": 2000000, //Макс первоначальный взнос
     *             "fromMonth": 1, //Период от
     *             "tillMonth": 36 //Период до
     */
    private int rate;
    private int fromDownAmount;
    private int tillDownAmount;
    private int fromMonth;
    private int tillMonth;

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public int getFromDownAmount() {
        return fromDownAmount;
    }

    public void setFromDownAmount(int fromDownAmount) {
        this.fromDownAmount = fromDownAmount;
    }

    public int getTillDownAmount() {
        return tillDownAmount;
    }

    public void setTillDownAmount(int tillDownAmount) {
        this.tillDownAmount = tillDownAmount;
    }

    public int getFromMonth() {
        return fromMonth;
    }

    public void setFromMonth(int fromMonth) {
        this.fromMonth = fromMonth;
    }

    public int getTillMonth() {
        return tillMonth;
    }

    public void setTillMonth(int tillMonth) {
        this.tillMonth = tillMonth;
    }

    @Override
    public String toString() {
        return "SelectedRate{" +
                "rate=" + rate +
                ", fromDownAmount=" + fromDownAmount +
                ", tillDownAmount=" + tillDownAmount +
                ", fromMonth=" + fromMonth +
                ", tillMonth=" + tillMonth +
                '}';
    }
}
