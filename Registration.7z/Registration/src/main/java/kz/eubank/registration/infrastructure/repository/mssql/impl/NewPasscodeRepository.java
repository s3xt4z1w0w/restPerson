package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.NewPasscode;
import kz.eubank.registration.domain.repository.INewPasscodeRepository;
import kz.eubank.registration.infrastructure.entity.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.NewPasscodeHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@RequiredArgsConstructor
public class NewPasscodeRepository implements INewPasscodeRepository {
   private final NewPasscodeHiberRepository newPasscodeHiberRepository;

    @Override
    public void save(NewPasscode newPasscode) {
        var entity = BaseMapper.INSTANCE.toEntity(newPasscode);
        newPasscodeHiberRepository.save(entity);
    }

    @Override
    public void changeStatus(String status, String deviceId) {
        newPasscodeHiberRepository.changeStatus(status, deviceId);
    }

    @Override
    public String findHash(String sessionId) {
        return newPasscodeHiberRepository.findHash(sessionId);
    }
}
