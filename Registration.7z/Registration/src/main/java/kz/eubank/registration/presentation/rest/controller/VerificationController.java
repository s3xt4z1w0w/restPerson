package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.IVerificationExecution;
import kz.eubank.registration.presentation.rest.model.response.VerificationBirthDateResponse;
import kz.eubank.registration.presentation.rest.model.response.VerificationIINResponse;
import kz.eubank.registration.presentation.rest.model.response.VerificationProductResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("verification")
@RequiredArgsConstructor
@Tag(name = "Верификация", description = "VerificationController")
public class VerificationController {

    private final IVerificationExecution execution;

    @Operation(summary = "Верификация ИИН", description = "verificationIIN")
    @Parameters({
            @Parameter(name = "iin", description = "iin", required = true)
    })
    @GetMapping("iin")
    public ResponseEntity<?> verificationIIN(@RequestHeader("User-Agent") String userAgent,
                                             @RequestHeader String language,
                                             @RequestHeader String authorization,
                                             @RequestParam String iin) {
        //var result = execution.verificationIIN(authorization, iin);
        return new ResponseEntity<>(new VerificationIINResponse("SendSms"), OK);
    }

    @Operation(summary = "Верификация даты рождения", description = "verificationBirthDate")
    @Parameters({
            @Parameter(name = "birthDate", description = "birthDate", required = true)
    })
    @GetMapping("birthDate")
    public ResponseEntity<?> verificationBirthDate(@RequestHeader("User-Agent") String userAgent,
                                                   @RequestHeader String language,
                                                   @RequestHeader String authorization,
                                                   @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date birthDate) {
        //var result = execution.verificationBirthDate(authorization, birthDate);
        return new ResponseEntity<>(new VerificationBirthDateResponse("SendOtpDigitalDocument"), OK);
    }

    @Operation(summary = "Верификация ИИН и продукта", description = "verificationProduct")
    @Parameters({
            @Parameter(name = "iin", description = "iin", required = true),
            @Parameter(name = "productNumber", description = "productNumber", required = true)
    })
    @GetMapping("product")
    public ResponseEntity<?> verificationProduct(@RequestHeader("User-Agent") String userAgent,
                                                 @RequestHeader String language,
                                                 @RequestHeader String authorization,
                                                 @RequestParam String iin,
                                                 @RequestParam String productNumber) {
        //var result = execution.verificationProduct(authorization, iin, productNumber);
        return new ResponseEntity<>(new VerificationProductResponse("PasscodeSet"), OK);
    }
}
