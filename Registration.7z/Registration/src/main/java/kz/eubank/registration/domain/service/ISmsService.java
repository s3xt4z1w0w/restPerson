package kz.eubank.registration.domain.service;

import java.util.Map;

public interface ISmsService {

    Map<String, Object> sendSms(String phoneNumber, String sessionId);

    Map<String, Object> checkSms(String sessionId, String clientCode);
}
