package kz.eubank.registration.infrastructure.repository.mssql.impl.view;

import kz.eubank.registration.domain.model.pojo.view.UserDefineRouteView;
import kz.eubank.registration.domain.repository.view.IUserDefineRouteViewRepository;
import kz.eubank.registration.infrastructure.entity.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.view.UserDefineRouteViewHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class UserDefineRouteViewRepository implements IUserDefineRouteViewRepository {

    private final UserDefineRouteViewHiberRepository userDefineRouteViewHiberRepository;

    @Override
    public Optional<UserDefineRouteView> getUserDefineRouteByMobilePhone(String mobilePhone) {
        return userDefineRouteViewHiberRepository.getUserDefineRouteByMobilePhone(mobilePhone)
                .map(BaseMapper.INSTANCE::toDomain);
    }
}
