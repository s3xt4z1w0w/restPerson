package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PasscodeSetResponse extends BaseResponseBody {

    public PasscodeSetResponse(String nextStep) {
        super(nextStep);
    }
}
