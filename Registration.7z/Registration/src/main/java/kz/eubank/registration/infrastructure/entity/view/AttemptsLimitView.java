package kz.eubank.registration.infrastructure.entity.view;

import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Getter
@Entity
public class AttemptsLimitView {

    @Id
    @Column(name = "Type")
    private String type;

    @Column(name = "Count")
    private int count;
}
