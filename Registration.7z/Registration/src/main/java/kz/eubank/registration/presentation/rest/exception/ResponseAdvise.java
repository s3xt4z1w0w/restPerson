package kz.eubank.registration.presentation.rest.exception;

import kz.eubank.registration.presentation.rest.model.response.APIResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.List;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_VD_400;
import static org.springframework.http.HttpStatus.*;

@ControllerAdvice
@Log4j2
public class ResponseAdvise extends ResponseEntityExceptionHandler implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object o, MethodParameter methodParameter, MediaType mediaType, Class aClass, ServerHttpRequest serverHttpRequest, ServerHttpResponse serverHttpResponse) {
        if (methodParameter.getContainingClass().isAnnotationPresent(RestController.class)) {
            APIResponse<Object> responseBody = new APIResponse<>();
            if (o instanceof String s) return responseBody.successResponse(s).json();
            return responseBody.successResponse(o);
        }
        return o;
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        List<String> errors = new ArrayList<>();
        ex.getBindingResult().getFieldErrors().forEach(fieldError -> {
            String defaultMessage = fieldError.getDefaultMessage();
            String fieldName = fieldError.getField();
            errors.add(String.format("Field: %s %s", fieldName, defaultMessage));
        });
        log.error("Request validate error: {}", errors);
        APIResponse<Object> responseBody = new APIResponse<>();
        responseBody.errorResponse(E_VD_400.getMessage(), ": " + errors);
        return new ResponseEntity<>(responseBody, BAD_REQUEST);
    }

    @ExceptionHandler(value = SelfException.class)
    protected ResponseEntity<Object> handleConflict(SelfException exception) {
        APIResponse<Object> responseBody = new APIResponse<>();
        responseBody.errorResponse(exception.getCode().getMessage(), exception.getMessage());
        return switch (exception.getCode()) {
            case E_EX_701 -> new ResponseEntity<>(responseBody, SERVICE_UNAVAILABLE);
            default -> new ResponseEntity<>(responseBody, INTERNAL_SERVER_ERROR);
        };
    }
}
