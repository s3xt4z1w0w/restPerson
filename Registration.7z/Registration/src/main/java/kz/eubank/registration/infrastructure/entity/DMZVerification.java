package kz.eubank.registration.infrastructure.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "DMZVerification")
@Builder
public class DMZVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DMZVerification_ID")
    private Long id;

    @Column(name = "SessionId")
    private String sessionId;

    @OneToOne
    @JoinColumn(name = "RouteType_IDREF")
    private RouteType routeType;

    @Column(name = "DateCreated")
    private Date dateCreated;

    @Column(name = "DateExpired")
    private Date dateExpired;

    @Column(name = "MobilePhone")
    private String mobilePhone;

    @Column(name = "Iin")
    private String iin;

    @OneToOne
    @JoinColumn(name = "RouteStatus_IDREF")
    private RouteStatus routeStatus;

    @Column(name = "DeviceId")
    private String deviceId;

    @Column(name = "VersionFront")
    private String versionFront;

    @Column(name = "FrontEnd_IDREF")
    private String frontEnd;
}
