package kz.eubank.registration.domain.model.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface PasscodeMapper {

    PasscodeMapper INSTANCE = Mappers.getMapper(PasscodeMapper.class);
}
