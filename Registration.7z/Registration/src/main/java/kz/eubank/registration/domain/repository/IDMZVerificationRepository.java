package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.DMZVerification;

import java.util.Optional;

public interface IDMZVerificationRepository {

    int getVerificationLimitCountByMobilePhone(String mobilePhone);

    Optional<DMZVerification> getNotFinishedSessionByMobilePhone(String mobilePhone);

    Optional<DMZVerification> findBySessionId(String sessionId);

    void save(DMZVerification dmzVerification);
    String findDeviceId(String sessionId);
    long findUserIdByIin(String sessionId);
}
