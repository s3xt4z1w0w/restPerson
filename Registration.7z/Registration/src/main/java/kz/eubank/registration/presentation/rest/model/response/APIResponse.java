package kz.eubank.registration.presentation.rest.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class APIResponse<T> {

    private T body;
    private String errorMessage;
    private String errorDetails;
    private boolean success;

    public APIResponse<T> successResponse(T body) {
        this.body = body;
        this.success = true;
        return this;
    }

    public APIResponse<T> errorResponse(String errorMessage, String errorDetails) {
        this.errorMessage = errorMessage;
        this.errorDetails = errorDetails;
        this.success = false;
        return this;
    }

    public String json() {
        return "{" +
                "\"body\":\"" + body + "\"" +
                ", \"errorMessage\":" + errorMessage +
                ", \"errorDetails\":\"" + errorDetails + "\"" +
                ", \"success\":\"" + success + "\"" +
                "}";
    }
}
