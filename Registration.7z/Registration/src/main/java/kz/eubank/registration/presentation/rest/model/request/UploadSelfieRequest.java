package kz.eubank.registration.presentation.rest.model.request;

import org.springframework.web.multipart.MultipartFile;

public record UploadSelfieRequest(MultipartFile mediaList,
                                  String payload) {
}
