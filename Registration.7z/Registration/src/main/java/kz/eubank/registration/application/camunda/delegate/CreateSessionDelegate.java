package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.domain.service.IDMZVerificationService;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CreateSessionDelegate implements JavaDelegate {

    private final IDMZVerificationService dmzVerificationService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var route = (String) execution.getVariable("currentRoute");
        var phoneNumber = (String) execution.getVariable("phoneNumber");
        var deviceId = (String) execution.getVariable("deviceId");
        var iin = (String) execution.getVariable("iin");
        var versionFront = (String) execution.getVariable("versionFront");
        var frontEnd = (String) execution.getVariable("frontEnd");

        execution.setVariable("route", route);
        execution.setVariables(dmzVerificationService.createDMZVerification(route, phoneNumber, deviceId, iin,
                versionFront, frontEnd));
    }
}
