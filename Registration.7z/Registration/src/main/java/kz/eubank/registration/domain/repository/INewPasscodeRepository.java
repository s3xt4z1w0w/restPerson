package kz.eubank.registration.domain.repository;

import kz.eubank.registration.domain.model.pojo.NewPasscode;


public interface INewPasscodeRepository {
    void save(NewPasscode newPasscode);
    void changeStatus(String status, String deviceId);
    String findHash(String sessionId);
}
