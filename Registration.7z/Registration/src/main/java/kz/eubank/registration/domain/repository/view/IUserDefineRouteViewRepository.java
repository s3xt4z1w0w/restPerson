package kz.eubank.registration.domain.repository.view;

import kz.eubank.registration.domain.model.pojo.view.UserDefineRouteView;

import java.util.Optional;

public interface IUserDefineRouteViewRepository {

    Optional<UserDefineRouteView> getUserDefineRouteByMobilePhone(String mobilePhone);
}
