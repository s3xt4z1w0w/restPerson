package kz.eubank.registration.presentation.rest.util;

public class Element2StepUtil {

    public static String convert(String taskDefinitionKey) {
        return switch (taskDefinitionKey) {
            case "Event_1m5o16x" -> "LoginPasscode";
            case "Event_0cy9nh9", "Event_1c7r1oq", "Event_06n4nuj", "Event_1w5emad" -> "ErrorText";
            case "Event_0w87ukn" -> "Login";
            case "Event_0dzr4w5" -> "Todo"; //TODO find nextStep value
            case "Activity_074bkig", "Activity_1byklnc", "Activity_184bovt" -> "SendSms";
            case "Activity_1lyjm18", "Activity_1jvpc3t", "Activity_03lcrn7" -> "CheckSms";
            case "Activity_0qpr1pf" -> "VerificationProduct";
            case "Activity_0mqk2py" -> "VerificationIIN";
            case "Activity_0h0gb13" -> "PasscodeSet";
            default -> taskDefinitionKey;
        };
    }
}
