package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.domain.service.IPasscodeService;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SetPasscodeDelegate implements JavaDelegate {
    @Qualifier("oldPasscode")
    private final IPasscodeService oldPasscodeService;
    @Qualifier("passcode")
    private final IPasscodeService passcodeService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var passcode = (String) execution.getVariable("passcode");
        var sessionId = (String) execution.getVariable("sessionId");
        oldPasscodeService.savePasscode(sessionId, passcode);
        passcodeService.savePasscode(sessionId, passcode);
    }
}
