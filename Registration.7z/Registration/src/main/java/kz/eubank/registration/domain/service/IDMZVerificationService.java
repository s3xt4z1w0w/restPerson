package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.dto.DMZVerificationDto;

import java.util.Map;

public interface IDMZVerificationService {

    Map<String, Object> createDMZVerification(String route, String phoneNumber, String deviceId, String iin,
                                              String versionFront, String frontEnd);

    int getVerificationLimitCountByMobilePhone(String phoneNumber);

    DMZVerificationDto getNotFinishedSessionByMobilePhone(String phoneNumber);
}
