package kz.eubank.registration.presentation.rest.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorDto {

    private String errorMessage;
    private String errorDetails;
}
