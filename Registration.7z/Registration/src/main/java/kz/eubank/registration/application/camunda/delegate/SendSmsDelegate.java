package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.domain.service.ISmsService;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SendSmsDelegate implements JavaDelegate {

    private final ISmsService service;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var phoneNumber = (String) execution.getVariable("phoneNumber");
        var sessionId = (String) execution.getVariable("sessionId");

        execution.setVariables(service.sendSms(phoneNumber, sessionId));
        if (execution.getVariable("error") != null) {
            throw new BpmnError((String) execution.getVariable("error"));
        }
    }
}
