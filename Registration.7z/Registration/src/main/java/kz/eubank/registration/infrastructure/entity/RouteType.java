package kz.eubank.registration.infrastructure.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "RouteType")
public class RouteType {

    @Id
    @Column(name = "RouteType_ID")
    private String id;

    @Column(name = "RouteType_Title")
    private String title;
}
