package kz.eubank.registration.application.camunda.delegate;

import kz.eubank.registration.domain.service.ISmsService;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CheckSmsDelegate implements JavaDelegate {

    private final ISmsService smsService;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        var clientCode = (String) execution.getVariable("clientCode");
        var sessionId = (String) execution.getVariable("sessionId");

        execution.setVariables(smsService.checkSms(sessionId, clientCode));
    }
}
