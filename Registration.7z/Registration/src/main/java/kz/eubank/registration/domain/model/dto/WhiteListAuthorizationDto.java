package kz.eubank.registration.domain.model.dto;

import java.util.Date;

public record WhiteListAuthorizationDto(Long id,
                                        String mobilePhone,
                                        String hash,
                                        String salt,
                                        Long userId,
                                        boolean isActive,
                                        Date dateValid) {
}
