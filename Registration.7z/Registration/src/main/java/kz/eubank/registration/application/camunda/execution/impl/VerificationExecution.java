package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IVerificationExecution;
import kz.eubank.registration.presentation.rest.model.response.VerificationBirthDateResponse;
import kz.eubank.registration.presentation.rest.model.response.VerificationIINResponse;
import kz.eubank.registration.presentation.rest.model.response.VerificationProductResponse;
import kz.eubank.registration.presentation.rest.util.Element2StepUtil;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@RequiredArgsConstructor
public class VerificationExecution implements IVerificationExecution {

    private final ProcessEngine engine;

    @Override
    public VerificationIINResponse verificationIIN(String sessionId, String iin) {
        var task = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult();
        engine.getRuntimeService().setVariable(task.getExecutionId(), "iin", iin);
        engine.getTaskService().complete(task.getId());

        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getTaskDefinitionKey();
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
        return new VerificationIINResponse(nextStep);
    }

    @Override
    public VerificationBirthDateResponse verificationBirthDate(String sessionId, Date birthDate) {
        var task = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult();
        engine.getRuntimeService().setVariable(task.getExecutionId(), "birthDate", birthDate);
        engine.getTaskService().complete(task.getId());

        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getTaskDefinitionKey();
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
        return new VerificationBirthDateResponse(nextStep);
    }

    @Override
    public VerificationProductResponse verificationProduct(String sessionId, String iin, String productNumber) {
        var task = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult();
        engine.getRuntimeService().setVariable(task.getExecutionId(), "iin", iin);
        engine.getRuntimeService().setVariable(task.getExecutionId(), "productNumber", productNumber);
        engine.getTaskService().complete(task.getId());

        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getTaskDefinitionKey();
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
        return new VerificationProductResponse(nextStep);
    }
}
