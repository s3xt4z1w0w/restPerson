package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.Passcode;
import kz.eubank.registration.domain.repository.IPasscodeRepository;
import kz.eubank.registration.infrastructure.entity.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.PasscodeHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@RequiredArgsConstructor
public class PasscodeRepository implements IPasscodeRepository {

    private final PasscodeHiberRepository passcodeHiberRepository;

    @Override
    public void save(Passcode passcode) {
        var entity = BaseMapper.INSTANCE.toEntity(passcode);
        passcodeHiberRepository.save(entity);
    }

    @Override
    public void changeStatus(String status, String deviceId) {
        passcodeHiberRepository.changeStatus(status, deviceId);
    }
}
