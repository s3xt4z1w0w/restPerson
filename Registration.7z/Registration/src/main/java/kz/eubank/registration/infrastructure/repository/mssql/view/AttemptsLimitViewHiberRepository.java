package kz.eubank.registration.infrastructure.repository.mssql.view;

import kz.eubank.registration.infrastructure.entity.view.AttemptsLimitView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface AttemptsLimitViewHiberRepository extends JpaRepository<AttemptsLimitView, String> {

    @Query(nativeQuery = true,
            value = """
                    select a.DMZVerificationAttemptsType_IDREF as "Type",
                           count(*) as "Count"
                      from DMZVerificationAttempts a
                     where a.MobilePhone = :mobilePhone
                       and a.DMZVerificationAttemptsType_IDREF in ('SSMS', 'VBIO', 'VIIN')
                       and format(a.DateCreated, 'yyyy-MM-dd') = format(GETDATE(), 'yyyy-MM-dd')
                     group by a.DMZVerificationAttemptsType_IDREF
                    """)
    List<AttemptsLimitView> getLimitsCountByMobilePhone(String mobilePhone);

    @Query(nativeQuery = true,
            value = """
                    select a.DMZVerificationAttemptsType_IDREF as "Type",
                           count(*) as "Count"
                      from DMZVerificationAttempts a
                     where a.MobilePhone = :mobilePhone
                       and a.DMZVerificationAttemptsType_IDREF = :type
                       and format(a.DateCreated, 'yyyy-MM-dd') = format(GETDATE(), 'yyyy-MM-dd')
                     group by a.DMZVerificationAttemptsType_IDREF
                    """)
    Optional<AttemptsLimitView> getLimitsCountByMobilePhoneAndType(String mobilePhone, String type);
}
