package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.presentation.rest.model.request.UploadSelfieRequest;
import kz.eubank.registration.presentation.rest.model.response.StatusAnalyseResponse;
import kz.eubank.registration.presentation.rest.model.response.UploadSelfieResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("biometry")
@RequiredArgsConstructor
@Tag(name = "Биометрия", description = "BiometryController")
public class BiometryController {

    @Operation(summary = "Загрузка фото лица", description = "uploadSelfie")
    @Parameters({
            @Parameter(name = "request", description = "request", required = true)
    })
    @PostMapping(value = "uploadSelfie", consumes = { "multipart/form-data" })
    public ResponseEntity<?> uploadSelfie(@RequestHeader("User-Agent") String userAgent,
                                          @RequestHeader String language,
                                          @RequestHeader String authorization,
                                          @RequestBody UploadSelfieRequest request) {
        return new ResponseEntity<>(new UploadSelfieResponse("StatusAnalyse"), OK);
    }

    @Operation(summary = "Статус анализа", description = "statusAnalyse")
    @GetMapping("statusAnalyse")
    public ResponseEntity<?> statusAnalyse(@RequestHeader("User-Agent") String userAgent,
                                           @RequestHeader String language,
                                           @RequestHeader String authorization) {
        return new ResponseEntity<>(new StatusAnalyseResponse("VerificationBirthDate"), OK);
    }
}
