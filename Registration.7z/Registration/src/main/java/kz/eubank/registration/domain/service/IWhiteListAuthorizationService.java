package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.dto.WhiteListAuthorizationDto;

public interface IWhiteListAuthorizationService {

    WhiteListAuthorizationDto getWhiteListByPhoneNumber(String phoneNumber);
}
