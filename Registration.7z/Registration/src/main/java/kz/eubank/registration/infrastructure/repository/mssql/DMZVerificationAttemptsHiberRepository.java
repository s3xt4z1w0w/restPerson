package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.entity.DMZVerificationAttempts;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DMZVerificationAttemptsHiberRepository extends JpaRepository<DMZVerificationAttempts, Long> {
}
