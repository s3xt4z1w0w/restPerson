package kz.eubank.registration.infrastructure.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "OtpStatus")
public class OtpStatus {

    @Id
    @Column(name = "OtpStatus_ID")
    private String id;

    @Column(name = "OtpStatus_Title")
    private String title;
}
