package kz.eubank.registration.domain.model.pojo;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class WhiteListAuthorization {

    private Long id;
    private String mobilePhone;
    private String hash;
    private String salt;
    private Long userId;
    private boolean isActive;
    private Date dateValid;
}
