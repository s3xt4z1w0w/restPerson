package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.DMZVerification;
import kz.eubank.registration.domain.repository.IDMZVerificationRepository;
import kz.eubank.registration.infrastructure.entity.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.DMZVerificationHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class DMZVerificationRepository implements IDMZVerificationRepository {

    private final DMZVerificationHiberRepository dmzVerificationHiberRepository;

    @Override
    public int getVerificationLimitCountByMobilePhone(String mobilePhone) {
        return dmzVerificationHiberRepository.getVerificationLimitCountByMobilePhone(mobilePhone);
    }

    @Override
    public Optional<DMZVerification> getNotFinishedSessionByMobilePhone(String mobilePhone) {
        return dmzVerificationHiberRepository.getNotFinishedSessionByMobilePhone(mobilePhone)
                .map(BaseMapper.INSTANCE::toDomain);
    }

    @Override
    public Optional<DMZVerification> findBySessionId(String sessionId) {
        return dmzVerificationHiberRepository.findBySessionId(sessionId)
                .map(BaseMapper.INSTANCE::toDomain);
    }

    @Override
    public void save(DMZVerification dmzVerification) {
        var entity = BaseMapper.INSTANCE.toEntity(dmzVerification);
        dmzVerificationHiberRepository.save(entity);
    }

    @Override
    public String findDeviceId(String sessionId) {
        return dmzVerificationHiberRepository.findDeviceId(sessionId);
    }

    @Override
    public long findUserIdByIin(String sessionId) {
        return dmzVerificationHiberRepository.findUserIdByIin(sessionId);
    }
}
