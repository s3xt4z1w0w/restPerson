package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IRegistrationExecution;
import kz.eubank.registration.presentation.rest.exception.SelfErrorCode;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import kz.eubank.registration.presentation.rest.model.response.DefineRouteResponse;
import kz.eubank.registration.presentation.rest.util.Element2StepUtil;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class RegistrationExecution implements IRegistrationExecution {

    private final ProcessEngine engine;

    @Override
    public DefineRouteResponse defineRoute(String phoneNumber, String deviceId) {
        var process = engine.getRuntimeService()
                .createProcessInstanceByKey("registration")
                .setVariable("phoneNumber", phoneNumber)
                .setVariable("deviceId", deviceId)
                //TODO get versionFront and frontEnd
                .setVariable("versionFront", "1.0.344.735")
                .setVariable("frontEnd", "ANDP")
                .executeWithVariablesInReturn();
        if (process.getVariables().get("error") != null) {
            throw new SelfException(SelfErrorCode.valueOf((String) process.getVariables().get("error")));
        }
        var sessionId = (String) process.getVariables().get("sessionId");
        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getTaskDefinitionKey();
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
        return new DefineRouteResponse(nextStep, sessionId);
    }
}
