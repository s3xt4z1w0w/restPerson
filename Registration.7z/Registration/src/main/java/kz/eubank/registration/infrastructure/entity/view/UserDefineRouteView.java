package kz.eubank.registration.infrastructure.entity.view;

import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Getter
@Entity
public class UserDefineRouteView {

    @Id
    @Column(name = "MobilePhone")
    private String mobilePhone;

    @Column(name = "IIN")
    private String iin;

    @Column(name = "IsResident")
    private boolean isResident;
}
