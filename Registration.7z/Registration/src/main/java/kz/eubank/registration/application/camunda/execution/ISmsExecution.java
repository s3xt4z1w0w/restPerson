package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.CheckSmsResponse;
import kz.eubank.registration.presentation.rest.model.response.SendSmsResponse;

public interface ISmsExecution {

    SendSmsResponse sendSms(String sessionId);

    CheckSmsResponse checkSms(String sessionId, String code);
}
