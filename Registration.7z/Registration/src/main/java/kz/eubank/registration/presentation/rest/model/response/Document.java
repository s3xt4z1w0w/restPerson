package kz.eubank.registration.presentation.rest.model.response;

public record Document(String name,
                       String type,
                       String base64,
                       String formatBase64) {
}