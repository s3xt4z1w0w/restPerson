package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.dto.DMZVerificationOtpDto;

public interface IDMZVerificationOtpService {

    String generateSmsCode(String sessionId);

    void saveDMZVerificationOtp(String generatedCode, String sessionId);

    DMZVerificationOtpDto getActualOtpBySessionId(String sessionId);

    void incrementCountValidation(DMZVerificationOtpDto dmzVerificationOtpDto);
}
