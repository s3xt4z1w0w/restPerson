package kz.eubank.registration.domain.service;

import kz.eubank.registration.domain.model.dto.WhiteListAuthorizationDto;

public interface IPasscodeService {

    void saveWhiteListPasscode(WhiteListAuthorizationDto whiteListAuthorizationDto, String deviceId);

    void savePasscode(String dmzSessionId, String password);
    boolean validatePasscode(String password, String storedPassword);
    void changeStatusPasscode(String status, String deviceId);
}
