package kz.eubank.registration.infrastructure.repository.mssql;

import kz.eubank.registration.infrastructure.entity.WhiteListAuthorization;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WhiteListAuthorizationHiberRepository extends JpaRepository<WhiteListAuthorization, String> {

    Optional<WhiteListAuthorization> findByMobilePhone(String mobilePhone);
}
