package kz.eubank.registration.infrastructure.entity;

import lombok.Builder;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Setter
@Entity
@Table(name = "DMZVerificationAttempts")
@Builder
public class DMZVerificationAttempts {

    @Id
    @Column(name = "DMZVerificationAttempts_ID")
    private Long id;

    @Column(name = "MobilePhone")
    private String mobilePhone;

    @Column(name = "DMZVerificationAttemptsType_IDREF")
    private String type;

    @ManyToOne
    @JoinColumn(name = "DMZVerification_IDREF")
    private DMZVerification dmzVerification;

    @Column(name = "DateCreated")
    private Date createdDate;

    @Column(name = "PasscodeSet")
    private boolean isPasscodeSet;
}
