package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.application.camunda.execution.IRegistrationExecution;
import kz.eubank.registration.presentation.rest.exception.SelfException;
import kz.eubank.registration.presentation.rest.model.response.UploadSelfieResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Size;

import static kz.eubank.registration.presentation.rest.exception.SelfErrorCode.E_LG_800;
import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("defineRoute")
@RequiredArgsConstructor
@Tag(name = "Определение роута", description = "RegistrationController")
@Validated
public class DefineRouteController {

    private final IRegistrationExecution execution;

    @Operation(summary = "Определение роута по номеру телефона", description = "defineRoute")
    @Parameters({
            @Parameter(name = "phoneNumber", description = "phoneNumber", required = true),
            @Parameter(name = "deviceId", description = "deviceId", required = true)
    })
    @GetMapping
    public ResponseEntity<?> defineRoute(@RequestHeader("User-Agent") String userAgent,
                                         @RequestHeader String language,
                                         @RequestParam String deviceId,
                                         @RequestParam @Size(max = 11) String phoneNumber) {
        return new ResponseEntity<>(execution.defineRoute(phoneNumber, deviceId), OK);
    }

    @GetMapping("test/{error}")
    public ResponseEntity<?> test(@RequestHeader("User-Agent") String userAgent,
                                  @PathVariable int error) {
        if (error == 1) {
            getError();
        }
        return new ResponseEntity<>(new UploadSelfieResponse("StatusAnalyse"), HttpStatus.OK);
    }

    private void getError() {
        throw new SelfException(E_LG_800);
    }
}
