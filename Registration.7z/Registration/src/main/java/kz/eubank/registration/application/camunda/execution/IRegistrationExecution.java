package kz.eubank.registration.application.camunda.execution;

import kz.eubank.registration.presentation.rest.model.response.DefineRouteResponse;

public interface IRegistrationExecution {

    DefineRouteResponse defineRoute(String phoneNumber, String deviceId);
}
