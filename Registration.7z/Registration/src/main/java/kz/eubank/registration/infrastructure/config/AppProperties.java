package kz.eubank.registration.infrastructure.config;

import lombok.RequiredArgsConstructor;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AppProperties {

    private final Environment environment;

    //Проверка общего лимита
    public int getVerificationLimitCount() {
        return Integer.parseInt(environment.getProperty("verification.limit.all", "10"));
    }

    //Проверка лимитов по SMS(SSMS), ИИН(SIIN), биометрии(SBIO)
    public int getLimitByTypeCount(String type) {
        return Integer.parseInt(environment.getProperty("verification.limit.type." + type, "5"));
    }

    //Текст отправки СМС/ОТП кода
    public String getSendSmsContent(String generatedCode) {
        //TODO i18n
        return environment.getProperty("sms.send.content") + generatedCode;
    }
}
