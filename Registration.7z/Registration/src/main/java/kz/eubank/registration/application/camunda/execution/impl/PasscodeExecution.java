package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.IPasscodeExecution;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PasscodeExecution implements IPasscodeExecution {

    private final ProcessEngine engine;

    @Override
    public Boolean createPasscode(String sessionId, String passcode) {
        var task = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult();
        engine.getRuntimeService().setVariable(task.getExecutionId(), "passcode", passcode);
        engine.getTaskService().complete(task.getId());
        return Boolean.TRUE;
    }
}
