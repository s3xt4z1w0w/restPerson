package kz.eubank.registration.presentation.rest.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import kz.eubank.registration.presentation.rest.model.response.SendOtpDigitalDocumentResponse;
import kz.eubank.registration.presentation.rest.model.response.UploadDigitalDocumentResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("digitalDocument")
@RequiredArgsConstructor
@Tag(name = "Цифровые документы", description = "DigitalDocumentController")
public class DigitalDocumentController {

    @Operation(summary = "Отправка ОТП", description = "sendOtp")
    @PostMapping("sendOtp")
    public ResponseEntity<?> sendOtp(@RequestHeader("User-Agent") String userAgent,
                                     @RequestHeader String language,
                                     @RequestHeader String authorization) {
        return new ResponseEntity<>(new SendOtpDigitalDocumentResponse("UploadDigitalDocument"), OK);
    }

    @Operation(summary = "Загрузка", description = "upload")
    @Parameters({
            @Parameter(name = "otpCode", description = "otpCode", required = true)
    })
    @PostMapping("upload")
    public ResponseEntity<?> upload(@RequestHeader("User-Agent") String userAgent,
                                    @RequestHeader String language,
                                    @RequestHeader String authorization,
                                    @RequestParam String otpCode) {
        return new ResponseEntity<>(new UploadDigitalDocumentResponse("StatusAnalyse"), OK);
    }
}
