package kz.eubank.registration.application.camunda.execution.impl;

import kz.eubank.registration.application.camunda.execution.ISmsExecution;
import kz.eubank.registration.presentation.rest.model.response.CheckSmsResponse;
import kz.eubank.registration.presentation.rest.model.response.SendSmsResponse;
import kz.eubank.registration.presentation.rest.util.Element2StepUtil;
import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.ProcessEngine;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SmsExecution implements ISmsExecution {

    private final ProcessEngine engine;

    @Override
    public SendSmsResponse sendSms(String sessionId) {
        var task = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult();
        engine.getTaskService().complete(task.getId());
        var generatedCode = engine.getRuntimeService()
                .getVariable(task.getExecutionId(), "generatedCode");

        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getTaskDefinitionKey();
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
        return new SendSmsResponse(nextStep);
    }

    @Override
    public CheckSmsResponse checkSms(String sessionId, String code) {
        var task = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult();
        engine.getRuntimeService().setVariable(task.getExecutionId(), "clientCode", code);
        engine.getTaskService().complete(task.getId());
        var isSmsChecked = engine.getRuntimeService()
                .getVariable(task.getExecutionId(), "isSmsChecked");

        var taskDefinitionKey = engine.getTaskService().createTaskQuery().taskAssignee(sessionId).singleResult()
                .getTaskDefinitionKey();
        var nextStep = Element2StepUtil.convert(taskDefinitionKey);
        return new CheckSmsResponse(nextStep);
    }
}
