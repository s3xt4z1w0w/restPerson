package kz.eubank.registration.infrastructure.repository.mssql.impl;

import kz.eubank.registration.domain.model.pojo.WhiteListAuthorization;
import kz.eubank.registration.domain.repository.IWhiteListAuthorizationRepository;
import kz.eubank.registration.infrastructure.entity.mapper.BaseMapper;
import kz.eubank.registration.infrastructure.repository.mssql.WhiteListAuthorizationHiberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Primary
@Component
@RequiredArgsConstructor
public class WhiteListAuthorizationRepository implements IWhiteListAuthorizationRepository {

    private final WhiteListAuthorizationHiberRepository whiteListAuthorizationHiberRepository;

    @Override
    public Optional<WhiteListAuthorization> findByMobilePhone(String mobilePhone) {
        return whiteListAuthorizationHiberRepository.findByMobilePhone(mobilePhone)
                .map(BaseMapper.INSTANCE::toDomain);
    }
}
