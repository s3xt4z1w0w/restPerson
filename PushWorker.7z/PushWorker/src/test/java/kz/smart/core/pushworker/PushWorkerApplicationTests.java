package kz.smart.core.pushworker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PushWorkerApplicationTests {

    @Test
    void contextLoads() {
    }

}
