package kz.smart.core.pushworker.andorid;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.Arrays;

import static com.google.api.client.googleapis.auth.oauth2.GoogleCredential.fromStream;

@Service
public class FCMInitializer {

    @Value("${app.firebase-configuration-file}")
    private String firebaseConfigPath;

    @Value("${app.proxy.host}")
    private String HOST;

    @Value("${app.proxy.port}")
    private int PORT;

    Logger logger = LoggerFactory.getLogger(FCMInitializer.class);



    @PostConstruct
    public void getToken() throws IOException {
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(HOST, PORT));
        HttpTransport httpTransport = new NetHttpTransport.Builder().setProxy(proxy).build();
        var googleCred = fromStream(new ClassPathResource(firebaseConfigPath)
                .getInputStream())
                .toBuilder()
                .setTransport(httpTransport)
                .build();
        var scoped = googleCred.createScoped(
                Arrays.asList(
                        "https://www.googleapis.com/auth/firebase.database",
                        "https://www.googleapis.com/auth/userinfo.email"
                )
        );
        scoped.refreshToken();
        String token = scoped.getAccessToken();
        System.out.println(token);
    }
}
