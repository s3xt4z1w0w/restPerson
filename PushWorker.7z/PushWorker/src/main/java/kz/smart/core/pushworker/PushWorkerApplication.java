package kz.smart.core.pushworker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PushWorkerApplication {

    public static void main(String[] args) {
        SpringApplication.run(PushWorkerApplication.class, args);
    }

}
