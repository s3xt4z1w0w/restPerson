package kz.smart.core.pushworker.andorid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/worker")
public class TestController {

    private final FCMService fcmService;

    public TestController(FCMService fcmService) {
        this.fcmService = fcmService;
    }

    @PostMapping
    public ResponseEntity<?> check(@RequestBody NotificationRequest request) throws ExecutionException, InterruptedException {
        fcmService.sendMessageToToken(request);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
