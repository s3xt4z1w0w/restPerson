package kz.smart.core.pushworker.andorid;

import lombok.Data;

@Data
public class NotificationResponse {
    private int status;
    private String message;
}
