//package kz.eubank.account;
//
//import org.camunda.bpm.client.ExternalTaskClient;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Service
//public class MyExternalTaskService {
//
//    @Autowired
//    private ExternalTaskClient externalTaskClient;
//
//    public void sendModel() {
////        ExternalTaskClient client = ExternalTaskClient.create().baseUrl(baseUrl).backoffStrategy(new ExponentialBackoffStrategy(500L, 2, 30000L)).
////                build();
//        externalTaskClient
//                .subscribe("one")
//                .handler((externalTask, externalTaskService) -> {
//
//                    UserModel model = new UserModel();
//                    model.setId(777);
//                    model.setName("Kasym");
//
//                    Map<String, Object> map = new HashMap<>();
//                    map.put("userModel", model);
//
//                    externalTaskService.setVariables(externalTask, map);
//
//                    externalTaskService.complete(externalTask);
//                })
//                .open();
//        ;
//    }
//}
