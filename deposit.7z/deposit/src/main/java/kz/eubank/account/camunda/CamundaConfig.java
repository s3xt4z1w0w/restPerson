//package kz.eubank.account.camunda;
//
//import org.camunda.bpm.engine.ProcessEngine;
//import org.camunda.bpm.engine.ProcessEngineConfiguration;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class CamundaConfig {
//
//    @Bean
//    public ProcessEngine processEngine() {
//        return ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration()
//                .setJdbcUrl("jdbc_url")
//                .setJdbcUsername("username")
//                .setJdbcPassword("password")
//                .setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE)
//                .buildProcessEngine();
//    }
//    }
//}
