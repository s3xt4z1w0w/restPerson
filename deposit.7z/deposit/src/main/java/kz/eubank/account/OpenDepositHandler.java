package kz.eubank.account;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.camunda.bpm.engine.variable.Variables;
import org.camunda.bpm.engine.variable.value.ObjectValue;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

import static org.camunda.bpm.engine.variable.Variables.SerializationDataFormats.JAVA;
import static org.camunda.bpm.engine.variable.Variables.SerializationDataFormats.JSON;

@ExternalTaskSubscription(
        topicName = "depositCreate",
        processDefinitionKey = "deposit_alibek",
        includeExtensionProperties = true
)
@Configuration
public class OpenDepositHandler implements ExternalTaskHandler {

    @Override
    public void execute(ExternalTask externalTask,
                        ExternalTaskService externalTaskService) {
        Model model = new Model(31, "Alibek");
        ObjectValue updatedObjectValue = Variables.objectValue(model)
                .serializationDataFormat(Variables.SerializationDataFormats.JAVA)
                .create();

        externalTaskService.complete(externalTask, Map.of("map", updatedObjectValue));
    }
}
