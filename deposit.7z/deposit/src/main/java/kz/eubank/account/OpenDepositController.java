//package kz.eubank.account;
//
//import kz.eubank.account.camunda.BaseExecution;
//import lombok.RequiredArgsConstructor;
//import org.camunda.bpm.engine.runtime.ProcessInstanceWithVariables;
//import org.camunda.bpm.engine.variable.Variables;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequiredArgsConstructor
//public class OpenDepositController {
//
//    private final BaseExecution baseExecution;
//
//    @GetMapping("/send")
//    public ResponseEntity<?> sendModel(){
//        System.out.println("Enter in controller");
//        Model model = new Model("777", "Kasym");
//        var modelValue = Variables
//                .objectValue(model)
//                .serializationDataFormat(Variables.SerializationDataFormats.JAVA)
//                .create();
//        ProcessInstanceWithVariables processInstanceWithVariables = baseExecution.startProcessAndGetVariables(modelValue);
//        return new ResponseEntity<>(processInstanceWithVariables, HttpStatus.OK);
//    }
//}
