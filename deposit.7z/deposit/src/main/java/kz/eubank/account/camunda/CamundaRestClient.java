package kz.eubank.account.camunda;

import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;

public class CamundaRestClient {

    private static final String CAMUNDA_URL = "https://camunda-v7.apps.osh-cln01-test.eub.kz/engine-rest";
    private static final String PROCESS_KEY = "deposit";




    public static void startProcess() {

        try {
            // Установка аутентификатора для HttpClient
            HttpClient client = HttpClient.newHttpClient();

            // URL для запуска процесса
            String url = CAMUNDA_URL + "/process-definition/key/"+PROCESS_KEY+"/start";

            // Переменные процесса
            Map<String, Object> variables = new HashMap<>();
            variables.put("key", "value");

            // Создание тела запроса в формате JSON
            String requestBody = String.format("{\"variables\":%s}", toJson(variables));

            // Создание HTTP-запроса POST
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString("{}"))
                    .build();

            // Отправка запроса и получение ответа
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Обработка ответа
            if (response.statusCode() == 200) {
                System.out.println("Процесс успешно запущен.");
            } else {
                System.err.println("Ошибка при запуске процесса: " + response.body());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Метод для преобразования объекта в JSON строку (можно использовать любую библиотеку для JSON)
    public static String toJson(Object obj) {
        // Здесь может быть использована ваша любимая библиотека для работы с JSON
        return "{\"key\":\"value\"}";
    }
}
