//package kz.eubank.account;
//
//import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
//import org.camunda.bpm.client.task.ExternalTaskHandler;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class MyExternalTaskConfig {
//    @Bean
//    @ExternalTaskSubscription(
//        topicName = "one",
//        processDefinitionKey = "open-deposit",
//        includeExtensionProperties = true,
//        variableNames = "defaultScore"
//    )
//    public ExternalTaskHandler externalTaskHandler(){
//        return ((externalTask, externalTaskService) -> {
//            System.out.println("Business logic");
//            externalTaskService.complete(externalTask);
//        });
//    }
//}
