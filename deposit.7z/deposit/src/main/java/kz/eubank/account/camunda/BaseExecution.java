package kz.eubank.account.camunda;

import lombok.RequiredArgsConstructor;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.runtime.ProcessInstanceWithVariables;
import org.camunda.bpm.engine.variable.value.ObjectValue;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class BaseExecution {

    private final static String BASE_MODEL_NAME = "model";
    private final static String REGISTRATION_PROCESS_NAME = "deposit_alibek";
    private final ProcessEngine engine;

    public ProcessInstanceWithVariables startProcessAndGetVariables(ObjectValue value) {
        return engine.getRuntimeService()
                .createProcessInstanceByKey(REGISTRATION_PROCESS_NAME)
                .setVariable(BASE_MODEL_NAME, value)
                .executeWithVariablesInReturn();
    }
}
