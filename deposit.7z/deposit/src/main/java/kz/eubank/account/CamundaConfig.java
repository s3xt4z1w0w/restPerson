//package kz.eubank.account;
//
//import org.camunda.bpm.client.ExternalTaskClient;
//import org.camunda.bpm.client.backoff.ExponentialBackoffStrategy;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class CamundaConfig {
//
//    @Bean
//    public ExternalTaskClient externalTaskClient() {
//        return ExternalTaskClient.create()
//                .baseUrl("https://camunda-v7.apps.osh-cln01-test.eub.kz/engine-rest")
//                .backoffStrategy(new ExponentialBackoffStrategy(500L, 2, 30000L))
//                .build();
//    }
//}
