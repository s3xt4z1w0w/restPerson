package com.example.smart4;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private final ActivityResultLauncher<String> activityResultLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback<Boolean>() {
        @Override
        public void onActivityResult(Boolean granted) {
            if (granted) {
                Toast.makeText(MainActivity.this, "Post notification permission granted!", Toast.LENGTH_SHORT).show();
                getTokenAndSendToServer();
            } else {
                Toast.makeText(MainActivity.this, "Post notification permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase App
        FirebaseApp.initializeApp(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                activityResultLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            } else {
                getTokenAndSendToServer();
            }
        } else {
            getTokenAndSendToServer();
        }
    }

    private void getTokenAndSendToServer() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Log.w("FCM", "Fetching FCM registration token failed", task.getException());
                        return;
                    }

                    // Get new FCM registration token
                    String token = task.getResult();
                    Log.d("FCM", "FCM Registration Token: " + token);

                    // Send token to your server
                    sendTokenToServer(token);
                });
    }

    private void sendTokenToServer(String token) {
        String serverUrl = "http://192.168.79.250:8080/api/device-tokens";
        MediaType contentType = MediaType.get("application/json; charset=utf-8");

        OkHttpClient client = new OkHttpClient();

        String deviceSerial = DeviceInfo.getDeviceSerial(this);
        String deviceModel = DeviceInfo.getDeviceModel();
        String deviceVersion = DeviceInfo.getOSVersion();
        String
        String appVersion = DeviceInfo.getAppVersion(this);

        String json = "{"
                + "\"token\":\"" + token + "\","
                + "\"userId\":\"12345\","  // replace with the actual user ID
                + "\"deviceSerial\":\"" + deviceSerial + "\","
                + "\"deviceModel\":\"" + deviceModel + "\","
                + "\"osVersion\":\"" + osVersion + "\","
                + "\"appVersion\":\"" + appVersion + "\""
                + "}";
        RequestBody body = RequestBody.create(json, contentType);

        Request request = new Request.Builder()
                .url(serverUrl)
                .post(body)
                .header("Content-Type", "application/json; charset=utf-8")
                .build();

        Log.d("Server Request", "Sending token to server: " + json);

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    Log.d("Server Response", "Token saved successfully");
                } else {
                    Log.d("Server Response", "Failed to save token");
                }
            }
        });
    }
}
