package org.zenwei.zenwei.application.model;


public record Pagination(int pageSize,
                         int pageNumber) {
}
