package org.zenwei.zenwei.application.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
public class Details {
    private String program;
    private String language;
    private LocalDate startDate;
    private Scholarship scholarship;
    private Price price;
}
