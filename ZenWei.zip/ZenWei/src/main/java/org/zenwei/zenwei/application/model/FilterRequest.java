package org.zenwei.zenwei.application.model;



public record FilterRequest(Filter filter,
                            Sort sort,
                            Pagination pagination) {
}
/*
{
    "filter": {
        "grant": null,
        "cityName": null,
        "programName": null,
        "language": null,
        "universityId": null,
        "degree": "Master",
        "season": "Fall",
        "scholarship": {
            "accommodation": true,
            "livingExpense": null
        }
    },
    "sort": {
        "sortField": null,
        "sortOrder": null
    },
    "pagination": {
        "pageSize": 20,
        "pageNumber": 0
    }
}
 */