package org.zenwei.zenwei.application.model;

public record City(Integer id, String name) {
}
