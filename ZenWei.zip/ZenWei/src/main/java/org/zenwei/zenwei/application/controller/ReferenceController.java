package org.zenwei.zenwei.application.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.zenwei.zenwei.application.model.FilterRequest;
import org.zenwei.zenwei.domain.service.GoodsService;

@RequiredArgsConstructor
@RestController
@RequestMapping("/reference/")
public class ReferenceController {

    private final GoodsService goodsService;

    @GetMapping("city")
    public ResponseEntity<?> getCities() {
        return new ResponseEntity<>(goodsService.getAll(), HttpStatus.OK);
    }


    @PostMapping
    public ResponseEntity<?> getPrograms(@RequestBody FilterRequest filterRequest) {
        return new ResponseEntity<>(goodsService.getPrograms(
                filterRequest), HttpStatus.OK);
    }
}
