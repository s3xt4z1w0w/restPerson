package org.zenwei.zenwei.application.model;

public record ActiveFilters(
        String grant,
        String cityName,
        String programName,
        String language,
        Integer universityId,
        String degree,
        String season,
        Scholarship scholarship) {
}
