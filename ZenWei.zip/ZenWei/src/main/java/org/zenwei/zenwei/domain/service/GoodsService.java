package org.zenwei.zenwei.domain.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jooq.*;
import org.jooq.Record;
import org.jooq.impl.DSL;
import org.springframework.stereotype.Service;
import org.zenwei.zenwei.application.model.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.jooq.DatePart.MONTH;
import static org.jooq.generated.public_.Tables.*;
import static org.jooq.impl.DSL.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class GoodsService {

    private final DSLContext dslContext;

    public List<City> getAll() {
        return dslContext.select().from(CITY).
                fetch()
                .stream()
                .map(record -> new City(
                        record.getValue(CITY.CITY_ID),
                        record.getValue(CITY.NAME)))
                .collect(Collectors.toList());
    }

    public FilterResponse getPrograms(FilterRequest filterRequest) {
        Condition condition = createFilterCondition(filterRequest);
        SortField<?> orderBy = createSortField(filterRequest);

        List<Record> records = fetchRecords(condition, orderBy, filterRequest);
        long totalItems = fetchTotalCount(condition);

        int totalPages = (int) Math.ceil((double) totalItems / filterRequest.pagination().pageSize());
        if (totalPages != 0) {
            totalPages -= 1;
        }
        List<University> universities = records.stream()
                .map(this::mapToUniversity)
                .collect(Collectors.toList());

        return buildFilterResponse(filterRequest, totalItems, totalPages, universities);
    }

    private Condition createFilterCondition(FilterRequest filterRequest) {
        Condition condition = DSL.trueCondition();

        if (filterRequest.filter().grant() != null && !filterRequest.filter().grant().isEmpty() && "full".equals(filterRequest.filter().grant())) {
            condition = condition.and(SCHOLARSHIP.ISACCOMMODATION.eq(true)).and(SCHOLARSHIP.ISLIVINGEXPENSE.eq(true));
        }
        if (filterRequest.filter().cityName() != null && !filterRequest.filter().cityName().isEmpty()) {
            condition = condition.and(CITY.NAME.eq(filterRequest.filter().cityName()));
        }
        if (filterRequest.filter().programName() != null && !filterRequest.filter().programName().isEmpty()) {
            condition = condition.and(PROGRAM.NAME.likeIgnoreCase("%" + filterRequest.filter().programName() + "%"));
        }
        if (filterRequest.filter().language() != null && !filterRequest.filter().language().isEmpty()) {
            condition = condition.and(PROGRAM.LANGUAGE.eq(filterRequest.filter().language()));
        }
        if (filterRequest.filter().universityId() != null) {
            condition = condition.and(UNIVERSITY.UNIVERSITY_ID.eq(filterRequest.filter().universityId()));
        }
        if (filterRequest.filter().degree() != null && !filterRequest.filter().degree().isEmpty()) {
            condition = condition.and(PROGRAM.DEGREE.eq(filterRequest.filter().degree()));
        }
        if (filterRequest.filter().scholarship().accommodation() != null) {
            condition = condition.and(SCHOLARSHIP.ISACCOMMODATION.eq(filterRequest.filter().scholarship().accommodation()));
        }
        if (filterRequest.filter().scholarship().livingExpense() != null) {
            condition = condition.and(SCHOLARSHIP.ISLIVINGEXPENSE.eq(filterRequest.filter().scholarship().livingExpense()));
        }
        if (filterRequest.filter().season() != null && !filterRequest.filter().season().isEmpty()) {
            condition = condition.and(createSeasonCondition(filterRequest.filter().season()));
        }

        return condition;
    }

    private Condition createSeasonCondition(String season) {
        return switch (season) {
            case "Spring" -> extract(PROGRAM.START_DATE, DatePart.MONTH).in(3, 4, 5);
            case "Summer" -> extract(PROGRAM.START_DATE, DatePart.MONTH).in(6, 7, 8);
            case "Fall" -> extract(PROGRAM.START_DATE, DatePart.MONTH).in(9, 10, 11);
            case "Winter" -> extract(PROGRAM.START_DATE, DatePart.MONTH).in(12, 1, 2);
            default -> DSL.noCondition();
        };
    }

    private List<Record> fetchRecords(Condition condition, SortField<?> orderBy, FilterRequest filterRequest) {
        return dslContext.select()
                .from(CITY)
                .join(UNIVERSITY).on(UNIVERSITY.CITY_ID.eq(CITY.CITY_ID))
                .join(PROGRAM).on(PROGRAM.UNIVERSITY_ID.eq(UNIVERSITY.UNIVERSITY_ID))
                .join(COST).on(COST.PROGRAM_ID.eq(PROGRAM.PROGRAM_ID))
                .join(SCHOLARSHIP).on(SCHOLARSHIP.PROGRAM_ID.eq(PROGRAM.PROGRAM_ID))
                .where(condition)
                .orderBy(orderBy)
                .offset(filterRequest.pagination().pageNumber() * filterRequest.pagination().pageSize())
                .limit(filterRequest.pagination().pageSize())
                .fetch();
    }

    private long fetchTotalCount(Condition condition) {
        return dslContext.fetchCount(CITY
                .join(UNIVERSITY).on(UNIVERSITY.CITY_ID.eq(CITY.CITY_ID))
                .join(PROGRAM).on(PROGRAM.UNIVERSITY_ID.eq(UNIVERSITY.UNIVERSITY_ID))
                .join(COST).on(COST.PROGRAM_ID.eq(PROGRAM.PROGRAM_ID))
                .join(SCHOLARSHIP).on(SCHOLARSHIP.PROGRAM_ID.eq(PROGRAM.PROGRAM_ID))
                .where(condition));
    }

    private University mapToUniversity(Record record) {
        Scholarship scholarship = new Scholarship(
                record.getValue(SCHOLARSHIP.ISACCOMMODATION),
                record.getValue(SCHOLARSHIP.ISLIVINGEXPENSE));
        Price price = new Price(
                record.getValue(COST.TUITION),
                record.getValue(COST.ACCOMMODATION_MIN),
                record.getValue(COST.ACCOMMODATION_MAX),
                record.getValue(COST.LIVING_EXPENSES_MIN),
                record.getValue(COST.LIVING_EXPENSES_MAX));
        Details details = new Details(
                record.getValue(PROGRAM.NAME),
                record.getValue(PROGRAM.LANGUAGE),
                record.getValue(PROGRAM.START_DATE),
                scholarship,
                price);
        return new University(
                record.getValue(UNIVERSITY.UNIVERSITY_ID),
                record.getValue(UNIVERSITY.NAME),
                record.getValue(CITY.NAME),
                details);
    }

    private FilterResponse buildFilterResponse(FilterRequest filterRequest, long totalItems, int totalPages, List<University> universities) {
        return new FilterResponse(
                new ActiveFilters(
                        filterRequest.filter().grant(),
                        filterRequest.filter().cityName(),
                        filterRequest.filter().programName(),
                        filterRequest.filter().language(),
                        filterRequest.filter().universityId(),
                        filterRequest.filter().degree(),
                        filterRequest.filter().season(),
                        new Scholarship(
                                filterRequest.filter().scholarship().accommodation(),
                                filterRequest.filter().scholarship().livingExpense()
                        )),
                new Sort(
                        filterRequest.sort().field(),
                        filterRequest.sort().order()),
                new PaginationActive(
                        filterRequest.pagination().pageNumber(),
                        totalItems,
                        totalPages),
                universities);
    }


    private SortField<?> createSortField(FilterRequest filterRequest) {
        String sortField = filterRequest.sort().field();
        if (sortField == null || sortField.isEmpty()) {
            sortField = CITY.NAME.getName();
        }

        Field<?> field = switch (sortField) {
            case "cityName" -> CITY.NAME;
            case "universityName" -> UNIVERSITY.NAME;
            case "price" -> COST.TUITION;
            case "programName", default -> PROGRAM.NAME;
        };

        return "desc".equalsIgnoreCase(filterRequest.sort().order())
                ? field.desc()
                : field.asc();
    }
}
