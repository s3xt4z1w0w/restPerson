package org.zenwei.zenwei.application.model;


import java.util.List;

public record FilterResponse(ActiveFilters activeFilters,
                             Sort sort,
                             PaginationActive pagination,
                             List<University> universities) {

}
