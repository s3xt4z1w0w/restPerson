package org.zenwei.zenwei;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZenWeiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZenWeiApplication.class, args);
	}

}
