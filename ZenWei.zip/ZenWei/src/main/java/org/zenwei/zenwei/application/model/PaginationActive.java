package org.zenwei.zenwei.application.model;

public record PaginationActive(int currentPage,
                               long totalItems,
                               int totalPages) {
}
