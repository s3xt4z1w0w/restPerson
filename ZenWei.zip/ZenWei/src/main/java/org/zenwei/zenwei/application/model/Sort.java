package org.zenwei.zenwei.application.model;


public record Sort(String field,
                   String order) {
}
