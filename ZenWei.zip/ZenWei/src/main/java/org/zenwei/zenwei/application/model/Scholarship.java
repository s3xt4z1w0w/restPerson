package org.zenwei.zenwei.application.model;


public record Scholarship(Boolean accommodation,
                          Boolean livingExpense)  {

}
