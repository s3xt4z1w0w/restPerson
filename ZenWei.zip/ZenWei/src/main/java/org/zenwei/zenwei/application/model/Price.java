package org.zenwei.zenwei.application.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
public class Price {
    private BigDecimal tuition;
    private BigDecimal accommodationMin;
    private BigDecimal accommodationMax;
    private BigDecimal livingExpenseMin;
    private BigDecimal livingExpenseMax;
}
