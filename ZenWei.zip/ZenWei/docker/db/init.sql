-- CREATE TABLE country (
--   country_id SERIAL PRIMARY KEY,
--   name VARCHAR(255) NOT NULL
-- );
--
-- CREATE TABLE city (
--   city_id SERIAL PRIMARY KEY,
--   name VARCHAR(255) NOT NULL,
--   country_id INT,
--   FOREIGN KEY (country_id) REFERENCES country(country_id)
-- );
--
-- CREATE TABLE university (
--   university_id SERIAL PRIMARY KEY,
--   name VARCHAR(255) NOT NULL,
--   city_id INT,
--   FOREIGN KEY (city_id) REFERENCES city(city_id)
-- );
--
-- CREATE TABLE program (
--   program_id SERIAL PRIMARY KEY,
--   university_id INT NOT NULL,
--   name VARCHAR(255) NOT NULL,
--   degree VARCHAR(255) NOT NULL,
--   language VARCHAR(255) NOT NULL,
--   start_date DATE NOT NULL,
--   duration VARCHAR(255) NOT NULL,
--   speciality VARCHAR(255) NOT NULL,
--   FOREIGN KEY (university_id) REFERENCES university(university_id)
-- );
--
-- CREATE TABLE grant (
--   grant_id SERIAL PRIMARY KEY,
--   program_id INT NOT NULL,
--   type VARCHAR(255) NOT NULL,
--   coverage VARCHAR(255),
--   amount VARCHAR(255),
--   deadline DATE,
--   comments TEXT,
--   FOREIGN KEY (program_id) REFERENCES program(program_id)
-- );
--
-- CREATE TABLE cost (
--   cost_id SERIAL PRIMARY KEY,
--   program_id INT NOT NULL,
--   tuition DECIMAL(10,2) NOT NULL,
--   dormitory_cost DECIMAL(10,2),
--   registration_fee DECIMAL(10,2),
--   insurance_cost DECIMAL(10,2),
--   medical_examination_cost DECIMAL(10,2),
--   literature_cost DECIMAL(10,2),
--   additional_costs DECIMAL(10,2),
--   accommodation_min DECIMAL(10,2),
--   accommodation_max DECIMAL(10,2),
--   living_expenses_min DECIMAL(10,2),
--   living_expenses_max DECIMAL(10,2),
--   FOREIGN KEY (program_id) REFERENCES program(program_id)
-- );
--
-- CREATE TABLE requirement (
--   requirement_id SERIAL PRIMARY KEY,
--   program_id INT NOT NULL,
--   HSK VARCHAR(255),
--   IELTS VARCHAR(255),
--   GPA DECIMAL(3,2),
--   documents TEXT,
--   FOREIGN KEY (program_id) REFERENCES program(program_id)
-- );
--
-- CREATE TABLE translation (
--   translation_id SERIAL PRIMARY KEY,
--   table_name VARCHAR(255) NOT NULL,
--   column_name VARCHAR(255) NOT NULL,
--   foreign_key INT NOT NULL,
--   language_code CHAR(2) NOT NULL,
--   text TEXT NOT NULL,
--   UNIQUE (table_name, column_name, foreign_key, language_code)
-- );
--
-- CREATE TABLE update_log (
--   id SERIAL PRIMARY KEY,
--   table_name VARCHAR(255),
--   last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );
--
-- --создание тригеров для обновление последних записей в БД. Нужно дописать все
--
-- --university
-- CREATE OR REPLACE FUNCTION update_university()
-- RETURNS TRIGGER AS $$
-- BEGIN
--     UPDATE update_log
--     SET last_updated = CURRENT_TIMESTAMP
--     WHERE table_name = 'university';
-- RETURN NEW;
-- END;
-- $$ LANGUAGE plpgsql;
--
-- CREATE TRIGGER update_university_timestamp
-- AFTER INSERT OR UPDATE OR DELETE ON university
-- FOR EACH ROW EXECUTE PROCEDURE update_university();
--
--
-- --city
-- CREATE OR REPLACE FUNCTION update_city()
-- RETURNS TRIGGER AS $$
-- BEGIN
--     UPDATE update_log
--     SET last_updated = CURRENT_TIMESTAMP
--     WHERE table_name = 'city';
-- RETURN NEW;
-- END;
-- $$ LANGUAGE plpgsql;
--
-- CREATE TRIGGER update_university_timestamp
-- AFTER INSERT OR UPDATE OR DELETE ON city
-- FOR EACH ROW EXECUTE PROCEDURE update_city();
--


CREATE TABLE country (
                         country_id SERIAL PRIMARY KEY,
                         name VARCHAR(255) NOT NULL
);

CREATE TABLE city (
                      city_id SERIAL PRIMARY KEY,
                      name VARCHAR(255) NOT NULL,
                      country_id INT,
                      FOREIGN KEY (country_id) REFERENCES country(country_id)
);

CREATE TABLE university (
                            university_id SERIAL PRIMARY KEY,
                            name VARCHAR(255) NOT NULL,
                            city_id INT,
                            FOREIGN KEY (city_id) REFERENCES city(city_id)
);

CREATE TABLE program (
                         program_id SERIAL PRIMARY KEY,
                         university_id INT NOT NULL,
                         name VARCHAR(255) NOT NULL,
                         degree VARCHAR(255) NOT NULL,
                         language VARCHAR(255) NOT NULL,
                         start_date DATE NOT NULL,
                         duration VARCHAR(255) NOT NULL,
                         speciality VARCHAR(255) NOT NULL,
                         FOREIGN KEY (university_id) REFERENCES university(university_id)
);

CREATE TABLE scholarship (
                       scholarship_id SERIAL PRIMARY KEY,
                       program_id INT NOT NULL,
                       type VARCHAR(255) NOT NULL,
                       coverage VARCHAR(255),
                       amount VARCHAR(255),
                       deadline DATE,
                       comments TEXT,
                       FOREIGN KEY (program_id) REFERENCES program(program_id)
);

CREATE TABLE cost (
                      cost_id SERIAL PRIMARY KEY,
                      program_id INT NOT NULL,
                      tuition DECIMAL(10,2) NOT NULL,
                      dormitory_cost DECIMAL(10,2),
                      registration_fee DECIMAL(10,2),
                      insurance_cost DECIMAL(10,2),
                      medical_examination_cost DECIMAL(10,2),
                      literature_cost DECIMAL(10,2),
                      additional_costs DECIMAL(10,2),
                      accommodation_min DECIMAL(10,2),
                      accommodation_max DECIMAL(10,2),
                      living_expenses_min DECIMAL(10,2),
                      living_expenses_max DECIMAL(10,2),
                      FOREIGN KEY (program_id) REFERENCES program(program_id)
);

CREATE TABLE requirement (
                             requirement_id SERIAL PRIMARY KEY,
                             program_id INT NOT NULL,
                             HSK VARCHAR(255),
                             IELTS VARCHAR(255),
                             GPA DECIMAL(3,2),
                             documents TEXT,
                             FOREIGN KEY (program_id) REFERENCES program(program_id)
);

CREATE TABLE translation (
                             translation_id SERIAL PRIMARY KEY,
                             table_name VARCHAR(255) NOT NULL,
                             column_name VARCHAR(255) NOT NULL,
                             foreign_key INT NOT NULL,
                             language_code CHAR(2) NOT NULL,
                             text TEXT NOT NULL,
                             UNIQUE (table_name, column_name, foreign_key, language_code)
);

CREATE TABLE update_log (
                            id SERIAL PRIMARY KEY,
                            table_name VARCHAR(255),
                            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

--создание тригеров для обновление последних записей в БД. Нужно дописать все

--university
CREATE OR REPLACE FUNCTION update_university()
RETURNS TRIGGER AS $$
BEGIN
UPDATE update_log
SET last_updated = CURRENT_TIMESTAMP
WHERE table_name = 'university';
RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_university_timestamp
    AFTER INSERT OR UPDATE OR DELETE ON university
    FOR EACH ROW EXECUTE PROCEDURE update_university();


--city
CREATE OR REPLACE FUNCTION update_city()
RETURNS TRIGGER AS $$
BEGIN
UPDATE update_log
SET last_updated = CURRENT_TIMESTAMP
WHERE table_name = 'city';
RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_university_timestamp
    AFTER INSERT OR UPDATE OR DELETE ON city
    FOR EACH ROW EXECUTE PROCEDURE update_city();



