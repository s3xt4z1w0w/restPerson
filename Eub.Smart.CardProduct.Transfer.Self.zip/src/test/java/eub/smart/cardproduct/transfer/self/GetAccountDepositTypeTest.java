package eub.smart.cardproduct.transfer.self;

import eub.smart.cardproduct.transfer.self.domain.model.DepositAccount;
import eub.smart.cardproduct.transfer.self.domain.repository.DepositAccountRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.impl.GetAccountDepositTypeUseCaseImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static eub.smart.cardproduct.transfer.self.core.constant.AccountType.SAVL;
import static eub.smart.cardproduct.transfer.self.core.constant.AccountType.SAVS;

public class GetAccountDepositTypeTest {
    DepositAccountRepository depositAccountRepository = Mockito.mock(DepositAccountRepository.class);
    GetAccountDepositTypeUseCaseImpl useCase = new GetAccountDepositTypeUseCaseImpl(depositAccountRepository);

    @Test
    public void whenShortExpectValueSavs() {
        DepositAccount shortTermAccount = new DepositAccount("M", 7);
        Mockito.when(depositAccountRepository.findByAccountIdOrException(Mockito.anyLong())).thenReturn(shortTermAccount);
        String invoke = useCase.invoke(123L);
        Assertions.assertEquals(SAVS, invoke);
    }

    @Test
    public void whenLongExpectValueSavl() {
        DepositAccount shortTermAccount = new DepositAccount("M", 25);
        Mockito.when(depositAccountRepository.findByAccountIdOrException(Mockito.anyLong())).thenReturn(shortTermAccount);
        String invoke = useCase.invoke(123L);
        Assertions.assertEquals(SAVL, invoke);
    }
}
