package eub.smart.cardproduct.transfer.self;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.use_case.impl.FormSmsMessageUseCaseImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.SMS_MESSAGE_DONE;
import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.SMS_MESSAGE_RJCT;
import static eub.smart.cardproduct.transfer.self.core.constant.CurrencyCode.KZT;
import static eub.smart.cardproduct.transfer.self.core.constant.DocStatus.*;

public class FormSmsMessageTest {

//    MessageSource messageSource = Mockito.mock(MessageSource.class);
//    FormSmsMessageUseCaseImpl useCase = new FormSmsMessageUseCaseImpl(messageSource);
//    Long finDocId = 123L;
//    BigDecimal amount = new BigDecimal("7");
//    Object[] rjctArgs = formRjctArgs(finDocId, amount, KZT);
//    Object[] doneArgs = formDoneArgs(amount, KZT);
//
//    @Test
//    public void whenRjctExpectValueRjctText() {
//        Mockito.when(messageSource.getMessage(SMS_MESSAGE_RJCT, rjctArgs, LangUtil.RU)).thenReturn(SMS_MESSAGE_RJCT);
//        String message = useCase.invoke(finDocId, RJCT, amount, KZT);
//
//        Assertions.assertEquals(message, SMS_MESSAGE_RJCT);
//    }
//
//    @Test
//    public void whenDoneExpectValueDoneText() {
//        Mockito.when(messageSource.getMessage(SMS_MESSAGE_DONE, doneArgs, LangUtil.RU)).thenReturn(SMS_MESSAGE_DONE);
//        String message = useCase.invoke(finDocId, DONE, amount, KZT);
//
//        Assertions.assertEquals(message, SMS_MESSAGE_DONE);
//    }
//
//    @Test
//    public void whenInvalidDocStatusExpectValueSelfException() {
//        try {
//            Mockito.when(messageSource.getMessage(SMS_MESSAGE_DONE, doneArgs, LangUtil.RU)).thenReturn(SMS_MESSAGE_DONE);
//            String message = useCase.invoke(finDocId, DRFT, amount, KZT);
//        } catch (SelfException e) {
//            Assertions.assertEquals(e.getCode(), E_LG_802);
//        }
//    }
//
//    private Object[] formRjctArgs(Long finDocId, BigDecimal amount, String currency) {
//        var dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
//        var operationDate = dateTimeFormatter.format(LocalDate.now());
//        return new Object[]{finDocId, operationDate, amount, currency};
//    }
//
//    private Object[] formDoneArgs(BigDecimal amount, String currency) {
//        return new Object[]{amount, currency};
//    }
}
