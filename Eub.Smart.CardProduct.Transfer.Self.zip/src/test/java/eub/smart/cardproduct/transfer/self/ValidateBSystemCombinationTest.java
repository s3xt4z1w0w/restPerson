package eub.smart.cardproduct.transfer.self;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.use_case.impl.ValidateBSystemCombinationUseCaseImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.self.core.constant.BSystemType.*;

public class ValidateBSystemCombinationTest {

    ValidateBSystemCombinationUseCaseImpl useCase = new ValidateBSystemCombinationUseCaseImpl();

    @Test
    public void whenValidBSystemExpectValueVoid() {
        useCase.invoke(WAY4, RSBK);
    }

    @Test
    public void whenInvalidBSystemExpectValueSelfException() {
        try {
            useCase.invoke(WAY4, SMBK);
        } catch (SelfException e) {
            Assertions.assertEquals(e.getCode(), E_LG_802);
        }
    }
}
