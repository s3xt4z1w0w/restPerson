package eub.smart.cardproduct.transfer.self;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.Client;
import eub.smart.cardproduct.transfer.self.domain.model.NewTransferClient;
import eub.smart.cardproduct.transfer.self.domain.repository.ClientRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.CorporationRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.PersonRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.impl.GetTransferClientUseCaseImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_801;


public class GetTransferClientTest {
    ClientRepository clientRepository = Mockito.mock(ClientRepository.class);
    PersonRepository personRepository = Mockito.mock(PersonRepository.class);
    CorporationRepository corporationRepository = Mockito.mock(CorporationRepository.class);
    GetTransferClientUseCaseImpl useCase = new GetTransferClientUseCaseImpl((PersonRepository) personRepository,
                                                                            (CorporationRepository) corporationRepository,
                                                                            (ClientRepository) clientRepository);

    @Test
    public void whenCorporationClientExpectValueShortText() {
        Client corporationClient = new Client();
        corporationClient.setCorporationId(1L);
        Mockito.when(clientRepository.findByAccountNumberOrException(Mockito.anyString())).thenReturn(corporationClient);

        NewTransferClient corporationTransferClient = new NewTransferClient();
        Mockito.when(corporationRepository.findNewTransferClientOrException(Mockito.anyLong())).thenReturn(corporationTransferClient);

        NewTransferClient result = useCase.invoke("accountNumber");
        Assertions.assertEquals(corporationTransferClient, result);
    }

    @Test
    public void whenPersonClientExpectValueShortText() {
        Client personClient = new Client();
        personClient.setCorporationId(2L);
        Mockito.when(clientRepository.findByAccountNumberOrException(Mockito.anyString())).thenReturn(personClient);

        NewTransferClient personTransferClient = new NewTransferClient();
        Mockito.when(corporationRepository.findNewTransferClientOrException(Mockito.anyLong())).thenReturn(personTransferClient);

        NewTransferClient result = useCase.invoke("accountNumber");
        Assertions.assertEquals(personTransferClient, result);
    }

    @Test
    public void whenInvalidClientExpectValueShortText() {
        try {
            Client unknownClient = new Client();
            Mockito.when(clientRepository.findByAccountNumberOrException(Mockito.anyString())).thenReturn(unknownClient);
            useCase.invoke("accountNumber");
        } catch (SelfException e) {
            Assertions.assertEquals(E_LG_801, e.getCode());
        }

    }
}
