package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToWay4;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;

public interface TransferWay4ToWay4ReverseDebitUseCase {

    TransferWay4ToWay4 invoke(UfxTransferRequest ufxTransferRequest);
}
