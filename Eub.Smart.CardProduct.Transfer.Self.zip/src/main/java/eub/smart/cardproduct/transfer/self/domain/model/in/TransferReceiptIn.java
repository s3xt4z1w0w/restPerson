package eub.smart.cardproduct.transfer.self.domain.model.in;

public record TransferReceiptIn(
        Long finDocId,
        String finDocType
) {
}
