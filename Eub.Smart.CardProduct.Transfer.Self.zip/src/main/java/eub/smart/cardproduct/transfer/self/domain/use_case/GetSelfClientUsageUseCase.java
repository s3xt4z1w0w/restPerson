package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;

public interface GetSelfClientUsageUseCase {

    Usage invoke(String limitFinDoc, String limitDay, String limitNight, String correlationId);

    Usage invoke(String limitFinDoc, String correlationId);
}
