package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbk;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferWay4ToRsbkDebitUseCase;
import eub.smart.cardproduct.transfer.self.domain.mapper.TransferWay4ToRsbkDebitMapper;

public class TransferWay4ToRsbkDebitUseCaseImpl implements TransferWay4ToRsbkDebitUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferWay4ToRsbkDebitUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferWay4ToRsbk invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn) {
        var request = TransferWay4ToRsbkDebitMapper.createRequest(finDocData, senderData, receiverData, rrnBrrn);
        var response = transferSelfProtoRepository.transferWay4ToRsbkDebit(request);
        return new TransferWay4ToRsbk(request, response);
    }
}
