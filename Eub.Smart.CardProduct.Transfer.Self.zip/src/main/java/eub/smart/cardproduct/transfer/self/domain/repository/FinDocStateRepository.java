package eub.smart.cardproduct.transfer.self.domain.repository;

public interface FinDocStateRepository {

    void saveFinDocStatus(String status, Long finDocId);
}
