package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.FinDocInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.FinDocHiberRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.FinDocMapper.toDomainModel;

@Primary
@Repository
public class FinDocRepositoryImpl implements FinDocRepository {

    private final NamedParameterJdbcTemplate template;
    private final FinDocHiberRepository finDocHiberRepository;
    private final InfrastructureMapper mapper;

    public FinDocRepositoryImpl(NamedParameterJdbcTemplate template,
                                FinDocHiberRepository finDocHiberRepository,
                                InfrastructureMapper mapper) {
        this.template = template;
        this.finDocHiberRepository = finDocHiberRepository;
        this.mapper = mapper;
    }

    @Override
    public FinDoc save(FinDoc finDoc) {
        var entity = mapper.toEntity(finDoc);
        var saved = finDocHiberRepository.save(entity);
        return mapper.toDomain(saved);
    }

    @Override
    public Optional<FinDocInfo> findFinDocAcc(Long finDocId, String senderIin, String correlationId) {
        String sql = """ 
                select F.FinDoc_ID              as finDocId,
                       F.FinDocType_IDREF       as finDocType,
                       T.KNP_IDREF              as knpCode,
                       F.Fee                    as feeAmount,
                       F.DateSigned             as dateSigned,
                       T.Receiver_IIN           as receiverIin,
                       BSCS.BSystem_IDREF       as senderBSystem,
                       BSCR.BSystem_IDREF       as receiverBSystem,
                       AccS.Number              as senderAccountNumber,
                       AccR.Number              as receiverAccountNumber,
                       F.Amount                 as senderAmount,
                       T.Receiver_Amount        as receiverAmount,
                       F.Currency               as senderCurrency,
                       T.Receiver_Currency      as receiverCurrency,
                       AccS.IsResident          as senderFlagResident,
                       AccR.IsResident          as receiverFlagResident,
                       BSCS.BSystemClient_Title as senderFullname,
                       BSCR.BSystemClient_Title as receiverFullname,
                       AccS.AccountType_IDREF   as senderAccountType,
                       AccR.AccountType_IDREF   as receiverAccountType,
                       AccS.IsMultiCurrency     as senderFlagMultiCurrency,
                       AccR.IsMultiCurrency     as receiverFlagMultiCurrency,
                       AccS.AccountStatus_IDREF as senderAccountStatus,
                       AccR.AccountStatus_IDREF as receiverAccountStatus,
                       AccS.Account_IDREF       as senderAccountIdRef,
                       AccR.Account_IDREF       as receiverAccountIdRef,
                       AccS.Account_OUTREF      as senderAccountOutRef,
                       AccR.Account_OUTREF      as receiverAccountOutRef              
                from FinDoc F
                         join Transfer T on F.FinDoc_ID = T.FinDoc_IDREF
                         join Account AccS on F.Account_IDREF = AccS.Account_ID
                         join BSystemClient BSCS on AccS.BSystemClient_IDREF = BSCS.BSystemClient_ID
                         join Account AccR on AccR.Number = T.Receiver_Account
                         join BSystemClient BSCR on AccR.BSystemClient_IDREF = BSCR.BSystemClient_ID
                where F.FinDoc_ID = :finDocId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(row -> toDomainModel(row, senderIin, correlationId));
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": FinDocRepository findFinDocAccOrException");
        }
    }

    @Override
    public FinDocInfo findFinDocAccOrException(Long finDocId, String senderIin, String correlationId) {
        return findFinDocAcc(finDocId, senderIin, correlationId)
                .orElseThrow(() -> new SelfException(E_DB_600, ": FinDocRepository findFinDocAccOrException"));
    }

    @Override
    public Optional<FinDoc> findById(Long finDocId) {
        var optEntity = finDocHiberRepository.findById(finDocId);
        if (optEntity.isPresent()) {
            var entity = optEntity.get();
            return Optional.of(mapper.toDomain(entity));
        } else {
            return Optional.empty();
        }
    }

    @Override
    public FinDoc findByIdOrException(Long finDocId) {
        return findById(finDocId)
                .orElseThrow(() -> new SelfException(E_DB_600, ": FinDocRepository findByIdOrException"));
    }
}
