package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbkRequest;

import java.util.Optional;

public interface TransferRsbkToRsbkRepository {

    Optional<TransferRsbkToRsbkRequest> findByFinDocId(Long finDocId, String iin);

    TransferRsbkToRsbkRequest findByFinDocIdOrException(Long finDocId, String iin);
}
