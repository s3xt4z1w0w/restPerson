package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.AccountInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.AccountRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.AccountMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.CommonMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Repository
public class AccountRepositoryImpl implements AccountRepository {

    private final NamedParameterJdbcTemplate template;

    public AccountRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<AccountInfo> findByPhoneNumber(String phoneNumber) {
        String sql = """
                select a.Account_ID        as accountId,
                       a.AccountType_IDREF as accountType,
                       a.Currency          as currency,
                       a.number            as number,
                       a.IsMultiCurrency   as multiCurrencyFlag,
                       a.Account_IDREF     as accountIdRef,
                       bc.Client_IDREF     as clientIdRef,
                       a.IsResident        as residentFlag
                from Account a
                join BSystemClient bc on a.BSystemClient_IDREF = bc.BSystemClient_ID
                join Client c on c.Client_ID = bc.Client_IDREF
                join Person p on p.Person_ID = c.Person_IDREF
                join [User] u on u.Person_IDREF = p.Person_ID
                join map_User_AuthTool m on m.User_IDREF = u.User_ID
                join AuthTool att on att.AuthTool_ID = m.AuthTool_IDREF
                join AuthSMS ats on ats.AuthTool_IDREF = att.AuthTool_ID
                join MobilePhone mp on mp.MobilePhone_ID = ats.MobilePhone_IDREF
                where mp.MobilePhone  = :phoneNumber and AuthToolStatus_IDREF = 'ACTV';
                 """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("phoneNumber", phoneNumber));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(AccountMapper::toNewAccountInfo);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": AccountRepository findByPhoneNumber");
        }
    }

    @Override
    public Optional<AccountInfo> findByNumber(String number) {
        String sql = """ 
                select a.Account_ID        as accountId,
                       a.AccountType_IDREF as accountType,
                       a.Currency          as currency,
                       a.Number            as number,
                       a.IsMultiCurrency   as multiCurrencyFlag,
                       a.Account_IDREF     as accountIdRef,
                       BSC.Client_IDREF    as clientIdRef,
                       a.IsResident        as residentFlag
                from Account a
                join BSystemClient BSC on a.BSystemClient_IDREF = BSC.BSystemClient_ID
                where A.Number = :number
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("number", number));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(AccountMapper::toNewAccountInfo);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": AccountRepository findByNumber");
        }
    }

    @Override
    public AccountInfo findByNumberOrException(String accountNumber) {
        return findByNumber(accountNumber)
                .orElseThrow(() -> new SelfException(E_DB_600, ": AccountRepository findByNumberOrException"));
    }

    @Override
    public AccountInfo findByPhoneNumberOrException(String phoneNumber) {
        return findByPhoneNumber(phoneNumber)
                .orElseThrow(() -> new SelfException(E_DB_600, ": AccountRepository findByPhoneNumberOrException"));
    }


    @Override
    public Optional<String> getAccountStatus(String accountNumber) {
        String sql = """ 
                select A.AccountStatus_IDREF as type
                from Account A
                where A.Number = :accountNumber
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("accountNumber", accountNumber));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(CommonMapper::getString);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": AccountRepository getAccountStatus");
        }
    }

    @Override
    public String getAccountStatusOrException(String accountNumber) {
        return getAccountStatus(accountNumber)
                .orElseThrow(() -> new SelfException(E_DB_600, ": AccountRepository getAccountStatusOrException"));
    }
}
