package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.MultiToMultiAccountInfo;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class MultiToMultiAccountInfoMapper {

    public static MultiToMultiAccountInfo toDomainModel(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);

        MultiToMultiAccountInfo model = new MultiToMultiAccountInfo();
        model.setSenderFlagMultiCurrency(scanner.getBoolean("senderFlagMultiCurrency"));
        model.setReceiverFlagMultiCurrency(scanner.getBoolean("receiverFlagMultiCurrency"));
        model.setSenderIdRef(scanner.getLong("senderIdRef"));
        model.setReceiverIdRef(scanner.getLong("receiverIdRef"));
        model.setSenderAccNumber(scanner.getString("senderAccNumber"));
        model.setReceiverAccNumber(scanner.getString("receiverAccNumber"));
        return model;
    }
}
