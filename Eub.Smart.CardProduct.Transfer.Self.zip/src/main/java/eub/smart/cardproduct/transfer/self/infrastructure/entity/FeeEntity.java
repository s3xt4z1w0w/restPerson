package eub.smart.cardproduct.transfer.self.infrastructure.entity;

import javax.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "Fee")
public class FeeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "Fee_ID", nullable = false)
    private Long id;

    @Column(name = "Fee_Title", nullable = false)
    private String title;

    @Column(name = "Term_OUTREF")
    private Long termId;

    @Column(name = "Currency", nullable = false)
    private String currency;

    @Column(name = "InheritCurrency", nullable = false)
    private Boolean inheritCurrency;

    @Column(name = "Fee_Fixed", nullable = false, scale = 4)
    private BigDecimal feeFixed;

    @Column(name = "Fee_PerCent", scale = 4)
    private BigDecimal feePercent;

    @Column(name = "Fee_PerCent_Min", nullable = false, scale = 4)
    private BigDecimal feePercentMin;

    @Column(name = "Fee_PerCent_Max", nullable = false, scale = 4)
    private BigDecimal feePercentMax;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getTermId() {
        return termId;
    }

    public void setTermId(Long termId) {
        this.termId = termId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Boolean getInheritCurrency() {
        return inheritCurrency;
    }

    public void setInheritCurrency(Boolean inheritCurrency) {
        this.inheritCurrency = inheritCurrency;
    }

    public BigDecimal getFeeFixed() {
        return feeFixed;
    }

    public void setFeeFixed(BigDecimal feeFixed) {
        this.feeFixed = feeFixed;
    }

    public BigDecimal getFeePercent() {
        return feePercent;
    }

    public void setFeePercent(BigDecimal feePercent) {
        this.feePercent = feePercent;
    }

    public BigDecimal getFeePercentMin() {
        return feePercentMin;
    }

    public void setFeePercentMin(BigDecimal feePercentMin) {
        this.feePercentMin = feePercentMin;
    }

    public BigDecimal getFeePercentMax() {
        return feePercentMax;
    }

    public void setFeePercentMax(BigDecimal feePercentMax) {
        this.feePercentMax = feePercentMax;
    }

    @Override
    public String toString() {
        return "Fee{" +
                "id=" + id +
                ", title=" + title +
                ", termId=" + termId +
                ", currency=" + currency +
                ", inheritCurrency=" + inheritCurrency +
                ", feeFixed=" + feeFixed +
                ", feePercent=" + feePercent +
                ", feePercentMin=" + feePercentMin +
                ", feePercentMax=" + feePercentMax +
                '}';
    }
}
