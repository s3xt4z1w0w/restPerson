package eub.smart.cardproduct.transfer.self.domain.model;

public class MultiToMultiAccountInfo {

    private Boolean senderFlagMultiCurrency;
    private Boolean receiverFlagMultiCurrency;
    private Long senderIdRef;
    private Long receiverIdRef;
    private String senderAccNumber;
    private String receiverAccNumber;

    public Boolean getSenderFlagMultiCurrency() {
        return senderFlagMultiCurrency;
    }

    public void setSenderFlagMultiCurrency(Boolean senderFlagMultiCurrency) {
        this.senderFlagMultiCurrency = senderFlagMultiCurrency;
    }

    public Boolean getReceiverFlagMultiCurrency() {
        return receiverFlagMultiCurrency;
    }

    public void setReceiverFlagMultiCurrency(Boolean receiverFlagMultiCurrency) {
        this.receiverFlagMultiCurrency = receiverFlagMultiCurrency;
    }

    public Long getSenderIdRef() {
        return senderIdRef;
    }

    public void setSenderIdRef(Long senderIdRef) {
        this.senderIdRef = senderIdRef;
    }

    public Long getReceiverIdRef() {
        return receiverIdRef;
    }

    public void setReceiverIdRef(Long receiverIdRef) {
        this.receiverIdRef = receiverIdRef;
    }

    public String getSenderAccNumber() {
        return senderAccNumber;
    }

    public void setSenderAccNumber(String senderAccNumber) {
        this.senderAccNumber = senderAccNumber;
    }

    public String getReceiverAccNumber() {
        return receiverAccNumber;
    }

    public void setReceiverAccNumber(String receiverAccNumber) {
        this.receiverAccNumber = receiverAccNumber;
    }

    @Override
    public String toString() {
        return "MultiToMultiAccountInfo{" +
                "senderFlagMultiCurrency=" + senderFlagMultiCurrency +
                ", receiverFlagMultiCurrency=" + receiverFlagMultiCurrency +
                ", senderIdRef=" + senderIdRef +
                ", receiverIdRef=" + receiverIdRef +
                ", senderAccNumber=" + senderAccNumber +
                ", receiverAccNumber=" + receiverAccNumber +
                '}';
    }
}
