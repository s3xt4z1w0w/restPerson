package eub.smart.cardproduct.transfer.self.application.model;

public class ValidationFlag {

    Boolean senderAccountStatus;
    Boolean receiverAccountStatus;
    Boolean multiConvertStatus;
    Boolean secondTime;

    public Boolean getSenderAccountStatus() {
        return senderAccountStatus;
    }

    public void setSenderAccountStatus(Boolean senderAccountStatus) {
        this.senderAccountStatus = senderAccountStatus;
    }

    public Boolean getReceiverAccountStatus() {
        return receiverAccountStatus;
    }

    public void setReceiverAccountStatus(Boolean receiverAccountStatus) {
        this.receiverAccountStatus = receiverAccountStatus;
    }

    public Boolean getMultiConvertStatus() {
        return multiConvertStatus;
    }

    public void setMultiConvertStatus(Boolean multiConvertStatus) {
        this.multiConvertStatus = multiConvertStatus;
    }

    public Boolean getSecondTime() {
        return secondTime;
    }

    public void setSecondTime(Boolean secondTime) {
        this.secondTime = secondTime;
    }

    @Override
    public String toString() {
        return "ValidationFlag{" +
                "senderAccountStatus=" + senderAccountStatus +
                ", receiverAccountStatus=" + receiverAccountStatus +
                ", multiConvertStatus=" + multiConvertStatus +
                ", secondTime=" + secondTime +
                '}';
    }
}
