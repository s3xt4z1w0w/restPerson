package eub.smart.cardproduct.transfer.self.domain.use_case;

public interface ValidateBSystemCombinationUseCase {

    void invoke(String senderBSystem, String receiverBSystem);
}
