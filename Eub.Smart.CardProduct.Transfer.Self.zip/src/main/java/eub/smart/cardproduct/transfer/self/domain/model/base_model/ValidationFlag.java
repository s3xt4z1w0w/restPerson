package eub.smart.cardproduct.transfer.self.domain.model.base_model;

public class ValidationFlag {

    Boolean senderAccountStatus;
    Boolean receiverAccountStatus;
    Boolean multiConvertStatus;

    public Boolean getSenderAccountStatus() {
        return senderAccountStatus;
    }

    public void setSenderAccountStatus(Boolean senderAccountStatus) {
        this.senderAccountStatus = senderAccountStatus;
    }

    public Boolean getReceiverAccountStatus() {
        return receiverAccountStatus;
    }

    public void setReceiverAccountStatus(Boolean receiverAccountStatus) {
        this.receiverAccountStatus = receiverAccountStatus;
    }

    public Boolean getMultiConvertStatus() {
        return multiConvertStatus;
    }

    public void setMultiConvertStatus(Boolean multiConvertStatus) {
        this.multiConvertStatus = multiConvertStatus;
    }

    @Override
    public String toString() {
        return "ValidationFlag{" +
                "senderAccountStatus=" + senderAccountStatus +
                ", receiverAccountStatus=" + receiverAccountStatus +
                ", multiConvertStatus=" + multiConvertStatus +
                '}';
    }
}
