package eub.smart.cardproduct.transfer.self.application.worker;

import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerException;
import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerFailFast;
import eub.smart.cardproduct.transfer.self.application.mapper.ApplicationMapper;
import eub.smart.cardproduct.transfer.self.application.model.TransferInternalRsbkToRsbkBaseModel;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbk;
import eub.smart.cardproduct.transfer.self.domain.use_case.ReverseRsbkDocumentUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.RsbkToRsbkSaveResultUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferRSBKtoRSBKUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferTcRsbkUseCase;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.springframework.stereotype.Component;

import static eub.smart.cardproduct.transfer.self.core.util.ZeebeConfigUtil.WORKER_ENABLE;

@Component
public class TransferInternalRsbkToRsbkWorker {

    private final TransferRSBKtoRSBKUseCase transferRSBKtoRSBKUseCase;
    private final TransferTcRsbkUseCase transferTcRsbkUseCase;
    private final ApplicationMapper applicationMapper;
    private final ReverseRsbkDocumentUseCase reverseRsbkDocumentUseCase;
    private final RsbkToRsbkSaveResultUseCase rsbkToRsbkSaveResultUseCase;

    public TransferInternalRsbkToRsbkWorker(TransferRSBKtoRSBKUseCase transferRSBKtoRSBKUseCase,
                                            TransferTcRsbkUseCase transferTcRsbkUseCase,
                                            ApplicationMapper applicationMapper,
                                            ReverseRsbkDocumentUseCase reverseRsbkDocumentUseCase,
                                            RsbkToRsbkSaveResultUseCase rsbkToRsbkSaveResultUseCase) {
        this.transferRSBKtoRSBKUseCase = transferRSBKtoRSBKUseCase;
        this.transferTcRsbkUseCase = transferTcRsbkUseCase;
        this.applicationMapper = applicationMapper;
        this.reverseRsbkDocumentUseCase = reverseRsbkDocumentUseCase;
        this.rsbkToRsbkSaveResultUseCase = rsbkToRsbkSaveResultUseCase;
    }

    @JobWorkerException(errorCode = "Reject")
    @JobWorkerFailFast("${app.fail.rsbk-to-rsbk.transfer-rsbk-to-rsbk}")
    @JobWorker(type = "transfer_self_rsbk_to_rsbk", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToRsbkBaseModel transferRSBKtoRSBK(@VariablesAsType TransferInternalRsbkToRsbkBaseModel baseModel,
                                                                  JobClient client,
                                                                  ActivatedJob job) {
        var finDocData = applicationMapper.toDomain(baseModel.getFinDoc());
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());

        var response = transferRSBKtoRSBKUseCase.invoke(finDocData, senderData, receiverData);
        baseModel.setTransferRsbkToRsbk(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "ReverseRsbkDoc", retries = 6)
    @JobWorkerFailFast("${app.fail.rsbk-to-rsbk.transfer-tc-rsbk}")
    @JobWorker(type = "transfer_self_rsbk_to_rsbk_tc", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToRsbkBaseModel transferTcRsbk(@VariablesAsType TransferInternalRsbkToRsbkBaseModel baseModel,
                                                              JobClient client,
                                                              ActivatedJob job) {
        var transferRsbkToRsbkResponse = baseModel.getTransferRsbkToRsbk().getTransferRSBKtoRSBKResponse();
        var correlationId = baseModel.getFinDoc().getCorrelationId();

        var response = transferTcRsbkUseCase.invoke(
                transferRsbkToRsbkResponse,
                correlationId);
        baseModel.setTransferTcRsbk(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_rsbk_to_rsbk_reverse_tc", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToRsbkBaseModel tryReverseDoc(@VariablesAsType TransferInternalRsbkToRsbkBaseModel baseModel) {
        var transferResponse = baseModel.getTransferRsbkToRsbk().getTransferRSBKtoRSBKResponse();
        var correlationId = baseModel.getFinDoc().getCorrelationId();

        var response = reverseRsbkDocumentUseCase.invoke(transferResponse, correlationId);
        baseModel.setReverseDoc(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_rsbk_to_rsbk_save_zeebe_findoc", enabled = WORKER_ENABLE)
    public TransferInternalRsbkToRsbkBaseModel saveZeebeFindoc(@VariablesAsType TransferInternalRsbkToRsbkBaseModel baseModel) {
        var finDocId = baseModel.getFinDocId();
        TransferRsbkToRsbk transferRsbkToRsbk = baseModel.getTransferRsbkToRsbk();
        rsbkToRsbkSaveResultUseCase.invoke(finDocId, transferRsbkToRsbk);
        return baseModel;
    }

}
