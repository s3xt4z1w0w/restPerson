package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.in.TransferReceiptIn;
import eub.smart.cardproduct.transfer.self.domain.model.out.TransferReceiptOut;
import eub.smart.cardproduct.transfer.self.domain.repository.ReceiptRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferReceiptUseCase;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class TransferReceiptUseCaseImpl implements TransferReceiptUseCase {

    private final Map<String, ReceiptRepository> repositoryMap = new HashMap<>();

    public TransferReceiptUseCaseImpl(Set<ReceiptRepository> repositories) {
        fillMap(repositories);
    }

    @Override
    public TransferReceiptOut invoke(TransferReceiptIn in, LangKey lang) {
        var receiptRepository = findRepository(in.finDocType())
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_LG_802, ": for finDocType: " + in.finDocType()));
        return receiptRepository.findByFinDocIdOrException(in.finDocId(), lang);
    }

    private void fillMap(Set<ReceiptRepository> repositories) {
        repositories.forEach(repo -> repositoryMap.put(repo.key(), repo));
    }

    private Optional<ReceiptRepository> findRepository(String finDocType) {
        var receiptRepository = repositoryMap.get(finDocType);
        return Optional.ofNullable(receiptRepository);
    }
}