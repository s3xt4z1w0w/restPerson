package eub.smart.cardproduct.transfer.self.infrastructure.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.*;
import eub.smart.cardproduct.transfer.self.infrastructure.entity.*;
import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface InfrastructureMapper {

    FinDocStatus toDomain(FinDocStatusEntity entity);
    Transfer toDomain(TransferEntity entity);
    FinDoc toDomain(FinDocEntity entity);
    Fee toDomain(FeeEntity entity);
    Client toDomain(ClientEntity entity);
    TransferEntity toEntity(Transfer model);
    FinDocEntity toEntity(FinDoc model);
}
