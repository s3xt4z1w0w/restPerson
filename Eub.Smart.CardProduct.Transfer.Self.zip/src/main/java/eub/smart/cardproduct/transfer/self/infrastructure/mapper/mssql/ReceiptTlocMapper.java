package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.common.LocalizedText;
import eub.smart.cardproduct.transfer.self.domain.model.out.MapDisplay;
import eub.smart.cardproduct.transfer.self.domain.model.out.StringDisplay;
import eub.smart.cardproduct.transfer.self.domain.model.out.TimestampDisplay;
import eub.smart.cardproduct.transfer.self.domain.model.out.TransferReceiptOut;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Queue;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.LOCAL;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.ReceiptHeadMapper.processHead;

public class ReceiptTlocMapper {

    public static TransferReceiptOut toDomain(ResultSet resultSet, LangKey lang) throws SQLException {
        var head = processHead(resultSet, lang, LOCAL);
        var body = processBody(resultSet, lang);
        var attachment = processAttachment(resultSet, lang);
        return new TransferReceiptOut(head, body, attachment);
    }

    private static Queue<MapDisplay> processAttachment(ResultSet resultSet, LangKey lang) throws SQLException {
        var createdDateKey = new LocalizedText(
                resultSet.getString("dataDetails_k1_RU"),
                resultSet.getString("dataDetails_k1_KZ"),
                resultSet.getString("dataDetails_k1_EN")
        ).text(lang);
        var createdDateValue = resultSet.getDate("dataDetails_v1_RU");
        var createdDate = new TimestampDisplay(createdDateKey, createdDateValue);

        var finDocKey = new LocalizedText(
                resultSet.getString("dataDetails_k2_RU"),
                resultSet.getString("dataDetails_k2_KZ"),
                resultSet.getString("dataDetails_k2_EN")
        ).text(lang);
        var finDocValue = new LocalizedText(
                resultSet.getString("dataDetails_v2_RU"),
                resultSet.getString("dataDetails_v2_KZ"),
                resultSet.getString("dataDetails_v2_EN")
        ).text(lang);
        var finDoc = new StringDisplay(finDocKey, finDocValue);

        Queue<MapDisplay> attachmentQueue = new LinkedList<>();
        if (createdDate.isValueNotNull()) attachmentQueue.add(createdDate);
        if (finDoc.isValueNotNull()) attachmentQueue.add(finDoc);
        return attachmentQueue;
    }

    private static Queue<MapDisplay> processBody(ResultSet resultSet, LangKey lang) throws SQLException {
        var senderKey = new LocalizedText(
                resultSet.getString("dataDesc_k1_RU"),
                resultSet.getString("dataDesc_k1_KZ"),
                resultSet.getString("dataDesc_k1_EN")
        ).text(lang);
        var senderValue = new LocalizedText(
                resultSet.getString("dataDesc_v1_RU"),
                resultSet.getString("dataDesc_v1_KZ"),
                resultSet.getString("dataDesc_v1_EN")
        ).text(lang);
        var sender = new StringDisplay(senderKey, senderValue);

        var fromKey = new LocalizedText(
                resultSet.getString("dataDesc_k2_RU"),
                resultSet.getString("dataDesc_k2_KZ"),
                resultSet.getString("dataDesc_k2_EN")
        ).text(lang);
        var fromValue = new LocalizedText(
                resultSet.getString("dataDesc_v2_RU"),
                resultSet.getString("dataDesc_v2_KZ"),
                resultSet.getString("dataDesc_v2_EN")
        ).text(lang);
        var from = new StringDisplay(fromKey, fromValue);

        var receiverBankKey = new LocalizedText(
                resultSet.getString("dataDesc_k3_RU"),
                resultSet.getString("dataDesc_k3_KZ"),
                resultSet.getString("dataDesc_k3_EN")
        ).text(lang);
        var receiverBankValue = new LocalizedText(
                resultSet.getString("dataDesc_v3_RU"),
                resultSet.getString("dataDesc_v3_KZ"),
                resultSet.getString("dataDesc_v3_EN")
        ).text(lang);
        var receiverBank = new StringDisplay(receiverBankKey, receiverBankValue);

        var knpKey = new LocalizedText(
                resultSet.getString("dataDesc_k4_RU"),
                resultSet.getString("dataDesc_k4_KZ"),
                resultSet.getString("dataDesc_k4_EN")
        ).text(lang);
        var knpValue = new LocalizedText(
                resultSet.getString("dataDesc_v4_RU"),
                resultSet.getString("dataDesc_v4_KZ"),
                resultSet.getString("dataDesc_v4_EN")
        ).text(lang);
        var knp = new StringDisplay(knpKey, knpValue);

        Queue<MapDisplay> bodyQueue = new LinkedList<>();
        if (sender.isValueNotNull()) bodyQueue.add(sender);
        if (from.isValueNotNull()) bodyQueue.add(from);
        if (receiverBank.isValueNotNull()) bodyQueue.add(receiverBank);
        if (knp.isValueNotNull()) bodyQueue.add(knp);
        return bodyQueue;
    }


}
