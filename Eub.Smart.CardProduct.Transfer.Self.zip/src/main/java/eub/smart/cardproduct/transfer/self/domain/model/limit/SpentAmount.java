package eub.smart.cardproduct.transfer.self.domain.model.limit;

import java.math.BigDecimal;

public class SpentAmount {

    private String senderCurrency;
    private String receiverCurrency;
    private BigDecimal spentSum;

    public SpentAmount() {
    }

    public SpentAmount(String senderCurrency, String receiverCurrency, BigDecimal spentSum) {
        this.senderCurrency = senderCurrency;
        this.receiverCurrency = receiverCurrency;
        this.spentSum = spentSum;
    }

    public String getSenderCurrency() {
        return senderCurrency;
    }

    public void setSenderCurrency(String senderCurrency) {
        this.senderCurrency = senderCurrency;
    }

    public String getReceiverCurrency() {
        return receiverCurrency;
    }

    public void setReceiverCurrency(String receiverCurrency) {
        this.receiverCurrency = receiverCurrency;
    }

    public BigDecimal getSpentSum() {
        return spentSum;
    }

    public void setSpentSum(BigDecimal spentSum) {
        this.spentSum = spentSum;
    }

    @Override
    public String toString() {
        return "SpentAmount{" +
                "senderCurrency=" + senderCurrency +
                ", receiverCurrency=" + receiverCurrency +
                ", spentSum=" + spentSum +
                '}';
    }
}
