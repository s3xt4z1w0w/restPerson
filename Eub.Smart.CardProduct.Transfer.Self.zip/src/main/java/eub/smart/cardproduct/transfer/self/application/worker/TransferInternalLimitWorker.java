package eub.smart.cardproduct.transfer.self.application.worker;

import eub.smart.cardproduct.transfer.self.application.model.TransferInternalBaseModel;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.self.core.util.ZeebeConfigUtil.WORKER_ENABLE;

@Component
public class TransferInternalLimitWorker {

    private final Logger log = LogManager.getLogger(getClass());

    private final GetSelfClientUsageUseCase getSelfClientUsageUseCase;
    private final GetAccountUsageUseCase getAccountUsageUseCase;
    private final GetClientUsageUseCase getClientUsageUseCase;
    private final LimitClientMonthUseCase limitClientMonthUseCase;
    private final LimitClientNightUseCase limitClientNightUseCase;
    private final LimitClientDayUseCase limitClientDayUseCase;
    private final LimitFinDocUseCase limitFinDocUseCase;
    private final LimitAccountDayUseCase limitAccountDayUseCase;
    private final LimitAccountNightUseCase limitAccountNightUseCase;
    private final LimitAccountMonthUseCase limitAccountMonthUseCase;
    private final String residentLimitFinDoc;
    private final String residentLimitDay;
    private final String residentLimitNight;
    private final String nonResidentLimitFinDoc;
    private final String nonResidentLimitDay;
    private final String nonResidentLimitNight;

    public TransferInternalLimitWorker(GetSelfClientUsageUseCase getSelfClientUsageUseCase,
                                       GetAccountUsageUseCase getAccountUsageUseCase,
                                       GetClientUsageUseCase getClientUsageUseCase,
                                       LimitClientMonthUseCase limitClientMonthUseCase,
                                       LimitClientNightUseCase limitClientNightUseCase,
                                       LimitClientDayUseCase limitClientDayUseCase,
                                       LimitFinDocUseCase limitFinDocUseCase,
                                       LimitAccountDayUseCase limitAccountDayUseCase,
                                       LimitAccountNightUseCase limitAccountNightUseCase,
                                       LimitAccountMonthUseCase limitAccountMonthUseCase,
                                       @Value("${app.resident_limit_finDoc}") String residentLimitFinDoc,
                                       @Value("${app.resident_limit_day}") String residentLimitDay,
                                       @Value("${app.resident_limit_night}") String residentLimitNight,
                                       @Value("${app.non_resident_limit_finDoc}") String nonResidentLimitFinDoc,
                                       @Value("${app.non_resident_limit_day}") String nonResidentLimitDay,
                                       @Value("${app.non_resident_limit_night}") String nonResidentLimitNight) {
        this.getSelfClientUsageUseCase = getSelfClientUsageUseCase;
        this.getAccountUsageUseCase = getAccountUsageUseCase;
        this.getClientUsageUseCase = getClientUsageUseCase;
        this.limitClientMonthUseCase = limitClientMonthUseCase;
        this.limitClientNightUseCase = limitClientNightUseCase;
        this.limitClientDayUseCase = limitClientDayUseCase;
        this.limitFinDocUseCase = limitFinDocUseCase;
        this.limitAccountDayUseCase = limitAccountDayUseCase;
        this.limitAccountNightUseCase = limitAccountNightUseCase;
        this.limitAccountMonthUseCase = limitAccountMonthUseCase;
        this.residentLimitFinDoc = residentLimitFinDoc;
        this.residentLimitDay = residentLimitDay;
        this.residentLimitNight = residentLimitNight;
        this.nonResidentLimitFinDoc = nonResidentLimitFinDoc;
        this.nonResidentLimitDay = nonResidentLimitDay;
        this.nonResidentLimitNight = nonResidentLimitNight;
    }

    @JobWorker(type = "transfer_local_fill_account_usage", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel fillAccountUsage(@VariablesAsType TransferInternalBaseModel baseModel) {
        var usage = getAccountUsageUseCase.invoke(baseModel.getSender().getAccountNumber());
        baseModel.setAccountUsage(usage);
        return baseModel;
    }

    @JobWorker(type = "transfer_local_fill_client_usage", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel transferLocalFillClintUsage(@VariablesAsType TransferInternalBaseModel baseModel) {
        var usage = getClientUsageUseCase.invoke(
                baseModel.getSenderDetails().getClientId(),
                baseModel.getSenderDetails().getUserId());
        baseModel.setClientUsage(usage);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_fill_non_resident_usage", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel transferSelfFillNonResidentUsage(@VariablesAsType TransferInternalBaseModel baseModel) {
        var usage = getSelfClientUsageUseCase.invoke(nonResidentLimitFinDoc, baseModel.getCorrelationId());
        baseModel.setClientUsage(usage);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_fill_non_resident_convert_usage", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel transferSelfFillNonResidentConvertUsage(@VariablesAsType TransferInternalBaseModel baseModel) {
        var usage = getSelfClientUsageUseCase.invoke(
                nonResidentLimitFinDoc,
                nonResidentLimitDay,
                nonResidentLimitNight,
                baseModel.getCorrelationId());
        baseModel.setClientUsage(usage);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_fill_resident_convert_usage", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel transferSelfFillResidentConvertUsage(@VariablesAsType TransferInternalBaseModel baseModel) {
        var usage = getSelfClientUsageUseCase.invoke(
                residentLimitFinDoc,
                residentLimitDay,
                residentLimitNight,
                baseModel.getCorrelationId());
        baseModel.setClientUsage(usage);
        return baseModel;
    }

    @JobWorker(type = "transfer_local_check_client_permission_findoc", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkClientPermissionFinDoc(@VariablesAsType TransferInternalBaseModel baseModel) {
        try {
            limitFinDocUseCase.invoke(
                    baseModel.getClientUsage().getLimitFinDoc(),
                    baseModel.getSender().getAmount(),
                    baseModel.getSender().getCurrency(),
                    baseModel.getFinDoc().getCorrelationId());
            baseModel.getLimitFlag().setClientFinDocLimit(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            baseModel.getLimitFlag().setClientFinDocLimit(false);
        }
        return baseModel;
    }

    @JobWorker(type = "transfer_local_check_client_permission_day", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkClientPermissionDay(@VariablesAsType TransferInternalBaseModel baseModel) {
        try {
            limitClientDayUseCase.invoke(
                    baseModel.getClientUsage().getLimitDay(),
                    baseModel.getSenderDetails().getClientId(),
                    baseModel.getSenderDetails().getUserId(),
                    baseModel.getSender().getAmount(),
                    baseModel.getSender().getCurrency(),
                    baseModel.getFinDoc().getCorrelationId(),
                    baseModel.getFinDoc().getFlagConvert());
            baseModel.getLimitFlag().setClientDayLimit(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            baseModel.getLimitFlag().setClientDayLimit(false);
        }
        return baseModel;
    }

    @JobWorker(type = "transfer_local_check_client_permission_night", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkClientPermissionNight(@VariablesAsType TransferInternalBaseModel baseModel) {
        try {
            limitClientNightUseCase.invoke(
                    baseModel.getClientUsage().getLimitNight(),
                    baseModel.getSenderDetails().getClientId(),
                    baseModel.getSenderDetails().getUserId(),
                    baseModel.getSender().getAmount(),
                    baseModel.getSender().getCurrency(),
                    baseModel.getFinDoc().getCorrelationId(),
                    baseModel.getFinDoc().getFlagConvert());
            baseModel.getLimitFlag().setClientNightLimit(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            baseModel.getLimitFlag().setClientNightLimit(false);
        }
        return baseModel;
    }

    @JobWorker(type = "transfer_local_check_client_permission_month", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkClientPermissionMonth(@VariablesAsType TransferInternalBaseModel baseModel) {
        try {
            limitClientMonthUseCase.invoke(
                    baseModel.getClientUsage().getLimitMonth(),
                    baseModel.getSenderDetails().getClientId(),
                    baseModel.getSenderDetails().getUserId(),
                    baseModel.getSender().getAmount(),
                    baseModel.getSender().getCurrency(),
                    baseModel.getFinDoc().getCorrelationId());
            baseModel.getLimitFlag().setClientMonthLimit(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            baseModel.getLimitFlag().setClientMonthLimit(false);
        }
        return baseModel;
    }

    @JobWorker(type = "transfer_local_check_account_permission_findoc", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkAccountPermissionFinDoc(@VariablesAsType TransferInternalBaseModel baseModel) {
        try {
            limitFinDocUseCase.invoke(
                    baseModel.getAccountUsage().getLimitFinDoc(),
                    baseModel.getSender().getAmount(),
                    baseModel.getSender().getCurrency(),
                    baseModel.getFinDoc().getCorrelationId());
            baseModel.getLimitFlag().setAccountFinDocLimit(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            baseModel.getLimitFlag().setAccountFinDocLimit(false);
        }
        return baseModel;
    }

    @JobWorker(type = "transfer_local_check_account_permission_day", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkAccountPermissionDay(@VariablesAsType TransferInternalBaseModel baseModel) {
        try {
            limitAccountDayUseCase.invoke(
                    baseModel.getAccountUsage().getLimitDay(),
                    baseModel.getSender().getAccountNumber(),
                    baseModel.getFinDoc().getCorrelationId(),
                    baseModel.getSender().getAmount(),
                    baseModel.getSender().getCurrency());
            baseModel.getLimitFlag().setAccountDayLimit(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            baseModel.getLimitFlag().setAccountDayLimit(false);
        }
        return baseModel;
    }

    @JobWorker(type = "transfer_local_check_account_permission_night", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkAccountPermissionNight(@VariablesAsType TransferInternalBaseModel baseModel) {
        try {
            limitAccountNightUseCase.invoke(
                    baseModel.getAccountUsage().getLimitNight(),
                    baseModel.getSender().getAccountNumber(),
                    baseModel.getFinDoc().getCorrelationId(),
                    baseModel.getSender().getAmount(),
                    baseModel.getSender().getCurrency());
            baseModel.getLimitFlag().setAccountNightLimit(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            baseModel.getLimitFlag().setAccountNightLimit(false);
        }
        return baseModel;
    }

    @JobWorker(type = "transfer_local_check_account_permission_month", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkAccountPermissionMonth(@VariablesAsType TransferInternalBaseModel baseModel) {
        try {
            limitAccountMonthUseCase.invoke(
                    baseModel.getAccountUsage().getLimitMonth(),
                    baseModel.getSender().getAccountNumber(),
                    baseModel.getFinDoc().getCorrelationId(),
                    baseModel.getSender().getAmount(),
                    baseModel.getSender().getCurrency());
            baseModel.getLimitFlag().setAccountMonthLimit(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            baseModel.getLimitFlag().setAccountMonthLimit(false);
        }
        return baseModel;
    }

}
