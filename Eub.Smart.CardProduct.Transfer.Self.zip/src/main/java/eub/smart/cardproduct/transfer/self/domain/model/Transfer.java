package eub.smart.cardproduct.transfer.self.domain.model;

import java.math.BigDecimal;
import java.util.Date;

public class Transfer {

    private Long id;
    private FinDoc finDoc;
    private String type;
    private String receiverBic;
    private String receiverAccountNumber;
    private String receiverName;
    private String receiverIin;
    private Boolean flagReceiverResident;
    private String secoId;
    private String knpId;
    private String knpText;
    private String purposeType;
    private String purposeNumber;
    private Date purposeDate;
    private String purposeText;
    private String receiverBIN;
    private String receiverCurrency;
    private String receiverSubAccountCurrency;
    private String currencyRates;
    private String senderSubAccountCurrency;
    private String transferMethod_IDREF;
    private String maskedNumber;
    private String cardNumberHash;
    private BigDecimal receiverAmount;

    public Transfer() {
    }

    public Transfer(FinDoc finDoc,
                    String type,
                    String receiverBic,
                    String receiverAccountNumber,
                    String receiverName,
                    String receiverIin,
                    Boolean flagReceiverResident,
                    String secoId,
                    String knpId,
                    String knpText,
                    String purposeType,
                    String purposeNumber,
                    Date purposeDate,
                    String purposeText,
                    String receiverBIN,
                    String receiverCurrency,
                    String receiverSubAccountCurrency,
                    String currencyRates,
                    String senderSubAccountCurrency,
                    String transferMethod_IDREF,
                    String maskedNumber,
                    String cardNumberHash,
                    BigDecimal receiverAmount) {
        this.finDoc = finDoc;
        this.type = type;
        this.receiverBic = receiverBic;
        this.receiverAccountNumber = receiverAccountNumber;
        this.receiverName = receiverName;
        this.receiverIin = receiverIin;
        this.flagReceiverResident = flagReceiverResident;
        this.secoId = secoId;
        this.knpId = knpId;
        this.knpText = knpText;
        this.purposeType = purposeType;
        this.purposeNumber = purposeNumber;
        this.purposeDate = purposeDate;
        this.purposeText = purposeText;
        this.receiverBIN = receiverBIN;
        this.receiverCurrency = receiverCurrency;
        this.receiverSubAccountCurrency = receiverSubAccountCurrency;
        this.currencyRates = currencyRates;
        this.senderSubAccountCurrency = senderSubAccountCurrency;
        this.transferMethod_IDREF = transferMethod_IDREF;
        this.maskedNumber = maskedNumber;
        this.cardNumberHash = cardNumberHash;
        this.receiverAmount = receiverAmount ;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FinDoc getFinDoc() {
        return finDoc;
    }

    public void setFinDoc(FinDoc finDoc) {
        this.finDoc = finDoc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReceiverBic() {
        return receiverBic;
    }

    public void setReceiverBic(String receiverBic) {
        this.receiverBic = receiverBic;
    }

    public String getReceiverAccountNumber() {
        return receiverAccountNumber;
    }

    public void setReceiverAccountNumber(String receiverAccountNumber) {
        this.receiverAccountNumber = receiverAccountNumber;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getReceiverIin() {
        return receiverIin;
    }

    public void setReceiverIin(String receiverIin) {
        this.receiverIin = receiverIin;
    }

    public Boolean getFlagReceiverResident() {
        return flagReceiverResident;
    }

    public void setFlagReceiverResident(Boolean flagReceiverResident) {
        this.flagReceiverResident = flagReceiverResident;
    }

    public String getSecoId() {
        return secoId;
    }

    public void setSecoId(String secoId) {
        this.secoId = secoId;
    }

    public String getKnpId() {
        return knpId;
    }

    public void setKnpId(String knpId) {
        this.knpId = knpId;
    }

    public String getKnpText() {
        return knpText;
    }

    public void setKnpText(String knpText) {
        this.knpText = knpText;
    }

    public String getPurposeType() {
        return purposeType;
    }

    public void setPurposeType(String purposeType) {
        this.purposeType = purposeType;
    }

    public String getPurposeNumber() {
        return purposeNumber;
    }

    public void setPurposeNumber(String purposeNumber) {
        this.purposeNumber = purposeNumber;
    }

    public Date getPurposeDate() {
        return purposeDate;
    }

    public void setPurposeDate(Date purposeDate) {
        this.purposeDate = purposeDate;
    }

    public String getPurposeText() {
        return purposeText;
    }

    public void setPurposeText(String purposeText) {
        this.purposeText = purposeText;
    }

    public String getReceiverBIN() {
        return receiverBIN;
    }

    public void setReceiverBIN(String receiverBIN) {
        this.receiverBIN = receiverBIN;
    }

    public String getReceiverCurrency() {
        return receiverCurrency;
    }

    public void setReceiverCurrency(String receiverCurrency) {
        this.receiverCurrency = receiverCurrency;
    }

    public String getReceiverSubAccountCurrency() {
        return receiverSubAccountCurrency;
    }

    public void setReceiverSubAccountCurrency(String receiverSubAccountCurrency) {
        this.receiverSubAccountCurrency = receiverSubAccountCurrency;
    }

    public String getCurrencyRates() {
        return currencyRates;
    }

    public void setCurrencyRates(String currencyRates) {
        this.currencyRates = currencyRates;
    }

    public String getSenderSubAccountCurrency() {
        return senderSubAccountCurrency;
    }

    public void setSenderSubAccountCurrency(String senderSubAccountCurrency) {
        this.senderSubAccountCurrency = senderSubAccountCurrency;
    }

    public String getTransferMethod_IDREF() {
        return transferMethod_IDREF;
    }

    public void setTransferMethod_IDREF(String transferMethod_IDREF) {
        this.transferMethod_IDREF = transferMethod_IDREF;
    }

    public String getMaskedNumber() {
        return maskedNumber;
    }

    public void setMaskedNumber(String maskedNumber) {
        this.maskedNumber = maskedNumber;
    }

    public String getCardNumberHash() {
        return cardNumberHash;
    }

    public void setCardNumberHash(String cardNumberHash) {
        this.cardNumberHash = cardNumberHash;
    }

    public BigDecimal getReceiverAmount() {
        return receiverAmount;
    }

    public void setReceiverAmount(BigDecimal receiverAmount) {
        this.receiverAmount = receiverAmount;
    }

    @Override
    public String toString() {
        return "Transfer{" +
                "id=" + id +
                ", type=" + type +
                ", receiverBic=" + receiverBic +
                ", receiverAccountNumber=" + receiverAccountNumber +
                ", receiverName=" + receiverName +
                ", receiverIin=" + receiverIin +
                ", flagReceiverResident=" + flagReceiverResident +
                ", secoId=" + secoId +
                ", knpId=" + knpId +
                ", knpText=" + knpText +
                ", purposeType=" + purposeType +
                ", purposeNumber=" + purposeNumber +
                ", purposeDate=" + purposeDate +
                ", purposeText=" + purposeText +
                ", receiverBIN=" + receiverBIN +
                ", receiverCurrency=" + receiverCurrency +
                ", receiverSubAccountCurrency=" + receiverSubAccountCurrency +
                ", currencyRates=" + currencyRates +
                ", senderSubAccountCurrency=" + senderSubAccountCurrency +
                ", transferMethod_IDREF=" + transferMethod_IDREF +
                ", maskedNumber=" + maskedNumber +
                ", cardNumberHash=" + cardNumberHash +
                ", receiverAmount=" + receiverAmount +
                '}';
    }
}
