package eub.smart.cardproduct.transfer.self.application.model;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;

public class TransferInternalRsbkToWay4BaseModel extends TransferInternalBaseModel {

    @JsonSetter(nulls = Nulls.SET)
    private TransferRsbkToWay4 transferRsbkToWay4;
    @JsonSetter(nulls = Nulls.SET)
    private TransferRsbkToWay4Credit debitTransit;
    @JsonSetter(nulls = Nulls.SET)
    private TransferRsbkToWay4Credit credit;
    @JsonSetter(nulls = Nulls.SET)
    private TransferRsbkToWay4ReverseTransit reverseTransit;
    @JsonSetter(nulls = Nulls.SET)
    private ReverseDoc reverseDoc;
    @JsonSetter(nulls = Nulls.SET)
    private TransferTcWay4 transferTcWay4;
    @JsonSetter(nulls = Nulls.SET)
    private RrnBrrn rrnBrrn;
    @JsonSetter(nulls = Nulls.SET)
    private PostingDate postingDate;
    @JsonSetter(nulls = Nulls.SET)
    private Way4TransactionDate way4TransactionDate;

    public TransferRsbkToWay4 getTransferRsbkToWay4() {
        return transferRsbkToWay4;
    }

    public void setTransferRsbkToWay4(TransferRsbkToWay4 transferRsbkToWay4) {
        this.transferRsbkToWay4 = transferRsbkToWay4;
    }

    public TransferRsbkToWay4Credit getDebitTransit() {
        return debitTransit;
    }

    public void setDebitTransit(TransferRsbkToWay4Credit debitTransit) {
        this.debitTransit = debitTransit;
    }

    public TransferRsbkToWay4Credit getCredit() {
        return credit;
    }

    public void setCredit(TransferRsbkToWay4Credit credit) {
        this.credit = credit;
    }

    public TransferRsbkToWay4ReverseTransit getReverseTransit() {
        return reverseTransit;
    }

    public void setReverseTransit(TransferRsbkToWay4ReverseTransit reverseTransit) {
        this.reverseTransit = reverseTransit;
    }

    public ReverseDoc getReverseDoc() {
        return reverseDoc;
    }

    public void setReverseDoc(ReverseDoc reverseDoc) {
        this.reverseDoc = reverseDoc;
    }

    public TransferTcWay4 getTransferTcWay4() {
        return transferTcWay4;
    }

    public void setTransferTcWay4(TransferTcWay4 transferTcWay4) {
        this.transferTcWay4 = transferTcWay4;
    }

    public RrnBrrn getRrnBrrn() {
        return rrnBrrn;
    }

    public void setRrnBrrn(RrnBrrn rrnBrrn) {
        this.rrnBrrn = rrnBrrn;
    }

    public PostingDate getPostingDate() {
        return postingDate;
    }

    public void setPostingDate(PostingDate postingDate) {
        this.postingDate = postingDate;
    }

    public Way4TransactionDate getWay4TransactionDate() {
        return way4TransactionDate;
    }

    public void setWay4TransactionDate(Way4TransactionDate way4TransactionDate) {
        this.way4TransactionDate = way4TransactionDate;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
