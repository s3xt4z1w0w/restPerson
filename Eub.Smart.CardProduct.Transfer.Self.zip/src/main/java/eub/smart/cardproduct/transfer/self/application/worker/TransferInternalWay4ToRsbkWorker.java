package eub.smart.cardproduct.transfer.self.application.worker;

import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerException;
import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerFailFast;
import eub.smart.cardproduct.transfer.self.application.mapper.ApplicationMapper;
import eub.smart.cardproduct.transfer.self.application.model.TransferInternalWay4ToRsbkBaseModel;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.springframework.stereotype.Component;

import static eub.smart.cardproduct.transfer.self.core.util.ZeebeConfigUtil.WORKER_ENABLE;

@Component
public class TransferInternalWay4ToRsbkWorker {

    private final TransferWay4ToRsbkDebitUseCase transferWay4ToRsbkDebitUseCase;
    private final TransferWay4ToRsbkReverseDebitUseCase transferWay4ToRsbkReverseDebitUseCase;
    private final TransferWay4ToRsbkCreditTransitUseCase transferWay4ToRsbkCreditTransitUseCase;
    private final TransferWay4ToRsbkReverseTransitUseCase transferWay4ToRsbkReverseTransitUseCase;
    private final TransferInternalWay4ToRsbkCreditRsbkUseCase transferInternalWay4ToRsbkCreditRsbkUseCase;
    private final TransferTcWay4UseCase transferTcWay4UseCase;
    private final GenerateRrnBrrnUseCase generateRrnBrrnUseCase;
    private final GetPostingDateUseCase getPostingDateUseCase;
    private final SetWay4TransactionDateUseCase setWay4TransactionDateUseCase;
    private final ApplicationMapper applicationMapper;
    private final Way4ToRsbkSaveResultUseCase way4ToRsbkSaveResultUseCase;
    private final ReverseRsbkDocumentUseCase reverseRsbkDocumentUseCase;

    public TransferInternalWay4ToRsbkWorker(TransferWay4ToRsbkDebitUseCase transferWay4ToRsbkDebitUseCase,
                                            TransferWay4ToRsbkReverseDebitUseCase transferWay4ToRsbkReverseDebitUseCase,
                                            TransferWay4ToRsbkCreditTransitUseCase transferWay4ToRsbkCreditTransitUseCase,
                                            TransferWay4ToRsbkReverseTransitUseCase transferWay4ToRsbkReverseTransitUseCase,
                                            TransferInternalWay4ToRsbkCreditRsbkUseCase transferInternalWay4ToRsbkCreditRsbkUseCase,
                                            TransferTcWay4UseCase transferTcWay4UseCase,
                                            GenerateRrnBrrnUseCase generateRrnBrrnUseCase,
                                            GetPostingDateUseCase getPostingDateUseCase,
                                            SetWay4TransactionDateUseCase setWay4TransactionDateUseCase,
                                            ApplicationMapper applicationMapper,
                                            Way4ToRsbkSaveResultUseCase way4ToRsbkSaveResultUseCase,
                                            ReverseRsbkDocumentUseCase reverseRsbkDocumentUseCase) {
        this.transferWay4ToRsbkDebitUseCase = transferWay4ToRsbkDebitUseCase;
        this.transferWay4ToRsbkReverseDebitUseCase = transferWay4ToRsbkReverseDebitUseCase;
        this.transferWay4ToRsbkCreditTransitUseCase = transferWay4ToRsbkCreditTransitUseCase;
        this.transferWay4ToRsbkReverseTransitUseCase = transferWay4ToRsbkReverseTransitUseCase;
        this.transferInternalWay4ToRsbkCreditRsbkUseCase = transferInternalWay4ToRsbkCreditRsbkUseCase;
        this.transferTcWay4UseCase = transferTcWay4UseCase;
        this.generateRrnBrrnUseCase = generateRrnBrrnUseCase;
        this.getPostingDateUseCase = getPostingDateUseCase;
        this.setWay4TransactionDateUseCase = setWay4TransactionDateUseCase;
        this.applicationMapper = applicationMapper;
        this.way4ToRsbkSaveResultUseCase = way4ToRsbkSaveResultUseCase;
        this.reverseRsbkDocumentUseCase = reverseRsbkDocumentUseCase;
    }

    @JobWorkerException(errorCode = "Reject")
    @JobWorkerFailFast("${app.fail.way4-to-rsbk.transfer-way4-to-rsbk-debit}")
    @JobWorker(type = "transfer_self_way4_to_rsbk_debit", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel transferWay4ToRsbkDebit(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel,
                                                                       JobClient client,
                                                                       ActivatedJob job) {
        var finDocData = applicationMapper.toDomain(baseModel.getFinDoc());
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());

        var response = transferWay4ToRsbkDebitUseCase.invoke(finDocData, senderData, receiverData, rrnBrrn);
        baseModel.setTransferWay4ToRsbkDebit(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_rsbk_reverse_debit", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel transferWay4ToRsbkReverseDebit(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel) {
        var ufxTransferRequest = baseModel.getTransferWay4ToRsbkDebit().getUfxTransferRequest();

        var response = transferWay4ToRsbkReverseDebitUseCase.invoke(ufxTransferRequest);
        baseModel.setTransferWay4ToRsbkReverseDebit(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "ReverseDebit")
    @JobWorkerFailFast("${app.fail.way4-to-rsbk.transfer-way4-to-rsbk-credit-transit}")
    @JobWorker(type = "transfer_self_way4_to_rsbk_credit_transit", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel transferWay4ToRsbkCreditTransit(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel,
                                                                               JobClient client,
                                                                               ActivatedJob job) {
        var finDocData = applicationMapper.toDomain(baseModel.getFinDoc());
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());

        var response = transferWay4ToRsbkCreditTransitUseCase.invoke(finDocData, senderData, receiverData, rrnBrrn);
        baseModel.setTransferWay4ToRsbkCreditTransit(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_rsbk_reverse_transit", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel transferWay4ToRsbkReverseTransit(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel) {
        var ufxTransferRequest = baseModel.getTransferWay4ToRsbkCreditTransit().getUfxTransferRequest();

        var response = transferWay4ToRsbkReverseTransitUseCase.invoke(ufxTransferRequest);
        baseModel.setTransferWay4ToRsbkReverseTransit(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "ReverseCreditTransit")
    @JobWorkerFailFast("${app.fail.way4-to-rsbk.transfer-way4-to-rsbk-credit-rsbk}")
    @JobWorker(type = "transfer_self_way4_to_rsbk_credit_rsbk", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel transferWay4ToRsbkCreditRsbk(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel,
                                                                            JobClient client,
                                                                            ActivatedJob job) {
        var finDocData = applicationMapper.toDomain(baseModel.getFinDoc());
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());

        var response = transferInternalWay4ToRsbkCreditRsbkUseCase.invoke(finDocData, senderData, receiverData);
        baseModel.setTransferWay4ToRsbkCreditRsbk(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "ReverseRsbkDoc", retries = 6)
    @JobWorkerFailFast("${app.fail.way4-to-rsbk.way4-to-rsbk-transfer-tc-way4}")
    @JobWorker(type = "transfer_self_way4_to_rsbk_tc", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel transferTcWay4(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel,
                                                              JobClient client,
                                                              ActivatedJob job) {
        var transferWay4ToRsbkResponse = baseModel.getTransferWay4ToRsbkCreditRsbk().getResponse();
        var correlationId = baseModel.getFinDoc().getCorrelationId();

        var response = transferTcWay4UseCase.invoke(transferWay4ToRsbkResponse, correlationId);
        baseModel.setTransferTcWay4(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_rsbk_generate_rrn", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel generateRrn(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel) {
        var response = generateRrnBrrnUseCase.invoke();
        var rrnBrrn = applicationMapper.toApplication(response);
        baseModel.setRrnBrrn(rrnBrrn);
        return baseModel;
    }

    @JobWorkerException(retries = 20)
    @JobWorker(type = "transfer_self_way4_to_rsbk_get_transaction_date", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel getPostingDate(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel,
                                                              JobClient client,
                                                              ActivatedJob job) {
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());
        var response = getPostingDateUseCase.invoke(
                rrnBrrn,
                baseModel.getFinDoc().getCorrelationId());
        baseModel.setPostingDate(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_rsbk_set_transaction_date", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel setWay4TransactionDate(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel) {
        var postingDateResponse = baseModel.getPostingDate().getResponse();
        var transferResponse = baseModel.getTransferWay4ToRsbkCreditRsbk().getResponse();
        var correlationId = baseModel.getFinDoc().getCorrelationId();

        var response = setWay4TransactionDateUseCase.invoke(
                postingDateResponse,
                transferResponse,
                correlationId);
        baseModel.setWay4TransactionDate(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_rsbk_save_zeebe_findoc", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel saveZeebeFindoc(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel) {
        var finDocId = baseModel.getFinDocId();
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());
        var transferWay4ToRsbkCreditRsbk = baseModel.getTransferWay4ToRsbkCreditRsbk();
        way4ToRsbkSaveResultUseCase.invoke(finDocId, rrnBrrn, transferWay4ToRsbkCreditRsbk);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_rsbk_reverse_tc", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToRsbkBaseModel tryReverseDoc(@VariablesAsType TransferInternalWay4ToRsbkBaseModel baseModel) {
        var transferResponse = baseModel.getTransferWay4ToRsbkCreditRsbk().getResponse();
        var correlationId = baseModel.getFinDoc().getCorrelationId();

        var response = reverseRsbkDocumentUseCase.invoke(transferResponse, correlationId);
        baseModel.setReverseDoc(response);
        return baseModel;
    }
}
