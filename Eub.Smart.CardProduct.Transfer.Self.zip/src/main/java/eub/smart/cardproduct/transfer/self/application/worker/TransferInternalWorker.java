package eub.smart.cardproduct.transfer.self.application.worker;

import eub.smart.cardproduct.transfer.self.application.model.TransferInternalBaseModel;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateBSystemCombinationUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.FormSmsMessageUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.SetSignDateUseCase;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.springframework.stereotype.Component;

import static eub.smart.cardproduct.transfer.self.core.util.ZeebeConfigUtil.WORKER_ENABLE;

@Component
public class TransferInternalWorker {

    private final ValidateBSystemCombinationUseCase validateBSystemCombinationUseCase;

    private final FormSmsMessageUseCase formSmsMessageUseCase;

    private final SetSignDateUseCase setSignDateUseCase;

    public TransferInternalWorker(ValidateBSystemCombinationUseCase validateBSystemCombinationUseCase,
                                  FormSmsMessageUseCase formSmsMessageUseCase,
                                  SetSignDateUseCase setSignDateUseCase) {
        this.validateBSystemCombinationUseCase = validateBSystemCombinationUseCase;
        this.formSmsMessageUseCase = formSmsMessageUseCase;
        this.setSignDateUseCase = setSignDateUseCase;
    }

    @JobWorker(type = "transfer_self_validate_bsystem_combination", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel validateBSystemCombination(@VariablesAsType TransferInternalBaseModel baseModel) {
        validateBSystemCombinationUseCase.invoke(
                baseModel.getSender().getbSystem(),
                baseModel.getReceiver().getbSystem());
        return baseModel;
    }

    @JobWorker(type = "transfer_self_form_sms_message", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel formSmsMessage(@VariablesAsType TransferInternalBaseModel baseModel) {
        var message = formSmsMessageUseCase.invoke(
                baseModel.getFinDoc().getId(),
                baseModel.getFinDocStatus().getDocTechStatus(),
                baseModel.getSender().getAmount(),
                baseModel.getSender().getCurrency());
        baseModel.getFinDoc().setMessage(message);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_set_sign_date", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel setSignDate(@VariablesAsType TransferInternalBaseModel baseModel) {
        var signDate = setSignDateUseCase.invoke(baseModel.getFinDoc().getId());
        baseModel.getFinDoc().setDateSigned(signDate);
        return baseModel;
    }
}
