package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4ReverseTransit;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;

public interface TransferRsbkToWay4ReverseTransitUseCase {

    TransferRsbkToWay4ReverseTransit invoke(UfxTransferRequest ufxTransferRequest);
}
