package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.DomainMapper;
import eub.smart.cardproduct.transfer.self.domain.model.Transfer;
import eub.smart.cardproduct.transfer.self.domain.model.create_transfer.CreateTransfer;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocStatusRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferKnpRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

import static eub.smart.cardproduct.transfer.self.core.constant.DocStatus.DRFT;
import static eub.smart.cardproduct.transfer.self.core.constant.TransferKNPConvertType.NONE;
import static eub.smart.cardproduct.transfer.self.core.constant.AccountType.isDeposit;

public class GetCreateTransferUseCaseImpl implements GetCreateTransferUseCase {

    private final CreateFinDocUseCase createFinDocUseCase;
    private final CreateTransferUseCase createTransferUseCase;
    private final TransferKnpRepository transferKnpRepository;
    private final FinDocStatusRepository finDocStatusRepository;
    private final GetAccountDepositTypeUseCase getAccountDepositTypeUseCase;
    private final GetAccountInfoBuyNumberUseCase getAccountInfoUseCase;
    private final ValidateReceiverAmountUseCase validateReceiverAmountUseCase;
    private final DomainMapper modelMapper;

    public GetCreateTransferUseCaseImpl(CreateFinDocUseCase createFinDocUseCase,
                                        CreateTransferUseCase createTransferUseCase,
                                        TransferKnpRepository transferKnpRepository,
                                        FinDocStatusRepository finDocStatusRepository,
                                        GetAccountDepositTypeUseCase getAccountDepositTypeUseCase,
                                        GetAccountInfoBuyNumberUseCase getAccountInfoUseCase,
                                        ValidateReceiverAmountUseCase validateReceiverAmountUseCase,
                                        DomainMapper modelMapper) {
        this.createFinDocUseCase = createFinDocUseCase;
        this.createTransferUseCase = createTransferUseCase;
        this.transferKnpRepository = transferKnpRepository;
        this.finDocStatusRepository = finDocStatusRepository;
        this.getAccountDepositTypeUseCase = getAccountDepositTypeUseCase;
        this.getAccountInfoUseCase = getAccountInfoUseCase;
        this.validateReceiverAmountUseCase = validateReceiverAmountUseCase;
        this.modelMapper = modelMapper;
    }

    @Override
    @Transactional
    public CreateTransfer invoke(String senderAccountNumber,
                                 String receiverAccountNumber,
                                 BigDecimal senderAmount,
                                 BigDecimal receiverAmount,
                                 String senderCurrency,
                                 String receiverCurrency,
                                 List<CurrencyRate> currencyRates,
                                 String correlationId) {
        validateReceiverAmountUseCase.invoke(senderAmount, receiverAmount, senderCurrency, receiverCurrency, correlationId); //TODO переделать
        var senderAccount = getAccountInfoUseCase.invoke(senderAccountNumber, senderCurrency);
        var receiverAccount = getAccountInfoUseCase.invoke(receiverAccountNumber, receiverCurrency);
        var savedTransfer = saveTransfer(senderAccount, receiverAccount, senderAmount, receiverAmount, currencyRates);

        var transfer = modelMapper.toCreateTransfer(savedTransfer);
        var finDocStatus = finDocStatusRepository.findByIdOrException(DRFT);
        return new CreateTransfer(transfer, senderAccount, finDocStatus);
    }

    private Transfer saveTransfer(CreateTransferAccountInfo senderAccount,
                                  CreateTransferAccountInfo receiverAccount,
                                  BigDecimal senderAmount,
                                  BigDecimal receiverAmount,
                                  List<CurrencyRate> currencyRates) {
        var knpCode = getKnpCode(senderAccount, receiverAccount);
        var finDoc = createFinDocUseCase.invoke(
                senderAmount,
                senderAccount,
                receiverAccount);
        return createTransferUseCase.invoke(
                finDoc,
                senderAccount,
                receiverAccount,
                knpCode,
                receiverAmount,
                currencyRates);
    }

    private String getKnpCode(CreateTransferAccountInfo account,
                              CreateTransferAccountInfo receiverAccount) {
        var senderAccountType = isDeposit(account.getType())
                ? getAccountDepositTypeUseCase.invoke(account.getId())
                : account.getType();
        var receiverAccountType = isDeposit(receiverAccount.getType())
                ? getAccountDepositTypeUseCase.invoke(receiverAccount.getId())
                : receiverAccount.getType();
        return transferKnpRepository.findKNPCodeOrException(senderAccountType, receiverAccountType, NONE, true);
    }

}
