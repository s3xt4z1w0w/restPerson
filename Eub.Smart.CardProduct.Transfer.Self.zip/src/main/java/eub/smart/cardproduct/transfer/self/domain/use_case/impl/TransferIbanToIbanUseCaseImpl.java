package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferIbanToIban;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferIbanToIbanUseCase;
import eub.smart.cardproduct.transfer.self.domain.mapper.TransferIbanToIbanMapper;

public class TransferIbanToIbanUseCaseImpl implements TransferIbanToIbanUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferIbanToIbanUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferIbanToIban invoke(AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn) {
        var request = TransferIbanToIbanMapper.createRequest(senderData, receiverData, rrnBrrn);
        var response = transferSelfProtoRepository.transferIbanToIban(request);
        return new TransferIbanToIban(request, response);
    }
}
