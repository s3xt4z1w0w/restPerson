package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class PostingDate {

    private PostingDateRequest request;
    private PostingDateResponse response;

    public PostingDate() {
    }

    public PostingDate(PostingDateRequest request, PostingDateResponse response) {
        this.request = request;
        this.response = response;
    }

    public void setRequest(PostingDateRequest request) {
        this.request = request;
    }

    public void setResponse(PostingDateResponse response) {
        this.response = response;
    }

    public PostingDateRequest getRequest() {
        return request;
    }

    public PostingDateResponse getResponse() {
        return response;
    }
}
