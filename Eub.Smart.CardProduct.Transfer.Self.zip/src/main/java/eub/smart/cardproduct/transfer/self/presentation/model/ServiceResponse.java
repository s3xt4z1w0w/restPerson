package eub.smart.cardproduct.transfer.self.presentation.model;

import eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import io.swagger.v3.oas.annotations.media.Schema;

public class ServiceResponse<T> {

    @Schema(description = "тело ответа")
    private T body;

    @Schema(description = "тех код ошибки", implementation = SelfErrorCode.class)
    private SelfErrorCode techErrorCode;

    @Schema(description = "тех сообщение ошибки")
    private String techErrorMessage;

    @Schema(description = "сообщение ошибки")
    private String errorMessage;

    @Schema(description = "детали ошибки")
    private String errorDetails;

    public T getBody() {
        return body;
    }

    public void setBody(T body) {
        this.body = body;
    }

    public SelfErrorCode getTechErrorCode() {
        return techErrorCode;
    }

    public void setTechErrorCode(SelfErrorCode techErrorCode) {
        this.techErrorCode = techErrorCode;
    }

    public String getTechErrorMessage() {
        return techErrorMessage;
    }

    public void setTechErrorMessage(String techErrorMessage) {
        this.techErrorMessage = techErrorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    public ServiceResponse<T> successResponse(T body){
        this.setBody(body);
        return this;
    }

    public ServiceResponse<T> errorResponse(SelfException e) {
        this.setTechErrorCode(e.getCode());
        this.setTechErrorMessage(e.getMessage());
        this.setErrorMessage(e.getErrorMessage());
        this.setErrorDetails(null);
        return this;
    }

    public String json() {
        return "{" +
                "\"body\":\"" + body + "\"" +
                ", \"techErrorCode\":" + techErrorCode +
                ", \"techErrorMessage\":\"" + techErrorMessage + "\"" +
                ", \"errorMessage\":\"" + errorMessage + "\"" +
                ", \"errorDetails\":\"" + errorDetails + "\"" +
                "}";
    }

    @Override
    public String toString() {
        return "BiometricResponse{" +
                "body=" + body +
                ", techErrorCode=" + techErrorCode +
                ", techErrorMessage=" + techErrorMessage +
                ", errorMessage=" + errorMessage +
                ", errorDetails=" + errorDetails +
                "}";
    }
}
