package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.Client;
import eub.smart.cardproduct.transfer.self.domain.repository.ClientRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.ClientHiberRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;

@Primary
@Component
public class ClientRepositoryImpl implements ClientRepository {

    private final ClientHiberRepository clientHiberRepository;
    private final InfrastructureMapper mapper;

    public ClientRepositoryImpl(ClientHiberRepository clientHiberRepository,
                                InfrastructureMapper mapper) {
        this.clientHiberRepository = clientHiberRepository;
        this.mapper = mapper;
    }

    @Override
    public Optional<Client> findByAccountNumber(String accountNumber) {
        return clientHiberRepository.findByAccountNumber(accountNumber)
                .map(mapper::toDomain);
    }

    @Override
    public Client findByAccountNumberOrException(String accountNumber) {
        return findByAccountNumber(accountNumber)
                .orElseThrow(() -> new SelfException(E_DB_600,": Client findByAccountNumberOrException"));
    }
}
