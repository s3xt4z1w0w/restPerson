package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferTcWay4 {

    private TransferTcRequest transferTcWay4Request;
    private TransferTcResponse transferTcWay4Response;

    public TransferTcWay4() {
    }

    public TransferTcWay4(TransferTcRequest transferTcWay4Request,
                          TransferTcResponse transferTcWay4Response) {
        this.transferTcWay4Request = transferTcWay4Request;
        this.transferTcWay4Response = transferTcWay4Response;
    }

    public void setTransferTcWay4Request(TransferTcRequest transferTcWay4Request) {
        this.transferTcWay4Request = transferTcWay4Request;
    }

    public void setTransferTcWay4Response(TransferTcResponse transferTcWay4Response) {
        this.transferTcWay4Response = transferTcWay4Response;
    }

    public TransferTcRequest getTransferTcWay4Request() {
        return transferTcWay4Request;
    }

    public TransferTcResponse getTransferTcWay4Response() {
        return transferTcWay4Response;
    }
}
