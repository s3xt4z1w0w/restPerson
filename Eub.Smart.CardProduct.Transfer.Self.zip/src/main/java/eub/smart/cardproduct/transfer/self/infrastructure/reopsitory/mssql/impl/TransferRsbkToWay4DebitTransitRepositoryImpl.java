package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferRsbkToWay4DebitTransitRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.TransferRsbkToWay4DebitTransitMapper.toDomainModel;

@Primary
@Repository
public class TransferRsbkToWay4DebitTransitRepositoryImpl implements TransferRsbkToWay4DebitTransitRepository {

    private final NamedParameterJdbcTemplate template;

    public TransferRsbkToWay4DebitTransitRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<UfxTransferRequest> findByFinDocId(Long finDocId,
                                                       String stun,
                                                       RrnBrrn rrnBrrn,
                                                       String operationAccount) {
        String sql = """ 
                select T.Receiver_Amount           as amount, 
                       T.Receiver_Currency         as currency, 
                       T.Receiver_Account          as accountNumber, 
                       A.AccountType_IDREF         as accountType, 
                       BSC.BSystemClient_Title     as fullname 
                from Transfer T
                         join Account A on T.Receiver_Account = A.Number
                         join BSystemClient BSC on A.BSystemClient_IDREF = BSC.BSystemClient_ID
                where T.FinDoc_IDREF = :finDocId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(row -> toDomainModel(row, finDocId, stun, rrnBrrn, operationAccount));
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferRsbkToWay4DebitTransitRepository findByFinDocId");
        }
    }

    @Override
    public UfxTransferRequest findByFinDocIdOrException(Long finDocId, String stun, RrnBrrn rrnBrrn, String operationAccount) {
        return findByFinDocId(finDocId, stun, rrnBrrn, operationAccount)
                .orElseThrow(() -> new SelfException(E_DB_600, ": TransferRsbkToWay4DebitTransitRepository findByFinDocIdOrException"));
    }
}
