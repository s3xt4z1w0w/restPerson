package eub.smart.cardproduct.transfer.self.domain.use_case;

import java.math.BigDecimal;

public interface LimitClientDayUseCase {

    void invoke(BigDecimal limitDay, Long clientId, Long userId, BigDecimal amount, String currency, String correlationId, Boolean convert);
}
