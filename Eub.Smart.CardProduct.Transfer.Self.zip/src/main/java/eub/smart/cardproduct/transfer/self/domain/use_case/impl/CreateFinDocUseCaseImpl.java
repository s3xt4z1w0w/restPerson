package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.component.AuthToken;
import eub.smart.cardproduct.transfer.self.core.constant.FinDocType;
import eub.smart.cardproduct.transfer.self.core.model.UserDetails;
import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.CreateFinDocUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetSelfFeeUseCase;

import java.math.BigDecimal;
import java.util.Date;

public class CreateFinDocUseCaseImpl implements CreateFinDocUseCase {

    private final GetSelfFeeUseCase getSelfFeeUseCase;
    private final FinDocRepository finDocRepository;
    private final AuthToken authToken;

    public CreateFinDocUseCaseImpl(GetSelfFeeUseCase getSelfFeeUseCase,
                                   FinDocRepository finDocRepository,
                                   AuthToken authToken) {
        this.getSelfFeeUseCase = getSelfFeeUseCase;
        this.finDocRepository = finDocRepository;
        this.authToken = authToken;
    }

    @Override
    public FinDoc invoke(BigDecimal amount,
                         CreateTransferAccountInfo senderAccount,
                         CreateTransferAccountInfo receiverAccount) {
        var senderClientIdRef = senderAccount.getClientIdRef();
        var receiverClientIdRef = receiverAccount.getClientIdRef();
        var senderAccountNumber = senderAccount.getNumber();
        var senderCurrency = senderAccount.getCurrency();
        var receiverCurrency = receiverAccount.getCurrency();
        var accountId = senderAccount.getId();
        var selfFee = getSelfFeeUseCase.invoke(amount, senderAccountNumber, receiverCurrency);
        var feeAmount = selfFee.getAmount();
        var feeCurrency = selfFee.getCurrency();
        var payload = authToken.getDecodedPayload();
        var userDetails = UserDetails.build(payload);
        var userId = userDetails.getUserId();
        var dateScheduled = new Date();
        var dateCreated = new Date();
        var type = getType(senderClientIdRef, receiverClientIdRef);

        var finDoc = new FinDoc(
                type, userId, null, accountId, senderCurrency,
                amount, feeAmount, feeCurrency, dateCreated,
                dateScheduled, null, false, false,
                null, null, 0, null);
        return finDocRepository.save(finDoc);
    }

    private String getType(Long senderClientId, Long receiverClientId) {
        if (senderClientId.equals(receiverClientId)) {
            return FinDocType.SELF;
        } else {
            return FinDocType.LOCAL;
        }
    }
}
