package eub.smart.cardproduct.transfer.self.domain.model;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class Fee {
    @NotNull
    private Long id;
    @NotNull
    private String title;
    private Long termId;
    @NotNull
    private String currency;
    @NotNull
    private Boolean inheritCurrency;
    @NotNull
    private BigDecimal feeFixed;
    private BigDecimal feePercent;
    @NotNull
    private BigDecimal feePercentMin;
    @NotNull
    private BigDecimal feePercentMax;

    public Fee() {
    }

    public Fee(Long id,
               String title,
               Long termId,
               String currency,
               Boolean inheritCurrency,
               BigDecimal feeFixed,
               BigDecimal feePercent,
               BigDecimal feePercentMin,
               BigDecimal feePercentMax) {
        this.id = id;
        this.title = title;
        this.termId = termId;
        this.currency = currency;
        this.inheritCurrency = inheritCurrency;
        this.feeFixed = feeFixed;
        this.feePercent = feePercent;
        this.feePercentMin = feePercentMin;
        this.feePercentMax = feePercentMax;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getTermId() {
        return termId;
    }

    public void setTermId(Long termId) {
        this.termId = termId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Boolean getInheritCurrency() {
        return inheritCurrency;
    }

    public void setInheritCurrency(Boolean inheritCurrency) {
        this.inheritCurrency = inheritCurrency;
    }

    public BigDecimal getFeeFixed() {
        return feeFixed;
    }

    public void setFeeFixed(BigDecimal feeFixed) {
        this.feeFixed = feeFixed;
    }

    public BigDecimal getFeePercent() {
        return feePercent;
    }

    public void setFeePercent(BigDecimal feePercent) {
        this.feePercent = feePercent;
    }

    public BigDecimal getFeePercentMin() {
        return feePercentMin;
    }

    public void setFeePercentMin(BigDecimal feePercentMin) {
        this.feePercentMin = feePercentMin;
    }

    public BigDecimal getFeePercentMax() {
        return feePercentMax;
    }

    public void setFeePercentMax(BigDecimal feePercentMax) {
        this.feePercentMax = feePercentMax;
    }

    @Override
    public String toString() {
        return "Fee{" +
                "id=" + id +
                ", title=" + title +
                ", termId=" + termId +
                ", currency=" + currency +
                ", inheritCurrency=" + inheritCurrency +
                ", feeFixed=" + feeFixed +
                ", feePercent=" + feePercent +
                ", feePercentMin=" + feePercentMin +
                ", feePercentMax=" + feePercentMax +
                '}';
    }
}
