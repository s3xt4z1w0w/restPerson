package eub.smart.cardproduct.transfer.self.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.NotNull;

public class NewTransferAccount {

    @NotNull
    @Schema(description = "id")
    private Long id;
    @NotNull
    @Schema(description = "Тип")
    private String type;
    @NotNull
    @Schema(description = "Тип валюты")
    private String currency;
    @NotNull
    @Schema(description = "Номер")
    private String number;

    public NewTransferAccount(Long id, String type, String currency, String number) {
        this.id = id;
        this.type = type;
        this.currency = currency;
        this.number = number;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
