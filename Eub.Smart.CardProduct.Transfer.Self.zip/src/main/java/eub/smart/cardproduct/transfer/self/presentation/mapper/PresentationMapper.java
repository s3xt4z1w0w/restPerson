package eub.smart.cardproduct.transfer.self.presentation.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.in.TransferHistoryIn;
import eub.smart.cardproduct.transfer.self.domain.model.in.TransferReceiptIn;
import eub.smart.cardproduct.transfer.self.presentation.model.request.TransferHistoryRequest;
import eub.smart.cardproduct.transfer.self.presentation.model.request.TransferReceiptRequest;
import eub.smart.cardproduct.transfer.self.presentation.model.response.FeeResponse;
import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface PresentationMapper {

    FeeResponse toResponse(eub.smart.cardproduct.transfer.self.domain.model.FeeResponse domainModel);

    TransferHistoryIn toDomain(TransferHistoryRequest transferHistoryRequest);

    TransferReceiptIn toDomain(TransferReceiptRequest request);
}
