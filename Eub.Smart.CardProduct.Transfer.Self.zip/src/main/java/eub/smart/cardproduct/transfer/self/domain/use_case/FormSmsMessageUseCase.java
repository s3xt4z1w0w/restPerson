package eub.smart.cardproduct.transfer.self.domain.use_case;

import java.math.BigDecimal;

public interface FormSmsMessageUseCase {
    String invoke(Long finDocId, String docStatus, BigDecimal amount, String currency);
}
