package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import DashboardInfo.V1.EubAggregatorCoreDashboard;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;

public class GetAggregateAccountsMapper {

    public static EubAggregatorCoreDashboard.AggregateAccountsRequest buildRequest(AccountData accountData) {
        var bSystemType = EubAggregatorCoreDashboard.BSystemType
                .valueOf(accountData.getbSystem());
        var entityId = EubAggregatorCoreDashboard.EntityId
                .newBuilder()
                .setBSystem(bSystemType)
                .setType("")
                .setValue(String.valueOf(accountData.getAccountOutRef()))
                .build();
        return EubAggregatorCoreDashboard.AggregateAccountsRequest
                .newBuilder()
                .addAccountId(entityId)
                .setTotalBalanceCurrency(EubAggregatorCoreDashboard.CurrencyCode.KZT)
                .build();
    }
}
