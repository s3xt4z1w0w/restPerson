package eub.smart.cardproduct.transfer.self.domain.model.create_transfer;

public class Transfer {

    private FinDoc finDoc;
    private String type;
    private String receiverBic;
    private String receiverAccountNumber;
    private String receiverName;
    private boolean flagReceiverResident;
    private String secoId;
    private String knpId;
    private String receiverSubAccountCurrency;
    private String senderSubAccountCurrency;

    public FinDoc getFinDoc() {
        return finDoc;
    }

    public void setFinDoc(FinDoc finDoc) {
        this.finDoc = finDoc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getReceiverBic() {
        return receiverBic;
    }

    public void setReceiverBic(String receiverBic) {
        this.receiverBic = receiverBic;
    }

    public String getReceiverAccountNumber() {
        return receiverAccountNumber;
    }

    public void setReceiverAccountNumber(String receiverAccountNumber) {
        this.receiverAccountNumber = receiverAccountNumber;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public boolean isFlagReceiverResident() {
        return flagReceiverResident;
    }

    public void setFlagReceiverResident(boolean flagReceiverResident) {
        this.flagReceiverResident = flagReceiverResident;
    }

    public String getSecoId() {
        return secoId;
    }

    public void setSecoId(String secoId) {
        this.secoId = secoId;
    }

    public String getKnpId() {
        return knpId;
    }

    public void setKnpId(String knpId) {
        this.knpId = knpId;
    }

    public String getReceiverSubAccountCurrency() {
        return receiverSubAccountCurrency;
    }

    public void setReceiverSubAccountCurrency(String receiverSubAccountCurrency) {
        this.receiverSubAccountCurrency = receiverSubAccountCurrency;
    }

    public String getSenderSubAccountCurrency() {
        return senderSubAccountCurrency;
    }

    public void setSenderSubAccountCurrency(String senderSubAccountCurrency) {
        this.senderSubAccountCurrency = senderSubAccountCurrency;
    }

    @Override
    public String toString() {
        return "Transfer{" +
                "type=" + type +
                ", receiverBic=" + receiverBic +
                ", receiverAccountNumber=" + receiverAccountNumber +
                ", receiverName=" + receiverName +
                ", flagReceiverResident=" + flagReceiverResident +
                ", secoId=" + secoId +
                ", knpId=" + knpId +
                ", receiverSubAccountCurrency=" + receiverSubAccountCurrency +
                ", senderSubAccountCurrency=" + senderSubAccountCurrency +
                '}';
    }
}
