package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferTcRequest;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferTcResponse;

public class TransferTcRsbkMapper {

    public static TransferSelf.EubAggregatorCardProductTransferSelf.TransferRsbkTcRequest toGrpcModel(TransferTcRequest request) {
        return TransferSelf.EubAggregatorCardProductTransferSelf.TransferRsbkTcRequest
                .newBuilder()
                .setCollectorID(request.getCollectorID())
                .build();
    }

    public static TransferTcResponse toDomainModel(TransferSelf.EubAggregatorCardProductTransferSelf.TransferRsbkTcResponse response) {
        TransferTcResponse domainModel = new TransferTcResponse();
        domainModel.setStatus(response.getStatus());
        domainModel.setMessage(response.getMessage());
        return domainModel;
    }
}
