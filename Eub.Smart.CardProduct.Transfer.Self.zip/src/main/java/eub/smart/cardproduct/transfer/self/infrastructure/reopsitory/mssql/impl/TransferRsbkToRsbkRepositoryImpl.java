package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbkRequest;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferRsbkToRsbkRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.TransferRsbkToRsbkMapper.toDomainModel;

@Primary
@Component
public class TransferRsbkToRsbkRepositoryImpl implements TransferRsbkToRsbkRepository {

    private final NamedParameterJdbcTemplate template;

    public TransferRsbkToRsbkRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<TransferRsbkToRsbkRequest> findByFinDocId(Long finDocId, String iin) {
        String sql = """ 
                select A.Number             as senderAccountNumber,
                       T.Receiver_Account   as receiverAccountNumber,
                       T.KNP_IDREF          as knpCode,
                       F.Amount             as senderAmount,
                       T.Receiver_Amount    as receiverAmount,
                       F.Fee                as feeAmount,
                       F.DateSigned         as signDate,
                       F.FinDocType_IDREF   as finDocType
                from FinDoc F
                    join Account A on F.Account_IDREF = A.Account_ID
                    join Transfer T on F.FinDoc_ID = T.FinDoc_IDREF
                where F.FinDoc_ID = :finDocId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(row -> toDomainModel(row, finDocId, iin));
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferRsbkToRsbkRepository findByFinDocId");
        }
    }

    @Override
    public TransferRsbkToRsbkRequest findByFinDocIdOrException(Long finDocId, String iin) {
        return findByFinDocId(finDocId, iin)
                .orElseThrow(() -> new SelfException(SelfErrorCode.E_DB_600, ": TransferRsbkToRsbkRepository findByFinDocIdOrException"));
    }
}
