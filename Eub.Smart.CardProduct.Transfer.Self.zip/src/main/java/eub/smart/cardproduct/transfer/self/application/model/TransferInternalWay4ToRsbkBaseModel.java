package eub.smart.cardproduct.transfer.self.application.model;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;

public class TransferInternalWay4ToRsbkBaseModel extends TransferInternalBaseModel {

    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4ToRsbk transferWay4ToRsbkDebit;
    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4ToRsbk transferWay4ToRsbkReverseDebit;
    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4ToRsbk transferWay4ToRsbkCreditTransit;
    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4ToRsbk transferWay4ToRsbkReverseTransit;
    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4ToRsbkCreditRsbk transferWay4ToRsbkCreditRsbk;
    @JsonSetter(nulls = Nulls.SET)
    private TransferTcWay4 transferTcWay4;
    @JsonSetter(nulls = Nulls.SET)
    private RrnBrrn rrnBrrn;
    @JsonSetter(nulls = Nulls.SET)
    private PostingDate postingDate;
    @JsonSetter(nulls = Nulls.SET)
    private Way4TransactionDate way4TransactionDate;
    @JsonSetter(nulls = Nulls.SET)
    private ReverseDoc reverseDoc;

    public TransferWay4ToRsbk getTransferWay4ToRsbkDebit() {
        return transferWay4ToRsbkDebit;
    }

    public void setTransferWay4ToRsbkDebit(TransferWay4ToRsbk transferWay4ToRsbkDebit) {
        this.transferWay4ToRsbkDebit = transferWay4ToRsbkDebit;
    }

    public TransferWay4ToRsbk getTransferWay4ToRsbkReverseDebit() {
        return transferWay4ToRsbkReverseDebit;
    }

    public void setTransferWay4ToRsbkReverseDebit(TransferWay4ToRsbk transferWay4ToRsbkReverseDebit) {
        this.transferWay4ToRsbkReverseDebit = transferWay4ToRsbkReverseDebit;
    }

    public TransferWay4ToRsbk getTransferWay4ToRsbkCreditTransit() {
        return transferWay4ToRsbkCreditTransit;
    }

    public void setTransferWay4ToRsbkCreditTransit(TransferWay4ToRsbk transferWay4ToRsbkCreditTransit) {
        this.transferWay4ToRsbkCreditTransit = transferWay4ToRsbkCreditTransit;
    }

    public TransferWay4ToRsbk getTransferWay4ToRsbkReverseTransit() {
        return transferWay4ToRsbkReverseTransit;
    }

    public void setTransferWay4ToRsbkReverseTransit(TransferWay4ToRsbk transferWay4ToRsbkReverseTransit) {
        this.transferWay4ToRsbkReverseTransit = transferWay4ToRsbkReverseTransit;
    }

    public TransferWay4ToRsbkCreditRsbk getTransferWay4ToRsbkCreditRsbk() {
        return transferWay4ToRsbkCreditRsbk;
    }

    public void setTransferWay4ToRsbkCreditRsbk(TransferWay4ToRsbkCreditRsbk transferWay4ToRsbkCreditRsbk) {
        this.transferWay4ToRsbkCreditRsbk = transferWay4ToRsbkCreditRsbk;
    }

    public TransferTcWay4 getTransferTcWay4() {
        return transferTcWay4;
    }

    public void setTransferTcWay4(TransferTcWay4 transferTcWay4) {
        this.transferTcWay4 = transferTcWay4;
    }

    public RrnBrrn getRrnBrrn() {
        return rrnBrrn;
    }

    public void setRrnBrrn(RrnBrrn rrnBrrn) {
        this.rrnBrrn = rrnBrrn;
    }

    public PostingDate getPostingDate() {
        return postingDate;
    }

    public void setPostingDate(PostingDate postingDate) {
        this.postingDate = postingDate;
    }

    public Way4TransactionDate getWay4TransactionDate() {
        return way4TransactionDate;
    }

    public void setWay4TransactionDate(Way4TransactionDate way4TransactionDate) {
        this.way4TransactionDate = way4TransactionDate;
    }

    public ReverseDoc getReverseDoc() {
        return reverseDoc;
    }

    public void setReverseDoc(ReverseDoc reverseDoc) {
        this.reverseDoc = reverseDoc;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
