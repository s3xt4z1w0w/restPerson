package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import TransferSelf.EubAggregatorCardProductTransferSelf;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ConvertRequest;

import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toAggregatorCurrencyCode;
import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toDecimalValue;

public class TransferWay4ConvertMapper {

    public static EubAggregatorCardProductTransferSelf.TransferWay4ConvertUfxRequest toProtoModel(TransferWay4ConvertRequest requestModel) {
        return EubAggregatorCardProductTransferSelf.TransferWay4ConvertUfxRequest
                .newBuilder()
                .setRRN(requestModel.getRrn())
                .setSTAN(requestModel.getStan())
                .setOperationAccount(requestModel.getOperationAccount())
                .setOperationSum(toDecimalValue(requestModel.getOperationSum()))
                .setOperationCurrency(toAggregatorCurrencyCode(requestModel.getOperationCurrency()))
                .setSourceAccountCurrency(requestModel.getSourceAccountCurrency())
                .setTargetAccountCurrency(requestModel.getTargetAccountCurrency())
                .build();
    }
}
