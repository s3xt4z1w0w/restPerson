package eub.smart.cardproduct.transfer.self.domain.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToWay4Debit;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.util.StanUtil.generateStun;

public class TransferWay4ToWay4DebitMapper {

    private static String createDetails(String fullname, String accountNumber) {
        return String.format("%s; %s", fullname, accountNumber);
    }

    public static TransferWay4ToWay4Debit createDomainModel(FinDocData finDocData, AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn) {
        TransferWay4ToWay4Debit request = new TransferWay4ToWay4Debit();
        request.setFindoc(String.valueOf(finDocData.getId()));
        request.setRrn(rrnBrrn.getRrn());
        request.setBrrn(rrnBrrn.getBrrn());
        request.setStan(generateStun());
        request.setOperationAccount(senderData.getAccountNumber());
        request.setLinkedOperationAccount(receiverData.getAccountNumber());
        request.setSenderAmount(senderData.getAmount());
        request.setReceiverAmount(receiverData.getAmount());
        request.setSenderCurrency(senderData.getCurrency());
        request.setReceiverCurrency(receiverData.getCurrency());
        request.setDeposit(false);
        request.setDetails(createDetails(senderData.getFullName(), receiverData.getAccountNumber()));
        request.setSenderFlagMultiCurrency(senderData.getFlagMulti());
        request.setReceiverFlagMultiCurrency(receiverData.getFlagMulti());
        return request;
    }
}
