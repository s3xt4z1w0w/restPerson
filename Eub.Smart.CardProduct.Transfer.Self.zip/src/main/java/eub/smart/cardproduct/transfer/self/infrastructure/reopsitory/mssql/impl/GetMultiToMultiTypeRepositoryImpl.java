package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.MultiToMultiAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.GetMultiToMultiTypeRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.MultiToMultiAccountInfoMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class GetMultiToMultiTypeRepositoryImpl implements GetMultiToMultiTypeRepository {

    private final NamedParameterJdbcTemplate template;

    public GetMultiToMultiTypeRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<MultiToMultiAccountInfo> findByFinDocId(Long finDocId) {
        String sql = """ 
                select AccS.IsMultiCurrency as senderFlagMultiCurrency,
                       AccR.IsMultiCurrency as receiverFlagMultiCurrency,
                       AccS.Account_IDREF   as senderIdRef,
                       AccR.Account_IDREF   as receiverIdRef,
                       AccS.Number          as senderAccNumber,
                       AccR.Number          as receiverAccNumber
                from FinDoc F
                         join Account AccS on F.Account_IDREF = AccS.Account_ID
                         join BSystemClient BSCS on AccS.BSystemClient_IDREF = BSCS.BSystemClient_ID
                         join Transfer T on F.FinDoc_ID = T.FinDoc_IDREF
                         join Account AccR on T.Receiver_Account = AccR.Number
                         join BSystemClient BSCR on AccR.BSystemClient_IDREF = BSCR.BSystemClient_ID
                where F.FinDoc_ID = :finDocId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(MultiToMultiAccountInfoMapper::toDomainModel);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": GetMultiToMultiTypeRepository findByFinDocId");
        }
    }

    @Override
    public MultiToMultiAccountInfo findByFinDocIdOrException(Long finDocId) {
        return findByFinDocId(finDocId)
                .orElseThrow(() -> new SelfException(E_DB_600, ": GetMultiToMultiTypeRepository findByFinDocIdOrException"));
    }
}
