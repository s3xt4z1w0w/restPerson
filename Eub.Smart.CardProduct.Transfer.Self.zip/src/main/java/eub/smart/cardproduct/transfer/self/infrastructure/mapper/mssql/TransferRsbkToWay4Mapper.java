package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4Request;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.SELF;

public class TransferRsbkToWay4Mapper {

    public static TransferRsbkToWay4Request toDomainModel(Map<String, Object> row, Long finDocId) {
        MapResultScanner scanner = new MapResultScanner(row);

        TransferRsbkToWay4Request model = new TransferRsbkToWay4Request();
        model.setPayerAccount(scanner.getString("senderAccNumber"));
        model.setReceiverAccount(scanner.getString("receiverAccNumber"));
        model.setKnp(scanner.getString("knpCode"));
        model.setOperSum(scanner.getBigDecimal("senderAmount"));
        model.setSumInReceiverAccCurr(scanner.getBigDecimal("receiverAmount"));
        model.setComissSummTg(scanner.getBigDecimal("fee"));
        model.setDboId(String.valueOf(finDocId));
        model.setSelf(SELF.equals(scanner.getString("finDocType")) ? 1 : 0);
        model.setReceiverIsNotRez(String.valueOf(!scanner.getBoolean("receiverIsResident")));
        model.setReceiverName(scanner.getString("receiverName"));
        model.setReceiverIin(scanner.getString("receiverIIN"));
        model.setDateSign(scanner.getDate("signDate"));
        model.setReceiverAccountCurr(scanner.getString("receiverCurrency"));
        return model;
    }
}
