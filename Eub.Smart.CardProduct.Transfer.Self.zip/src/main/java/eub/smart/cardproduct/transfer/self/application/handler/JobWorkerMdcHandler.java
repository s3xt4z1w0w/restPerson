package eub.smart.cardproduct.transfer.self.application.handler;

import eub.smart.cardproduct.transfer.self.application.model.TransferInternalBaseModel;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.slf4j.MDC;

import static eub.smart.cardproduct.transfer.self.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.self.core.constant.UserDetails.PREFERRED_USERNAME;
import static eub.smart.cardproduct.transfer.self.core.constant.UserDetails.USER_ID;
import static eub.smart.cardproduct.transfer.self.core.constant.UserDetails.CLIENT_ID;
import static eub.smart.cardproduct.transfer.self.core.constant.UserDetails.IIN;

@Aspect
@Component
public class JobWorkerMdcHandler {

    @Before("within(eub.smart.cardproduct.transfer.self.application.worker..*)")
    public void before(JoinPoint joinPoint) {
        TransferInternalBaseModel baseModel = (TransferInternalBaseModel) joinPoint.getArgs()[0];

        MDC.put(CORRELATION_ID, baseModel.getCorrelationId());
        MDC.put(PREFERRED_USERNAME, baseModel.getSenderDetails().getPhoneNumber());
        MDC.put(USER_ID, baseModel.getSenderDetails().getUserId().toString());
        MDC.put(CLIENT_ID, baseModel.getSenderDetails().getClientId().toString());
        MDC.put(IIN, baseModel.getSender().getIin());
    }

    @After("within(eub.smart.cardproduct.transfer.self.application.worker..*)")
    public void after() {
        MDC.clear();
    }
}
