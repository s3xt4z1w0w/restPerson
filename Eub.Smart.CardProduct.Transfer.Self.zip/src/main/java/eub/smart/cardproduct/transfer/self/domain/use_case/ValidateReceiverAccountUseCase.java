package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;

public interface ValidateReceiverAccountUseCase {

    void invoke(AccountData senderDetails, LangKey lang);
}
