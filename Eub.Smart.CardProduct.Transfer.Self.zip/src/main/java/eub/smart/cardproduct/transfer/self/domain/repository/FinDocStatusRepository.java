package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.FinDocStatus;

import java.util.Optional;

public interface FinDocStatusRepository {

    Optional<FinDocStatus> findByFinIdDoc(Long finDocId);
    Optional<FinDocStatus> findById(String id);
    FinDocStatus findByIdOrException(String id);
}
