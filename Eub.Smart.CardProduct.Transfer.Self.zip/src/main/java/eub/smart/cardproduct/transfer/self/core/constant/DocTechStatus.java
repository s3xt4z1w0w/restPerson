package eub.smart.cardproduct.transfer.self.core.constant;

public interface DocTechStatus {

    String VLBS = "VLBS";
    String VLSU = "VLSU";
    String VLSS = "VLSS";
    String MTNT = "MTNT";
}
