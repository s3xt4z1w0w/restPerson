package eub.smart.cardproduct.transfer.self.presentation.model.response;


import io.swagger.v3.oas.annotations.media.Schema;

public record HistoryResponse(
        @Schema(description = "Id фин. док")
        Long finDocId,
        @Schema(description = "Тип фин. док")
        String finDocType,
        @Schema(description = "Дата создания перевода")
        Long createdDate,
        @Schema(description = "UID на иконку для перевода")
        MetaDocumentResponse image,
        @Schema(description = "Тип перевода")
        String transferType,
        @Schema(description = "Display sender")
        AccountNameDisplay senderDisplay,
        @Schema(description = "Display receiver")
        AccountNameDisplay receiverDisplay,
        @Schema(description = "Display amount")
        AmountDisplay amountDisplay,
        @Schema(description = "Дата создания перевода")
        String transferStatus
) {
}
