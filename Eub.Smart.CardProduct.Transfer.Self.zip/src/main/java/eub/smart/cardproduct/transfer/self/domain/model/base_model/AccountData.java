package eub.smart.cardproduct.transfer.self.domain.model.base_model;

import eub.smart.cardproduct.transfer.self.domain.model.FinDocInfo;

import java.math.BigDecimal;

public class AccountData {

    private String iin;
    private String bSystem;
    private String accountNumber;
    private BigDecimal amount;
    private String currency;
    private Boolean flagResident;
    private String fullName;
    private String accountType;
    private Boolean flagMulti;
    private String accountStatus;
    private Long accountIdRef;
    private Long accountOutRef;

    public AccountData() {
    }

    public AccountData(String iin,
                       String bSystem,
                       String accountNumber,
                       BigDecimal amount,
                       String currency,
                       Boolean flagResident,
                       String fullName,
                       String accountType,
                       Boolean flagMulti,
                       String accountStatus,
                       Long accountIdRef,
                       Long accountOutRef) {
        this.iin = iin;
        this.bSystem = bSystem;
        this.accountNumber = accountNumber;
        this.amount = amount;
        this.currency = currency;
        this.flagResident = flagResident;
        this.fullName = fullName;
        this.accountType = accountType;
        this.flagMulti = flagMulti;
        this.accountStatus = accountStatus;
        this.accountIdRef = accountIdRef;
        this.accountOutRef = accountOutRef;
    }

    public static AccountData buildSenderData(FinDocInfo finDocInfo) {
        return new AccountData(
                finDocInfo.getSenderIin(),
                finDocInfo.getSenderBSystem(),
                finDocInfo.getSenderAccountNumber(),
                finDocInfo.getSenderAmount(),
                finDocInfo.getSenderCurrency(),
                finDocInfo.getSenderFlagResident(),
                finDocInfo.getSenderFullName(),
                finDocInfo.getSenderAccountType(),
                finDocInfo.getSenderFlagMulti(),
                finDocInfo.getSenderAccountStatus(),
                finDocInfo.getSenderAccountIdRef(),
                finDocInfo.getSenderAccountOutRef());
    }

    public static AccountData buildReceiverData(FinDocInfo finDocInfo) {
        return new AccountData(
                finDocInfo.getReceiverIin(),
                finDocInfo.getReceiverBSystem(),
                finDocInfo.getReceiverAccountNumber(),
                finDocInfo.getReceiverAmount(),
                finDocInfo.getReceiverCurrency(),
                finDocInfo.getReceiverFlagResident(),
                finDocInfo.getReceiverFullName(),
                finDocInfo.getReceiverAccountType(),
                finDocInfo.getReceiverFlagMulti(),
                finDocInfo.getReceiverAccountStatus(),
                finDocInfo.getReceiverAccountIdRef(),
                finDocInfo.getReceiverAccountOutRef());
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public String getbSystem() {
        return bSystem;
    }

    public void setbSystem(String bSystem) {
        this.bSystem = bSystem;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Boolean getFlagMulti() {
        return flagMulti;
    }

    public void setFlagMulti(Boolean flagMulti) {
        this.flagMulti = flagMulti;
    }

    public Boolean getFlagResident() {
        return flagResident;
    }

    public void setFlagResident(Boolean flagResident) {
        this.flagResident = flagResident;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public Long getAccountIdRef() {
        return accountIdRef;
    }

    public void setAccountIdRef(Long accountIdRef) {
        this.accountIdRef = accountIdRef;
    }

    public Long getAccountOutRef() {
        return accountOutRef;
    }

    public void setAccountOutRef(Long accountOutRef) {
        this.accountOutRef = accountOutRef;
    }

    @Override
    public String toString() {
        return "AccountData{" +
                "iin=" + iin +
                ", bSystem=" + bSystem +
                ", accountNumber=" + accountNumber +
                ", amount=" + amount +
                ", currency=" + currency +
                ", flagResident=" + flagResident +
                ", fullName=" + fullName +
                ", accountType=" + accountType +
                ", flagMulti=" + flagMulti +
                ", accountStatus=" + accountStatus +
                ", accountIdRef=" + accountIdRef +
                ", accountOutRef=" + accountOutRef +
                '}';
    }
}
