package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class UfxResponse {
    private Boolean status;
    private String errorMessage;

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "UfxResponse{" +
                "status=" + status +
                ", errorMessage=" + errorMessage +
                "}";
    }
}
