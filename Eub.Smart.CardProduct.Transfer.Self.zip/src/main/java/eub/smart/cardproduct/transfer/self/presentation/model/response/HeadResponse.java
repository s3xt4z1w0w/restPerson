package eub.smart.cardproduct.transfer.self.presentation.model.response;

import eub.smart.cardproduct.transfer.self.domain.model.out.AmountDisplay;
import eub.smart.cardproduct.transfer.self.domain.model.out.MetaDocumentOut;
import io.swagger.v3.oas.annotations.media.Schema;

public record HeadResponse(
        @Schema(description = "Display amount")
        AmountDisplay amountDisplay,
        @Schema(description = "Display fee")
        AmountDisplay feeDisplay,
        @Schema(description = "Status")
        String status,
        @Schema(description = "UID на иконку для перевода")
        MetaDocumentOut image,
        @Schema(description = "Данные зоголовка")
        String title,
        @Schema(description = "Данные зоголовка")
        String desc
) {
}
