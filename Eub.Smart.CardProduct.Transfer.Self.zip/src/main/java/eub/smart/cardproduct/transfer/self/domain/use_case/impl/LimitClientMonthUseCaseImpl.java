package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.repository.LimitClientMonthRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitClientMonthUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitFinDocUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitUseCase;

import java.math.BigDecimal;
import java.time.LocalDate;

import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isEmpty;

public class LimitClientMonthUseCaseImpl implements LimitClientMonthUseCase {

    private final LimitClientMonthRepository limitClientMonthRepository;
    private final LimitFinDocUseCase finDocUseCase;
    private final LimitUseCase limitUseCase;

    public LimitClientMonthUseCaseImpl(LimitClientMonthRepository limitClientMonthRepository,
                                       LimitFinDocUseCase finDocUseCase, LimitUseCase limitUseCase) {
        this.limitClientMonthRepository = limitClientMonthRepository;
        this.finDocUseCase = finDocUseCase;
        this.limitUseCase = limitUseCase;
    }

    @Override
    public void invoke(BigDecimal limitMonth, Long clientId, Long userId, BigDecimal amount, String currency, String correlationId) {
        var now = LocalDate.now();
        var currentMonth = LocalDate.of(now.getYear(), now.getMonth(), 1);
        var spentAmountGroupByCurrency = limitClientMonthRepository.findByClientIdAndUserId(currentMonth, clientId, userId);
        if (isEmpty(spentAmountGroupByCurrency)) finDocUseCase.invoke(limitMonth, amount, currency, correlationId);
        limitUseCase.invoke(limitMonth, correlationId, amount, currency, false, spentAmountGroupByCurrency);
    }

}
