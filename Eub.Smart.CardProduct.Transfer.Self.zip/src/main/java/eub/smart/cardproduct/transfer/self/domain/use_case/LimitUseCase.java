package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.limit.SpentAmount;

import java.math.BigDecimal;
import java.util.List;

public interface LimitUseCase {

    void invoke(BigDecimal limitDay, String correlationId, BigDecimal amount, String currency, Boolean convert, List<SpentAmount> spentAmountGroupByCurrency);
}
