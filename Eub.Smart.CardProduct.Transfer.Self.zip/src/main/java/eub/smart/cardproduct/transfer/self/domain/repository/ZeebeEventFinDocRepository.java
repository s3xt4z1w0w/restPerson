package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.ZeebeEventFinDoc;

public interface ZeebeEventFinDocRepository {

    void save(Long finDocId);

    void saveErrorMessage(Long finDocId, SelfException exception);

    void saveResult(ZeebeEventFinDoc zeebeEventFinDoc);
}
