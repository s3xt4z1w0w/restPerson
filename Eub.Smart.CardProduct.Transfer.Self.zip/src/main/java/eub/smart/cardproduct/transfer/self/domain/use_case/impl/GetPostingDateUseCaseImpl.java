package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDate;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDateRequest;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.repository.Way4TransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetPostingDateUseCase;

public class GetPostingDateUseCaseImpl implements GetPostingDateUseCase {

    private final Way4TransactionalProtoRepository way4TransactionalProtoRepository;

    public GetPostingDateUseCaseImpl(Way4TransactionalProtoRepository way4TransactionalProtoRepository) {
        this.way4TransactionalProtoRepository = way4TransactionalProtoRepository;
    }

    @Override
    public PostingDate invoke(RrnBrrn rrnBrrn, String correlationId) {
        var request = new PostingDateRequest(rrnBrrn.getRrn());
        var response = way4TransactionalProtoRepository.getPostingDate(request, correlationId);
        return new PostingDate(request, response);
    }
}
