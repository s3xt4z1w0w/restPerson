package eub.smart.cardproduct.transfer.self.domain.repository;

import java.util.Optional;

public interface ViewMapAccountBSystemClientRepository {

    Optional<Long> findProductId(String accountNumber);

    Long findProductIdOrException(String accountNumber);
}
