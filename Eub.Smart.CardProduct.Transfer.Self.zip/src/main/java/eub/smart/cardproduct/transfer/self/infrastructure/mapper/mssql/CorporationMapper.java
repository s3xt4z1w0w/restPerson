package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.NewTransferClient;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class CorporationMapper {

    public static NewTransferClient toDomainModel(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);

        NewTransferClient model = new NewTransferClient();
        model.setName(scanner.getString("name"));
        model.setFlagResident(scanner.getBoolean("flagResident"));
        model.setFlagCorporate(true);
        model.setBin(scanner.getString("bin"));
        return model;
    }
}
