package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbk;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferWay4ToRsbkCreditTransitUseCase;
import eub.smart.cardproduct.transfer.self.domain.mapper.TransferWay4ToRsbkCreditTransitMapper;

public class TransferWay4ToRsbkCreditTransitUseCaseImpl implements TransferWay4ToRsbkCreditTransitUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;
    private final String operationAccount;

    public TransferWay4ToRsbkCreditTransitUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository,
                                                      String operationAccount) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
        this.operationAccount = operationAccount;
    }

    @Override
    public TransferWay4ToRsbk invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn) {
        var request = TransferWay4ToRsbkCreditTransitMapper.createRequest(finDocData, senderData, receiverData, rrnBrrn, operationAccount);
        var response = transferSelfProtoRepository.transferWay4ToRsbkCreditTransit(request);
        return new TransferWay4ToRsbk(request, response);
    }
}
