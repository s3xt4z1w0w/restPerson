package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.create_transfer.CreateTransfer;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;

import java.math.BigDecimal;
import java.util.List;

public interface GetCreateTransferUseCase {

    CreateTransfer invoke(String senderAccountNumber,
                          String receiverAccountNumber,
                          BigDecimal senderAmount,
                          BigDecimal receiverAmount,
                          String senderCurrency,
                          String receiverCurrency,
                          List<CurrencyRate> currencyRates,
                          String correlationId);
}
