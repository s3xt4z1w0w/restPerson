package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.ZeebeEventFinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.repository.ZeebeEventFinDocRepository;

public class ZeebeEventFinDocSaveResult {

    private final ZeebeEventFinDocRepository zeebeEventFinDocRepository;

    public ZeebeEventFinDocSaveResult(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        this.zeebeEventFinDocRepository = zeebeEventFinDocRepository;
    }

    protected void saveResult(Long finDocId) {
        var zeebeEventFinDoc = new ZeebeEventFinDoc(finDocId);
        zeebeEventFinDocRepository.saveResult(zeebeEventFinDoc);
    }

    protected void saveResult(Long finDocId, String collectorId) {
        var zeebeEventFinDoc = new ZeebeEventFinDoc(finDocId, collectorId);
        zeebeEventFinDocRepository.saveResult(zeebeEventFinDoc);
    }

    protected void saveResult(Long finDocId, RrnBrrn rrnBrrn) {
        var rrn = rrnBrrn.getRrn();
        var brrn = rrnBrrn.getBrrn();

        var zeebeEventFinDoc = new ZeebeEventFinDoc(finDocId, rrn, brrn);
        zeebeEventFinDocRepository.saveResult(zeebeEventFinDoc);
    }

    protected void saveResult(Long finDocId, RrnBrrn rrnBrrn, String collectorId) {
        var rrn = rrnBrrn.getRrn();
        var brrn = rrnBrrn.getBrrn();

        var zeebeEventFinDoc = new ZeebeEventFinDoc(finDocId, rrn, brrn, collectorId);
        zeebeEventFinDocRepository.saveResult(zeebeEventFinDoc);
    }
}
