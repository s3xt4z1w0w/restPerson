package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class CommonMapper {

    public static Long getLong(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);
        return scanner.getLong("id");
    }

    public static String getString(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);
        return scanner.getString("type");
    }
}
