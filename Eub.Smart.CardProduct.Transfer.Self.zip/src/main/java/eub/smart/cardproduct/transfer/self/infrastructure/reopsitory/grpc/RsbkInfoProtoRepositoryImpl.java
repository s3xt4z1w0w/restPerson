package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.grpc;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;
import eub.smart.cardproduct.transfer.self.domain.repository.RsbkInfoProtoRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.GetCurrencyRatesListMapper;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Component;
import rsbkinfo.V1.RsbkInfoGrpc;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_EX_700;

@Component
public class RsbkInfoProtoRepositoryImpl implements RsbkInfoProtoRepository {

    @GrpcClient("adapter-rsbk-info")
    private RsbkInfoGrpc.RsbkInfoBlockingStub stub;

    @Override
    public CurrencyRate getCurrencyRate(String currency, String correlationId) {
        try {
            var request = GetCurrencyRatesListMapper.toGrpcModel(currency);
            var response = stub
                    .getCurrencyRatesList(request);
            return GetCurrencyRatesListMapper.toDomainModel(response);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": getCurrencyRatesList " + e.getStatus().getCode().name());
        }
    }
}
