package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;
import java.util.Date;

public class TransferWay4ToRsbkRequest {

    private String payerAccount;
    private String receiverAccount;
    private BigDecimal operSum;
    private String knp;
    private String viCardIso;
    private Integer isSelf;
    private String viCardHolderName;
    private String viCardHolderName1;
    private String viCardHolderName2;
    private String viCardHolderName3;
    private String viIin;
    private String viNotRez;
    private BigDecimal viCalcSumm;
    private String ground;
    private String dboId;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date dateSign;
    private Integer isSpecRate;
    private BigDecimal rate;
    private BigDecimal coverRate;
    private String dboIdPrefix;
    private Integer procVersion;

    public String getPayerAccount() {
        return payerAccount;
    }

    public String getReceiverAccount() {
        return receiverAccount;
    }

    public BigDecimal getOperSum() {
        return operSum;
    }

    public String getKnp() {
        return knp;
    }

    public String getViCardIso() {
        return viCardIso;
    }

    public Integer getIsSelf() {
        return isSelf;
    }

    public String getViCardHolderName() {
        return viCardHolderName;
    }

    public String getViCardHolderName1() {
        return viCardHolderName1;
    }

    public String getViCardHolderName2() {
        return viCardHolderName2;
    }

    public String getViCardHolderName3() {
        return viCardHolderName3;
    }

    public String getViIin() {
        return viIin;
    }

    public String getViNotRez() {
        return viNotRez;
    }

    public BigDecimal getViCalcSumm() {
        return viCalcSumm;
    }

    public String getGround() {
        return ground;
    }

    public String getDboId() {
        return dboId;
    }

    public Date getDateSign() {
        return dateSign;
    }

    public Integer getIsSpecRate() {
        return isSpecRate;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public BigDecimal getCoverRate() {
        return coverRate;
    }

    public String getDboIdPrefix() {
        return dboIdPrefix;
    }

    public Integer getProcVersion() {
        return procVersion;
    }

    public void setPayerAccount(String payerAccount) {
        this.payerAccount = payerAccount;
    }

    public void setReceiverAccount(String receiverAccount) {
        this.receiverAccount = receiverAccount;
    }

    public void setOperSum(BigDecimal operSum) {
        this.operSum = operSum;
    }

    public void setKnp(String knp) {
        this.knp = knp;
    }

    public void setViCardIso(String viCardIso) {
        this.viCardIso = viCardIso;
    }

    public void setIsSelf(Integer isSelf) {
        this.isSelf = isSelf;
    }

    public void setViCardHolderName(String viCardHolderName) {
        this.viCardHolderName = viCardHolderName;
    }

    public void setViCardHolderName1(String viCardHolderName1) {
        this.viCardHolderName1 = viCardHolderName1;
    }

    public void setViCardHolderName2(String viCardHolderName2) {
        this.viCardHolderName2 = viCardHolderName2;
    }

    public void setViCardHolderName3(String viCardHolderName3) {
        this.viCardHolderName3 = viCardHolderName3;
    }

    public void setViIin(String viIin) {
        this.viIin = viIin;
    }

    public void setViNotRez(String viNotRez) {
        this.viNotRez = viNotRez;
    }

    public void setViCalcSumm(BigDecimal viCalcSumm) {
        this.viCalcSumm = viCalcSumm;
    }

    public void setGround(String ground) {
        this.ground = ground;
    }

    public void setDboId(String dboId) {
        this.dboId = dboId;
    }

    public void setDateSign(Date dateSign) {
        this.dateSign = dateSign;
    }

    public void setIsSpecRate(Integer isSpecRate) {
        this.isSpecRate = isSpecRate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    public void setCoverRate(BigDecimal coverRate) {
        this.coverRate = coverRate;
    }

    public void setDboIdPrefix(String dboIdPrefix) {
        this.dboIdPrefix = dboIdPrefix;
    }

    public void setProcVersion(Integer procVersion) {
        this.procVersion = procVersion;
    }

    @Override
    public String toString() {
        return "TransferWay4ToRsbkRequest{" +
                "payerAccount=" + payerAccount +
                ", receiverAccount=" + receiverAccount +
                ", operSum=" + operSum +
                ", knp=" + knp +
                ", viCardIso=" + viCardIso +
                ", isSelf=" + isSelf +
                ", viCardHolderName=" + viCardHolderName +
                ", viCardHolderName1=" + viCardHolderName1 +
                ", viCardHolderName2=" + viCardHolderName2 +
                ", viCardHolderName3=" + viCardHolderName3 +
                ", viIin=" + viIin +
                ", viNotRez=" + viNotRez +
                ", viCalcSumm=" + viCalcSumm +
                ", ground=" + ground +
                ", dboId=" + dboId +
                ", dateSign=" + dateSign +
                ", isSpecRate=" + isSpecRate +
                ", rate=" + rate +
                ", coverRate=" + coverRate +
                ", dboIdPrefix=" + dboIdPrefix +
                ", procVersion=" + procVersion +
                '}';
    }
}
