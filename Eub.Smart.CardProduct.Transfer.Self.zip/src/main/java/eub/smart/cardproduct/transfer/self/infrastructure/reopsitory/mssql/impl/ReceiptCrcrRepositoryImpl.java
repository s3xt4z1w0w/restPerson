package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.out.TransferReceiptOut;
import eub.smart.cardproduct.transfer.self.domain.repository.ReceiptRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.ReceiptCrcrMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.CRCR;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Repository
public class ReceiptCrcrRepositoryImpl implements ReceiptRepository {

    private final NamedParameterJdbcTemplate template;

    public ReceiptCrcrRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<TransferReceiptOut> findByFinDocId(Long finDocId, LangKey lang) {
        String sql = """
                select fd.Amount                                    as amount,
                       fd.Currency                                  as currency,
                       fd.Fee                                       as fee,
                       fd.FeeCurrency                               as feeCurrency,
                       bank.bank_ID                                 as dataTitle_imagesUrl_Definition,
                       dts.FinDocStatus_IDREF                       as status,
                       case
                           when bc.Bin is not null then
                               case
                                   when bank.term_OUTREF is not null then
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (trm_bank.Term_RU + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (trm_bank.Term_RU + ' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (trm_bank.Term_RU + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (trm_bank.Term_RU + ' • ') end
                                           end
                                   else /*b.term_OUTREF is null*/
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (bank.bank_title + ' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (bank.bank_title + ' • ') end
                                           end
                                   end
                           /*1*/
                           else /*bc.Bin is null*/
                               case
                                   when bank.term_OUTREF is not null then
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else '' end
                                           end
                                   else /*b.term_OUTREF is null*/
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else '' end
                                           end
                                   end
                           end                                      as dataTitle_title_RU,
                       case
                           when bc.Bin is not null then
                               case
                                   when bank.term_OUTREF is not null then
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (trm_bank.Term_KZ + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (trm_bank.Term_KZ + ' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (trm_bank.Term_KZ + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (trm_bank.Term_KZ + ' • ') end
                                           end
                                   else /*b.term_OUTREF is null*/
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (bank.bank_title + ' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (bank.bank_title + ' • ') end
                                           end
                                   end
                           /*1*/
                           else /*bc.Bin is null*/
                               case
                                   when bank.term_OUTREF is not null then
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else '' end
                                           end
                                   else /*b.term_OUTREF is null*/
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else '' end
                                           end
                                   end
                           end                                      as dataTitle_title_KZ,
                       case
                           when bc.Bin is not null then
                               case
                                   when bank.term_OUTREF is not null then
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (trm_bank.term_EN + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (trm_bank.term_EN + ' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (trm_bank.term_EN + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (trm_bank.term_EN + ' • ') end
                                           end
                                   else /*b.term_OUTREF is null*/
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (bank.bank_title + ' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (bank.bank_title + ' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (bank.bank_title + ' • ') end
                                           end
                                   end
                           /*1*/
                           else /*bc.Bin is null*/
                               case
                                   when bank.term_OUTREF is not null then
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else '' end
                                           end
                                   else /*b.term_OUTREF is null*/
                                       case
                                           when c2.MaskedNumber is not null then
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else (' • ' + right(c2.MaskedNumber, 4)) end
                                           else /*cc2.MaskedNumber is null*/
                                               case
                                                   when ct.CreditMaskedCardNumber is not null
                                                       then (' • ' + right(ct.CreditMaskedCardNumber, 4))
                                                   /*ct.CreditMaskedCardNumber is null*/
                                                   else '' end
                                           end
                                   end
                           end                                      as dataTitle_title_EN,
                       trm_fdt.Term_RU                              as dataTitle_desc_RU,
                       trm_fdt.Term_KZ                              as dataTitle_desc_KZ,
                       trm_fdt.Term_EN                              as dataTitle_desc_EN,
                       'Отправитель'                                as dataDesc_k1_RU,
                       N'Жіберуші'                                  as dataDesc_k1_KZ,
                       'Sender'                                     as dataDesc_k1_EN,
                       (p.FirstName + ' ' + left(p.Firstname, 1) + '. ' +
                        isnull(left((p.FathersName + '.'), 1), '')) as dataDesc_v1_RU,
                       (p.FirstName + ' ' + left(p.Firstname, 1) + '. ' +
                        isnull(left((p.FathersName + '.'), 1), '')) as dataDesc_v1_KZ,
                       (p.FirstName + ' ' + left(p.Firstname, 1) + '. ' +
                        isnull(left((p.FathersName + '.'), 1), '')) as dataDesc_v1_EN,
                       'Откуда'                                     as dataDesc_k2_RU,
                       N'Қайдан'                                    as dataDesc_k2_KZ,
                       'From'                                       as dataDesc_k2_EN,
                       case
                           when ct.DebitMaskedCardNumber is not null then
                               case
                                   when ct.DebitCard_IDREF is not null
                                       then (ct1.CardType_Title + ' • ' + right(ct.DebitMaskedCardNumber, 4))
                                   else (' • ' + right(ct.DebitMaskedCardNumber, 4)) end
                           else case
                                    when ct.DebitCard_IDREF is not null then (ct1.CardType_Title + ' • ' + right(c1.MaskedNumber, 4))
                                    else (' • ' + right(c1.MaskedNumber, 4)) end
                           end                                      as dataDesc_v2_RU,
                       case
                           when ct.DebitMaskedCardNumber is not null then
                               case
                                   when ct.DebitCard_IDREF is not null
                                       then (ct1.CardType_Title + ' • ' + right(ct.DebitMaskedCardNumber, 4))
                                   else (' • ' + right(ct.DebitMaskedCardNumber, 4)) end
                           else case
                                    when ct.DebitCard_IDREF is not null then (ct1.CardType_Title + ' • ' + right(c1.MaskedNumber, 4))
                                    else (' • ' + right(c1.MaskedNumber, 4)) end
                           end                                      as dataDesc_v2_KZ,
                       case
                           when ct.DebitMaskedCardNumber is not null then
                               case
                                   when ct.DebitCard_IDREF is not null
                                       then (ct1.CardType_Title + ' • ' + right(ct.DebitMaskedCardNumber, 4))
                                   else (' • ' + right(ct.DebitMaskedCardNumber, 4)) end
                           else case
                                    when ct.DebitCard_IDREF is not null then (ct1.CardType_Title + ' • ' + right(c1.MaskedNumber, 4))
                                    else (' • ' + right(c1.MaskedNumber, 4)) end
                           end                                      as dataDesc_v2_EN,
                       'Дата'                                       as dataDetails_k1_RU,
                       N'Күні'                                      as dataDetails_k1_KZ,
                       'Date'                                       as dataDetails_k1_EN,
                       fd.DateCreated                               as dataDetails_v1_RU,
                       fd.DateCreated                               as dataDetails_v1_KZ,
                       fd.DateCreated                               as dataDetails_v1_EN,
                       '№ квитанции'                                as dataDetails_k2_RU,
                       N'Түбіртектің нөмірі'                        as dataDetails_k2_KZ,
                       'Receipt No.'                                as dataDetails_k2_EN,
                       fd.FinDoc_ID                                 as dataDetails_v2_RU,
                       fd.FinDoc_ID                                 as dataDetails_v2_KZ,
                       fd.FinDoc_ID                                 as dataDetails_v2_EN
                from FinDoc fd
                         join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                         join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                   dts.FinDocStatus_IDREF in ('DONE', 'RTRN')
                         join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                         left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                         join CardTransfer ct on ct.FinDoc_IDREF = fd.FinDoc_ID and ct.CardTransferType_IDREF != 'LPEC'
                         left join CardTransferType ctt on ct.CardTransferType_IDREF = ctt.CardTransferType_ID
                         left join card c1 on ct.DebitCard_IDREF = c1.Card_ID
                         left join card c2 on ct.CreditCard_IDREF = c2.Card_ID
                         left join CardType ct1 on c1.CardType_IDREF = ct1.CardType_ID
                         left join CardType ct2 on c2.CardType_IDREF = ct2.CardType_ID
                         left join BinCard bc on left(ct.CreditMaskedCardNumber, 6) = bc.Bin
                         left join Bank bank on bc.Bank_IDREF = bank.Bank_ID
                         left join Term trm_bank on bank.Term_OUTREF = trm_bank.Term_ID
                         left join [User] u on fd.User_IDREF = u.User_ID
                         left join Person p on u.Person_IDREF = p.Person_ID
                where FinDocType_ID in ('CRCR')
                  and fd.FinDoc_ID = :finDocId;
                """;
        List<TransferReceiptOut> queryResult = template.query(sql, Map.of("finDocId", finDocId), (resultSet, i) -> ReceiptCrcrMapper.toDomain(resultSet, lang));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": ReceiptCrcrRepositoryImpl findByFinDocId");
        }
    }

    @Override
    public TransferReceiptOut findByFinDocIdOrException(Long finDocId, LangKey lang) {
        return findByFinDocId(finDocId, lang).
                orElseThrow(() -> new SelfException(E_DB_600, ": ReceiptCrcrRepositoryImpl findByFinDocIdOrException"));
    }

    @Override
    public String key() {
        return CRCR;
    }
}
