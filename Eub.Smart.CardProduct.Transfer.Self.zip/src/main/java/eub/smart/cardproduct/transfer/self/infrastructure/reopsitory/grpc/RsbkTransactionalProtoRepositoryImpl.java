package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.grpc;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;
import eub.smart.cardproduct.transfer.self.domain.repository.RsbkTransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.handler.GrpcReturnValueHandler;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.*;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Component;
import rsbktransactional.V1.RsbkTransactionalGrpc;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_EX_700;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.TransferInternalRsbkToRsbkMapper.toDomainModel;

@Component
public class RsbkTransactionalProtoRepositoryImpl implements RsbkTransactionalProtoRepository {

    @GrpcClient("adapter-rsbk-transactional")
    private RsbkTransactionalGrpc.RsbkTransactionalBlockingStub stub;

    @Override
    @GrpcReturnValueHandler(methodName = "setWay4TransactionDate")
    public TransferResponse setWay4TransactionDate(SetWay4TransactionDateRequest requestModel, String correlationId) {
        try {
            var grpcRequest = Way4TransactionDateMapper.toGrpcModel(requestModel);
            var grpcResponse = stub.setWay4TransactionDate(grpcRequest);
            return RsbkTransactionalProtoMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": setWay4TransactionDate " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "tryReverseDoc")
    public TryReverseDocReply tryReverseDoc(TryReverseDocRequest requestModel, String correlationId) {
        try {
            var grpcRequest = ReverseDocMapper.toGrpcModel(requestModel);
            var grpcResponse = stub.tryReverseDoc(grpcRequest);
            return ReverseDocMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": tryReverseDoc " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4ToRsbkCreditRsbk")
    public TransferResponse transferWay4ToRsbkCreditRsbk(TransferWay4ToRsbkRequest requestModel) {
        try {
            var grpcRequest = TransferWay4ToRsbkCreditRsbkMapper.toGrpcModel(requestModel);
            var grpcResponse = stub.transferWay4ToRsbkCreditRsbk(grpcRequest);
            return RsbkTransactionalProtoMapper.toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4ToRsbkCreditRsbk " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferRsbkToRsbk")
    public TransferResponse transferRsbkToRsbk(TransferRsbkToRsbkRequest requestModel, String correlationId) {
        try {
            var grpcRequest = TransferInternalRsbkToRsbkMapper.toGrpcModel(requestModel);
            var grpcResponse = stub.transferRsbkToRsbk(grpcRequest);
            return toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferRsbkToRsbk " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferRsbkToWay4")
    public TransferResponse transferRsbkToWay4(TransferRsbkToWay4Request requestModel, String correlationId) {
        try {
            var grpcRequest = TransferInternalRsbkToWay4Mapper.toGrpcModel(requestModel);
            var grpcResponse = stub.transferRsbkToWay4(grpcRequest);
            return toDomainModel(grpcResponse);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferRsbkToWay4 " + e.getStatus().getCode().name());
        }
    }
}
