package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDateRequest;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDateResponse;

import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toDate;

public class PostingDateMapper {

    public static way4transactional.EubAdapterWay4Transactional.PostingDateRequest toGrpcModel(PostingDateRequest requestModel) {
        return way4transactional.EubAdapterWay4Transactional.PostingDateRequest
                .newBuilder()
                .setRrn(requestModel.getRrn())
                .build();
    }

    public static PostingDateResponse toDomainModel(way4transactional.EubAdapterWay4Transactional.PostingDateResponse response) {
        return new PostingDateResponse(response.getDocStatus(), toDate(response.getPostingDate()));
    }
}
