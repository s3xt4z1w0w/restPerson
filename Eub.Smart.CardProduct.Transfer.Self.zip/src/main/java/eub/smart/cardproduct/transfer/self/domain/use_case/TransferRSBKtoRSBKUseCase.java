package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbk;

public interface TransferRSBKtoRSBKUseCase {

    TransferRsbkToRsbk invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData);
}
