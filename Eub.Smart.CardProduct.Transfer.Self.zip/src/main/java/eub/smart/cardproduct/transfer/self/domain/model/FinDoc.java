package eub.smart.cardproduct.transfer.self.domain.model;

import java.math.BigDecimal;
import java.util.Date;

public class FinDoc {

    private Long id;
    private String docType;
    private Long userId;
    private byte[] blob;
    private Long accountId;
    private String currency;
    private BigDecimal amount;
    private BigDecimal feeAmount;
    private String feeCurrency;
    private Date dateCreated;
    private Date dateScheduled;
    private Date dateSigned;
    private Boolean flagUrgent;
    private Boolean flagTemplate;
    private String frontEnd;
    private String details;
    private int lockVersion;
    private Long finDocId;

    public FinDoc() {
    }

    public FinDoc(String docType,
                  Long userId,
                  byte[] blob,
                  Long accountId,
                  String currency,
                  BigDecimal amount,
                  BigDecimal feeAmount,
                  String feeCurrency,
                  Date dateCreated,
                  Date dateScheduled,
                  Date dateSigned,
                  Boolean flagUrgent,
                  Boolean flagTemplate,
                  String frontEnd,
                  String details,
                  int lockVersion,
                  Long finDocId) {
        this.docType = docType;
        this.userId = userId;
        this.blob = blob;
        this.accountId = accountId;
        this.currency = currency;
        this.amount = amount;
        this.feeAmount = feeAmount;
        this.feeCurrency = feeCurrency;
        this.dateCreated = dateCreated;
        this.dateScheduled = dateScheduled;
        this.dateSigned = dateSigned;
        this.flagUrgent = flagUrgent;
        this.flagTemplate = flagTemplate;
        this.frontEnd = frontEnd;
        this.details = details;
        this.lockVersion = lockVersion;
        this.finDocId = finDocId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public byte[] getBlob() {
        return blob;
    }

    public void setBlob(byte[] blob) {
        this.blob = blob;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public String getFeeCurrency() {
        return feeCurrency;
    }

    public void setFeeCurrency(String feeCurrency) {
        this.feeCurrency = feeCurrency;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateScheduled() {
        return dateScheduled;
    }

    public void setDateScheduled(Date dateScheduled) {
        this.dateScheduled = dateScheduled;
    }

    public Date getDateSigned() {
        return dateSigned;
    }

    public void setDateSigned(Date dateSigned) {
        this.dateSigned = dateSigned;
    }

    public Boolean getFlagUrgent() {
        return flagUrgent;
    }

    public void setFlagUrgent(Boolean flagUrgent) {
        this.flagUrgent = flagUrgent;
    }

    public Boolean getFlagTemplate() {
        return flagTemplate;
    }

    public void setFlagTemplate(Boolean flagTemplate) {
        this.flagTemplate = flagTemplate;
    }

    public String getFrontEnd() {
        return frontEnd;
    }

    public void setFrontEnd(String frontEnd) {
        this.frontEnd = frontEnd;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public int getLockVersion() {
        return lockVersion;
    }

    public void setLockVersion(int lockVersion) {
        this.lockVersion = lockVersion;
    }

    public Long getFinDocId() {
        return finDocId;
    }

    public void setFinDocId(Long finDocId) {
        this.finDocId = finDocId;
    }

    @Override
    public String toString() {
        return "FinDoc{" +
                "id=" + id +
                ", docType=" + docType +
                ", userId=" + userId +
                ", accountId=" + accountId +
                ", currency=" + currency +
                ", amount=" + amount +
                ", feeAmount=" + feeAmount +
                ", feeCurrency=" + feeCurrency +
                ", dateCreated=" + dateCreated +
                ", dateScheduled=" + dateScheduled +
                ", dateSigned=" + dateSigned +
                ", flagUrgent=" + flagUrgent +
                ", flagTemplate=" + flagTemplate +
                ", frontEnd=" + frontEnd +
                ", details=" + details +
                ", lockVersion=" + lockVersion +
                ", finDocId=" + finDocId +
                '}';
    }
}
