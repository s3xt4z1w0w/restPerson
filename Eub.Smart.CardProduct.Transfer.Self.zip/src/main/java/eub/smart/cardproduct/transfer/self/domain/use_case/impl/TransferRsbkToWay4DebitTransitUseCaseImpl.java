package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4Credit;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferRsbkToWay4DebitTransitUseCase;

import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.TransferRsbkToWay4DebitTransitMapper.createRequest;

public class TransferRsbkToWay4DebitTransitUseCaseImpl implements TransferRsbkToWay4DebitTransitUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;
    private final String operationAccount;

    public TransferRsbkToWay4DebitTransitUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository,
                                                     String operationAccount) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
        this.operationAccount = operationAccount;
    }

    @Override
    public TransferRsbkToWay4Credit invoke(FinDocData finDocData, AccountData receiverData, RrnBrrn rrnBrrn) {
        var request = createRequest(finDocData, receiverData, rrnBrrn, operationAccount);
        var response = transferSelfProtoRepository.transferRsbkToWay4DebitTransit(request);
        return new TransferRsbkToWay4Credit(request, response);
    }
}
