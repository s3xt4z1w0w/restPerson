package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TransferWay4Post {

    private final TransferWay4PostRequest transferWay4PostRequest;
    private final TransferWay4PostResponse transferWay4PostResponse;

    @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
    public TransferWay4Post(@JsonProperty("transferWay4PostRequest") TransferWay4PostRequest transferWay4PostRequest,
                            @JsonProperty("transferWay4PostResponse") TransferWay4PostResponse transferWay4PostResponse) {
        this.transferWay4PostRequest = transferWay4PostRequest;
        this.transferWay4PostResponse = transferWay4PostResponse;
    }

    public TransferWay4PostRequest getTransferWay4PostRequest() {
        return transferWay4PostRequest;
    }

    public TransferWay4PostResponse getTransferWay4PostResponse() {
        return transferWay4PostResponse;
    }
}
