package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import TransferSelf.EubAggregatorCardProductTransferSelf;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferIbanToIbanRequest;

import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toAggregatorCurrencyCode;
import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toDecimalValue;

public class TransferIbanToIbanMapper {

    public static EubAggregatorCardProductTransferSelf.TransferIbanToIbanRq toProtoModel(TransferIbanToIbanRequest requestModel) {
        return EubAggregatorCardProductTransferSelf.TransferIbanToIbanRq
                .newBuilder()
                .setSenderNumber(requestModel.getSenderNumber())
                .setReceiverNumber(requestModel.getReceiverNumber())
                .setSTAN(requestModel.getStan())
                .setRRN(requestModel.getRrn())
                .setAmount(toDecimalValue(requestModel.getAmount()))
                .setCurrency(toAggregatorCurrencyCode(requestModel.getCurrency()))
                .build();
    }
}
