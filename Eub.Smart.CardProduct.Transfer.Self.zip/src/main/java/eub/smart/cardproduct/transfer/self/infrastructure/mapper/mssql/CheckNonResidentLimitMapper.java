package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class CheckNonResidentLimitMapper {

    public static Usage toDomainModel(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);

        Usage model = new Usage();
        model.setId(scanner.getLong("usage_id"));
        model.setLimitDay(scanner.getBigDecimal("limit_day"));
        model.setLimitNight(scanner.getBigDecimal("limit_night"));
        return model;
    }
}
