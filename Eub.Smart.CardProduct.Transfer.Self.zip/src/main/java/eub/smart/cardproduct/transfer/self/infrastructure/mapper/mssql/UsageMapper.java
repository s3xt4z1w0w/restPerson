package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class UsageMapper {

    public static Usage toDomainModel(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);

        Usage model = new Usage();
        model.setId(scanner.getLong("id"));
        model.setLimitFinDoc(scanner.getBigDecimal("limitFinDoc"));
        model.setLimitDay(scanner.getBigDecimal("limitDay"));
        model.setLimitNight(scanner.getBigDecimal("limitNight"));
        model.setLimitMonth(scanner.getBigDecimal("limitMonth"));
        return model;

    }
}
