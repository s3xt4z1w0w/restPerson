package eub.smart.cardproduct.transfer.self.core.constant;

public interface BundleCode {

    String SMS_MESSAGE_RJCT = "sms.message.rjct";
    String SMS_MESSAGE_DONE = "sms.message.done";
    String SMS_MESSAGE_VLAL = "sms.message.vlal";
    String SMS_MESSAGE_VLDA = "sms.message.vlda";
    String SMS_MESSAGE_VLDL = "sms.message.vldl";
    String SMS_MESSAGE_VLMA = "sms.message.vlma";
    String SMS_MESSAGE_VLML = "sms.message.vlml";
    String SMS_MESSAGE_VLPS = "sms.message.vlps";
    String SMS_MESSAGE_DCCF = "sms.message.dccf";
    String SMS_MESSAGE_ENBS = "sms.message.enbs";
    String SMS_MESSAGE_VLBS = "sms.message.vlbs";
    String SMS_MESSAGE_VLCP = "sms.message.vlcp";
    String SMS_MESSAGE_VLSS = "sms.message.vlss";
    String SMS_MESSAGE_VLSU = "sms.message.vlsu";
    String SMS_MESSAGE_MTNT = "sms.message.mtnt";
    String SMS_MESSAGE_VLD = "sms.message.vld";

    String ERROR_MESSAGE_EMPTY_TRANSFER_HISTORY = "error.message.empty.transfer.history";

    String ERROR_MESSAGE_DCCF = "error.message.dccf";
    String ERROR_MESSAGE_VLBS = "error.message.vlbs";
    String ERROR_MESSAGE_VLSS = "error.message.vlss";
    String ERROR_MESSAGE_VLSU = "error.message.vlsu";
    String ERROR_MESSAGE_MTNT = "error.message.mtnt";
}
