package eub.smart.cardproduct.transfer.self.domain.use_case;

import java.math.BigDecimal;

public interface LimitFinDocUseCase {

    void invoke(BigDecimal limitFinDoc, BigDecimal amount, String currency, String correlationId);
}
