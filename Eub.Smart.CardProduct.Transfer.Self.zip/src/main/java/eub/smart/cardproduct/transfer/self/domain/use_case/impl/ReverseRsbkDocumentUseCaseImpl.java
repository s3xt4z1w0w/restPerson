package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.ReverseDoc;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TryReverseDocReply;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TryReverseDocRequest;
import eub.smart.cardproduct.transfer.self.domain.repository.RsbkTransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.ReverseRsbkDocumentUseCase;

public class ReverseRsbkDocumentUseCaseImpl implements ReverseRsbkDocumentUseCase {

    private final RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository;

    public ReverseRsbkDocumentUseCaseImpl(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository) {
        this.rsbkTransactionalProtoRepository = rsbkTransactionalProtoRepository;
    }

    @Override
    public ReverseDoc invoke(TransferResponse transferResponse, String correlationId) {
        var request = new TryReverseDocRequest(transferResponse.getCollectorId());
        var response = rsbkTransactionalProtoRepository.tryReverseDoc(request, correlationId);
        return new ReverseDoc(request, response);
    }
}
