package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import com.fasterxml.jackson.annotation.JsonFormat;
import eub.smart.cardproduct.transfer.self.domain.model.FullName;
import eub.smart.cardproduct.transfer.self.core.util.NameUtil;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.SELF;

public class TransferRsbkToWay4Request {
    @NotNull
    private String payerAccount;
    @NotNull
    private String receiverAccount;
    @NotNull
    private String knp;
    @NotNull
    private BigDecimal operSum;
    @NotNull
    private BigDecimal sumInReceiverAccCurr;
    @NotNull
    private BigDecimal comissSummTg;
    @NotNull
    private String dboId;
    @NotNull
    private Integer isSelf;
    @NotNull
    private String receiverIsNotRez;
    @NotNull
    private String receiverNameFull;
    @NotNull
    private String receiverNameFirst;
    @NotNull
    private String receiverNameLast;
    private String receiverNameMiddle;
    private String receiverIin;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date dateSign;
    private String receiverAccountCurr;

    public TransferRsbkToWay4Request() {
    }

    public TransferRsbkToWay4Request(FinDocData finDocData, AccountData senderData, AccountData receiverData) {
        this.payerAccount = senderData.getAccountNumber();
        this.receiverAccount = receiverData.getAccountNumber();
        this.knp = finDocData.getKnpCode();
        this.operSum = senderData.getAmount();
        this.sumInReceiverAccCurr = receiverData.getAmount();
        this.comissSummTg = finDocData.getFeeAmount();
        this.dboId = String.valueOf(finDocData.getId());
        this.isSelf = SELF.equals(finDocData.getType()) ? 1 : 0;
        this.receiverIsNotRez = String.valueOf(!receiverData.getFlagResident());
        this.receiverIin = receiverData.getIin();
        this.dateSign = finDocData.getDateSigned();
        this.receiverAccountCurr = receiverData.getCurrency();
        var name = NameUtil.getPersonFullName(receiverData.getFullName());
        this.receiverNameFull = receiverData.getFullName();
        this.receiverNameFirst = name.getFirstname();
        this.receiverNameLast = name.getLastname();
        this.receiverNameMiddle = name.getMiddlename();
    }

    public String getPayerAccount() {
        return payerAccount;
    }

    public String getReceiverAccount() {
        return receiverAccount;
    }

    public String getKnp() {
        return knp;
    }

    public BigDecimal getOperSum() {
        return operSum;
    }

    public BigDecimal getSumInReceiverAccCurr() {
        return sumInReceiverAccCurr;
    }

    public BigDecimal getComissSummTg() {
        return comissSummTg;
    }

    public String getDboId() {
        return dboId;
    }

    public Integer getSelf() {
        return isSelf;
    }

    public String getReceiverIsNotRez() {
        return receiverIsNotRez;
    }

    public String getReceiverNameFull() {
        return receiverNameFull;
    }

    public String getReceiverNameFirst() {
        return receiverNameFirst;
    }

    public String getReceiverNameLast() {
        return receiverNameLast;
    }

    public String getReceiverNameMiddle() {
        return receiverNameMiddle;
    }

    public String getReceiverIin() {
        return receiverIin;
    }

    public Date getDateSign() {
        return dateSign;
    }

    public String getReceiverAccountCurr() {
        return receiverAccountCurr;
    }

    public void setPayerAccount(String payerAccount) {
        this.payerAccount = payerAccount;
    }

    public void setReceiverAccount(String receiverAccount) {
        this.receiverAccount = receiverAccount;
    }

    public void setKnp(String knp) {
        this.knp = knp;
    }

    public void setOperSum(BigDecimal operSum) {
        this.operSum = operSum;
    }

    public void setSumInReceiverAccCurr(BigDecimal sumInReceiverAccCurr) {
        this.sumInReceiverAccCurr = sumInReceiverAccCurr;
    }

    public void setComissSummTg(BigDecimal comissSummTg) {
        this.comissSummTg = comissSummTg;
    }

    public void setDboId(String dboId) {
        this.dboId = dboId;
    }

    public void setSelf(Integer self) {
        isSelf = self;
    }

    public void setReceiverIsNotRez(String receiverIsNotRez) {
        this.receiverIsNotRez = receiverIsNotRez;
    }

    public void setReceiverNameFull(String receiverNameFull) {
        this.receiverNameFull = receiverNameFull;
    }

    public void setReceiverNameFirst(String receiverNameFirst) {
        this.receiverNameFirst = receiverNameFirst;
    }

    public void setReceiverNameLast(String receiverNameLast) {
        this.receiverNameLast = receiverNameLast;
    }

    public void setReceiverNameMiddle(String receiverNameMiddle) {
        this.receiverNameMiddle = receiverNameMiddle;
    }

    public void setReceiverIin(String receiverIin) {
        this.receiverIin = receiverIin;
    }

    public void setDateSign(Date dateSign) {
        this.dateSign = dateSign;
    }

    public void setReceiverAccountCurr(String receiverAccountCurr) {
        this.receiverAccountCurr = receiverAccountCurr;
    }

    public void setReceiverName(String receiverName) {
        FullName personFullName = NameUtil.getPersonFullName(receiverName);
        setReceiverNameFull(receiverName);
        setReceiverNameLast(personFullName.getLastname());
        setReceiverNameFirst(personFullName.getFirstname());
        setReceiverNameMiddle(personFullName.getMiddlename());
    }

    @Override
    public String toString() {
        return "TransferRsbkToWay4Request{" +
                "payerAccount=" + payerAccount +
                ", receiverAccount=" + receiverAccount +
                ", knp=" + knp +
                ", operSum=" + operSum +
                ", sumInReceiverAccCurr=" + sumInReceiverAccCurr +
                ", comissSummTg=" + comissSummTg +
                ", dboId=" + dboId +
                ", isSelf=" + isSelf +
                ", receiverIsNotRez=" + receiverIsNotRez +
                ", receiverNameFull=" + receiverNameFull +
                ", receiverNameFirst=" + receiverNameFirst +
                ", receiverNameLast=" + receiverNameLast +
                ", receiverNameMiddle=" + receiverNameMiddle +
                ", receiverIin=" + receiverIin +
                ", dateSign=" + dateSign +
                ", receiverAccountCurr=" + receiverAccountCurr +
                '}';
    }
}
