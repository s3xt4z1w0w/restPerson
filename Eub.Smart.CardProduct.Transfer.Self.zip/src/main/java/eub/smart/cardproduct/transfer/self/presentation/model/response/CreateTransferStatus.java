package eub.smart.cardproduct.transfer.self.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public class CreateTransferStatus {

    @Schema(description = "Статус Id")
    private String id;
    @Schema(description = "Заголовок статуса")
    private String title;
    @Schema(description = "Код статуса")
    private String code;

    public CreateTransferStatus() {
    }

    public CreateTransferStatus(String id, String title, String code) {
        this.id = id;
        this.title = title;
        this.code = code;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
