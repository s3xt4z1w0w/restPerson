package eub.smart.cardproduct.transfer.self.application.worker;

import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerException;
import eub.smart.cardproduct.transfer.self.application.mapper.ApplicationMapper;
import eub.smart.cardproduct.transfer.self.application.model.TransferInternalBaseModel;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import static eub.smart.cardproduct.transfer.self.core.enums.LangKey.RU;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.*;
import static eub.smart.cardproduct.transfer.self.core.util.ZeebeConfigUtil.WORKER_ENABLE;

@Component
public class TransferInternalValidationWorker {

    private final Logger log = LogManager.getLogger(getClass());
    private final ApplicationMapper applicationMapper;
    private final ValidateSenderAccountUseCase validateSenderAccountUseCase;
    private final ValidateReceiverAccountUseCase validateReceiverAccountUseCase;
    private final ValidateMultiConvertUseCase validateMultiConvertUseCase;

    public TransferInternalValidationWorker(ApplicationMapper applicationMapper,
                                            ValidateSenderAccountUseCase validateSenderAccountUseCase,
                                            ValidateReceiverAccountUseCase validateReceiverAccountUseCase,
                                            ValidateMultiConvertUseCase validateMultiConvertUseCase) {
        this.applicationMapper = applicationMapper;
        this.validateSenderAccountUseCase = validateSenderAccountUseCase;
        this.validateReceiverAccountUseCase = validateReceiverAccountUseCase;
        this.validateMultiConvertUseCase = validateMultiConvertUseCase;
    }

    @JobWorkerException(errorCode = "TechnicalError")
    @JobWorker(type = "transfer_self_check_sender_account_status", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkSenderAccountStatus(@VariablesAsType TransferInternalBaseModel baseModel,
                                                              JobClient client,
                                                              ActivatedJob job) {
        try {
            var accountData = applicationMapper.toDomain(baseModel.getSender());
            validateSenderAccountUseCase.invoke(accountData, RU);
            baseModel.getValidationFlag().setSenderAccountStatus(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            if (isDomainLayerException(e)) {
                baseModel.getValidationFlag().setSenderAccountStatus(false);
            } else {
                throw new SelfException(E_SM_500, ": out of domain logic");
            }
        }
        return baseModel;
    }

    @JobWorkerException(errorCode = "TechnicalError")
    @JobWorker(type = "transfer_self_check_receiver_account_status", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkReceiverAccountStatus(@VariablesAsType TransferInternalBaseModel baseModel,
                                                                JobClient client,
                                                                ActivatedJob job) {
        try {
            var accountData = applicationMapper.toDomain(baseModel.getReceiver());
            validateReceiverAccountUseCase.invoke(accountData, RU);
            baseModel.getValidationFlag().setReceiverAccountStatus(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            if (isDomainLayerException(e)) {
                baseModel.getValidationFlag().setReceiverAccountStatus(false);
            } else {
                throw new SelfException(E_SM_500, ": out of domain logic");
            }
        }
        return baseModel;
    }

    @JobWorkerException(errorCode = "TechnicalError")
    @JobWorker(type = "transfer_self_check_multi_convert", enabled = WORKER_ENABLE)
    public TransferInternalBaseModel checkMultiConvert(@VariablesAsType TransferInternalBaseModel baseModel,
                                                       JobClient client,
                                                       ActivatedJob job) {
        try {
            var senderData = applicationMapper.toDomain(baseModel.getSender());
            var receiverData = applicationMapper.toDomain(baseModel.getReceiver());

            validateMultiConvertUseCase.invoke(senderData, receiverData, RU);
            baseModel.getValidationFlag().setMultiConvertStatus(true);
        } catch (Exception e) {
            log.error(e.getMessage());
            if (isDomainLayerException(e)) {
                baseModel.getValidationFlag().setMultiConvertStatus(false);
            } else {
                throw new SelfException(E_SM_500, ": out of domain logic");
            }
        }
        return baseModel;
    }

    private boolean isDomainLayerException(Exception e) {
        return e instanceof SelfException ex && isDomainErrorCode(ex);
    }
}
