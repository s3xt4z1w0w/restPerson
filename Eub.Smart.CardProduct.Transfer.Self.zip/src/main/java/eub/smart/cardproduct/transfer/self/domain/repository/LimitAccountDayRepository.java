package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.limit.SpentAmount;

import java.time.LocalDate;
import java.util.List;

public interface LimitAccountDayRepository {

    List<SpentAmount> findByAccountNumber(LocalDate signDate, String accountNumber);
}
