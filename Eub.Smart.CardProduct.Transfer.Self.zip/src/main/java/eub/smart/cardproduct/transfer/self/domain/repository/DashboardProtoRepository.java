package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;

import java.math.BigDecimal;

public interface DashboardProtoRepository {

    BigDecimal availableBalance(AccountData accountData, String correlationId);
}
