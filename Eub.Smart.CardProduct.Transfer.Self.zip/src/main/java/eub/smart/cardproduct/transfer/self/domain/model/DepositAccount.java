package eub.smart.cardproduct.transfer.self.domain.model;

public class DepositAccount {

    private String termPeriodType;
    private Integer termPeriodCount;

    public DepositAccount() {
    }

    public DepositAccount(String termPeriodType, Integer termPeriodCount) {
        this.termPeriodType = termPeriodType;
        this.termPeriodCount = termPeriodCount;
    }

    public String getTermPeriodType() {
        return termPeriodType;
    }

    public void setTermPeriodType(String termPeriodType) {
        this.termPeriodType = termPeriodType;
    }

    public Integer getTermPeriodCount() {
        return termPeriodCount;
    }

    public void setTermPeriodCount(Integer termPeriodCount) {
        this.termPeriodCount = termPeriodCount;
    }

    @Override
    public String toString() {
        return "DepositAccount{" +
                "termPeriodType=" + termPeriodType +
                ", termPeriodCount=" + termPeriodCount +
                '}';
    }
}
