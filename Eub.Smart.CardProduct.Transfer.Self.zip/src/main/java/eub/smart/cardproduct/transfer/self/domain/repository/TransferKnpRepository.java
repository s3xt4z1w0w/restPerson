package eub.smart.cardproduct.transfer.self.domain.repository;

import java.util.Optional;

public interface TransferKnpRepository {

    Optional<String> findKNPCode(String accountType, String receiverAccountType, String convertType, Boolean isSelf);

    String findKNPCodeOrException(String senderAccountType, String receiverAccountType, String none, Boolean b);
}
