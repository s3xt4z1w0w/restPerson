package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDateRequest;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDateResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4PostRequest;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4PostResponse;

public interface Way4TransactionalProtoRepository {

    PostingDateResponse getPostingDate(PostingDateRequest requestModel, String correlationId);

    TransferWay4PostResponse transferWay4Post(TransferWay4PostRequest requestModel, String correlationId);
}
