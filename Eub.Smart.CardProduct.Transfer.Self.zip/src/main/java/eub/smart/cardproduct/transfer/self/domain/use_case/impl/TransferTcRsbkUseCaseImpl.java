package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferTcRsbkUseCase;

public class TransferTcRsbkUseCaseImpl implements TransferTcRsbkUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferTcRsbkUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferTcRsbk invoke(TransferResponse transferResponse, String correlationId) {
        var request = new TransferTcRequest(transferResponse);
        var response = transferSelfProtoRepository.transferTcRsbk(request, correlationId);
        return new TransferTcRsbk(request, response);
    }
}
