package eub.smart.cardproduct.transfer.self.application.model;

public class RrnBrrn {

    private String rrn;

    private String brrn;

    public String getRrn() {
        return rrn;
    }

    public void setRrn(String rrn) {
        this.rrn = rrn;
    }

    public String getBrrn() {
        return brrn;
    }

    public void setBrrn(String brrn) {
        this.brrn = brrn;
    }

    @Override
    public String toString() {
        return "RrnBrrn{" +
                "rrn=" + rrn +
                ", brrn=" + brrn +
                '}';
    }
}
