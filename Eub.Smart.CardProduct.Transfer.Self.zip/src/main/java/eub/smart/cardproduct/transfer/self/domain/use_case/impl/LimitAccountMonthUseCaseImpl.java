package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.repository.LimitAccountMonthRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitAccountMonthUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitFinDocUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitUseCase;

import java.math.BigDecimal;
import java.time.LocalDate;

import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isEmpty;

public class LimitAccountMonthUseCaseImpl implements LimitAccountMonthUseCase {

    private final LimitAccountMonthRepository limitAccountMonthRepository;
    private final LimitFinDocUseCase finDocUseCase;
    private final LimitUseCase limitUseCase;

    public LimitAccountMonthUseCaseImpl(LimitAccountMonthRepository limitAccountMonthRepository,
                                        LimitFinDocUseCase finDocUseCase,
                                        LimitUseCase limitUseCase) {
        this.limitAccountMonthRepository = limitAccountMonthRepository;
        this.finDocUseCase = finDocUseCase;
        this.limitUseCase = limitUseCase;
    }

    @Override
    public void invoke(BigDecimal limitMonth, String accountNumber, String correlationId, BigDecimal amount, String currency) {
        var now = LocalDate.now();
        var currentMonth = LocalDate.of(now.getYear(), now.getMonth(), 1);
        var spentAmountGroupByCurrency = limitAccountMonthRepository.findByAccountNumber(currentMonth, accountNumber);
        if (isEmpty(spentAmountGroupByCurrency)) finDocUseCase.invoke(limitMonth, amount, currency, correlationId);
        limitUseCase.invoke(limitMonth, correlationId, amount, currency, false, spentAmountGroupByCurrency);
    }

}

