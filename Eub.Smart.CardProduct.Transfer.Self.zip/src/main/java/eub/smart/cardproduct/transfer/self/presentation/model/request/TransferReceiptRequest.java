package eub.smart.cardproduct.transfer.self.presentation.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.NotNull;

public record TransferReceiptRequest(
        @NotNull
        @JsonProperty("finDocId")
        @Schema(description = "Фин док Id")
        Long finDocId,

        @NotNull
        @JsonProperty("finDocType")
        @Schema(description = "Фин док тип")
        String finDocType
) {
}
