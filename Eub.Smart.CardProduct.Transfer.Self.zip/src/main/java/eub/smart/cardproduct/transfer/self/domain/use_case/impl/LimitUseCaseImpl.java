package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.limit.SpentAmount;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetConvertingInfoUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitUseCase;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800;
import static eub.smart.cardproduct.transfer.self.core.util.BigDecimalUtil.isNullOrZero;
import static eub.smart.cardproduct.transfer.self.core.constant.CurrencyCode.KZT;

public class LimitUseCaseImpl implements LimitUseCase {

    private final GetConvertingInfoUseCase getConvertingInfoUseCase;

    public LimitUseCaseImpl(GetConvertingInfoUseCase getConvertingInfoUseCase) {
        this.getConvertingInfoUseCase = getConvertingInfoUseCase;
    }

    @Override
    public void invoke(BigDecimal limit, String correlationId, BigDecimal amount, String currency, Boolean convert, List<SpentAmount> spentAmountGroupByCurrency) {
        if (isNullOrZero(limit)) return;
        int index = convert ? 1 : 0;
        List<BigDecimal> spentAmountList = getSpentAmountList(correlationId, spentAmountGroupByCurrency);
        var spentAmount = spentAmountList.get(index);
        var convertingInfo = getConvertingInfoUseCase.invoke(amount, currency, KZT, correlationId);
        var totalAmount = spentAmount.add(convertingInfo.getReceiverAmount());
        if (invalidLimit(limit, totalAmount))
            throw new SelfException(E_LG_800, ": total account amount:" + totalAmount + " greater then limit:" + limit);
    }

    private boolean invalidLimit(BigDecimal limit, BigDecimal totalAmount) {
        return limit.compareTo(totalAmount) < 0;
    }

    private List<BigDecimal> getSpentAmountList(String correlationId, List<SpentAmount> spentAmountGroupByCurrency) {
        List<BigDecimal> spentAmountList = new ArrayList<>();
        var unconvertedSpentAmount = new BigDecimal("0");
        var convertedSpentAmount = new BigDecimal("0");
        spentAmountList.add(unconvertedSpentAmount);
        spentAmountList.add(convertedSpentAmount);
        spentAmountGroupByCurrency.forEach(spentAmount -> sumConvertedAndUnconvertedAmount(spentAmount, correlationId, spentAmountList));
        spentAmountList.set(0, spentAmountList.get(0).add(spentAmountList.get(1)));
        return spentAmountList;
    }

    private void sumConvertedAndUnconvertedAmount(SpentAmount spentAmount, String correlationId, List<BigDecimal> spentAmountList) {
        if (KZT.equals(spentAmount.getSenderCurrency())) {
            if (KZT.equals(spentAmount.getReceiverCurrency())) {
                spentAmountList.set(0, spentAmountList.get(0).add(spentAmount.getSpentSum()));
            } else {
                spentAmountList.set(1, spentAmountList.get(1).add(spentAmount.getSpentSum()));
            }
        } else {
            var convertingInfo = getConvertingInfoUseCase.invoke(spentAmount.getSpentSum(), spentAmount.getSenderCurrency(), KZT, correlationId);
            spentAmountList.set(1, spentAmountList.get(1).add(convertingInfo.getReceiverAmount()));
        }
    }
}
