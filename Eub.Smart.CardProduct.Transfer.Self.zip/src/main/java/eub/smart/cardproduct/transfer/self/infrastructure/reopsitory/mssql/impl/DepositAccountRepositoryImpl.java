package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.DepositAccount;
import eub.smart.cardproduct.transfer.self.domain.repository.DepositAccountRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.DepositAccountMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class DepositAccountRepositoryImpl implements DepositAccountRepository {

    private final NamedParameterJdbcTemplate template;

    public DepositAccountRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<DepositAccount> findByAccountId(Long accountId) {
        String sql = """ 
                select DA.TermPeriod    as termPeriodType, 
                       DA.Term          as termPeriodCount
                from DepositAccount DA
                where DA.Account_IDREF = :accountId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("accountId", accountId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(DepositAccountMapper::toDomainModel);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": DepositAccountRepository findByAccountId");
        }
    }

    @Override
    public DepositAccount findByAccountIdOrException(Long accountId) {
        return findByAccountId(accountId)
                .orElseThrow(() -> new SelfException(E_DB_600, ": DepositAccountRepository findByAccountIdOrException"));
    }
}
