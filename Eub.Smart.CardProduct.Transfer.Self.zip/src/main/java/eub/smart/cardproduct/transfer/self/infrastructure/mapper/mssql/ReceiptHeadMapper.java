package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.common.LocalizedText;
import eub.smart.cardproduct.transfer.self.domain.model.out.AccountNameDisplay;
import eub.smart.cardproduct.transfer.self.domain.model.out.AmountDisplay;
import eub.smart.cardproduct.transfer.self.domain.model.out.HeadOut;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReceiptHeadMapper {

    public static HeadOut processHead(ResultSet resultSet, LangKey lang, String finDocType) throws SQLException {
        var amount = resultSet.getBigDecimal("amount");
        var currency = resultSet.getString("currency");
        var fee = resultSet.getBigDecimal("fee");
        var feeCurrency = resultSet.getString("feeCurrency");
        var status = resultSet.getString("status");
        Long targetId = null; //TODO
        var titleRu = resultSet.getString("dataTitle_title_RU");
        var titleKz = resultSet.getString("dataTitle_title_KZ");
        var titleEn = resultSet.getString("dataTitle_title_EN");
        var descRu = resultSet.getString("dataTitle_desc_RU");
        var descKz = resultSet.getString("dataTitle_desc_KZ");
        var descEn = resultSet.getString("dataTitle_desc_EN");

        var title = new LocalizedText(titleRu, titleKz, titleEn).text(lang);
        var accountNameDisplay = new AccountNameDisplay(title, finDocType);
        var desc = new LocalizedText(descRu, descKz, descEn).text(lang);

        return new HeadOut(
                new AmountDisplay(amount, currency),
                new AmountDisplay(fee, feeCurrency),
                status,
                null,
                accountNameDisplay,
                desc);
    }
}
