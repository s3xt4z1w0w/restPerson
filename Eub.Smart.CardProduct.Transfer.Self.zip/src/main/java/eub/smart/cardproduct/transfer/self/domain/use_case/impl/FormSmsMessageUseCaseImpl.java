package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.FormSmsMessageUseCase;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.*;
import static eub.smart.cardproduct.transfer.self.core.constant.DocStatus.*;
import static eub.smart.cardproduct.transfer.self.core.constant.DocStatus.VLML;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_802;

public class FormSmsMessageUseCaseImpl implements FormSmsMessageUseCase {

    private final MessageSourceRepository messageSourceRepository;

    public FormSmsMessageUseCaseImpl(MessageSourceRepository messageSourceRepository) {
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public String invoke(Long finDocId,
                         String docStatus,
                         BigDecimal amount,
                         String currency) {
        if (RJCT.equals(docStatus)) {
            return formMessageWithDateNow(finDocId, amount, currency, SMS_MESSAGE_RJCT);
        } else if (DONE.equals(docStatus)) {
            return formDoneMessage(amount, currency);
        } else if (VLAL.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLAL);
        } else if (VLDA.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLDA);
        } else if (VLDL.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLDL);
        } else if (VLMA.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLMA);
        } else if (VLML.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLML);
        } else if (VLPS.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLPS);
        } else if (DCCF.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_DCCF);
        } else if (ENBS.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_ENBS);
        } else if (VLBS.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLBS);
        } else if (VLCP.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLCP);
        } else if (VLSS.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLSS);
        } else if (VLSU.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_VLSU);
        } else if (MTNT.equals(docStatus)) {
            return formMessageWithDateNow(amount, currency, SMS_MESSAGE_MTNT);
        } else {
            throw new SelfException(E_LG_802, ": doc status : " + docStatus);
        }
    }

    private String formMessageWithDateNow(BigDecimal amount, String currency, String bundleCode) {
        var dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        var operationDate = dateTimeFormatter.format(LocalDateTime.now());
        var args = new Object[]{operationDate, amount, currency};
        return messageSourceRepository.getMessage(bundleCode, args, LangUtil.RU);
    }

    private String formMessageWithDateNow(Long finDocId, BigDecimal amount, String currency, String bundleCode) {
        var dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        var operationDate = dateTimeFormatter.format(LocalDate.now());
        var args = new Object[]{finDocId, operationDate, amount, currency};
        return messageSourceRepository.getMessage(bundleCode, args, LangUtil.RU);
    }

    private String formDoneMessage(BigDecimal amount, String currency) {
        var args = new Object[]{amount, currency};
        return messageSourceRepository.getMessage(SMS_MESSAGE_DONE, args, LangUtil.RU);
    }
}