package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;

public interface ValidateBSystemAvailabilityUseCase {

    void invoke(String bSystem, LangKey lang);
}
