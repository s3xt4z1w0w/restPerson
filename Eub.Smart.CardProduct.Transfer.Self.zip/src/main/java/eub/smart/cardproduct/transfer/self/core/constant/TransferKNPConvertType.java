package eub.smart.cardproduct.transfer.self.core.constant;

public interface TransferKNPConvertType {

    String NONE = "NONE";
}
