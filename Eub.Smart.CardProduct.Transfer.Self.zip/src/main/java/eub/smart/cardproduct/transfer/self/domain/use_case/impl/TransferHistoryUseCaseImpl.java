package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.in.TransferHistoryIn;
import eub.smart.cardproduct.transfer.self.domain.model.out.StoryOut;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferHistoryRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferHistoryUseCase;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.stream.Collectors;

public class TransferHistoryUseCaseImpl implements TransferHistoryUseCase {

    private final TransferHistoryRepository transferHistoryRepository;

    public TransferHistoryUseCaseImpl(TransferHistoryRepository transferHistoryRepository) {
        this.transferHistoryRepository = transferHistoryRepository;
    }

    @Override
    public Page<StoryOut> invoke(TransferHistoryIn in, Pageable pageable, LangKey lang) {
        var historyInPage = transferHistoryRepository.findByDatePeriodAndUserId(in.from(), in.to(), pageable, lang);
        var historyOut = historyInPage.stream()
                .map(storyIn -> new StoryOut(storyIn, lang))
                .collect(Collectors.toList()); //TODO story image
        return new PageImpl<>(historyOut, pageable, historyInPage.getTotalElements());
    }
}
