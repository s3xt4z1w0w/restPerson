package eub.smart.cardproduct.transfer.self.domain.model;

import javax.validation.constraints.NotNull;

public class Client {

    @NotNull
    private Long id;
    private Long personId;
    private Long corporationId;
    @NotNull
    private String status;
    @NotNull
    private String typeCode;

    public Client() {
    }

    public Client(Long id, Long personId, Long corporationId, String status, String typeCode) {
        this.id = id;
        this.personId = personId;
        this.corporationId = corporationId;
        this.status = status;
        this.typeCode = typeCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public Long getCorporationId() {
        return corporationId;
    }

    public void setCorporationId(Long corporationId) {
        this.corporationId = corporationId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    @Override
    public String toString() {
        return "Client{" +
                "id=" + id +
                ", personId=" + personId +
                ", corporationId=" + corporationId +
                ", status=" + status +
                ", typeCode=" + typeCode +
                '}';
    }
}
