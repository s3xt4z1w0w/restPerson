package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4Request;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferRsbkToWay4Repository;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.TransferRsbkToWay4Mapper.toDomainModel;

@Repository
public class TransferRsbkToWay4RepositoryImpl implements TransferRsbkToWay4Repository {

    private final NamedParameterJdbcTemplate template;

    public TransferRsbkToWay4RepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<TransferRsbkToWay4Request> findByFinDocId(Long finDocId) {
        String sql = """ 
                select A.Number                 as senderAccNumber,
                       T.Receiver_Account       as receiverAccNumber,
                       T.KNP_IDREF              as knpCode,
                       F.Amount                 as senderAmount,
                       T.Receiver_Amount        as receiverAmount,
                       F.Fee                    as fee,
                       F.DateSigned             as signDate,
                       T.Receiver_Currency      as receiverCurrency,
                       F.FinDocType_IDREF       as finDocType,
                       T.Receiver_Name          as receiverName,
                       T.Receiver_IIN           as receiverIIN,
                       T.Receiver_IsResident    as receiverIsResident
                from FinDoc F
                    join Account A on F.Account_IDREF = A.Account_ID
                    join Transfer T on F.FinDoc_ID = T.FinDoc_IDREF
                where F.FinDoc_ID = :finDocId
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(row -> toDomainModel(row, finDocId));
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferRsbkToWay4Repository findByFinDocId");
        }
    }

    @Override
    public TransferRsbkToWay4Request findByFinDocIdOrException(Long finDocId) {
        return findByFinDocId(finDocId)
                .orElseThrow(() -> new SelfException(E_DB_600, ": TransferRsbkToWay4Repository findByFinDocIdOrException"));
    }
}
