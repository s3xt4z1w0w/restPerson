package eub.smart.cardproduct.transfer.self.presentation.swagger.response;

import eub.smart.cardproduct.transfer.self.presentation.model.ServiceResponse;
import eub.smart.cardproduct.transfer.self.presentation.model.response.FeeResponse;

public class GetFeeResponse extends ServiceResponse<FeeResponse> {
}
