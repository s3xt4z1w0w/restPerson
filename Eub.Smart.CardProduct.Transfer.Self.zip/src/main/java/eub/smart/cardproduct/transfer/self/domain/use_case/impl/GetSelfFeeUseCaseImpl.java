package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.FeeResponse;
import eub.smart.cardproduct.transfer.self.domain.repository.FeeRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.MapProductOperationRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferTypeRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.ViewMapAccountBSystemClientRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.SELF;

public class GetSelfFeeUseCaseImpl implements GetSelfFeeUseCase {

    private final FeeRepository feeRepository;
    private final GetFeeAmountUseCase getFeeAmountUseCase;
    private final TransferTypeRepository transferTypeRepository;
    private final MapProductOperationRepository mapProductOperationRepository;
    private final ViewMapAccountBSystemClientRepository viewMapAccountBSystemClientRepository;

    public GetSelfFeeUseCaseImpl(FeeRepository feeRepository,
                                 GetFeeAmountUseCase getFeeAmountUseCase,
                                 TransferTypeRepository transferTypeRepository,
                                 MapProductOperationRepository mapProductOperationRepository,
                                 ViewMapAccountBSystemClientRepository viewMapAccountBSystemClientRepository) {
        this.feeRepository = feeRepository;
        this.getFeeAmountUseCase = getFeeAmountUseCase;
        this.transferTypeRepository = transferTypeRepository;
        this.mapProductOperationRepository = mapProductOperationRepository;
        this.viewMapAccountBSystemClientRepository = viewMapAccountBSystemClientRepository;
    }

    @Override
    public FeeResponse invoke(BigDecimal amount, String accountNumber, String targetCurrency) {
        var operationId = transferTypeRepository.findOperationIdOrException(accountNumber, targetCurrency);
        var productId = viewMapAccountBSystemClientRepository.findProductIdOrException(accountNumber);
        var feeId = mapProductOperationRepository.findFeeIdOrException(amount, operationId, productId);
        var fee = feeRepository.findByIdOrException(feeId);
        var feeAmount = getFeeAmountUseCase.invoke(amount, fee);
        return new FeeResponse(feeAmount, fee.getCurrency());
    }

    @Override
    public FeeResponse invoke(BigDecimal amount, String accountNumber, String sourceCurrency, String targetCurrency) {
        var operationId = transferTypeRepository.findOperationIdOrException(SELF, sourceCurrency, targetCurrency);
        var productId = viewMapAccountBSystemClientRepository.findProductIdOrException(accountNumber);
        var feeId = mapProductOperationRepository.findFeeIdOrException(amount, operationId, productId);
        var fee = feeRepository.findByIdOrException(feeId);
        var feeAmount = getFeeAmountUseCase.invoke(amount, fee);
        return new FeeResponse(feeAmount, fee.getCurrency());
    }
}
