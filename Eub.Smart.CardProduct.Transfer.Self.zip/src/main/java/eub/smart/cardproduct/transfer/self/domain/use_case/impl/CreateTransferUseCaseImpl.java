package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.JsonUtil;
import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.model.Transfer;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferTypeRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.CreateTransferUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetTransferClientUseCase;

import java.math.BigDecimal;
import java.util.List;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_SM_501;

public class CreateTransferUseCaseImpl implements CreateTransferUseCase {

    private final GetTransferClientUseCase getTransferClientUseCase;
    private final TransferTypeRepository transferTypeRepository;
    private final TransferRepository transferRepository;
    private final String receiverBIC;
    private final String seco; //economic sector

    public CreateTransferUseCaseImpl(GetTransferClientUseCase getTransferClientUseCase,
                                     TransferTypeRepository transferTypeRepository,
                                     TransferRepository transferRepository,
                                     String receiverBIC,
                                     String seco) {
        this.getTransferClientUseCase = getTransferClientUseCase;
        this.transferTypeRepository = transferTypeRepository;
        this.transferRepository = transferRepository;
        this.receiverBIC = receiverBIC;
        this.seco = seco;
    }

    @Override
    public Transfer invoke(FinDoc finDoc,
                           CreateTransferAccountInfo senderAccount,
                           CreateTransferAccountInfo receiverAccount,
                           String knpCode,
                           BigDecimal receiverAmount,
                           List<CurrencyRate> currencyRates) {
        var receiverAccountNumber = receiverAccount.getNumber();
        var receiverAccountCurrency = receiverAccount.getCurrency();
        var senderAccountCurrency = senderAccount.getCurrency();

        var receiver = getTransferClientUseCase.invoke(receiverAccountNumber);
        var transferType = transferTypeRepository.findIdOrException(finDoc.getDocType(), senderAccountCurrency, receiverAccountCurrency, receiver.getFlagCorporate());
        var currencyRatesJson = JsonUtil.toJson(currencyRates)
                .orElseThrow(() -> new SelfException(E_SM_501, ": CurrencyRate"));

        var transfer = new Transfer(finDoc, transferType, receiverBIC, receiverAccountNumber, receiver.getName(),
                receiver.getIin(), receiver.getFlagResident(), seco, knpCode, null, null,
                null, null, null, receiver.getBin(), receiverAccountCurrency,
                null, currencyRatesJson, senderAccountCurrency, null,
                null, null, receiverAmount);
        return transferRepository.save(transfer);
    }
}
