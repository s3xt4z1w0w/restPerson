package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetConvertingInfoUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.LimitFinDocUseCase;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800;
import static eub.smart.cardproduct.transfer.self.core.util.BigDecimalUtil.isNullOrZero;
import static eub.smart.cardproduct.transfer.self.core.constant.CurrencyCode.KZT;

public class LimitFinDocUseCaseImpl implements LimitFinDocUseCase {

    private final GetConvertingInfoUseCase getConvertingInfoUseCase;

    public LimitFinDocUseCaseImpl(GetConvertingInfoUseCase getConvertingInfoUseCase) {
        this.getConvertingInfoUseCase = getConvertingInfoUseCase;
    }

    @Override
    public void invoke(BigDecimal limitFinDoc, BigDecimal amount, String currency, String correlationId) {
        if (isNullOrZero(limitFinDoc)) return;
        var convertingInfo = getConvertingInfoUseCase.invoke(amount, currency, KZT, correlationId);
        if (invalidLimit(limitFinDoc, convertingInfo.getReceiverAmount()))
            throw new SelfException(E_LG_800, ": operation amount greater then limit findoc");
    }

    private boolean invalidLimit(BigDecimal limitFinDoc, BigDecimal amount) {
        return limitFinDoc.compareTo(amount) < 0;
    }
}
