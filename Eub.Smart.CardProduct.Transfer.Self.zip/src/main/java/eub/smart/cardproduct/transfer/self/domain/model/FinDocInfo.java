package eub.smart.cardproduct.transfer.self.domain.model;

import java.math.BigDecimal;
import java.util.Date;

public class FinDocInfo {

    private Long finDocId;
    private String finDocType;
    private String knpCode;
    private BigDecimal feeAmount;
    private Date dateSigned;
    private Boolean flagConvert;
    private String correlationId;
    private String senderIin;
    private String senderBSystem;
    private String senderAccountNumber;
    private BigDecimal senderAmount;
    private String senderCurrency;
    private Boolean senderFlagResident;
    private String senderFullName;
    private String senderAccountType;
    private Boolean senderFlagMulti;
    private String receiverIin;
    private String receiverBSystem;
    private String receiverAccountNumber;
    private BigDecimal receiverAmount;
    private String receiverCurrency;
    private Boolean receiverFlagResident;
    private String receiverFullName;
    private String receiverAccountType;
    private Boolean receiverFlagMulti;
    private String senderAccountStatus;
    private String receiverAccountStatus;
    private Long senderAccountIdRef;
    private Long receiverAccountIdRef;
    private Long senderAccountOutRef;
    private Long receiverAccountOutRef;

    public FinDocInfo() {
    }

    public FinDocInfo(Long finDocId,
                      String finDocType,
                      String knpCode,
                      BigDecimal feeAmount,
                      Date dateSigned,
                      Boolean flagConvert,
                      String correlationId,
                      String senderIin,
                      String senderBSystem,
                      String senderAccountNumber,
                      BigDecimal senderAmount,
                      String senderCurrency,
                      Boolean senderFlagResident,
                      String senderFullName,
                      String senderAccountType,
                      Boolean senderFlagMulti,
                      String receiverIin,
                      String receiverBSystem,
                      String receiverAccountNumber,
                      BigDecimal receiverAmount,
                      String receiverCurrency,
                      Boolean receiverFlagResident,
                      String receiverFullName,
                      String receiverAccountType,
                      Boolean receiverFlagMulti) {
        this.finDocId = finDocId;
        this.finDocType = finDocType;
        this.knpCode = knpCode;
        this.feeAmount = feeAmount;
        this.dateSigned = dateSigned;
        this.flagConvert = flagConvert;
        this.correlationId = correlationId;
        this.senderIin = senderIin;
        this.senderBSystem = senderBSystem;
        this.senderAccountNumber = senderAccountNumber;
        this.senderAmount = senderAmount;
        this.senderCurrency = senderCurrency;
        this.senderFlagResident = senderFlagResident;
        this.senderFullName = senderFullName;
        this.senderAccountType = senderAccountType;
        this.senderFlagMulti = senderFlagMulti;
        this.receiverIin = receiverIin;
        this.receiverBSystem = receiverBSystem;
        this.receiverAccountNumber = receiverAccountNumber;
        this.receiverAmount = receiverAmount;
        this.receiverCurrency = receiverCurrency;
        this.receiverFlagResident = receiverFlagResident;
        this.receiverFullName = receiverFullName;
        this.receiverAccountType = receiverAccountType;
        this.receiverFlagMulti = receiverFlagMulti;
    }

    public Long getFinDocId() {
        return finDocId;
    }

    public String getFinDocType() {
        return finDocType;
    }

    public String getKnpCode() {
        return knpCode;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public Date getDateSigned() {
        return dateSigned;
    }

    public Boolean getFlagConvert() {
        return flagConvert;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public String getSenderIin() {
        return senderIin;
    }

    public String getSenderBSystem() {
        return senderBSystem;
    }

    public String getSenderAccountNumber() {
        return senderAccountNumber;
    }

    public BigDecimal getSenderAmount() {
        return senderAmount;
    }

    public String getSenderCurrency() {
        return senderCurrency;
    }

    public Boolean getSenderFlagResident() {
        return senderFlagResident;
    }

    public String getSenderFullName() {
        return senderFullName;
    }

    public String getSenderAccountType() {
        return senderAccountType;
    }

    public Boolean getSenderFlagMulti() {
        return senderFlagMulti;
    }

    public String getReceiverIin() {
        return receiverIin;
    }

    public String getReceiverBSystem() {
        return receiverBSystem;
    }

    public String getReceiverAccountNumber() {
        return receiverAccountNumber;
    }

    public BigDecimal getReceiverAmount() {
        return receiverAmount;
    }

    public String getReceiverCurrency() {
        return receiverCurrency;
    }

    public Boolean getReceiverFlagResident() {
        return receiverFlagResident;
    }

    public String getReceiverFullName() {
        return receiverFullName;
    }

    public String getReceiverAccountType() {
        return receiverAccountType;
    }

    public Boolean getReceiverFlagMulti() {
        return receiverFlagMulti;
    }

    public void setFinDocId(Long finDocId) {
        this.finDocId = finDocId;
    }

    public void setFinDocType(String finDocType) {
        this.finDocType = finDocType;
    }

    public void setKnpCode(String knpCode) {
        this.knpCode = knpCode;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public void setDateSigned(Date dateSigned) {
        this.dateSigned = dateSigned;
    }

    public void setFlagConvert(Boolean flagConvert) {
        this.flagConvert = flagConvert;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public void setSenderIin(String senderIin) {
        this.senderIin = senderIin;
    }

    public void setSenderBSystem(String senderBSystem) {
        this.senderBSystem = senderBSystem;
    }

    public void setSenderAccountNumber(String senderAccountNumber) {
        this.senderAccountNumber = senderAccountNumber;
    }

    public void setSenderAmount(BigDecimal senderAmount) {
        this.senderAmount = senderAmount;
    }

    public void setSenderCurrency(String senderCurrency) {
        this.senderCurrency = senderCurrency;
    }

    public void setSenderFlagResident(Boolean senderFlagResident) {
        this.senderFlagResident = senderFlagResident;
    }

    public void setSenderFullName(String senderFullName) {
        this.senderFullName = senderFullName;
    }

    public void setSenderAccountType(String senderAccountType) {
        this.senderAccountType = senderAccountType;
    }

    public void setSenderFlagMulti(Boolean senderFlagMulti) {
        this.senderFlagMulti = senderFlagMulti;
    }

    public void setReceiverIin(String receiverIin) {
        this.receiverIin = receiverIin;
    }

    public void setReceiverBSystem(String receiverBSystem) {
        this.receiverBSystem = receiverBSystem;
    }

    public void setReceiverAccountNumber(String receiverAccountNumber) {
        this.receiverAccountNumber = receiverAccountNumber;
    }

    public void setReceiverAmount(BigDecimal receiverAmount) {
        this.receiverAmount = receiverAmount;
    }

    public void setReceiverCurrency(String receiverCurrency) {
        this.receiverCurrency = receiverCurrency;
    }

    public void setReceiverFlagResident(Boolean receiverFlagResident) {
        this.receiverFlagResident = receiverFlagResident;
    }

    public void setReceiverFullName(String receiverFullName) {
        this.receiverFullName = receiverFullName;
    }

    public void setReceiverAccountType(String receiverAccountType) {
        this.receiverAccountType = receiverAccountType;
    }

    public void setReceiverFlagMulti(Boolean receiverFlagMulti) {
        this.receiverFlagMulti = receiverFlagMulti;
    }

    public void setSenderAccountStatus(String senderAccountStatus) {
        this.senderAccountStatus = senderAccountStatus;
    }

    public String getSenderAccountStatus() {
        return senderAccountStatus;
    }

    public void setReceiverAccountStatus(String receiverAccountStatus) {
        this.receiverAccountStatus = receiverAccountStatus;
    }

    public String getReceiverAccountStatus() {
        return receiverAccountStatus;
    }

    public void setSenderAccountIdRef(Long senderAccountIdRef) {
        this.senderAccountIdRef = senderAccountIdRef;
    }

    public Long getSenderAccountIdRef() {
        return senderAccountIdRef;
    }

    public void setReceiverAccountIdRef(Long receiverAccountIdRef) {
        this.receiverAccountIdRef = receiverAccountIdRef;
    }

    public Long getReceiverAccountIdRef() {
        return receiverAccountIdRef;
    }

    public void setSenderAccountOutRef(Long senderAccountOutRef) {
        this.senderAccountOutRef = senderAccountOutRef;
    }

    public Long getSenderAccountOutRef() {
        return senderAccountOutRef;
    }

    public void setReceiverAccountOutRef(Long receiverAccountOutRef) {
        this.receiverAccountOutRef = receiverAccountOutRef;
    }

    public Long getReceiverAccountOutRef() {
        return receiverAccountOutRef;
    }
}
