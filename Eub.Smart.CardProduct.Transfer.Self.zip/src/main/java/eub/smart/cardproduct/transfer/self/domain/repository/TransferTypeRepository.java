package eub.smart.cardproduct.transfer.self.domain.repository;


import java.util.Optional;

public interface TransferTypeRepository {

    Optional<Long> findOperationId(String accountNumber, String targetCurrency);

    Optional<Long> findOperationId(String finDocType, String sourceCurrency, String targetCurrency);

    Optional<String> findId(String finDocType, String srcCurrency, String targetCurrency, Boolean flagCorporate);

    String findIdOrException(String finDocType, String srcCurrency, String targetCurrency, Boolean flagCorporate);

    Long findOperationIdOrException(String accountNumber, String targetCurrency);

    Long findOperationIdOrException(String finDocType, String sourceCurrency, String targetCurrency);
}
