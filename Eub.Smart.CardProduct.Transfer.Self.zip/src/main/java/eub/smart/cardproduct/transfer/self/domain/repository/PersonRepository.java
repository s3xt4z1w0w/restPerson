package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.NewTransferClient;

import java.util.Optional;

public interface PersonRepository {

    Optional<NewTransferClient> findNewTransferClient(Long id);

    NewTransferClient findNewTransferClientOrException(Long id);
}
