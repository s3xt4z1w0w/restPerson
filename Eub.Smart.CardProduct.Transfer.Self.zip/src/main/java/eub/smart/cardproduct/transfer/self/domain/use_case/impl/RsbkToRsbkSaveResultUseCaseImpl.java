package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbk;
import eub.smart.cardproduct.transfer.self.domain.repository.ZeebeEventFinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.RsbkToRsbkSaveResultUseCase;

import static java.util.Objects.isNull;

public class RsbkToRsbkSaveResultUseCaseImpl extends ZeebeEventFinDocSaveResult implements RsbkToRsbkSaveResultUseCase {

    public RsbkToRsbkSaveResultUseCaseImpl(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        super(zeebeEventFinDocRepository);
    }

    @Override
    public void invoke(Long finDocId, TransferRsbkToRsbk transferRsbkToRsbk) {
        if (isNull(transferRsbkToRsbk)) {
            saveResult(finDocId);
        } else {
            var collectorId = getCollectorId(transferRsbkToRsbk);
            saveResult(finDocId, collectorId);
        }
    }

    private String getCollectorId(TransferRsbkToRsbk transferRsbkToRsbk) {
        return transferRsbkToRsbk.getTransferRSBKtoRSBKResponse().getCollectorId();
    }
}
