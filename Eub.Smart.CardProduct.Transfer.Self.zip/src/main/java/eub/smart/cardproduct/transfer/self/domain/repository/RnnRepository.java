package eub.smart.cardproduct.transfer.self.domain.repository;

import java.util.Optional;

public interface RnnRepository {

    Optional<String> generateRnn();

    String generateRnnOrException();
}
