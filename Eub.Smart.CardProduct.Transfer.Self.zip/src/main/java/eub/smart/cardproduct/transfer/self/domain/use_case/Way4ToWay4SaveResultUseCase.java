package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;

public interface Way4ToWay4SaveResultUseCase {

    void invoke(Long finDocId, RrnBrrn rrnBrrn);
}
