package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.common.LocalizedText;
import eub.smart.cardproduct.transfer.self.domain.model.in.StoryIn;
import eub.smart.cardproduct.transfer.self.infrastructure.model.TransferStory;

public class TransferHistoryMapper {

    public static StoryIn toStoryIn(TransferStory transferStory) {
        return new StoryIn(transferStory.getFinDocId(),
                transferStory.getFinDocType(),
                transferStory.getCreatedDate(),
                transferStory.getAmount(),
                transferStory.getCurrency(),
                transferStory.getStatus(),
                new LocalizedText(transferStory.getTransferTypeRu(), transferStory.getTransferTypeKk(), transferStory.getReceiverEn()),
                new LocalizedText(transferStory.getSenderRu(), transferStory.getSenderKk(), transferStory.getSenderEn()),
                new LocalizedText(transferStory.getReceiverRu(), transferStory.getReceiverKk(), transferStory.getSenderEn()),
                transferStory.getImageDefinition());
    }
}
