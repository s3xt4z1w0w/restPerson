package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4;

public interface TransferRsbkToWay4UseCase {

    TransferRsbkToWay4 invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData);
}
