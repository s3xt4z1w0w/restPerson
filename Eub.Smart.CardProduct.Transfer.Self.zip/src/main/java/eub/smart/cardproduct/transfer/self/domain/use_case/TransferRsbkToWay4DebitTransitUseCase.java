package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4Credit;

public interface TransferRsbkToWay4DebitTransitUseCase {

    TransferRsbkToWay4Credit invoke(FinDocData finDocData, AccountData receiverData, RrnBrrn rrnBrrn);
}
