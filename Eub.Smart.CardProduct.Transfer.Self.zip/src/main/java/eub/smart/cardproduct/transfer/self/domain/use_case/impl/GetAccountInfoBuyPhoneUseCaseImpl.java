package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.AccountInfo;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.repository.AccountRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetAccountInfoBuyPhoneUseCase;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800;
import static java.util.Objects.isNull;

public class GetAccountInfoBuyPhoneUseCaseImpl implements GetAccountInfoBuyPhoneUseCase {

    private final AccountRepository accountRepository;

    public GetAccountInfoBuyPhoneUseCaseImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public CreateTransferAccountInfo invoke(String phoneNumber, String currency) {
        var accountInfo = accountRepository.findByPhoneNumberOrException(phoneNumber);
        if (isOldMultiCurrency(accountInfo)) {
            accountInfo.setCurrency(currency);
        } else if(!accountInfo.getCurrency().equals(currency)) {
            throw new SelfException(E_LG_800, ": invalid currency by transfer account number: " + phoneNumber);
        }
        return new CreateTransferAccountInfo(accountInfo);
    }

    private boolean isOldMultiCurrency(AccountInfo accountInfo) {
        return accountInfo.getFlagMultiCurrency() && isNull(accountInfo.getIdRef());
    }
}
