package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.self.infrastructure.entity.FeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeHiberRepository extends JpaRepository<FeeEntity, Long> {

}
