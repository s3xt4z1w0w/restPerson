package eub.smart.cardproduct.transfer.self.application.model;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;

import java.math.BigDecimal;
import java.util.Date;

public class FinDocData {

    private Long id;
    private String type;
    private String knpCode;
    private BigDecimal feeAmount;
    private Date dateSigned;
    private Boolean flagConvert;
    private String correlationId;
    @JsonSetter(nulls = Nulls.SET)
    private String message;

    public String getKnpCode() {
        return knpCode;
    }

    public void setKnpCode(String knpCode) {
        this.knpCode = knpCode;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public Date getDateSigned() {
        return dateSigned;
    }

    public void setDateSigned(Date dateSigned) {
        this.dateSigned = dateSigned;
    }

    public Boolean getFlagConvert() {
        return flagConvert;
    }

    public void setFlagConvert(Boolean flagConvert) {
        this.flagConvert = flagConvert;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "FinDocData{" +
                "id=" + id +
                ", type=" + type +
                ", knpCode=" + knpCode +
                ", feeAmount=" + feeAmount +
                ", dateSigned=" + dateSigned +
                ", flagConvert=" + flagConvert +
                ", correlationId=" + correlationId +
                ", message=" + message +
                '}';
    }
}
