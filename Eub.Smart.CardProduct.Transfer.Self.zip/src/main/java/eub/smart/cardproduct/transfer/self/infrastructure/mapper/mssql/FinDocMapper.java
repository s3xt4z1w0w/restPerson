package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.FinDocInfo;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;
import java.util.Objects;

public class FinDocMapper {

    public static FinDocInfo toDomainModel(Map<String, Object> row, String senderIin, String correlationId) {
        MapResultScanner scanner = new MapResultScanner(row);

        FinDocInfo model = new FinDocInfo();
        model.setFinDocId(scanner.getLong("finDocId"));
        model.setFinDocType(scanner.getString("finDocType"));
        model.setKnpCode(scanner.getString("knpCode"));
        model.setFeeAmount(scanner.getBigDecimal("feeAmount"));
        model.setDateSigned(scanner.getDate("dateSigned"));
        model.setFlagConvert(isConvert(scanner));
        model.setCorrelationId(correlationId);
        model.setSenderIin(senderIin);
        model.setSenderBSystem(scanner.getString("senderBSystem"));
        model.setSenderAccountNumber(scanner.getString("senderAccountNumber"));
        model.setSenderAmount(scanner.getBigDecimal("senderAmount"));
        model.setSenderCurrency(scanner.getString("senderCurrency"));
        model.setSenderFlagResident(scanner.getBoolean("senderFlagResident"));
        model.setSenderFullName(scanner.getString("senderFullname"));
        model.setSenderAccountType(scanner.getString("senderAccountType"));
        model.setSenderFlagMulti(scanner.getBoolean("senderFlagMultiCurrency"));
        model.setReceiverIin(scanner.getString("receiverIin"));
        model.setReceiverBSystem(scanner.getString("receiverBSystem"));
        model.setReceiverAccountNumber(scanner.getString("receiverAccountNumber"));
        model.setReceiverAmount(scanner.getBigDecimal("receiverAmount"));
        model.setReceiverCurrency(scanner.getString("receiverCurrency"));
        model.setReceiverFlagResident(scanner.getBoolean("receiverFlagResident"));
        model.setReceiverFullName(scanner.getString("receiverFullname"));
        model.setReceiverAccountType(scanner.getString("receiverAccountType"));
        model.setReceiverFlagMulti(scanner.getBoolean("receiverFlagMultiCurrency"));
        model.setSenderAccountStatus(scanner.getString("senderAccountStatus"));
        model.setReceiverAccountStatus(scanner.getString("receiverAccountStatus"));
        model.setSenderAccountIdRef(scanner.getLong("senderAccountIdRef"));
        model.setReceiverAccountIdRef(scanner.getLong("receiverAccountIdRef"));
        model.setSenderAccountOutRef(scanner.getLong("senderAccountOutRef"));
        model.setReceiverAccountOutRef(scanner.getLong("receiverAccountOutRef"));
        return model;
    }

    private static boolean isConvert(MapResultScanner scanner) {
        var senderCurrency = scanner.getString("senderCurrency");
        var receiverCurrency = scanner.getString("receiverCurrency");
        return !Objects.equals(senderCurrency, receiverCurrency);
    }
}
