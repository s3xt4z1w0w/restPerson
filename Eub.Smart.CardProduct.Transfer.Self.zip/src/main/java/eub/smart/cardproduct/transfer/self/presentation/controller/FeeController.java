package eub.smart.cardproduct.transfer.self.presentation.controller;

import eub.smart.cardproduct.transfer.self.presentation.mapper.PresentationMapper;
import eub.smart.cardproduct.transfer.self.presentation.model.request.FeeRequest;
import eub.smart.cardproduct.transfer.self.presentation.response_advise.ResponseBinding;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetSelfFeeUseCase;
import eub.smart.cardproduct.transfer.self.presentation.swagger.response.GetFeeResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;

@ResponseBinding
@RestController
@RequestMapping("/api/fee")
@Tag(name = "FeeController", description = "API для комиссии")
public class FeeController {

    private final GetSelfFeeUseCase getSelfFeeUseCase;
    private final PresentationMapper mapper;

    public FeeController(GetSelfFeeUseCase getSelfFeeUseCase,
                         PresentationMapper mapper) {
        this.getSelfFeeUseCase = getSelfFeeUseCase;
        this.mapper = mapper;
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Получение информации о комиссии", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = GetFeeResponse.class))})})
    @GetMapping("/self")
    public ResponseEntity<?> getSelf(@Valid @RequestBody FeeRequest feeRequest) {
        var feeResponse = getSelfFeeUseCase.invoke(
                feeRequest.getAmount(),
                feeRequest.getAccountNumber(),
                feeRequest.getSourceCurrency(),
                feeRequest.getTargetCurrency());
        var response = mapper.toResponse(feeResponse);
        return ResponseEntity.ok(response);
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Получение информации о комиссии", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = GetFeeResponse.class))})})
    @GetMapping
    public ResponseEntity<?> getSelfOld(@Parameter(description = "сумма")
                                        @RequestParam("amount") BigDecimal amount,
                                        @Parameter(description = "номер аккаунта")
                                        @RequestParam("accountNumber") String accountNumber,
                                        @Parameter(description = "тип валюты")
                                        @RequestParam("targetCurrency") String targetCurrency) {
        var feeResponse = getSelfFeeUseCase.invoke(
                amount,
                accountNumber,
                targetCurrency);
        var response = mapper.toResponse(feeResponse);
        return ResponseEntity.ok(response);
    }
}
