package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class ReverseDoc {

    private TryReverseDocRequest request;
    private TryReverseDocReply response;

    public ReverseDoc() {
    }

    public ReverseDoc(TryReverseDocRequest request, TryReverseDocReply response) {
        this.request = request;
        this.response = response;
    }

    public void setRequest(TryReverseDocRequest request) {
        this.request = request;
    }

    public void setResponse(TryReverseDocReply response) {
        this.response = response;
    }

    public TryReverseDocRequest getRequest() {
        return request;
    }

    public TryReverseDocReply getResponse() {
        return response;
    }
}
