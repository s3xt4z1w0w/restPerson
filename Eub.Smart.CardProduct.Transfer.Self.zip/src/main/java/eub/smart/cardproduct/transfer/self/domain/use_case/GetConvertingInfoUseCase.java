package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.ConvertingInfo;

import java.math.BigDecimal;

public interface GetConvertingInfoUseCase {

    ConvertingInfo invoke(BigDecimal amount, String senderAccountCurrency, String receiverAccountCurrency, String correlationId);

}
