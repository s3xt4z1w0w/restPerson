package eub.smart.cardproduct.transfer.self.application.model;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.ReverseDoc;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToRsbk;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferTcRsbk;

public class TransferInternalRsbkToRsbkBaseModel extends TransferInternalBaseModel {

    @JsonSetter(nulls = Nulls.SET)
    private TransferRsbkToRsbk transferRsbkToRsbk;
    @JsonSetter(nulls = Nulls.SET)
    private TransferTcRsbk transferTcRsbk;
    @JsonSetter(nulls = Nulls.SET)
    private ReverseDoc reverseDoc;

    public TransferRsbkToRsbk getTransferRsbkToRsbk() {
        return transferRsbkToRsbk;
    }

    public void setTransferRsbkToRsbk(TransferRsbkToRsbk transferRsbkToRsbk) {
        this.transferRsbkToRsbk = transferRsbkToRsbk;
    }

    public TransferTcRsbk getTransferTcRsbk() {
        return transferTcRsbk;
    }

    public void setTransferTcRsbk(TransferTcRsbk transferTcRsbk) {
        this.transferTcRsbk = transferTcRsbk;
    }

    public ReverseDoc getReverseDoc() {
        return reverseDoc;
    }

    public void setReverseDoc(ReverseDoc reverseDoc) {
        this.reverseDoc = reverseDoc;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
