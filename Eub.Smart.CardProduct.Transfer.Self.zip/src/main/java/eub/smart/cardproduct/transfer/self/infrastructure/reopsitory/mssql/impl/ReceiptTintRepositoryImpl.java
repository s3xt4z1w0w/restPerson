package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.out.TransferReceiptOut;
import eub.smart.cardproduct.transfer.self.domain.repository.ReceiptRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.ReceiptTintMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.constant.FinDocType.TINT;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Repository
public class ReceiptTintRepositoryImpl implements ReceiptRepository {

    private final NamedParameterJdbcTemplate template;

    public ReceiptTintRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<TransferReceiptOut> findByFinDocId(Long finDocId, LangKey lang) {
        String sql = """
                select fd.Amount                                                                      as amount,
                       fd.Currency                                                                    as currency,
                       fd.Fee                                                                         as fee,
                       fd.FeeCurrency                                                                 as feeCurrency,
                       bank.bank_ID                                                                   as dataTitle_imagesUrl_Definition,
                       dts.FinDocStatus_IDREF                                                         as status,
                       case
                           when bank.Bank_ID is not null then
                               case
                                   when bank.Term_OUTREF is not null then
                                       case
                                           when t.MaskedNumber is not null then (trm_bank.Term_RU + ' • ' + right(t.MaskedNumber, 4))
                                           else (trm_bank.Term_RU + ' • ' + left(t.Receiver_Account, 2) +
                                                 right(t.Receiver_Account, 4)) end
                                   else case
                                            when t.MaskedNumber is not null then (bank.Bank_Title + ' • ' + right(t.MaskedNumber, 4))
                                            else (bank.Bank_Title + ' • ' + left(t.Receiver_Account, 2) +
                                                  right(t.Receiver_Account, 4)) end
                                   end
                           else case
                                    when t.MaskedNumber is not null then (' • ' + right(t.MaskedNumber, 4))
                                    else (' • ' + left(t.Receiver_Account, 2) + right(t.Receiver_Account, 4)) end
                           end                                                                        as dataTitle_title_RU,
                       case
                           when bank.Bank_ID is not null then
                               case
                                   when bank.Term_OUTREF is not null then
                                       case
                                           when t.MaskedNumber is not null then (trm_bank.Term_KZ + ' • ' + right(t.MaskedNumber, 4))
                                           else (trm_bank.Term_KZ + ' • ' + left(t.Receiver_Account, 2) +
                                                 right(t.Receiver_Account, 4)) end
                                   else case
                                            when t.MaskedNumber is not null then (bank.Bank_Title + ' • ' + right(t.MaskedNumber, 4))
                                            else (bank.Bank_Title + ' • ' + left(t.Receiver_Account, 2) +
                                                  right(t.Receiver_Account, 4)) end
                                   end
                           else
                               case
                                   when t.MaskedNumber is not null then (' • ' + right(t.MaskedNumber, 4))
                                   else (' • ' + left(t.Receiver_Account, 2) + right(t.Receiver_Account, 4)) end
                           end
                                                                                                      as dataTitle_title_KZ,
                       case
                           when bank.Bank_ID is not null then
                               case
                                   when bank.Term_OUTREF is not null then
                                       case
                                           when t.MaskedNumber is not null then (trm_bank.Term_EN + ' • ' + right(t.MaskedNumber, 4))
                                           else (trm_bank.Term_EN + ' • ' + left(t.Receiver_Account, 2) +
                                                 right(t.Receiver_Account, 4)) end
                                   else case
                                            when t.MaskedNumber is not null then (bank.Bank_Title + ' • ' + right(t.MaskedNumber, 4))
                                            else (bank.Bank_Title + ' • ' + left(t.Receiver_Account, 2) +
                                                  right(t.Receiver_Account, 4)) end
                                   end
                           else case
                                    when t.MaskedNumber is not null then (' • ' + right(t.MaskedNumber, 4))
                                    else (' • ' + left(t.Receiver_Account, 2) + right(t.Receiver_Account, 4)) end
                           end                                                                        as dataTitle_title_EN,
                       trm_fdt.Term_RU                                                                as dataTitle_desc_RU,
                       trm_fdt.Term_KZ                                                                as dataTitle_desc_KZ,
                       trm_fdt.Term_EN                                                                as dataTitle_desc_EN,
                       'Отправитель'                                                                  as dataDesc_k1_RU,
                       N'Жіберуші'                                                                    as dataDesc_k1_KZ,
                       'Sender'                                                                       as dataDesc_k1_EN,
                       (p.FirstName + ' ' + left(p.Firstname, 1) + '. ' +
                        isnull(left((p.FathersName + '.'), 1), ''))                                   as dataDesc_v1_RU,
                       (p.FirstName + ' ' + left(p.Firstname, 1) + '. ' +
                        isnull(left((p.FathersName + '.'), 1), ''))                                   as dataDesc_v1_KZ,
                       (p.FirstName + ' ' + left(p.Firstname, 1) + '. ' +
                        isnull(left((p.FathersName + '.'), 1), ''))                                   as dataDesc_v1_EN,
                       'Откуда'                                                                       as dataDesc_k2_RU,
                       N'Қайдан'                                                                      as dataDesc_k2_KZ,
                       'From'                                                                         as dataDesc_k2_EN,
                       case
                           when map_user_account.Pseudonym is not null
                               then (map_user_account.Pseudonym + ' • ' + left(a.Number, 2) + right(a.Number, 4))
                           else (trm_at.Term_RU + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as dataDesc_v2_RU,
                       case
                           when map_user_account.Pseudonym is not null
                               then (map_user_account.Pseudonym + ' • ' + left(a.Number, 2) + right(a.Number, 4))
                           else (trm_at.Term_KZ + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as dataDesc_v2_KZ,
                       case
                           when map_user_account.Pseudonym is not null
                               then (map_user_account.Pseudonym + ' • ' + left(a.Number, 2) + right(a.Number, 4))
                           else (trm_at.Term_EN + ' • ' + left(a.Number, 2) + right(a.Number, 4)) end as dataDesc_v2_EN,
                       'Банк получатель'                                                              as dataDesc_k3_RU,
                       N'Алушы банк'                                                                  as dataDesc_k3_KZ,
                       'Recipient Bank'                                                               as dataDesc_k3_EN,
                       case
                           when bank.Bank_ID is not null then
                               case
                                   when bank.Term_OUTREF is not null then trm_bank.Term_RU
                                   else bank.Bank_Title end end                                       as dataDesc_v3_RU,
                       case
                           when bank.Bank_ID is not null then
                               case
                                   when bank.Term_OUTREF is not null then trm_bank.Term_KZ
                                   else bank.Bank_Title end end                                       as dataDesc_v3_KZ,
                       case
                           when bank.Bank_ID is not null then
                               case
                                   when bank.Term_OUTREF is not null then trm_bank.Term_RU
                                   else bank.Bank_Title end end                                       as dataDesc_v3_EN,
                       'БИК'                                                                          as dataDesc_k4_RU,
                       N'БСК'                                                                         as dataDesc_k4_KZ,
                       'BIC'                                                                          as dataDesc_k4_EN,
                       t.Receiver_BIC                                                                 as dataDesc_v4_RU,
                       t.Receiver_BIC                                                                 as dataDesc_v4_KZ,
                       t.Receiver_BIC                                                                 as dataDesc_v4_EN,
                       'КНП'                                                                          as dataDesc_k5_RU,
                       N'ТТК'                                                                         as dataDesc_k5_KZ,
                       'PPC'                                                                          as dataDesc_k5_EN,
                       (t.KNP_IDREF + ' - ' + trm_knp.Term_RU)                                        as dataDesc_v5_RU,
                       (t.KNP_IDREF + ' - ' + trm_knp.Term_KZ)                                        as dataDesc_v5_KZ,
                       (t.KNP_IDREF + ' - ' + trm_knp.Term_EN)                                        as dataDesc_v5_EN,
                       'Дата'                                                                         as dataDetails_k1_RU,
                       N'Күні'                                                                        as dataDetails_k1_KZ,
                       'Date'                                                                         as dataDetails_k1_EN,
                       fd.DateCreated                                                                 as dataDetails_v1_RU,
                       fd.DateCreated                                                                 as dataDetails_v1_KZ,
                       fd.DateCreated                                                                 as dataDetails_v1_EN,
                       '№ квитанции'                                                                  as dataDetails_k2_RU,
                       N'Түбіртектің нөмірі'                                                          as dataDetails_k2_KZ,
                       'Receipt No.'                                                                  as dataDetails_k2_EN,
                       fd.FinDoc_ID                                                                   as dataDetails_v2_RU,
                       fd.FinDoc_ID                                                                   as dataDetails_v2_KZ,
                       fd.FinDoc_ID                                                                   as dataDetails_v2_EN
                from FinDoc fd
                         join FinDocState fds on fd.FinDoc_ID = fds.FinDoc_IDREF
                         join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF and
                                                   dts.FinDocStatus_IDREF in ('DONE', 'RTRN')
                         join FinDocType fdt on fdt.FinDocType_ID = fd.FinDocType_IDREF
                         left join Term trm_fdt on trm_fdt.Term_ID = fdt.Term_OUTREF
                         left join Account a on a.Account_ID = fd.Account_IDREF
                         left join AccountType at on a.AccountType_IDREF = at.AccountType_ID
                         left join Term trm_at on at.Term_OUTREF = trm_at.Term_ID
                         join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                         left join map_User_Account on map_User_Account.User_IDREF = fd.User_IDREF and
                                                       map_User_Account.Account_IDREF = fd.Account_IDREF
                         left join bank on t.Receiver_BIC = bank.BIC
                         left join term trm_bank on bank.Term_OUTREF = trm_bank.Term_ID
                         left join [User] u on fd.User_IDREF = u.User_ID
                         left join Person p on u.Person_IDREF = p.Person_ID
                         left join KNP on knp.KNP_ID = t.KNP_IDREF
                         left join term trm_knp on trm_knp.Term_ID = knp.Term_OUTREF
                where FinDocType_ID in ('TINT')
                  and fd.FinDoc_ID = :finDocId;
                """;
        List<TransferReceiptOut> queryResult = template.query(sql, Map.of("finDocId", finDocId), (resultSet, i) -> ReceiptTintMapper.toDomain(resultSet, lang));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": ReceiptTintRepositoryImpl findByFinDocId");
        }
    }

    @Override
    public TransferReceiptOut findByFinDocIdOrException(Long finDocId, LangKey lang) {
        return findByFinDocId(finDocId, lang).
                orElseThrow(() -> new SelfException(E_DB_600, ": ReceiptTintRepositoryImpl findByFinDocIdOrException"));
    }

    @Override
    public String key() {
        return TINT;
    }
}
