package eub.smart.cardproduct.transfer.self.presentation.model.response;

import eub.smart.cardproduct.transfer.self.domain.model.out.MapDisplay;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.Queue;

public record ReceiptResponse(

        @Schema(description = "Данные зоголовка")
        HeadResponse head,
        @Schema(description = "Тело квитанции")
        Queue<? extends MapDisplay> body,
        @Schema(description = "Прилогающие данные квитанции")
        Queue<? extends MapDisplay> attachment
) {

}

