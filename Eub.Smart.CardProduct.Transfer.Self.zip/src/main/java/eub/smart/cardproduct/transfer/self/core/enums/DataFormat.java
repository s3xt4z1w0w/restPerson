package eub.smart.cardproduct.transfer.self.core.enums;

public enum DataFormat {

    PHONE_NUMBER,
    STRING,
    TIMESTAMP,
}
