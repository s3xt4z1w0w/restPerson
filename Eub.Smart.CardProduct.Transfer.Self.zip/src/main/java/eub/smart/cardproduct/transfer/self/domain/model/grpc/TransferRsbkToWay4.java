package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferRsbkToWay4 {

    private TransferRsbkToWay4Request transferRsbkToWay4Request;
    private TransferResponse transferRsbkToWay4Response;

    public TransferRsbkToWay4() {
    }

    public TransferRsbkToWay4(TransferRsbkToWay4Request transferRsbkToWay4Request, TransferResponse transferRsbkToWay4Response) {
        this.transferRsbkToWay4Request = transferRsbkToWay4Request;
        this.transferRsbkToWay4Response = transferRsbkToWay4Response;
    }

    public TransferRsbkToWay4Request getTransferRsbkToWay4Request() {
        return transferRsbkToWay4Request;
    }

    public TransferResponse getTransferRsbkToWay4Response() {
        return transferRsbkToWay4Response;
    }

    public void setTransferRsbkToWay4Request(TransferRsbkToWay4Request transferRsbkToWay4Request) {
        this.transferRsbkToWay4Request = transferRsbkToWay4Request;
    }

    public void setTransferRsbkToWay4Response(TransferResponse transferRsbkToWay4Response) {
        this.transferRsbkToWay4Response = transferRsbkToWay4Response;
    }
}
