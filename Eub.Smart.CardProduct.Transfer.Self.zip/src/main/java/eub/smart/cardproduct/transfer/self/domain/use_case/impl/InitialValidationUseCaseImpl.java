package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.TransferInternalBaseModel;
import eub.smart.cardproduct.transfer.self.domain.repository.FinDocStateRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static eub.smart.cardproduct.transfer.self.core.constant.DocTechStatus.*;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.*;
import static java.util.concurrent.CompletableFuture.runAsync;
import static java.util.concurrent.TimeUnit.SECONDS;

public class InitialValidationUseCaseImpl implements InitialValidationUseCase {

    private final ValidateAccountAmountUseCase validateAccountAmountUseCase;
    private final ValidateSenderAccountUseCase validateSenderAccountUseCase;
    private final ValidateReceiverAccountUseCase validateReceiverAccountUseCase;
    private final ValidateBSystemAvailabilityUseCase validateBSystemAvailabilityUseCase;
    private final FinDocStateRepository finDocStateRepository;

    public InitialValidationUseCaseImpl(ValidateAccountAmountUseCase validateAccountAmountUseCase,
                                        ValidateSenderAccountUseCase validateSenderAccountUseCase,
                                        ValidateReceiverAccountUseCase validateReceiverAccountUseCase,
                                        ValidateBSystemAvailabilityUseCase validateBSystemAvailabilityUseCase,
                                        FinDocStateRepository finDocStateRepository) {
        this.validateAccountAmountUseCase = validateAccountAmountUseCase;
        this.validateSenderAccountUseCase = validateSenderAccountUseCase;
        this.validateReceiverAccountUseCase = validateReceiverAccountUseCase;
        this.validateBSystemAvailabilityUseCase = validateBSystemAvailabilityUseCase;
        this.finDocStateRepository = finDocStateRepository;
    }

    @Override
    public void invoke(TransferInternalBaseModel baseModel, LangKey lang) {
        List<CompletableFuture<Void>> validateFutures = futures(baseModel, lang);
        executeFuture(baseModel, validateFutures);
    }

    protected List<CompletableFuture<Void>> futures(TransferInternalBaseModel baseModel, LangKey lang) {
        var sender = baseModel.getSender();
        var receiver = baseModel.getReceiver();

        var validateSenderAccountFuture = runAsync(() -> validateSenderAccountUseCase.invoke(sender, lang));
        var validateReceiverAccountFuture = runAsync(() -> validateReceiverAccountUseCase.invoke(receiver, lang));
        var validateSenderAmountFuture = runAsync(() -> validateAccountAmountUseCase.invoke(sender, baseModel.getCorrelationId(), lang));
        var validateSenderBSystemAvailabilityFuture = runAsync(() -> validateBSystemAvailabilityUseCase.invoke(sender.getbSystem(), lang));
        var validateReceiverBSystemAvailabilityFuture = runAsync(() -> validateBSystemAvailabilityUseCase.invoke(receiver.getbSystem(), lang));

        return new ArrayList<>(List.of(
                validateSenderAccountFuture,
                validateReceiverAccountFuture,
                validateSenderAmountFuture,
                validateSenderBSystemAvailabilityFuture,
                validateReceiverBSystemAvailabilityFuture));
    }

    protected final void executeFuture(TransferInternalBaseModel baseModel, List<CompletableFuture<Void>> validateFutures) {
        try {
            for (CompletableFuture<Void> validateFuture : validateFutures)
                validateFuture.get(25L, SECONDS);
        } catch (ExecutionException e) {
            saveDocTechStatus(e, baseModel);
            throw new SelfException(E_SM_503, e);
        } catch (InterruptedException e) {
            throw new SelfException(E_SM_504, e);
        } catch (TimeoutException e) {
            throw new SelfException(E_SM_505, e);
        }
    }

    private void saveDocTechStatus(ExecutionException e, TransferInternalBaseModel baseModel) {
        if (e.getCause() instanceof SelfException se) {
            var code = se.getCode();
            var finDocId = baseModel.getFinDocId();
            switch (code) {
                case E_LG_800_VLBS -> finDocStateRepository.saveFinDocStatus(VLBS, finDocId);
                case E_LG_800_VLSU -> finDocStateRepository.saveFinDocStatus(VLSU, finDocId);
                case E_LG_800_VLSS -> finDocStateRepository.saveFinDocStatus(VLSS, finDocId);
                case E_LG_800_MTNT -> finDocStateRepository.saveFinDocStatus(MTNT, finDocId);
                default -> throw se;
            }
        }
    }
}
