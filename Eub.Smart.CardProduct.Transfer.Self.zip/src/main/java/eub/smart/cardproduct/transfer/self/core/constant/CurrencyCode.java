package eub.smart.cardproduct.transfer.self.core.constant;

public interface CurrencyCode {

    String KZT = "KZT";
    String USD = "USD";
    String EUR = "EUR";
    String RUB = "RUB";
    String BNS = "BNS";
    String CHF = "CHF";
    String CNY = "CNY";
    String GBP = "GBP";
    String KZT_OLD = "398";
}
