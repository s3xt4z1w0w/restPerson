package eub.smart.cardproduct.transfer.self.presentation.swagger.response;

import eub.smart.cardproduct.transfer.self.presentation.model.ServiceResponse;

public class ExecuteTransferResponse extends ServiceResponse<Boolean> {
}
