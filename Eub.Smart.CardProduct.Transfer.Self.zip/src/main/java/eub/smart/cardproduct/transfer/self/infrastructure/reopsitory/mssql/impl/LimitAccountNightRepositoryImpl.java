package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.domain.model.limit.SpentAmount;
import eub.smart.cardproduct.transfer.self.domain.repository.LimitAccountNightRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.SpentAmountMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Primary
@Repository
public class LimitAccountNightRepositoryImpl implements LimitAccountNightRepository {

    private final NamedParameterJdbcTemplate template;

    public LimitAccountNightRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public List<SpentAmount> findByAccountNumber(LocalDate signDate, String accountNumber) {
        Map<String, Object> map = new HashMap<>();
        map.put("dateSigned", signDate);
        map.put("accountNumber", accountNumber);

        String sql = """ 
                select tt.SrcCurrency               as senderCurrency,
                       tt.TargetCurrency            as receiverCurrency,
                       coalesce(sum(fd.Amount), 0)  as amountSum
                from FinDoc fd
                         join dbo.FinDocState fds on fds.FinDoc_IDREF = fd.FinDoc_ID
                         join DocTechStatus dts on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                         join Account a on a.Account_ID = fd.Account_IDREF
                         join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                         join TransferType tt on t.TransferType_IDREF = tt.TransferType_ID
                where dts.FinDocStatus_IDREF IN ('PROC', 'DONE')
                  and a.Number = :accountNumber
                  and cast(fd.DateSigned as date) = :dateSigned
                  and cast(fd.DateSigned as time) NOT BETWEEN '09:00:00' and '17:00:00'
                  and tt.SrcCurrency != tt.TargetCurrency
                group by tt.SrcCurrency, tt.TargetCurrency
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, map);
        return queryResult
                .stream()
                .map(SpentAmountMapper::toDomainModel)
                .collect(Collectors.toList());
    }
}
