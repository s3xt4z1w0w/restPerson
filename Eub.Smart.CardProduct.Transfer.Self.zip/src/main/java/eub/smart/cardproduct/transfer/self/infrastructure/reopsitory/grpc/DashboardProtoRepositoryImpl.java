package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.grpc;

import DashboardInfo.V1.DashboardInfoGrpc;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.repository.DashboardProtoRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.GetAggregateAccountsMapper;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_EX_700;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isEmpty;
import static eub.smart.cardproduct.transfer.self.core.util.GrpcUtil.toBigDecimal;

@Component
public class DashboardProtoRepositoryImpl implements DashboardProtoRepository {

    @GrpcClient("dashboard-info")
    private DashboardInfoGrpc.DashboardInfoBlockingStub stub;

    @Override
    public BigDecimal availableBalance(AccountData accountData, String correlationId) {
        try {
            var request = GetAggregateAccountsMapper.buildRequest(accountData);
            var response = stub.getAggregateAccounts(request);
            if (isEmpty(response.getAccountsList())) throw new SelfException(E_EX_700, ": result is empty");
            var amountValue = response                                                                          // TODO переделать
                    .getAccounts(0)
                    .getAvailableBalance()
                    .getAmount();
            return toBigDecimal(amountValue);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": availableBalance " + e.getStatus().getCode().name());
        }
    }
}
