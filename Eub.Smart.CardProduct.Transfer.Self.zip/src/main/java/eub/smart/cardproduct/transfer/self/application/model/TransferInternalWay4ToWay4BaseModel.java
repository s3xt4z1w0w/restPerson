package eub.smart.cardproduct.transfer.self.application.model;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;

public class TransferInternalWay4ToWay4BaseModel extends TransferInternalBaseModel {

    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4ToWay4 transferWay4ToWay4Debit;
    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4ToWay4 transferWay4ToWay4ReverseDebit;
    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4ToWay4 transferWay4ToWay4Credit;
    @JsonSetter(nulls = Nulls.SET)
    private RrnBrrn rrnBrrn;
    @JsonSetter(nulls = Nulls.SET)
    private String selfMultiType;
    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4Post transferWay4Post;
    @JsonSetter(nulls = Nulls.SET)
    private TransferIbanToIban transferIbanToIban;
    @JsonSetter(nulls = Nulls.SET)
    private TransferWay4Convert transferWay4Convert;

    public TransferWay4ToWay4 getTransferWay4ToWay4Debit() {
        return transferWay4ToWay4Debit;
    }

    public void setTransferWay4ToWay4Debit(TransferWay4ToWay4 transferWay4ToWay4Debit) {
        this.transferWay4ToWay4Debit = transferWay4ToWay4Debit;
    }

    public TransferWay4ToWay4 getTransferWay4ToWay4ReverseDebit() {
        return transferWay4ToWay4ReverseDebit;
    }

    public void setTransferWay4ToWay4ReverseDebit(TransferWay4ToWay4 transferWay4ToWay4ReverseDebit) {
        this.transferWay4ToWay4ReverseDebit = transferWay4ToWay4ReverseDebit;
    }

    public TransferWay4ToWay4 getTransferWay4ToWay4Credit() {
        return transferWay4ToWay4Credit;
    }

    public void setTransferWay4ToWay4Credit(TransferWay4ToWay4 transferWay4ToWay4Credit) {
        this.transferWay4ToWay4Credit = transferWay4ToWay4Credit;
    }

    public RrnBrrn getRrnBrrn() {
        return rrnBrrn;
    }

    public void setRrnBrrn(RrnBrrn rrnBrrn) {
        this.rrnBrrn = rrnBrrn;
    }

    public String getSelfMultiType() {
        return selfMultiType;
    }

    public void setSelfMultiType(String selfMultiType) {
        this.selfMultiType = selfMultiType;
    }

    public TransferWay4Post getTransferWay4Post() {
        return transferWay4Post;
    }

    public void setTransferWay4Post(TransferWay4Post transferWay4Post) {
        this.transferWay4Post = transferWay4Post;
    }

    public void setTransferIbanToIban(TransferIbanToIban transferIbanToIban) {
        this.transferIbanToIban = transferIbanToIban;
    }

    public TransferIbanToIban getTransferIbanToIban() {
        return transferIbanToIban;
    }

    public void setTransferWay4Convert(TransferWay4Convert transferWay4Convert) {
        this.transferWay4Convert = transferWay4Convert;
    }

    public TransferWay4Convert getTransferWay4Convert() {
        return transferWay4Convert;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
