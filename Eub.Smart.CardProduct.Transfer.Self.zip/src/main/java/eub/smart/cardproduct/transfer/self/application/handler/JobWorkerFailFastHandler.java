package eub.smart.cardproduct.transfer.self.application.handler;

import eub.smart.cardproduct.transfer.self.application.model.TransferInternalBaseModel;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Objects;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_VD_400;

@Aspect
@Component
public class JobWorkerFailFastHandler {

    private final Boolean flagProdStand;
    private final ConfigurableBeanFactory configurableBeanFactory;

    public JobWorkerFailFastHandler(@Value("${app.flag-prod-stand}") Boolean flagProdStand,
                                    ConfigurableBeanFactory configurableBeanFactory) {
        this.flagProdStand = flagProdStand;
        this.configurableBeanFactory = configurableBeanFactory;
    }

    @Before(value = "@annotation(eub.smart.cardproduct.transfer.self.application.handler.JobWorkerFailFast)")
    public void failFast(JoinPoint joinPoint) {
        if (flagProdStand) return;
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        JobWorkerFailFast handler = method.getAnnotation(JobWorkerFailFast.class);
        String key = handler.value();
        String value = configurableBeanFactory.resolveEmbeddedValue(key);

        Object[] args = joinPoint.getArgs();
        TransferInternalBaseModel baseModel = (TransferInternalBaseModel) args[0];
        String correlationId = baseModel.getFinDoc().getCorrelationId();
        if (Objects.equals(correlationId, value)) {
            throw new SelfException(E_VD_400, ": fail fast and loud!!!");
        }
    }
}
