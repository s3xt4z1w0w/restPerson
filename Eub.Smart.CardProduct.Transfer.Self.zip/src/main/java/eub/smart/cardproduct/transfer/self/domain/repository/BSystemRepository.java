package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.BSystem;

import java.util.Optional;

public interface BSystemRepository {

    Optional<BSystem> findByFinDocId(Long finDocId);

    BSystem findByFinDocIdOrException(Long finDocId);

    Optional<Integer> findInactiveBSystemCount(String bSystem);

    Integer findInactiveBSystemCountOrException(String bSystem);

}
