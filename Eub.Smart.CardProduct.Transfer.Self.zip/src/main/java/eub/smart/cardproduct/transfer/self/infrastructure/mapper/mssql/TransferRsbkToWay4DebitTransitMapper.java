package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.constant.AccountType.isDeposit;
import static eub.smart.cardproduct.transfer.self.core.util.StanUtil.generateStun;

public class TransferRsbkToWay4DebitTransitMapper {

    public static UfxTransferRequest toDomainModel(Map<String, Object> row, Long finDocId, String stun, RrnBrrn rrnBrrn, String operationAccount) {
        MapResultScanner scanner = new MapResultScanner(row);

        UfxTransferRequest request = new UfxTransferRequest();
        request.setFindoc(finDocId.toString());
        request.setRrn(rrnBrrn.getRrn());
        request.setBrrn(rrnBrrn.getBrrn());
        request.setStan(stun);
        request.setOperationAccount(operationAccount);
        request.setOperationSum(scanner.getBigDecimal("amount"));
        request.setOperationCurrency(scanner.getString("currency"));
        request.setLinkedOperationAccount(scanner.getString("accountNumber"));
        request.setDeposit(isDeposit(scanner.getString("accountType")));
        request.setDetails(createDetails(scanner.getString("fullname"), scanner.getString("accountNumber")));
        return request;
    }

    private static String createDetails(String fullname, String accountNumber) {
        return String.format("From RS; %s; %s", fullname, accountNumber);
    }

    public static UfxTransferRequest createRequest(FinDocData finDocData,
                                                   AccountData receiverData,
                                                   RrnBrrn rrnBrrn,
                                                   String operationAccount) {
        UfxTransferRequest request = new UfxTransferRequest();
        request.setFindoc(String.valueOf(finDocData.getId()));
        request.setRrn(rrnBrrn.getRrn());
        request.setBrrn(rrnBrrn.getBrrn());
        request.setStan(generateStun());
        request.setOperationAccount(operationAccount);
        request.setOperationSum(receiverData.getAmount());
        request.setOperationCurrency(receiverData.getCurrency());
        request.setLinkedOperationAccount(receiverData.getAccountNumber());
        request.setDeposit(isDeposit(receiverData.getAccountType()));
        request.setDetails(createDetails(receiverData.getFullName(), receiverData.getAccountNumber()));
        return request;
    }
}
