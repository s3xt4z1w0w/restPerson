package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.response_interface.ErrorMessage;

public class TransferWay4PostResponse implements ErrorMessage {

    private final String errorMessage;

    @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
    public TransferWay4PostResponse(@JsonProperty("errorMessage") String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String getErrorMessage() {
        return errorMessage;
    }

    @Override
    public String toString() {
        return "TransferWay4PostResponse{" +
                "errorMessage=" + errorMessage +
                '}';
    }
}
