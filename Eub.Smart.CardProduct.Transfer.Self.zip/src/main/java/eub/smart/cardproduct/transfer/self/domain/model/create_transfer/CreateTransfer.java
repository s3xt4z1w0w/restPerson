package eub.smart.cardproduct.transfer.self.domain.model.create_transfer;

import eub.smart.cardproduct.transfer.self.domain.model.FinDocStatus;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;

public class CreateTransfer {

    private Transfer transfer;
    private CreateTransferAccountInfo account;
    private FinDocStatus finDocStatus;

    public CreateTransfer() {
    }

    public CreateTransfer(Transfer transfer, CreateTransferAccountInfo account, FinDocStatus finDocStatus) {
        this.transfer = transfer;
        this.account = account;
        this.finDocStatus = finDocStatus;
    }

    public Transfer getTransfer() {
        return transfer;
    }

    public void setTransfer(Transfer transfer) {
        this.transfer = transfer;
    }

    public CreateTransferAccountInfo getAccount() {
        return account;
    }

    public void setAccount(CreateTransferAccountInfo account) {
        this.account = account;
    }

    public FinDocStatus getFinDocStatus() {
        return finDocStatus;
    }

    public void setFinDocStatus(FinDocStatus finDocStatus) {
        this.finDocStatus = finDocStatus;
    }
}
