package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.RnnRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_602;

@Primary
@Repository
public class RnnRepositoryImpl implements RnnRepository {

    private final NamedParameterJdbcTemplate template;

    public RnnRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<String> generateRnn() {
        String sql = "exec bis_GenerateRRN";
        return template.query(sql, resultSet -> {
            if (resultSet.next()) {
                return Optional.of(resultSet.getString(1));
            } else {
                return Optional.empty();
            }
        });
    }

    @Override
    public String generateRnnOrException() {
        return generateRnn()
                .orElseThrow(() -> new SelfException(E_DB_602, ": generate rrn"));
    }
}
