package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;

public interface RsbkTransactionalProtoRepository {

    TransferResponse setWay4TransactionDate(SetWay4TransactionDateRequest requestModel, String correlationId);

    TryReverseDocReply tryReverseDoc(TryReverseDocRequest requestModel, String correlationId);

    TransferResponse transferWay4ToRsbkCreditRsbk(TransferWay4ToRsbkRequest requestModel);

    TransferResponse transferRsbkToRsbk(TransferRsbkToRsbkRequest request, String correlationId);

    TransferResponse transferRsbkToWay4(TransferRsbkToWay4Request request, String correlationId);
}
