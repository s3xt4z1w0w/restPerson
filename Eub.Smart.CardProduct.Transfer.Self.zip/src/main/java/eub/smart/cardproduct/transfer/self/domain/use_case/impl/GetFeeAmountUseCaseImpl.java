package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.Fee;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetFeeAmountUseCase;

import java.math.BigDecimal;

public class GetFeeAmountUseCaseImpl implements GetFeeAmountUseCase {

    @Override
    public BigDecimal invoke(BigDecimal amount, Fee fee) {
        if (isFixedFee(fee)) {
            return fee.getFeeFixed();
        } else if (isPercentFee(fee)) {
            return getPercentAmount(amount, fee);
        } else {
            return new BigDecimal(0);
        }
    }

    private BigDecimal getPercentAmount(BigDecimal amount, Fee fee) {
        var feeByPercent = amount.multiply(fee.getFeePercent());
        if (isMinFee(fee, feeByPercent)) {
            return fee.getFeePercentMin();
        } else if (isMaxFee(fee, feeByPercent)) {
            return fee.getFeePercentMax();
        } else {
            return feeByPercent;
        }
    }

    private boolean isFixedFee(Fee fee) {
        var zero = new BigDecimal(0);
        return fee.getFeeFixed().compareTo(zero) > 0;
    }

    private boolean isPercentFee(Fee fee) {
        var zero = new BigDecimal(0);
        var feePercent = fee.getFeePercent();
        if (feePercent == null) return false;
        return feePercent.compareTo(zero) > 0;
    }

    private boolean isMinFee(Fee fee, BigDecimal feeByPercent) {
        return feeByPercent.compareTo(fee.getFeePercentMin()) < 0;
    }
    private boolean isMaxFee(Fee fee, BigDecimal feeByPercent) {
        return feeByPercent.compareTo(fee.getFeePercentMax()) > 0;
    }

}
