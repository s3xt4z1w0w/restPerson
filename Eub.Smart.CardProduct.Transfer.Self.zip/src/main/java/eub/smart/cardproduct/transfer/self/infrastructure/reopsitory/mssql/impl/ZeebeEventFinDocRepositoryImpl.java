package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.ZeebeEventFinDoc;
import eub.smart.cardproduct.transfer.self.domain.repository.ZeebeEventFinDocRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.entity.ZeebeEventFinDocEntity;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.ZeebeEventFinDocHiberRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_604;

@Primary
@Repository
public class ZeebeEventFinDocRepositoryImpl implements ZeebeEventFinDocRepository {

    private final ZeebeEventFinDocHiberRepository zeebeEventFinDocHiberRepository;

    public ZeebeEventFinDocRepositoryImpl(ZeebeEventFinDocHiberRepository zeebeEventFinDocHiberRepository) {
        this.zeebeEventFinDocHiberRepository = zeebeEventFinDocHiberRepository;
    }

    @Transactional(isolation = Isolation.SERIALIZABLE)
    @Override
    public void save(Long finDocId) {
        try {
            var entity = new ZeebeEventFinDocEntity(finDocId);
            zeebeEventFinDocHiberRepository.save(entity);
        } catch (DataIntegrityViolationException e) {
            throw new SelfException(E_DB_604, ": with finDoc id: " + finDocId);
        }
    }

    @Override
    public void saveErrorMessage(Long finDocId, SelfException exception) {
        var entity = zeebeEventFinDocHiberRepository.findByFinDocId(finDocId)
                .orElseGet(() -> new ZeebeEventFinDocEntity(finDocId));
        entity.setErrorMessage(exception.getMessage());
        zeebeEventFinDocHiberRepository.save(entity);
    }

    @Override
    public void saveResult(ZeebeEventFinDoc domainModel) {
        Long finDocId = domainModel.finDocId();
        var entity = zeebeEventFinDocHiberRepository.findByFinDocId(finDocId)
                .orElseGet(() -> new ZeebeEventFinDocEntity(finDocId));
        entity.setRrn(domainModel.rrn());
        entity.setBrrn(domainModel.brrn());
        entity.setCollectorId(domainModel.collectorId());
        zeebeEventFinDocHiberRepository.save(entity);
    }
}
