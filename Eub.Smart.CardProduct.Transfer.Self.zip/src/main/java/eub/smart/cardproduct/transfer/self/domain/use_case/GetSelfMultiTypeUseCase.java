package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;

public interface GetSelfMultiTypeUseCase {

    String invoke(AccountData senderData, AccountData receiverData);
}
