package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferWay4ToWay4DebitUseCase;
import eub.smart.cardproduct.transfer.self.domain.mapper.TransferWay4ToWay4DebitMapper;

public class TransferWay4ToWay4DebitUseCaseImpl implements TransferWay4ToWay4DebitUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferWay4ToWay4DebitUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferWay4ToWay4 invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn) {
        var debitInfo = TransferWay4ToWay4DebitMapper.createDomainModel(finDocData, senderData, receiverData, rrnBrrn);
        var request = formRequest(debitInfo);
        var response = transferSelfProtoRepository.transferWay4ToWay4Debit(request);
        return new TransferWay4ToWay4(request, response);
    }

    private UfxTransferRequest formRequest(TransferWay4ToWay4Debit creditInfo) {
        UfxTransferRequest request = new UfxTransferRequest();
        request.setFindoc(creditInfo.getFindoc());
        request.setRrn(creditInfo.getRrn());
        request.setBrrn(creditInfo.getBrrn());
        request.setStan(creditInfo.getStan());
        request.setOperationAccount(creditInfo.getOperationAccount());
        request.setOperationSum(creditInfo.getSenderAmount());
        request.setOperationCurrency(creditInfo.getSenderCurrency());
        request.setLinkedOperationAccount(creditInfo.getLinkedOperationAccount());
        request.setDeposit(creditInfo.getDeposit());
        request.setDetails(creditInfo.getDetails());

        if (creditInfo.getSenderFlagMultiCurrency() && !creditInfo.getReceiverFlagMultiCurrency()) {  //кусок кода из Bis
            request.setOperationSum(creditInfo.getSenderAmount());
            request.setOperationCurrency(creditInfo.getSenderCurrency());
        } else if (!creditInfo.getSenderFlagMultiCurrency() && creditInfo.getReceiverFlagMultiCurrency()) {
            request.setOperationSum(creditInfo.getReceiverAmount());
            request.setOperationCurrency(creditInfo.getReceiverCurrency());
        }

        return request;
    }
}
