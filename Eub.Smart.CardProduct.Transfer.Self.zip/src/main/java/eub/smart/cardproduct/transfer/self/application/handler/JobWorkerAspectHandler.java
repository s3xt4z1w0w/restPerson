package eub.smart.cardproduct.transfer.self.application.handler;

import eub.smart.cardproduct.transfer.self.application.model.TransferInternalBaseModel;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.ZeebeEventFinDocRepository;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.time.Duration;

@Aspect
@Component
public class JobWorkerAspectHandler {

    private final ZeebeEventFinDocRepository zeebeEventFinDocRepository;

    public JobWorkerAspectHandler(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        this.zeebeEventFinDocRepository = zeebeEventFinDocRepository;
    }

    @AfterThrowing(value = "@annotation(eub.smart.cardproduct.transfer.self.application.handler.JobWorkerException)", throwing = "exception")
    public void catchException(JoinPoint joinPoint, SelfException exception) {

        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        JobWorkerException handler = method.getAnnotation(JobWorkerException.class);
        int retries = handler.retries();
        String errorCode = handler.errorCode();

        Object[] args = joinPoint.getArgs();
        TransferInternalBaseModel baseModel = (TransferInternalBaseModel) args[0];
        Long finDocId = baseModel.getFinDocId();
        JobClient client = (JobClient) args[1];
        ActivatedJob job = (ActivatedJob) args[2];

        if (job.getRetries() <= 1 && exception != null) {
            zeebeEventFinDocRepository.saveErrorMessage(finDocId, exception);
            client.newThrowErrorCommand(job)
                    .errorCode(errorCode)
                    .send()
                    .join();
        } else {
            int backOff = (int) Math.pow(2, (retries - job.getRetries() + 1));
            client.newFailCommand(job)
                    .retries(job.getRetries() - 1)
                    .retryBackoff(Duration.ofSeconds(backOff))
                    .send()
                    .join();
        }
    }

}
