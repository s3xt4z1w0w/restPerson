package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferRsbkToWay4Credit;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferRsbkToWay4CreditUseCase;
import eub.smart.cardproduct.transfer.self.domain.mapper.TransferRsbkToWay4CreditMapper;

public class TransferRsbkToWay4CreditUseCaseImpl implements TransferRsbkToWay4CreditUseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferRsbkToWay4CreditUseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferRsbkToWay4Credit invoke(FinDocData finDocData, AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn) {
        var request = TransferRsbkToWay4CreditMapper.createRequest(finDocData, senderData, receiverData, rrnBrrn);
        var response = transferSelfProtoRepository.transferRsbkToWay4Credit(request);
        return new TransferRsbkToWay4Credit(request, response);
    }
}
