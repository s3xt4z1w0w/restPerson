package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.grpc;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDateRequest;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.PostingDateResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4PostRequest;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4PostResponse;
import eub.smart.cardproduct.transfer.self.domain.repository.Way4TransactionalProtoRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.handler.GrpcReturnValueHandler;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.PostingDateMapper;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.TransferWay4PostMapper;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Component;
import way4transactional.Way4TransactionalGrpc;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_EX_700;
import static eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc.PostingDateMapper.toDomainModel;

@Component
public class Way4TransactionalProtoRepositoryImpl implements Way4TransactionalProtoRepository {

    @GrpcClient("adapter-way4-transactional")
    private Way4TransactionalGrpc.Way4TransactionalBlockingStub stub;

    @Override
    @GrpcReturnValueHandler(methodName = "getPostingDate")
    public PostingDateResponse getPostingDate(PostingDateRequest requestModel, String correlationId) {
        try {
            var request = PostingDateMapper.toGrpcModel(requestModel);
            var response = stub.getPostingDate(request);
            return toDomainModel(response);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": getPostingDate " + e.getStatus().getCode().name());
        }
    }

    @Override
    @GrpcReturnValueHandler(methodName = "transferWay4Post")
    public TransferWay4PostResponse transferWay4Post(TransferWay4PostRequest requestModel, String correlationId) {
        try {
            var request = TransferWay4PostMapper.toGrpcModel(requestModel);
            var response = stub.transferWay4Post(request);
            return TransferWay4PostMapper.toDomainModel(response);
        } catch (StatusRuntimeException e) {
            throw new SelfException(E_EX_700, ": transferWay4Post " + e.getStatus().getCode().name());
        }
    }
}
