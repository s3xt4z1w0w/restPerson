package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.Transfer;

public interface TransferRepository {
    Transfer save(Transfer finDoc);
}
