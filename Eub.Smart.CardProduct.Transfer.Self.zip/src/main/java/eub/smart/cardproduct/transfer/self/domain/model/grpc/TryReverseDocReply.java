package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TryReverseDocReply {

    private Boolean isSuccess;
    private String errorDesc;

    public TryReverseDocReply() {
    }

    public TryReverseDocReply(Boolean isSuccess, String errorDesc) {
        this.isSuccess = isSuccess;
        this.errorDesc = errorDesc;
    }

    public void setSuccess(Boolean success) {
        isSuccess = success;
    }

    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc;
    }

    public Boolean getSuccess() {
        return isSuccess;
    }

    public String getErrorDesc() {
        return errorDesc;
    }

    @Override
    public String toString() {
        return "TryReverseDocReply{" +
                "isSuccess=" + isSuccess +
                ", errorDesc=" + errorDesc +
                '}';
    }
}
