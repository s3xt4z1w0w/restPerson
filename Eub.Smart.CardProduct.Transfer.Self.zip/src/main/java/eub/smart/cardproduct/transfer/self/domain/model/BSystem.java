package eub.smart.cardproduct.transfer.self.domain.model;


public class BSystem {

    private String senderSystem;

    private String receiverSystem;

    public BSystem() {
    }

    public BSystem(String senderSystem, String receiverSystem) {
        this.senderSystem = senderSystem;
        this.receiverSystem = receiverSystem;
    }

    public String getSenderSystem() {
        return senderSystem;
    }

    public void setSenderSystem(String senderSystem) {
        this.senderSystem = senderSystem;
    }

    public String getReceiverSystem() {
        return receiverSystem;
    }

    public void setReceiverSystem(String receiverSystem) {
        this.receiverSystem = receiverSystem;
    }

    @Override
    public String toString() {
        return "BSystem{" +
                "senderSystem=" + senderSystem +
                ", receiverSystem=" + receiverSystem +
                '}';
    }
}
