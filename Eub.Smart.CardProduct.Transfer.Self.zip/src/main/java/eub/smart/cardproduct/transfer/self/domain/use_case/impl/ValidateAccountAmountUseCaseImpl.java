package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.repository.DashboardProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateAccountAmountUseCase;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.ERROR_MESSAGE_VLSU;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800_VLSU;

public class ValidateAccountAmountUseCaseImpl implements ValidateAccountAmountUseCase {

    private final DashboardProtoRepository dashboardProtoRepository;
    private final MessageSourceRepository messageSourceRepository;

    public ValidateAccountAmountUseCaseImpl(DashboardProtoRepository dashboardProtoRepository,
                                            MessageSourceRepository messageSourceRepository) {
        this.dashboardProtoRepository = dashboardProtoRepository;
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public void invoke(AccountData accountData, String correlationId, LangKey lang) {
        var operationAmount = accountData.getAmount();
        var availableBalance = dashboardProtoRepository.availableBalance(accountData, correlationId);

        if (isAvailableBalanceLess(availableBalance, operationAmount)) {
            var locale = LangUtil.get(lang);
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_VLSU, locale);
            throw new SelfException(
                    E_LG_800_VLSU,
                    ": available balance less then operation amount",
                    message);
        }
    }

    private boolean isAvailableBalanceLess(BigDecimal availableBalance, BigDecimal operationAmount) {
        return availableBalance.compareTo(operationAmount) < 0;
    }
}


