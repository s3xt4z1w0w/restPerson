package eub.smart.cardproduct.transfer.self.infrastructure.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ZeebeEventFinDoc")
public class ZeebeEventFinDocEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ZeebeEventFinDoc_ID")
    private Long id;

    @Column(name = "FinDoc_IDREF", nullable = false, unique = true)
    private Long finDocId;

    @Column(name = "CreatedDate", nullable = false)
    private Date createdDate = new Date();

    @Column(name = "CollectorID")
    private String collectorId;

    @Column(name = "Rrn")
    private String rrn;

    @Column(name = "Brrn")
    private String brrn;

    @Column(name = "ErrorMessage", columnDefinition = "TEXT")
    private String errorMessage;

    public ZeebeEventFinDocEntity() {
    }

    public ZeebeEventFinDocEntity(Long finDocId) {
        this.finDocId = finDocId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFinDocId() {
        return finDocId;
    }

    public void setFinDocId(Long finDocId) {
        this.finDocId = finDocId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCollectorId() {
        return collectorId;
    }

    public void setCollectorId(String collectorId) {
        this.collectorId = collectorId;
    }

    public String getRrn() {
        return rrn;
    }

    public void setRrn(String rrn) {
        this.rrn = rrn;
    }

    public String getBrrn() {
        return brrn;
    }

    public void setBrrn(String brrn) {
        this.brrn = brrn;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "ZeebeEventFinDoc{" +
                "id=" + id +
                ", finDocId=" + finDocId +
                ", createdDate=" + createdDate +
                ", collectorId=" + collectorId +
                ", rrn=" + rrn +
                ", brrn=" + brrn +
                ", errorMessage=" + errorMessage +
                '}';
    }
}
