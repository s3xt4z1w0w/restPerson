package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import java.math.BigDecimal;

public class TransferWay4ToWay4Debit {

    private String findoc;
    private String rrn;
    private String brrn;
    private String stan;
    private BigDecimal senderAmount;
    private BigDecimal receiverAmount;
    private String operationAccount;
    private String senderCurrency;
    private String receiverCurrency;
    private String linkedOperationAccount;
    private Boolean isDeposit;
    private String details;
    private Boolean receiverFlagMultiCurrency;
    private Boolean senderFlagMultiCurrency;

    public String getFindoc() {
        return findoc;
    }

    public void setFindoc(String findoc) {
        this.findoc = findoc;
    }

    public String getRrn() {
        return rrn;
    }

    public void setRrn(String rrn) {
        this.rrn = rrn;
    }

    public String getBrrn() {
        return brrn;
    }

    public void setBrrn(String brrn) {
        this.brrn = brrn;
    }

    public String getStan() {
        return stan;
    }

    public void setStan(String stan) {
        this.stan = stan;
    }

    public BigDecimal getSenderAmount() {
        return senderAmount;
    }

    public void setSenderAmount(BigDecimal senderAmount) {
        this.senderAmount = senderAmount;
    }

    public BigDecimal getReceiverAmount() {
        return receiverAmount;
    }

    public void setReceiverAmount(BigDecimal receiverAmount) {
        this.receiverAmount = receiverAmount;
    }

    public String getOperationAccount() {
        return operationAccount;
    }

    public void setOperationAccount(String operationAccount) {
        this.operationAccount = operationAccount;
    }

    public String getSenderCurrency() {
        return senderCurrency;
    }

    public void setSenderCurrency(String senderCurrency) {
        this.senderCurrency = senderCurrency;
    }

    public String getReceiverCurrency() {
        return receiverCurrency;
    }

    public void setReceiverCurrency(String receiverCurrency) {
        this.receiverCurrency = receiverCurrency;
    }

    public String getLinkedOperationAccount() {
        return linkedOperationAccount;
    }

    public void setLinkedOperationAccount(String linkedOperationAccount) {
        this.linkedOperationAccount = linkedOperationAccount;
    }

    public Boolean getDeposit() {
        return isDeposit;
    }

    public void setDeposit(Boolean deposit) {
        isDeposit = deposit;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Boolean getReceiverFlagMultiCurrency() {
        return receiverFlagMultiCurrency;
    }

    public void setReceiverFlagMultiCurrency(Boolean receiverFlagMultiCurrency) {
        this.receiverFlagMultiCurrency = receiverFlagMultiCurrency;
    }

    public Boolean getSenderFlagMultiCurrency() {
        return senderFlagMultiCurrency;
    }

    public void setSenderFlagMultiCurrency(Boolean senderFlagMultiCurrency) {
        this.senderFlagMultiCurrency = senderFlagMultiCurrency;
    }
}
