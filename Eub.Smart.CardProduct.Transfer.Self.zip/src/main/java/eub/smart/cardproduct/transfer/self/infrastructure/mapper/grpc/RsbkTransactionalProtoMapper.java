package eub.smart.cardproduct.transfer.self.infrastructure.mapper.grpc;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferResponse;
import rsbktransactional.V1.EubAdapterRsbkTransactional;

public class RsbkTransactionalProtoMapper {

    public static TransferResponse toDomainModel(EubAdapterRsbkTransactional.TransferResponse response) {
        TransferResponse domainModel = new TransferResponse();
        domainModel.setErrorMessage(response.getErrorMessage());
        domainModel.setCollectorId(response.getCollectorId());
        return domainModel;
    }
}
