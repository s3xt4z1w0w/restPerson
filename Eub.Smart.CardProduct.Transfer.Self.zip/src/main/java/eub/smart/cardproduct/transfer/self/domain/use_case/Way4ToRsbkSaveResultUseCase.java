package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4ToRsbkCreditRsbk;

public interface Way4ToRsbkSaveResultUseCase {

    void invoke(Long finDocId, RrnBrrn rrnBrrn, TransferWay4ToRsbkCreditRsbk transferWay4ToRsbkCreditRsbk);
}
