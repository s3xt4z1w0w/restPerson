package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferTcRequest;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferTcResponse;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferTcWay4;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferTcWay4UseCase;

public class TransferTcWay4UseCaseImpl implements TransferTcWay4UseCase {

    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferTcWay4UseCaseImpl(TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferTcWay4 invoke(TransferResponse transferResponse, String correlationId) {
        var request = new TransferTcRequest(transferResponse);
        var response = transferSelfProtoRepository.transferTcWay4(request, correlationId);
        return new TransferTcWay4(request, response);
    }
}
