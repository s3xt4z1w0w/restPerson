package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.BSystem;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_603;

public class BSystemMapper {

    public static BSystem toTransferModel(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);

        BSystem model = new BSystem();
        model.setSenderSystem(scanner.getString("senderBSystem"));
        model.setReceiverSystem(scanner.getString("receiverBSystem"));
        return model;
    }

    public static Integer toActiveBSystemModel(ResultSet rs, int row) {
        try {
            return rs.getInt("activeSystemsCount");
        } catch (SQLException e) {
            throw new SelfException(E_DB_603, e);
        }
    }
}
