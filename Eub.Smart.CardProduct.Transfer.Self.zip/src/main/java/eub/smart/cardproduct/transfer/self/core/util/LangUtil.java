package eub.smart.cardproduct.transfer.self.core.util;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;

import java.util.Locale;

public class LangUtil {

    public final static Locale KK = new Locale("kk", "KZ");
    public final static Locale RU = new Locale("ru", "RU");
    public final static Locale EN = new Locale("en", "EN");

    public static Locale get(LangKey langKey) {
        return switch (langKey) {
            case RU -> RU;
            case KK -> KK;
            case EN -> EN;
        };
    }
}
