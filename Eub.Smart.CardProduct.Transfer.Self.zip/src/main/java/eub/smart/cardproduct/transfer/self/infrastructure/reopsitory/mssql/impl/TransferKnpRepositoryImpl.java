package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferKnpRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.CommonMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class TransferKnpRepositoryImpl implements TransferKnpRepository {

    private final NamedParameterJdbcTemplate template;

    public TransferKnpRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<String> findKNPCode(String accountType, String receiverAccountType, String convertType, Boolean isSelf) {
        Map<String, Object> map = new HashMap<>();
        map.put("accountType", accountType);
        map.put("receiverAccountType", receiverAccountType);
        map.put("convertType", convertType);
        map.put("isSelf", isSelf);

        String sql = """ 
                select TK.KNP   as type
                from TransferKNP TK
                where TK.SrcAcctType = :accountType
                    and TK.DestAcctType = :receiverAccountType
                    and TK.IsSelf = :isSelf
                    and TK.[Convert] = :convertType
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, map);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(CommonMapper::getString);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": TransferKnpRepository findKNPCode");
        }
    }

    @Override
    public String findKNPCodeOrException(String senderAccountType, String receiverAccountType, String convertType, Boolean isSelf) {
        return findKNPCode(senderAccountType, receiverAccountType, convertType, isSelf)
                .orElseThrow(() -> new SelfException(E_DB_600, ": TransferKnpRepository findKNPCodeOrException"));
    }
}
