package eub.smart.cardproduct.transfer.self.domain.use_case;

import java.util.Date;

public interface SetSignDateUseCase {

    Date invoke(Long finDocId);
}
