package eub.smart.cardproduct.transfer.self.domain.repository;


import eub.smart.cardproduct.transfer.self.domain.model.MultiToMultiAccountInfo;

import java.util.Optional;

public interface GetMultiToMultiTypeRepository {

    Optional<MultiToMultiAccountInfo> findByFinDocId(Long finDocId);

    MultiToMultiAccountInfo findByFinDocIdOrException(Long finDocId);
}
