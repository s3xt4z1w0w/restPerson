package eub.smart.cardproduct.transfer.self.domain.model;

public record ZeebeEventFinDoc(Long finDocId, String rrn, String brrn, String collectorId) {
    public ZeebeEventFinDoc(Long finDocId, String rrn, String brrn) {
        this(finDocId, rrn, brrn, null);
    }

    public ZeebeEventFinDoc(Long finDocId) {
        this(finDocId, null, null, null);
    }

    public ZeebeEventFinDoc(Long finDocId, String collectorId) {
        this(finDocId, null, null, collectorId);
    }
}
