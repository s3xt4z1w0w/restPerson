package eub.smart.cardproduct.transfer.self.presentation.model.response;

import eub.smart.cardproduct.transfer.self.domain.model.ConvertingInfo;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;
import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;
import java.util.List;

public class ConversionResponse {

    @Schema(description = "Скорректированная сумма отправителя")
    private BigDecimal senderAmount;

    @Schema(description = "Валюта скорректированной суммы")
    private String currency;

    @Schema(description = "Предупреждающее сообщение")
    private String warningMessage;

    @Schema(description = "Сумма получателя")
    private BigDecimal receiverAmount;

    @Schema(description = "Курсы валют")
    private List<CurrencyRate> currencyRates;

    public ConversionResponse() {
    }

    public ConversionResponse(ConvertingInfo convertingInfo, String currency, String warningMessage) {
        this.senderAmount = convertingInfo.getCorrectAmount();
        this.currency = currency;
        this.warningMessage = warningMessage;
        this.receiverAmount = convertingInfo.getReceiverAmount();
        this.currencyRates = convertingInfo.getCurrencyRates();
    }

    public BigDecimal getSenderAmount() {
        return senderAmount;
    }

    public void setSenderAmount(BigDecimal senderAmount) {
        this.senderAmount = senderAmount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getWarningMessage() {
        return warningMessage;
    }

    public void setWarningMessage(String warningMessage) {
        this.warningMessage = warningMessage;
    }

    public BigDecimal getReceiverAmount() {
        return receiverAmount;
    }

    public void setReceiverAmount(BigDecimal receiverAmount) {
        this.receiverAmount = receiverAmount;
    }

    public List<CurrencyRate> getCurrencyRates() {
        return currencyRates;
    }

    public void setCurrencyRates(List<CurrencyRate> currencyRates) {
        this.currencyRates = currencyRates;
    }

    @Override
    public String toString() {
        return "CorrectAmount{" +
                "senderAmount=" + senderAmount +
                ", currency=" + currency +
                ", warningMessage=" + warningMessage +
                ", receiverAmount=" + receiverAmount +
                ", currencyRates=" + currencyRates +
                '}';
    }
}
