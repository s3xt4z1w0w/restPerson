package eub.smart.cardproduct.transfer.self.core.util;

import eub.smart.cardproduct.transfer.self.domain.model.FullName;

import java.util.List;

public class NameUtil {

    public static FullName getPersonFullName(String fullname) {
        FullName presonFullFullName = new FullName();
        List<String> nameList = StringUtil.split(fullname, " ");
        for (String name : nameList) {
            if (presonFullFullName.getLastname() == null) {
                presonFullFullName.setLastname(name);
                continue;
            }
            if (presonFullFullName.getFirstname() == null) {
                presonFullFullName.setFirstname(name);
                continue;
            }
            if (presonFullFullName.getMiddlename() == null) {
                presonFullFullName.setMiddlename(name);
                continue;
            }
            break;
        }
        return presonFullFullName;
    }
}
