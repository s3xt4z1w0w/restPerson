package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.repository.ZeebeEventFinDocRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.SaveZeebeEventFinDocUseCase;

public class SaveZeebeEventFinDocUseCaseImpl implements SaveZeebeEventFinDocUseCase {

    private final ZeebeEventFinDocRepository zeebeEventFinDocRepository;

    public SaveZeebeEventFinDocUseCaseImpl(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        this.zeebeEventFinDocRepository = zeebeEventFinDocRepository;
    }

    @Override
    public void invoke(Long finDocId) {
        zeebeEventFinDocRepository.save(finDocId);
    }
}
