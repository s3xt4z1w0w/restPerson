package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.*;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferSelfProtoRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.TransferWay4ToWay4CreditRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.TransferWay4ToWay4CreditUseCase;

import static eub.smart.cardproduct.transfer.self.core.util.StanUtil.generateStun;

public class TransferWay4ToWay4CreditUseCaseImpl implements TransferWay4ToWay4CreditUseCase {

    private final TransferWay4ToWay4CreditRepository transferWay4ToWay4CreditRepository;
    private final TransferSelfProtoRepository transferSelfProtoRepository;

    public TransferWay4ToWay4CreditUseCaseImpl(TransferWay4ToWay4CreditRepository transferWay4ToWay4CreditRepository,
                                               TransferSelfProtoRepository transferSelfProtoRepository) {
        this.transferWay4ToWay4CreditRepository = transferWay4ToWay4CreditRepository;
        this.transferSelfProtoRepository = transferSelfProtoRepository;
    }

    @Override
    public TransferWay4ToWay4 invoke(Long finDocId, RrnBrrn rrnBrrn, String correlationId) {
        var stun = generateStun();
        var creditInfo = transferWay4ToWay4CreditRepository.findByFinDocIdOrException(finDocId, rrnBrrn, stun);
        var request = formRequest(creditInfo);
        var response = transferSelfProtoRepository.transferWay4ToWay4Credit(request);
        return new TransferWay4ToWay4(request, response);
    }

    private UfxTransferRequest formRequest(TransferWay4ToWay4Credit creditInfo) {
        UfxTransferRequest request = new UfxTransferRequest();
        request.setFindoc(creditInfo.getFindoc());
        request.setRrn(creditInfo.getRrn());
        request.setBrrn(creditInfo.getBrrn());
        request.setStan(creditInfo.getStan());
        request.setOperationAccount(creditInfo.getOperationAccount());
        request.setOperationSum(creditInfo.getSenderAmount());
        request.setOperationCurrency(creditInfo.getSenderCurrency());
        request.setLinkedOperationAccount(creditInfo.getLinkedOperationAccount());
        request.setDeposit(creditInfo.getDeposit());
        request.setDetails(creditInfo.getDetails());

        if (creditInfo.getSenderFlagMultiCurrency() && !creditInfo.getReceiverFlagMultiCurrency()) {  //кусок кода из Bis
            request.setOperationSum(creditInfo.getSenderAmount());
            request.setOperationCurrency(creditInfo.getSenderCurrency());
        } else if (!creditInfo.getSenderFlagMultiCurrency() && creditInfo.getReceiverFlagMultiCurrency()) {
            request.setOperationSum(creditInfo.getReceiverAmount());
            request.setOperationCurrency(creditInfo.getReceiverCurrency());
        }

        return request;
    }
}
