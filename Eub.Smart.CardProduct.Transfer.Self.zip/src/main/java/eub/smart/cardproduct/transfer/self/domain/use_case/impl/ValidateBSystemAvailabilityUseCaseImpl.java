package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.core.util.LangUtil;
import eub.smart.cardproduct.transfer.self.domain.repository.BSystemRepository;
import eub.smart.cardproduct.transfer.self.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.self.domain.use_case.ValidateBSystemAvailabilityUseCase;

import java.util.Locale;

import static eub.smart.cardproduct.transfer.self.core.constant.BundleCode.ERROR_MESSAGE_VLBS;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_LG_800_VLBS;

public class ValidateBSystemAvailabilityUseCaseImpl implements ValidateBSystemAvailabilityUseCase {

    private final BSystemRepository bSystemRepository;
    private final MessageSourceRepository messageSourceRepository;

    public ValidateBSystemAvailabilityUseCaseImpl(BSystemRepository bSystemRepository,
                                                  MessageSourceRepository messageSourceRepository) {
        this.bSystemRepository = bSystemRepository;
        this.messageSourceRepository = messageSourceRepository;
    }

    public void invoke(String bSystem, LangKey lang) {
        var inactiveBSystemCount = bSystemRepository.findInactiveBSystemCountOrException(bSystem);
        if (inactiveBSystemCount != 0) {
            var locale = LangUtil.get(lang);
            var message = messageSourceRepository.getMessage(ERROR_MESSAGE_VLBS, locale);
            throw new SelfException(
                    E_LG_800_VLBS,
                    ": inactive BSystem " + bSystem,
                    message);
        }
    }
}
