package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferIbanToIban;

public interface TransferIbanToIbanUseCase {

    TransferIbanToIban invoke(AccountData senderData, AccountData receiverData, RrnBrrn rrnBrrn);
}
