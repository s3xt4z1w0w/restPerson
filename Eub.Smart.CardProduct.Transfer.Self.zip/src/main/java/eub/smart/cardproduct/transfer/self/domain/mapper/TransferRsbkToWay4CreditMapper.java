package eub.smart.cardproduct.transfer.self.domain.mapper;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.FinDocData;
import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.UfxTransferRequest;

import static eub.smart.cardproduct.transfer.self.core.constant.AccountType.isDeposit;
import static eub.smart.cardproduct.transfer.self.core.util.StanUtil.generateStun;

public class TransferRsbkToWay4CreditMapper {

    private static String createDetails(String fullname, String accountNumber) {
        return String.format("From RS; %s; %s", fullname, accountNumber);
    }

    public static UfxTransferRequest createRequest(FinDocData finDocData,
                                                   AccountData senderData,
                                                   AccountData receiverData,
                                                   RrnBrrn rrnBrrn) {
        UfxTransferRequest request = new UfxTransferRequest();
        request.setFindoc(String.valueOf(finDocData.getId()));
        request.setRrn(rrnBrrn.getBrrn());
        request.setBrrn(rrnBrrn.getRrn());
        request.setStan(generateStun());
        request.setOperationAccount(receiverData.getAccountNumber());
        request.setOperationSum(receiverData.getAmount());
        request.setOperationCurrency(receiverData.getCurrency());
        request.setLinkedOperationAccount(senderData.getAccountNumber());
        request.setDeposit(isDeposit(senderData.getAccountType()));
        request.setDetails(createDetails(senderData.getFullName(), senderData.getAccountNumber()));
        return request;
    }
}
