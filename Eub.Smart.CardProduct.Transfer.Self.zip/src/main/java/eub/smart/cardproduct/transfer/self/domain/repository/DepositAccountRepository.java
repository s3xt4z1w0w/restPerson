package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.domain.model.DepositAccount;

import java.util.Optional;

public interface DepositAccountRepository {

    Optional<DepositAccount> findByAccountId(Long accountId);

    DepositAccount findByAccountIdOrException(Long accountId);
}
