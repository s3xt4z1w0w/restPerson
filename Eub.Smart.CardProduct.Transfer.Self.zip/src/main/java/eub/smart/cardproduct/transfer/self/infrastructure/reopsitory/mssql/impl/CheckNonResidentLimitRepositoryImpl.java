package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.Usage;
import eub.smart.cardproduct.transfer.self.domain.repository.CheckNonResidentLimitRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.CheckNonResidentLimitMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class CheckNonResidentLimitRepositoryImpl implements CheckNonResidentLimitRepository {

    private final NamedParameterJdbcTemplate template;

    public CheckNonResidentLimitRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<Usage> findByFinDocId(Long finDocId) {
        String sql = """ 
                select top 1 usg.Usage_ID    as usage_id,
                             usg.Limit_Day   as limit_day,
                             usg.Limit_Night as limit_night
                from Usage usg
                         join FinDoc fd on fd.FinDoc_ID = :finDocId
                         join [user] us on us.User_ID = fd.User_IDREF
                         join Person pr on pr.Person_ID = us.Person_IDREF
                WHERE pr.IsResident = 0
                  and usg.IsResidentOnly = 1;
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("finDocId", finDocId));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(CheckNonResidentLimitMapper::toDomainModel);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": CheckNonResidentLimitRepository findByFinDocId");
        }
    }
}
