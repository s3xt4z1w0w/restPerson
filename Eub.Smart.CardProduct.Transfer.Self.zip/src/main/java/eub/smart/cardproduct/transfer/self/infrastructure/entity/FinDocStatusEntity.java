package eub.smart.cardproduct.transfer.self.infrastructure.entity;

import javax.persistence.*;

@Entity
@Table(name = "FinDocStatus")
public class FinDocStatusEntity {

    @Id
    @Column(name = "FinDocStatus_ID")
    private String code;

    @Column(name = "FinDocStatus_Title")
    private String title;

    @Column(name = "Term_OUTREF")
    private Long termId;
    
    @Column(name = "IsFinal")
    private boolean flagFinal;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getTermId() {
        return termId;
    }

    public void setTermId(Long termId) {
        this.termId = termId;
    }

    public boolean getFlagFinal() {
        return flagFinal;
    }

    public void setFlagFinal(boolean flagFinal) {
        this.flagFinal = flagFinal;
    }
}
