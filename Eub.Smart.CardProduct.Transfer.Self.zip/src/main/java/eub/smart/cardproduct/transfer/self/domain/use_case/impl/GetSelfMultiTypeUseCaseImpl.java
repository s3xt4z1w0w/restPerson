package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.AccountData;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetSelfMultiTypeUseCase;

import static eub.smart.cardproduct.transfer.self.core.constant.SelfMultiType.*;
import static java.util.Objects.nonNull;

public class GetSelfMultiTypeUseCaseImpl implements GetSelfMultiTypeUseCase {

    public GetSelfMultiTypeUseCaseImpl() {
    }

    @Override
    public String invoke(AccountData sender, AccountData receiver) {
        var senderFlagMulti = sender.getFlagMulti();
        var receiverFlagMulti = receiver.getFlagMulti();

        if (senderFlagMulti && receiverFlagMulti) {
            return getMultiToMultiType(sender, receiver);
        } else {
            return NON_SELF;
        }
    }

    private String getMultiToMultiType(AccountData sender, AccountData receiver) {
        var senderAccountIdRef = sender.getAccountIdRef();
        var receiverAccountIdRef = receiver.getAccountIdRef();
        var senderAccountNumber = sender.getAccountNumber();
        var receiverAccountNumber = receiver.getAccountNumber();

        if (nonNull(senderAccountIdRef) && senderAccountIdRef.equals(receiverAccountIdRef)) {
            return NEW_MULTI;
        } else if (senderAccountNumber.equals(receiverAccountNumber)) {
            return OLD_MULTI;
        } else {
            return NON_SELF;
        }
    }

}
