package eub.smart.cardproduct.transfer.self.domain.use_case;

public interface GetAccountDepositTypeUseCase {

    String invoke(Long accountId);
}
