package eub.smart.cardproduct.transfer.self.domain.model;

import javax.validation.constraints.NotNull;

public class NewTransferClient {

    @NotNull
    private String name;
    @NotNull
    private Boolean flagResident;
    @NotNull
    private Boolean flagCorporate;
    private String iin;
    private String bin;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getFlagResident() {
        return flagResident;
    }

    public void setFlagResident(Boolean flagResident) {
        this.flagResident = flagResident;
    }

    public Boolean getFlagCorporate() {
        return flagCorporate;
    }

    public void setFlagCorporate(Boolean flagCorporate) {
        this.flagCorporate = flagCorporate;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    @Override
    public String toString() {
        return "NewTransferClient{" +
                "name=" + name +
                ", flagResident=" + flagResident +
                ", flagCorporate=" + flagCorporate +
                ", iin=" + iin +
                ", bin=" + bin +
                '}';
    }
}
