package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferRsbkToWay4ReverseTransit {

    private UfxTransferRequest request;
    private UfxResponse response;

    public TransferRsbkToWay4ReverseTransit() {
    }

    public TransferRsbkToWay4ReverseTransit(UfxTransferRequest request, UfxResponse response) {
        this.request = request;
        this.response = response;
    }

    public void setRequest(UfxTransferRequest request) {
        this.request = request;
    }

    public void setResponse(UfxResponse response) {
        this.response = response;
    }

    public UfxTransferRequest getRequest() {
        return request;
    }

    public UfxResponse getResponse() {
        return response;
    }
}
