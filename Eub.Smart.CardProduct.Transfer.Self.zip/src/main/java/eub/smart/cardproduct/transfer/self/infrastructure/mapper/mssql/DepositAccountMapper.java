package eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.self.domain.model.DepositAccount;
import eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.scanner.MapResultScanner;

import java.util.Map;

public class DepositAccountMapper {

    public static DepositAccount toDomainModel(Map<String, Object> row) {
        MapResultScanner scanner = new MapResultScanner(row);

        String termPeriodType = scanner.getString("termPeriodType");
        Integer termPeriodCount = scanner.getInteger("termPeriodCount");
        return new DepositAccount(termPeriodType, termPeriodCount);
    }

}
