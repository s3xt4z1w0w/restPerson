package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferWay4ToRsbkCreditRsbk {

    private TransferWay4ToRsbkRequest request;
    private TransferResponse response;

    public TransferWay4ToRsbkCreditRsbk() {
    }

    public TransferWay4ToRsbkCreditRsbk(TransferWay4ToRsbkRequest request, TransferResponse response) {
        this.request = request;
        this.response = response;
    }

    public void setRequest(TransferWay4ToRsbkRequest request) {
        this.request = request;
    }

    public void setResponse(TransferResponse response) {
        this.response = response;
    }

    public TransferWay4ToRsbkRequest getRequest() {
        return request;
    }

    public TransferResponse getResponse() {
        return response;
    }
}
