package eub.smart.cardproduct.transfer.self.presentation.controller;

import eub.smart.cardproduct.transfer.self.presentation.model.response.ConversionResponse;
import eub.smart.cardproduct.transfer.self.presentation.response_advise.ResponseBinding;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetConvertingInfoUseCase;
import eub.smart.cardproduct.transfer.self.presentation.swagger.response.GetConversionResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.self.core.constant.HeaderName.CORRELATION_ID;

@ResponseBinding
@RestController
@RequestMapping("/api/conversion")
@Tag(name = "ConversionController", description = "API для конвертации")
public class ConversionController {

    private final GetConvertingInfoUseCase getConversionInfoUseCase;

    public ConversionController(GetConvertingInfoUseCase getConversionInfoUseCase) {
        this.getConversionInfoUseCase = getConversionInfoUseCase;
    }

    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(description = "Информация о конвертаций", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = GetConversionResponse.class))})})
    @GetMapping
    public ResponseEntity<?> getConversion(@RequestHeader(CORRELATION_ID) String correlationId,
                                           @Parameter(description = "сумма")
                                           @RequestParam("amount") BigDecimal amount,
                                           @Parameter(description = "валюта отправитель")
                                           @RequestParam("senderAccountCurrency") String senderAccountCurrency,
                                           @Parameter(description = "валюта получателя")
                                           @RequestParam("receiverAccountCurrency") String receiverAccountCurrency) {
        var conversionInfo = getConversionInfoUseCase.invoke(amount, senderAccountCurrency, receiverAccountCurrency, correlationId);
        var conversionResponse = new ConversionResponse(
                conversionInfo,
                senderAccountCurrency,
                String.format("Внимание! При конвертации, в целях избежания округления дробной части в остатке, сумма была скорректирована на %s %s", conversionInfo.getCorrectAmount(), senderAccountCurrency));
        return ResponseEntity.ok(conversionResponse);
    }
}
