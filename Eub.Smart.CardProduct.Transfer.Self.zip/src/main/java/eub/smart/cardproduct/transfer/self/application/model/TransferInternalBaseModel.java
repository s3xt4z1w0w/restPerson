package eub.smart.cardproduct.transfer.self.application.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import eub.smart.cardproduct.transfer.self.domain.model.Usage;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TransferInternalBaseModel {

    private Long finDocId;
    private String correlationId;
    private FinDocData finDoc;
    private AccountData sender;
    private AccountData receiver;
    private LimitFlag limitFlag;
    private SenderDetails senderDetails;
    private ValidationFlag validationFlag;
    private TransferStatus finDocStatus;
    private Usage accountUsage;
    private Usage clientUsage;

    public TransferInternalBaseModel() {
    }

    public TransferInternalBaseModel(FinDocData finDoc,
                                     AccountData sender,
                                     AccountData receiver,
                                     LimitFlag limitFlag,
                                     SenderDetails senderDetails) {
        this.finDoc = finDoc;
        this.sender = sender;
        this.receiver = receiver;
        this.limitFlag = limitFlag;
        this.senderDetails = senderDetails;
    }

    public FinDocData getFinDoc() {
        return finDoc;
    }

    public Long getFinDocId() {
        return finDocId;
    }

    public void setFinDocId(Long finDocId) {
        this.finDocId = finDocId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public void setFinDoc(FinDocData finDoc) {
        this.finDoc = finDoc;
    }

    public AccountData getSender() {
        return sender;
    }

    public void setSender(AccountData sender) {
        this.sender = sender;
    }

    public AccountData getReceiver() {
        return receiver;
    }

    public void setReceiver(AccountData receiver) {
        this.receiver = receiver;
    }

    public ValidationFlag getValidationFlag() {
        if (validationFlag == null) return new ValidationFlag();
        return validationFlag;
    }

    public void setValidationFlag(ValidationFlag validationFlag) {
        this.validationFlag = validationFlag;
    }

    public LimitFlag getLimitFlag() {
        if (limitFlag == null) return new LimitFlag();
        return limitFlag;
    }

    public void setLimitFlag(LimitFlag limitFlag) {
        this.limitFlag = limitFlag;
    }

    public TransferStatus getFinDocStatus() {
        return finDocStatus;
    }

    public void setFinDocStatus(TransferStatus finDocStatus) {
        this.finDocStatus = finDocStatus;
    }

    public Usage getAccountUsage() {
        return accountUsage;
    }

    public void setAccountUsage(Usage accountUsage) {
        this.accountUsage = accountUsage;
    }

    public Usage getClientUsage() {
        return clientUsage;
    }

    public void setClientUsage(Usage clientUsage) {
        this.clientUsage = clientUsage;
    }

    public SenderDetails getSenderDetails() {
        return senderDetails;
    }

    public void setSenderDetails(SenderDetails senderDetails) {
        this.senderDetails = senderDetails;
    }

    @Override
    public String toString() {
        return "TransferInternalBaseModel{" +
                "finDoc=" + finDoc +
                ", sender=" + sender +
                ", receiver=" + receiver +
                ", limitFlag=" + limitFlag +
                ", validationFlag=" + validationFlag +
                ", finDocStatus=" + finDocStatus +
                ", accountUsage=" + accountUsage +
                ", clientUsage=" + clientUsage +
                ", senderDetails=" + senderDetails +
                '}';
    }
}
