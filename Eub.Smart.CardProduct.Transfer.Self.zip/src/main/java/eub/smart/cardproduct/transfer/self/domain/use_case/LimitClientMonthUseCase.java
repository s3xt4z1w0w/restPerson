package eub.smart.cardproduct.transfer.self.domain.use_case;

import java.math.BigDecimal;

public interface LimitClientMonthUseCase {

    void invoke(BigDecimal limitMonth, Long clientId, Long userId, BigDecimal amount, String currency, String correlationId);
}
