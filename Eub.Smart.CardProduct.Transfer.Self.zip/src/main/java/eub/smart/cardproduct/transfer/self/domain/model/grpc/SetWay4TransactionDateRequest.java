package eub.smart.cardproduct.transfer.self.domain.model.grpc;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class SetWay4TransactionDateRequest {

    private String collectorId;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date way4PostingDate;

    public SetWay4TransactionDateRequest() {
    }

    public SetWay4TransactionDateRequest(String collectorId, Date way4PostingDate) {
        this.collectorId = collectorId;
        this.way4PostingDate = way4PostingDate;
    }

    public String getCollectorId() {
        return collectorId;
    }

    public void setCollectorId(String collectorId) {
        this.collectorId = collectorId;
    }

    public Date getWay4PostingDate() {
        return way4PostingDate;
    }

    public void setWay4PostingDate(Date way4PostingDate) {
        this.way4PostingDate = way4PostingDate;
    }

    @Override
    public String toString() {
        return "SetWay4TransactionDateRequest{" +
                "collectorId=" + collectorId +
                ", way4PostingDate=" + way4PostingDate +
                '}';
    }
}
