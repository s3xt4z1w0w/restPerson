package eub.smart.cardproduct.transfer.self.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.self.core.exception.SelfException;
import eub.smart.cardproduct.transfer.self.domain.model.NewTransferClient;
import eub.smart.cardproduct.transfer.self.domain.repository.PersonRepository;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.mssql.PersonMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.self.core.exception.SelfErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.self.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class PersonRepositoryImpl implements PersonRepository {

    private final NamedParameterJdbcTemplate template;

    public PersonRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<NewTransferClient> findNewTransferClient(Long id) {
        String sql = """ 
                select concat(P.LastName, ' ', P.FirstName, ' ',  P.FathersName)    as fullName,
                       P.IsResident                                                 as flagResident,
                       P.IIN                                                        as iin
                from Person P
                where P.Person_ID = :id
                """;

        List<Map<String, Object>> queryResult = template.queryForList(sql, Map.of("id", id));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .map(PersonMapper::toDomainModel);
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new SelfException(E_DB_601, ": PersonRepository findNewTransferClient");
        }
    }

    @Override
    public NewTransferClient findNewTransferClientOrException(Long id) {
        return findNewTransferClient(id)
                .orElseThrow(() -> new SelfException(E_DB_600, ": PersonRepository findNewTransferClientOrException"));
    }
}
