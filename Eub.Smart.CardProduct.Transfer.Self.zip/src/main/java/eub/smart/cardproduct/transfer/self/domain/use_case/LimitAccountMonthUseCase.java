package eub.smart.cardproduct.transfer.self.domain.use_case;

import java.math.BigDecimal;

public interface LimitAccountMonthUseCase {

    void invoke(BigDecimal limitMonth, String accountNumber, String correlationId, BigDecimal amount, String currency);
}
