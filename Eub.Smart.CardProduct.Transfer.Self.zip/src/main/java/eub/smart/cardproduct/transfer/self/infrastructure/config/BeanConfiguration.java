package eub.smart.cardproduct.transfer.self.infrastructure.config;

import eub.smart.cardproduct.transfer.self.SelfApplication;
import eub.smart.cardproduct.transfer.self.core.component.AuthToken;
import eub.smart.cardproduct.transfer.self.domain.repository.*;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import eub.smart.cardproduct.transfer.self.domain.use_case.impl.*;
import eub.smart.cardproduct.transfer.self.infrastructure.mapper.DomainMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.Set;

@Configuration
@ComponentScan(basePackageClasses = SelfApplication.class)
public class BeanConfiguration {

    @Bean
    CreateFinDocUseCase createFinDocUseCase(GetSelfFeeUseCase getSelfFeeUseCase,
                                            FinDocRepository finDocRepository,
                                            AuthToken authToken) {
        return new CreateFinDocUseCaseImpl(getSelfFeeUseCase, finDocRepository, authToken);
    }

    @Bean
    CreateTransferUseCase createTransferUseCase(GetTransferClientUseCase getTransferClientUseCase,
                                                TransferTypeRepository transferTypeRepository,
                                                TransferRepository transferRepository,
                                                @Value("${app.eubankBIC}") String receiverBIC,
                                                @Value("${app.seco}") String seco) {
        return new CreateTransferUseCaseImpl(getTransferClientUseCase, transferTypeRepository, transferRepository, receiverBIC, seco);
    }

    @Bean
    GetAccountDepositTypeUseCase getAccountDepositTypeUseCase(DepositAccountRepository depositAccountRepository) {
        return new GetAccountDepositTypeUseCaseImpl(depositAccountRepository);
    }

    @Bean
    GetCreateTransferUseCase getCreateTransferUseCase(CreateFinDocUseCase createFinDocUseCase,
                                                      CreateTransferUseCase createTransferUseCase,
                                                      TransferKnpRepository transferKnpRepository,
                                                      FinDocStatusRepository finDocStatusRepository,
                                                      GetAccountDepositTypeUseCase getAccountDepositTypeUseCase,
                                                      GetAccountInfoBuyNumberUseCase getAccountInfoUseCase,
                                                      ValidateReceiverAmountUseCase validateReceiverAmountUseCase,
                                                      DomainMapper modelMapper) {
        return new GetCreateTransferUseCaseImpl(createFinDocUseCase,
                createTransferUseCase,
                transferKnpRepository,
                finDocStatusRepository,
                getAccountDepositTypeUseCase,
                getAccountInfoUseCase,
                validateReceiverAmountUseCase,
                modelMapper);
    }

    @Bean
    GetFeeAmountUseCase getFeeAmountUseCase() {
        return new GetFeeAmountUseCaseImpl();
    }

    @Bean
    GetSelfFeeUseCase getSelfFeeUseCase(FeeRepository feeRepository,
                                        GetFeeAmountUseCase getFeeAmountUseCase,
                                        TransferTypeRepository transferTypeRepository,
                                        MapProductOperationRepository mapProductOperationRepository,
                                        ViewMapAccountBSystemClientRepository viewMapAccountBSystemClientRepository) {
        return new GetSelfFeeUseCaseImpl(feeRepository,
                getFeeAmountUseCase,
                transferTypeRepository,
                mapProductOperationRepository,
                viewMapAccountBSystemClientRepository);
    }

    @Bean
    GetTransferClientUseCase getTransferClientUseCase(PersonRepository personRepository,
                                                      CorporationRepository corporationRepository,
                                                      ClientRepository clientRepository) {
        return new GetTransferClientUseCaseImpl(personRepository, corporationRepository, clientRepository);
    }

    @Bean
    TransferRSBKtoRSBKUseCase transferRSBKtoRSBKUseCase(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository) {
        return new TransferRSBKtoRSBKUseCaseImpl(rsbkTransactionalProtoRepository);
    }

    @Bean
    TransferTcRsbkUseCase transferTcRsbkUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferTcRsbkUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    TransferRsbkToWay4UseCase transferRsbkToWay4UseCase(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository) {
        return new TransferRsbkToWay4UseCaseImpl(rsbkTransactionalProtoRepository);
    }

    @Bean
    TransferTcWay4UseCase transferTcWay4UseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferTcWay4UseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    TransferRsbkToWay4DebitTransitUseCase transferRsbkToWay4DebitTransitUseCase(TransferSelfProtoRepository transferSelfProtoRepository,
                                                                                @Value("${app.operation-account}") String operationAccount) {
        return new TransferRsbkToWay4DebitTransitUseCaseImpl(transferSelfProtoRepository, operationAccount);
    }

    @Bean
    TransferRsbkToWay4CreditUseCase transferRsbkToWay4CreditUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferRsbkToWay4CreditUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    GenerateRrnBrrnUseCase generateRrnBrrnUseCase(RnnRepository rnnRepository) {
        return new GenerateRrnBrrnUseCaseImpl(rnnRepository);
    }

    @Bean
    GetPostingDateUseCase getPostingDateUseCase(Way4TransactionalProtoRepository way4TransactionalProtoRepository) {
        return new GetPostingDateUseCaseImpl(way4TransactionalProtoRepository);
    }

    @Bean
    SetWay4TransactionDateUseCase setWay4TransactionDateUseCase(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository) {
        return new SetWay4TransactionDateUseCaseImpl(rsbkTransactionalProtoRepository);
    }

    @Bean
    ReverseRsbkDocumentUseCase reverseRsbkDocumentUseCase(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository) {
        return new ReverseRsbkDocumentUseCaseImpl(rsbkTransactionalProtoRepository);
    }

    @Bean
    TransferRsbkToWay4ReverseTransitUseCase transferRsbkToWay4ReverseTransitUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferRsbkToWay4ReverseTransitUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    TransferWay4ToRsbkCreditTransitUseCase transferWay4ToRsbkCreditTransitUseCase(TransferSelfProtoRepository transferSelfProtoRepository,
                                                                                  @Value("${app.operation-account}") String operationAccount) {
        return new TransferWay4ToRsbkCreditTransitUseCaseImpl(transferSelfProtoRepository, operationAccount);
    }

    @Bean
    public TransferWay4ToRsbkDebitUseCase transferWay4ToRsbkDebitUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferWay4ToRsbkDebitUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    TransferWay4ToRsbkReverseDebitUseCase transferWay4ToRsbkReverseDebitUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferWay4ToRsbkReverseDebitUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    TransferWay4ToRsbkReverseTransitUseCaseImpl transferWay4ToRsbkReverseTransitUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferWay4ToRsbkReverseTransitUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    TransferInternalWay4ToRsbkCreditRsbkUseCase transferInternalWay4ToRsbkCreditRsbkUseCase(RsbkTransactionalProtoRepository rsbkTransactionalProtoRepository,
                                                                                            @Value("${app.dbo-id-prefix}") String dboIdPrefix) {
        return new TransferInternalWay4ToRsbkCreditRsbkUseCaseImpl(rsbkTransactionalProtoRepository, dboIdPrefix);
    }

    @Bean
    TransferWay4ToWay4DebitUseCase transferWay4ToWay4DebitUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferWay4ToWay4DebitUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    TransferWay4ToWay4CreditUseCase transferWay4ToWay4CreditUseCase(TransferWay4ToWay4CreditRepository transferWay4ToWay4CreditRepository,
                                                                    TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferWay4ToWay4CreditUseCaseImpl(transferWay4ToWay4CreditRepository, transferSelfProtoRepository);
    }

    @Bean
    TransferWay4ToWay4ReverseDebitUseCase transferWay4ToWay4ReverseDebitUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferWay4ToWay4ReverseDebitUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    ValidateBSystemCombinationUseCase findTransferBSystemUseCase() {
        return new ValidateBSystemCombinationUseCaseImpl();
    }

    @Bean
    ValidateReceiverAccountUseCase validateReceiverAccountUseCase(MessageSourceRepository messageSourceRepository) {
        return new ValidateReceiverAccountUseCaseImpl(messageSourceRepository);
    }

    @Bean
    ValidateSenderAccountUseCase validateSenderAccountUseCase(MessageSourceRepository messageSourceRepository) {
        return new ValidateSenderAccountUseCaseImpl(messageSourceRepository);
    }

    @Bean
    GetConvertingInfoUseCase countConversionUseCase(RsbkInfoProtoRepository rsbkInfoProtoRepository) {
        return new GetConvertingInfoUseCaseImpl(rsbkInfoProtoRepository);
    }

    @Bean
    public CreateBaseModeUseCase createBaseModeUseCase(FinDocRepository finDocRepository,
                                                       AuthToken authToken) {
        return new CreateBaseModeUseCaseImpl(finDocRepository, authToken);
    }

    @Bean
    public GetAccountInfoBuyNumberUseCase getAccountInfoUseCase(AccountRepository accountRepository) {
        return new GetAccountInfoBuyNumberUseCaseImpl(accountRepository);
    }

    @Bean
    public GetAccountInfoBuyPhoneUseCase getAccountInfoBuyPhoneUseCase(AccountRepository accountRepository) {
        return new GetAccountInfoBuyPhoneUseCaseImpl(accountRepository);
    }

    @Bean
    public TransferWay4ConvertUseCase transferWay4ConvertUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferWay4ConvertUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    public TransferIbanToIbanUseCase transferIbanToIbanUseCase(TransferSelfProtoRepository transferSelfProtoRepository) {
        return new TransferIbanToIbanUseCaseImpl(transferSelfProtoRepository);
    }

    @Bean
    public GetSelfMultiTypeUseCase getSelfMultiTypeUseCase() {
        return new GetSelfMultiTypeUseCaseImpl();
    }

    @Bean
    public TransferWay4PostUseCase transferWay4PostUseCase(Way4TransactionalProtoRepository way4TransactionalProtoRepository) {
        return new TransferWay4PostUseCaseImpl(way4TransactionalProtoRepository);
    }

    @Bean
    public FormSmsMessageUseCase formSmsMessageUseCase(MessageSourceRepository messageSourceRepository) {
        return new FormSmsMessageUseCaseImpl(messageSourceRepository);
    }

    @Bean
    public GetAccountUsageUseCase getAccountUsageUseCase(UsageRepository usageRepository) {
        return new GetAccountUsageUseCaseImpl(usageRepository);
    }

    @Bean
    public GetClientUsageUseCase getClintUsageUseCase(UsageRepository usageRepository) {
        return new GetClientUsageUseCaseImpl(usageRepository);
    }

    @Bean
    public LimitClientMonthUseCase limitClientMonthUseCase(LimitClientMonthRepository limitClientMonthRepository,
                                                           LimitFinDocUseCase finDocUseCase,
                                                           LimitUseCase limitUseCase) {
        return new LimitClientMonthUseCaseImpl(limitClientMonthRepository, finDocUseCase, limitUseCase);
    }

    @Bean
    public LimitClientNightUseCase limitClientNightUseCase(LimitClientNightRepository limitClientNightRepository,
                                                           LimitFinDocUseCase finDocUseCase,
                                                           LimitUseCase limitUseCase) {
        return new LimitClientNightUseCaseImpl(limitClientNightRepository, finDocUseCase, limitUseCase);
    }

    @Bean
    public LimitClientDayUseCase limitClientDayUseCase(LimitClientDayRepository limitClientDayRepository,
                                                       LimitFinDocUseCase finDocUseCase,
                                                       LimitUseCase limitUseCase) {
        return new LimitClientDayUseCaseImpl(limitClientDayRepository, finDocUseCase, limitUseCase);
    }

    @Bean
    public LimitFinDocUseCase limitFinDocUseCase(GetConvertingInfoUseCase getConvertingInfoUseCase) {
        return new LimitFinDocUseCaseImpl(getConvertingInfoUseCase);
    }

    @Bean
    public LimitAccountDayUseCase limitAccountDayUseCase(LimitAccountDayRepository limitAccountNightRepository,
                                                         LimitFinDocUseCase finDocUseCase,
                                                         LimitUseCase limitUseCase) {
        return new LimitAccountDayUseCaseImpl(limitAccountNightRepository, finDocUseCase, limitUseCase);
    }

    @Bean
    public LimitAccountNightUseCase limitAccountNightUseCase(LimitAccountNightRepository limitAccountNightRepository,
                                                             LimitFinDocUseCase finDocUseCase,
                                                             LimitUseCase limitUseCase) {
        return new LimitAccountNightUseCaseImpl(limitAccountNightRepository, finDocUseCase, limitUseCase);
    }

    @Bean
    public LimitAccountMonthUseCase limitAccountMonthUseCase(LimitAccountMonthRepository limitAccountMonthRepository,
                                                             LimitFinDocUseCase finDocUseCase,
                                                             LimitUseCase limitUseCase) {
        return new LimitAccountMonthUseCaseImpl(limitAccountMonthRepository, finDocUseCase, limitUseCase);
    }

    @Bean
    public LimitUseCase limitUseCase(GetConvertingInfoUseCase getConvertingInfoUseCase) {
        return new LimitUseCaseImpl(getConvertingInfoUseCase);
    }

    @Bean
    public ValidateMultiConvertUseCase validateMultiConvertUseCase(MessageSourceRepository messageSourceRepository) {
        return new ValidateMultiConvertUseCaseImpl(messageSourceRepository);
    }

    @Bean
    public SetSignDateUseCase setSignDateUseCase(FinDocRepository finDocRepository) {
        return new SetSignDateUseCaseImpl(finDocRepository);
    }

    @Bean
    public GetSelfClientUsageUseCase getSelfClientUsageUseCase(GetConvertingInfoUseCase getConvertingInfoUseCase) {
        return new GetSelfClientUsageUseCaseImpl(getConvertingInfoUseCase);
    }

    @Bean
    public ValidateReceiverAmountUseCase validateReceiverAmountUseCase(GetConvertingInfoUseCase getConvertingInfoUseCase) {
        return new ValidateReceiverAmountUseCaseImpl(getConvertingInfoUseCase);
    }

    @Bean
    public SaveZeebeEventFinDocUseCase saveZeebeEventFinDocUseCase(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        return new SaveZeebeEventFinDocUseCaseImpl(zeebeEventFinDocRepository);
    }

    @Bean
    public RsbkToRsbkSaveResultUseCase rsbkToRsbkSaveResultUseCase(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        return new RsbkToRsbkSaveResultUseCaseImpl(zeebeEventFinDocRepository);
    }

    @Bean
    public RsbkToWay4SaveResultUseCase rsbkToWay4SaveResultUseCase(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        return new RsbkToWay4SaveResultUseCaseImpl(zeebeEventFinDocRepository);
    }

    @Bean
    public Way4ToRsbkSaveResultUseCase way4ToRsbkSaveResultUseCase(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        return new Way4ToRsbkSaveResultUseCaseImpl(zeebeEventFinDocRepository);
    }

    @Bean
    public Way4ToWay4SaveResultUseCase way4ToWay4SaveResultUseCase(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        return new Way4ToWay4SaveResultUseCaseImpl(zeebeEventFinDocRepository);
    }

    @Bean
    ZeebeEventFinDocSaveResult zeebeEventFinDocSaveResult(ZeebeEventFinDocRepository zeebeEventFinDocRepository) {
        return new ZeebeEventFinDocSaveResult(zeebeEventFinDocRepository);
    }

    @Bean
    public ValidateBSystemAvailabilityUseCase validateBSystemAvailabilityUseCase(BSystemRepository bSystemRepository,
                                                                                 MessageSourceRepository messageSourceRepository) {
        return new ValidateBSystemAvailabilityUseCaseImpl(bSystemRepository, messageSourceRepository);
    }

    @Bean
    public ValidateAccountAmountUseCase validateAccountAmountUseCase(DashboardProtoRepository dashboardProtoRepository,
                                                                     MessageSourceRepository messageSourceRepository) {
        return new ValidateAccountAmountUseCaseImpl(dashboardProtoRepository, messageSourceRepository);
    }

    @Bean(name = "initialValidationUseCaseImpl")
    public InitialValidationUseCase initialValidationUseCase(ValidateAccountAmountUseCase validateAccountAmountUseCase,
                                                             ValidateSenderAccountUseCase validateSenderAccountUseCase,
                                                             ValidateReceiverAccountUseCase validateReceiverAccountUseCase,
                                                             ValidateBSystemAvailabilityUseCase validateBSystemAvailabilityUseCase,
                                                             FinDocStateRepository finDocStateRepository) {
        return new InitialValidationUseCaseImpl(
                validateAccountAmountUseCase,
                validateSenderAccountUseCase,
                validateReceiverAccountUseCase,
                validateBSystemAvailabilityUseCase,
                finDocStateRepository);
    }

    @Bean(name = "way4ToWay4InitialValidationUseCaseImpl")
    public InitialValidationUseCase way4ToWay4InitialValidationUseCase(ValidateAccountAmountUseCase validateAccountAmountUseCase,
                                                                       ValidateSenderAccountUseCase validateSenderAccountUseCase,
                                                                       ValidateReceiverAccountUseCase validateReceiverAccountUseCase,
                                                                       ValidateBSystemAvailabilityUseCase validateBSystemAvailabilityUseCase,
                                                                       FinDocStateRepository finDocStateRepository,
                                                                       ValidateMultiConvertUseCase validateMultiConvertUseCase) {
        return new Way4ToWay4InitialValidationUseCaseImpl(
                validateAccountAmountUseCase,
                validateSenderAccountUseCase,
                validateReceiverAccountUseCase,
                validateBSystemAvailabilityUseCase,
                finDocStateRepository,
                validateMultiConvertUseCase);
    }

    @Bean
    public TransferHistoryUseCase transferHistoryUseCase(TransferHistoryRepository transferHistoryRepository) {
        return new TransferHistoryUseCaseImpl(transferHistoryRepository);
    }

    @Bean
    public TransferReceiptUseCase transferReceiptUseCase(Set<ReceiptRepository> repositories) {
        return new TransferReceiptUseCaseImpl(repositories);
    }
}