package eub.smart.cardproduct.transfer.self.presentation.filter.logger;

import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import static eub.smart.cardproduct.transfer.self.core.constant.MdcConstants.X_FORWARDED_FOR;
import static eub.smart.cardproduct.transfer.self.core.util.StringUtil.isNotEmpty;

@Component
public class AccessLogger {

    private final HttpServletRequest request;

    public AccessLogger(HttpServletRequest request) {
        this.request = request;
    }

    public String getClientIp() {
        String xForwardedFor = request.getHeader(X_FORWARDED_FOR);
        if (isNotEmpty(xForwardedFor)) {
            return xForwardedFor.split(",")[0].trim();
        } else {
            return request.getRemoteAddr();
        }
    }
}