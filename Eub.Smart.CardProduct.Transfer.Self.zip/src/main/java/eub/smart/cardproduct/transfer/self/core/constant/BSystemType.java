package eub.smart.cardproduct.transfer.self.core.constant;

public interface BSystemType {

    String AERC = "AERC";
    String BPMS = "BPMS";
    String CDLG = "CDLG";
    String EQMS = "EQMS";
    String MDMM = "MDMM";
    String NOMD = "NOMD";
    String RSBK = "RSBK";
    String RSLN = "RSLN";
    String SMBK = "SMBK";
    String SOLR = "SOLR";
    String WAY4 = "WAY4";
}
