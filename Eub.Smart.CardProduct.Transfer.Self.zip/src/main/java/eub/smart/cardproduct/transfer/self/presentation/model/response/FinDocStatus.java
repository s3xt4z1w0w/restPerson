package eub.smart.cardproduct.transfer.self.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public class FinDocStatus {

    @Schema(description = "Статус Платежного поручения")
    private String code;
    @Schema(description = "Называть")
    private String title;
    @Schema(description = "Id на справочник переводов")
    private Long termId;
    @Schema(description = "Признак завершенности")
    private boolean flagFinal;

    public FinDocStatus(String code, String title, Long termId, boolean flagFinal) {
        this.code = code;
        this.title = title;
        this.termId = termId;
        this.flagFinal = flagFinal;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getTermId() {
        return termId;
    }

    public void setTermId(Long termId) {
        this.termId = termId;
    }

    public boolean getFlagFinal() {
        return flagFinal;
    }

    public void setFlagFinal(boolean aFlagFinal) {
        flagFinal = aFlagFinal;
    }
}
