package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;
import eub.smart.cardproduct.transfer.self.domain.model.Transfer;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.CurrencyRate;

import java.math.BigDecimal;
import java.util.List;

public interface CreateTransferUseCase {

    Transfer invoke(FinDoc finDoc, CreateTransferAccountInfo senderAccount, CreateTransferAccountInfo receiverAccount, String knpCode, BigDecimal receiverAmount, List<CurrencyRate> currencyRates);
}
