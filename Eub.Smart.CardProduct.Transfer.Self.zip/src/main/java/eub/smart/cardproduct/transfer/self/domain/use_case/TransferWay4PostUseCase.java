package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.base_model.RrnBrrn;
import eub.smart.cardproduct.transfer.self.domain.model.grpc.TransferWay4Post;

public interface TransferWay4PostUseCase {

    TransferWay4Post invoke(RrnBrrn rrnBrrn, String correlationId);
}
