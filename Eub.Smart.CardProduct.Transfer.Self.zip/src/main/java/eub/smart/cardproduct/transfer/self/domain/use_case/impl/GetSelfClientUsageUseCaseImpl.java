package eub.smart.cardproduct.transfer.self.domain.use_case.impl;

import eub.smart.cardproduct.transfer.self.domain.model.Usage;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetConvertingInfoUseCase;
import eub.smart.cardproduct.transfer.self.domain.use_case.GetSelfClientUsageUseCase;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static eub.smart.cardproduct.transfer.self.core.constant.CurrencyCode.KZT;
import static eub.smart.cardproduct.transfer.self.core.constant.CurrencyCode.USD;

public class GetSelfClientUsageUseCaseImpl implements GetSelfClientUsageUseCase {

    private final GetConvertingInfoUseCase getConvertingInfoUseCase;

    public GetSelfClientUsageUseCaseImpl(GetConvertingInfoUseCase getConvertingInfoUseCase) {
        this.getConvertingInfoUseCase = getConvertingInfoUseCase;
    }

    @Override
    public Usage invoke(String limitFinDoc, String correlationId) {
        return invoke(limitFinDoc, "0", "0", correlationId);
    }

    @Override
    public Usage invoke(String limitFinDoc, String limitDay, String limitNight, String correlationId) {
        var limitFinDocUsd = new BigDecimal(limitFinDoc);
        var limitDayUsd = new BigDecimal(limitDay);

        var finDocConvertingInfo = getConvertingInfoUseCase.invoke(limitFinDocUsd, USD, KZT, correlationId);
        var limitDayConvertingInfo = getConvertingInfoUseCase.invoke(limitDayUsd, USD, KZT, correlationId);

        var limitFinDocKzt = finDocConvertingInfo.getReceiverAmount().setScale(0, RoundingMode.DOWN);
        var limitDayKzt = limitDayConvertingInfo.getReceiverAmount().setScale(0, RoundingMode.DOWN);
        var limitNightKzt = new BigDecimal(limitNight).setScale(0, RoundingMode.DOWN);
        return new Usage(limitFinDocKzt, limitDayKzt, limitNightKzt);
    }
}
