package eub.smart.cardproduct.transfer.self.domain.repository;

import eub.smart.cardproduct.transfer.self.core.enums.LangKey;
import eub.smart.cardproduct.transfer.self.domain.model.out.TransferReceiptOut;

import java.util.Optional;

public interface ReceiptRepository {

    Optional<TransferReceiptOut> findByFinDocId(Long finDocId, LangKey lang);

    TransferReceiptOut findByFinDocIdOrException(Long finDocId, LangKey lang);

    String key();
}
