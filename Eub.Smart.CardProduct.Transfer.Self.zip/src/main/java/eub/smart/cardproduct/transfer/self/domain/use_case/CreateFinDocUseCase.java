package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.FinDoc;
import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;

import java.math.BigDecimal;

public interface CreateFinDocUseCase {

    FinDoc invoke(BigDecimal amount, CreateTransferAccountInfo senderAccount, CreateTransferAccountInfo receiverAccount);
}
