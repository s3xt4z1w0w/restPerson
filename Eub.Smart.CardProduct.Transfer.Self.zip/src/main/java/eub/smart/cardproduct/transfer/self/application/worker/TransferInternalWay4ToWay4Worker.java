package eub.smart.cardproduct.transfer.self.application.worker;

import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerException;
import eub.smart.cardproduct.transfer.self.application.handler.JobWorkerFailFast;
import eub.smart.cardproduct.transfer.self.application.mapper.ApplicationMapper;
import eub.smart.cardproduct.transfer.self.application.model.TransferInternalWay4ToWay4BaseModel;
import eub.smart.cardproduct.transfer.self.domain.use_case.*;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.springframework.stereotype.Component;

import static eub.smart.cardproduct.transfer.self.core.util.ZeebeConfigUtil.WORKER_ENABLE;

@Component
public class TransferInternalWay4ToWay4Worker {

    private final TransferWay4ToWay4DebitUseCase transferWay4ToWay4DebitUseCase;
    private final TransferWay4ToWay4CreditUseCase transferWay4ToWay4CreditUseCase;
    private final TransferWay4ToWay4ReverseDebitUseCase transferWay4ToWay4ReverseDebitUseCase;
    private final GenerateRrnBrrnUseCase generateRrnBrrnUseCase;
    private final TransferWay4ConvertUseCase transferWay4ConvertUseCase;
    private final TransferIbanToIbanUseCase transferIbanToIbanUseCase;
    private final TransferWay4PostUseCase transferWay4PostUseCase;
    private final GetSelfMultiTypeUseCase getSelfMultiTypeUseCase;
    private final ApplicationMapper applicationMapper;
    private final Way4ToWay4SaveResultUseCase way4ToWay4SaveResultUseCase;

    public TransferInternalWay4ToWay4Worker(TransferWay4ToWay4DebitUseCase transferWay4ToWay4DebitUseCase,
                                            TransferWay4ToWay4CreditUseCase transferWay4ToWay4CreditUseCase,
                                            TransferWay4ToWay4ReverseDebitUseCase transferWay4ToWay4ReverseDebitUseCase,
                                            GenerateRrnBrrnUseCase generateRrnBrrnUseCase,
                                            TransferWay4ConvertUseCase transferWay4ConvertUseCase,
                                            TransferIbanToIbanUseCase transferIbanToIbanUseCase,
                                            TransferWay4PostUseCase transferWay4PostUseCase,
                                            GetSelfMultiTypeUseCase getSelfMultiTypeUseCase,
                                            ApplicationMapper applicationMapper,
                                            Way4ToWay4SaveResultUseCase way4ToWay4SaveResultUseCase) {
        this.transferWay4ToWay4DebitUseCase = transferWay4ToWay4DebitUseCase;
        this.transferWay4ToWay4CreditUseCase = transferWay4ToWay4CreditUseCase;
        this.transferWay4ToWay4ReverseDebitUseCase = transferWay4ToWay4ReverseDebitUseCase;
        this.generateRrnBrrnUseCase = generateRrnBrrnUseCase;
        this.transferWay4ConvertUseCase = transferWay4ConvertUseCase;
        this.transferIbanToIbanUseCase = transferIbanToIbanUseCase;
        this.transferWay4PostUseCase = transferWay4PostUseCase;
        this.getSelfMultiTypeUseCase = getSelfMultiTypeUseCase;
        this.applicationMapper = applicationMapper;
        this.way4ToWay4SaveResultUseCase = way4ToWay4SaveResultUseCase;
    }

    @JobWorkerException(errorCode = "Reject")
    @JobWorkerFailFast("${app.fail.way4-to-way4.transfer-way4-to-way4-debit}")
    @JobWorker(type = "transfer_self_way4_to_way4_debit", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel transferWay4ToWay4Debit(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel,
                                                                       JobClient client,
                                                                       ActivatedJob job) {
        var finDocData = applicationMapper.toDomain(baseModel.getFinDoc());
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());

        var response = transferWay4ToWay4DebitUseCase.invoke(finDocData, senderData, receiverData, rrnBrrn);
        baseModel.setTransferWay4ToWay4Debit(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_way4_reverse_debit", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel transferWay4ToWay4ReverseDebit(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel) {
        var ufxTransferRequest = baseModel.getTransferWay4ToWay4Debit().getUfxTransferRequest();
        var response = transferWay4ToWay4ReverseDebitUseCase.invoke(ufxTransferRequest);
        baseModel.setTransferWay4ToWay4ReverseDebit(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "ReverseDebit")
    @JobWorkerFailFast("${app.fail.way4-to-way4.transfer-way4-to-way4-credit}")
    @JobWorker(type = "transfer_self_way4_to_way4_credit", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel transferWay4ToWay4CreditTransit(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel,
                                                                               JobClient jobClient,
                                                                               ActivatedJob job) {
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());
        var response = transferWay4ToWay4CreditUseCase.invoke(
                baseModel.getFinDoc().getId(),
                rrnBrrn,
                baseModel.getFinDoc().getCorrelationId());
        baseModel.setTransferWay4ToWay4Credit(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_way4_generate_rrn", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel generateRrn(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel) {
        var response = generateRrnBrrnUseCase.invoke();
        var rrnBrrn = applicationMapper.toApplication(response);
        baseModel.setRrnBrrn(rrnBrrn);
        return baseModel;
    }

    @JobWorkerException(errorCode = "Reject")
    @JobWorkerFailFast("${app.fail.way4-to-way4.transfer-way4-convert}")
    @JobWorker(type = "transfer_self_way4_to_way4_old_multi", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel transferWay4Convert(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel,
                                                                   JobClient client,
                                                                   ActivatedJob job) {
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());

        var response = transferWay4ConvertUseCase.invoke(senderData, receiverData, rrnBrrn);
        baseModel.setTransferWay4Convert(response);
        return baseModel;
    }

    @JobWorkerException(errorCode = "Reject")
    @JobWorkerFailFast("${app.fail.way4-to-way4.transfer-iban-to-iban}")
    @JobWorker(type = "transfer_self_way4_to_way4_new_multi", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel transferIbanToIban(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel,
                                                                  JobClient client,
                                                                  ActivatedJob job) {
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());

        var response = transferIbanToIbanUseCase.invoke(senderData, receiverData, rrnBrrn);
        baseModel.setTransferIbanToIban(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_way4_post", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel transferWay4Post(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel) {
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());
        var response = transferWay4PostUseCase.invoke(
                rrnBrrn,
                baseModel.getFinDoc().getCorrelationId());
        baseModel.setTransferWay4Post(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_way4_get_self_multi_type", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel getCurrencyType(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel) {
        var senderData = applicationMapper.toDomain(baseModel.getSender());
        var receiverData = applicationMapper.toDomain(baseModel.getReceiver());

        var response = getSelfMultiTypeUseCase.invoke(senderData, receiverData);
        baseModel.setSelfMultiType(response);
        return baseModel;
    }

    @JobWorker(type = "transfer_self_way4_to_way4_save_zeebe_findoc", enabled = WORKER_ENABLE)
    public TransferInternalWay4ToWay4BaseModel saveZeebeFindoc(@VariablesAsType TransferInternalWay4ToWay4BaseModel baseModel) {
        var finDocId = baseModel.getFinDocId();
        var rrnBrrn = applicationMapper.toDomain(baseModel.getRrnBrrn());
        way4ToWay4SaveResultUseCase.invoke(finDocId, rrnBrrn);
        return baseModel;
    }
}
