package eub.smart.cardproduct.transfer.self.domain.use_case;

import eub.smart.cardproduct.transfer.self.domain.model.CreateTransferAccountInfo;

public interface GetAccountInfoBuyNumberUseCase {

    CreateTransferAccountInfo invoke(String phoneNumber, String currency);
}
