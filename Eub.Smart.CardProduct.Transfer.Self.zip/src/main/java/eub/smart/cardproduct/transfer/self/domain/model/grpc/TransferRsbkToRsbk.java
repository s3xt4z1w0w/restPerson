package eub.smart.cardproduct.transfer.self.domain.model.grpc;

public class TransferRsbkToRsbk {

    private TransferRsbkToRsbkRequest transferRsbkToRsbkRequest;
    private TransferResponse transferRSBKtoRSBKResponse;

    public TransferRsbkToRsbk() {
    }

    public TransferRsbkToRsbk(TransferRsbkToRsbkRequest transferRsbkToRsbkRequest,
                              TransferResponse transferRSBKtoRSBKResponse) {
        this.transferRsbkToRsbkRequest = transferRsbkToRsbkRequest;
        this.transferRSBKtoRSBKResponse = transferRSBKtoRSBKResponse;
    }

    public TransferRsbkToRsbkRequest getTransferRsbkToRsbkRequest() {
        return transferRsbkToRsbkRequest;
    }

    public TransferResponse getTransferRSBKtoRSBKResponse() {
        return transferRSBKtoRSBKResponse;
    }

    public void setTransferRsbkToRsbkRequest(TransferRsbkToRsbkRequest transferRsbkToRsbkRequest) {
        this.transferRsbkToRsbkRequest = transferRsbkToRsbkRequest;
    }

    public void setTransferRSBKtoRSBKResponse(TransferResponse transferRSBKtoRSBKResponse) {
        this.transferRSBKtoRSBKResponse = transferRSBKtoRSBKResponse;
    }
}
