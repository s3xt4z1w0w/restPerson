package eub.smart.cardproduct.transfer.generic.presentation.model;

import eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import io.swagger.v3.oas.annotations.media.Schema;

public class ErrorResponse {

    @Schema(description = "тех код ошибки", implementation = AppErrorCode.class)
    private AppErrorCode techErrorCode;

    @Schema(description = "тех сообщение ошибки")
    private String techErrorMessage;

    @Schema(description = "сообщение ошибки")
    private String errorMessage;

    @Schema(description = "детали ошибки")
    private String errorDetails;

    @Schema(description = "Ошибки полей")
    private FieldsValidationResponse fieldsValidationResponse;

    public AppErrorCode getTechErrorCode() {
        return techErrorCode;
    }

    public void setTechErrorCode(AppErrorCode techErrorCode) {
        this.techErrorCode = techErrorCode;
    }

    public String getTechErrorMessage() {
        return techErrorMessage;
    }

    public void setTechErrorMessage(String techErrorMessage) {
        this.techErrorMessage = techErrorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    public FieldsValidationResponse getFieldsValidationResponse() {
        return fieldsValidationResponse;
    }

    public void setFieldsValidationResponse(FieldsValidationResponse fieldsValidationResponse) {
        this.fieldsValidationResponse = fieldsValidationResponse;
    }

    public void errorResponse(AppException e) {
        this.setTechErrorCode(e.getCode());
        this.setTechErrorMessage(e.getMessage());
        this.setErrorMessage(e.getErrorMessage());
        this.setErrorDetails(null);
        this.setFieldsValidationResponse(e.getFieldsValidationResponse());
    }

    @Override
    public String toString() {
        return "ErrorResponse{" +
                ", techErrorCode=" + techErrorCode +
                ", techErrorMessage=" + techErrorMessage +
                ", errorMessage=" + errorMessage +
                ", errorDetails=" + errorDetails +
                "}";
    }
}
