package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateIpsoTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.IpsoReceiverDataOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.*;
import eub.smart.cardproduct.transfer.generic.domain.use_case.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static eub.smart.cardproduct.transfer.generic.core.constant.BankBic.HALYK;
import static eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType.IPSO;

@Service
public class CreateIpsoTransferUseCaseImpl implements CreateIpsoTransferUseCase {

    private final IpsTransferRepository ipsTransferRepository;
    private final GetAituPayVerificationUseCase getAituPayVerificationUseCase;
    private final GetVisaAliasReceiverUseCase getVisaAliasReceiverUseCase;
    private final CreateVisaTransferUseCase createVisaTransferUseCase;
    private final CreateAituTransferUseCase createAituTransferUseCase;
    private final AccountRepository accountRepository;
    private final AuthToken authToken;
    private final String KNP = "191";
    private final String eubankBIC;
    private final ValidateLimitUseCase validateLimitUseCase;

    public CreateIpsoTransferUseCaseImpl(IpsTransferRepository ipsTransferRepository,
                                         GetAituPayVerificationUseCase getAituPayVerificationUseCase,
                                         GetVisaAliasReceiverUseCase getVisaAliasReceiverUseCase,
                                         CreateVisaTransferUseCase createVisaTransferUseCase,
                                         CreateAituTransferUseCase createAituTransferUseCase,
                                         AccountRepository accountRepository,
                                         AuthToken authToken,
                                         @Value("${app.eubankBIC}") String eubankBIC,
                                         ValidateLimitUseCase validateLimitUseCase) {
        this.ipsTransferRepository = ipsTransferRepository;
        this.getAituPayVerificationUseCase = getAituPayVerificationUseCase;
        this.getVisaAliasReceiverUseCase = getVisaAliasReceiverUseCase;
        this.createVisaTransferUseCase = createVisaTransferUseCase;
        this.createAituTransferUseCase = createAituTransferUseCase;
        this.accountRepository = accountRepository;
        this.authToken = authToken;
        this.eubankBIC = eubankBIC;
        this.validateLimitUseCase = validateLimitUseCase;
    }

    @Transactional
    @Override
    public RetransferOut invoke(CreateRetransferDataIn in) {
        var receiverBic = ipsTransferRepository.findReceiverBankByFinDocId(in.finDocId());
        var receiverInfo = getReceiver(in.finDocId(), receiverBic);
        var finDoc = getFinDoc(in, receiverBic);
        var senderDetails = getUserDetails();
        var senderAccount = accountRepository.findByCardId(in.senderCardId());
        var ipsTransferOut = new CreateIpsoTransferOut(finDoc, in, receiverInfo, senderDetails, KNP, eubankBIC, senderAccount);
        ipsTransferRepository.save(ipsTransferOut);
        if(receiverBic.equals(HALYK)) {
            validateLimitUseCase.invoke(finDoc.getId(), IPSO.name(), in.senderCardId(), in.debitAmount());
        }
        return new RetransferOut(finDoc.getId(), finDoc.getFeeAmount());
    }

    private IpsoReceiverDataOut getReceiver(Long finDocId, String receiverBic) {
        if (receiverBic.equals(HALYK)) {
            return getVisaAliasReceiverUseCase.invoke(finDocId);
        } else {
            return getAituPayVerificationUseCase.invoke(finDocId);
        }
    }

    private FinDocOut getFinDoc(CreateRetransferDataIn in, String receiverBic) {
        if (receiverBic.equals(HALYK)) {
            return createVisaTransferUseCase.invoke(in);
        } else {
            return createAituTransferUseCase.invoke(in);
        }
    }

    private UserDetails getUserDetails() {
        var payload = authToken.getDecodedPayload();
        return UserDetails.build(payload);
    }
}
