package eub.smart.cardproduct.transfer.generic.presentation.model.response;

public record DetailResponse(
        String key,
        String value
) {
}
