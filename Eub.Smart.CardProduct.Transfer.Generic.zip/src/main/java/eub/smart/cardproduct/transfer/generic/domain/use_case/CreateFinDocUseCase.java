package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateFinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateTransferDataOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FeeOut;

import java.math.BigDecimal;

public interface CreateFinDocUseCase {

    FinDocOut invoke(CreateTransferDataOut out, CreateTransferClientDataIn senderAccount);

    FinDocOut invoke(BigDecimal amount, String currency, FeeOut fee);

    FinDocOut invoke(CreateFinDocOut out);

}
