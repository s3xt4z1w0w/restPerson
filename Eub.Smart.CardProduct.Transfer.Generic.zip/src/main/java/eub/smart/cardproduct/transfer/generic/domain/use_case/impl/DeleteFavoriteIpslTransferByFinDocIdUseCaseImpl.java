package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteIpsTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.DeleteFavoriteTransferByFinDocIdUseCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.IPSL;

@Service
public class DeleteFavoriteIpslTransferByFinDocIdUseCaseImpl implements DeleteFavoriteTransferByFinDocIdUseCase {

    private final Logger log = LogManager.getLogger(getClass());
    private final FavoriteIpsTransferRepository favoriteIpsTransferRepository;
    private final FavoriteAcctTransferRepository favoriteAcctTransferRepository;

    public DeleteFavoriteIpslTransferByFinDocIdUseCaseImpl(FavoriteIpsTransferRepository favoriteIpsTransferRepository,
                                                           FavoriteAcctTransferRepository favoriteAcctTransferRepository) {
        this.favoriteIpsTransferRepository = favoriteIpsTransferRepository;
        this.favoriteAcctTransferRepository = favoriteAcctTransferRepository;
    }

    @Override
    public void invoke(Long id) {
        var optIn = favoriteIpsTransferRepository.findByFinDocId(id);
        if (optIn.isPresent()) {
            var favoriteIpslTransfer = optIn.get();
            var favoriteAccTransfer = new FavoriteAccTransferOut(favoriteIpslTransfer);
            favoriteAcctTransferRepository.delete(favoriteAccTransfer);
        }
        else log.error("FavoriteIpslTransfer is not found");
    }

    @Override
    public Set<String> keySet() {
        return Set.of(IPSL);
    }
}
