package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record IpsoAccountDataIn(
        String accountNumber,
        Long accountOutRefId,
        String accountStatus,
        String bSystem
) {
}
