package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.util.NameUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientAdditionalDataIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.PersonRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class PersonRepositoryImpl implements PersonRepository {

    private final NamedParameterJdbcTemplate template;

    public PersonRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<CreateTransferClientAdditionalDataIn> findNewTransferClient(Long id) {
        RowMapper<CreateTransferClientAdditionalDataIn> rowMapper = (rs, rowNum) -> new CreateTransferClientAdditionalDataIn(
                NameUtil.getDisplayName(rs.getString("fullName")),
                rs.getBoolean("flagResident"),
                rs.getString("iin"));

        String sql = """ 
                select concat(P.LastName, ' ', P.FirstName, ' ',  P.FathersName)    as fullName,
                       P.IsResident                                                 as flagResident,
                       P.IIN                                                        as iin
                from Person P
                where P.Person_ID = :id
                """;

        List<CreateTransferClientAdditionalDataIn> queryResult = template.query(
                sql,
                Map.of("id", id),
                rowMapper);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": PersonRepository findNewTransferClient");
        }
    }

    @Override
    public CreateTransferClientAdditionalDataIn findNewTransferClientOrException(Long id) {
        return findNewTransferClient(id)
                .orElseThrow(() -> new AppException(E_DB_600, ": PersonRepository findNewTransferClientOrException"));
    }
}
