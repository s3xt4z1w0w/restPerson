package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import java.math.BigDecimal;

public record FeeOutgoingIIn(
        BigDecimal feeAmount,
        BigDecimal operationLimitAmount,
        BigDecimal dayLimitAmount,
        BigDecimal monthLimitAmount
) {
}
