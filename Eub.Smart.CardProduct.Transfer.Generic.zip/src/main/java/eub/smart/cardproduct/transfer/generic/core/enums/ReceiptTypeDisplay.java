package eub.smart.cardproduct.transfer.generic.core.enums;

public enum ReceiptTypeDisplay {
    DEFT("default"),
    IPSL("cancellable");

    private final String value;

    ReceiptTypeDisplay(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
