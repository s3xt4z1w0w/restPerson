package eub.smart.cardproduct.transfer.generic.core.util;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_SM_500;

public class EnumUtil {

    private static final Logger log = LogManager.getLogger(EnumUtil.class);

    public static <T extends Enum<T>> T valueOfOrNull(Class<T> enumType, String name) {
        try {
            return Enum.valueOf(enumType, name);
        }catch (NullPointerException | IllegalArgumentException ex){
            log.error("Error valueOfOrNull enumType: {}, name: {}", enumType, name);
            return null;
        }
    }

    public static <T extends Enum<T>> T valueOfOrException(Class<T> enumType, String name) {
        try {
            return Enum.valueOf(enumType, name);
        }catch (NullPointerException | IllegalArgumentException ex){
            log.error("Error valueOfOrNull enumType: {}, name: {}", enumType, name);
            throw new AppException(E_SM_500, ex);
        }
    }

    public static <T extends Enum<T>> T valueOfOrDefault(Class<T> enumType, String name, T defaultValue) {
        try {
            return Enum.valueOf(enumType, name);
        }catch (NullPointerException | IllegalArgumentException ex){
            log.error("Error valueOfOrNull enumType: {}, name: {}", enumType, name);
            return defaultValue;
        }
    }

}
