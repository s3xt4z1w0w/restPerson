package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldError;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountOutRefIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.TransferValidate;
import eub.smart.cardproduct.transfer.generic.domain.repository.AccountRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MyBankAggregatorRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.ValidateAmountFieldUseCase;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

import static eub.smart.cardproduct.transfer.generic.core.constant.AccountType.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUM_FIELD_LESS_THAN_AVAILABLE;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUM_FIELD_LESS_THAN_MIN;
import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.KZT;
import static eub.smart.cardproduct.transfer.generic.core.constant.Fields.SUM;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_EX_700;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil.getCurrentLocale;

@Service
public class ValidateAmountFieldUseCaseImpl implements ValidateAmountFieldUseCase {

    private final MyBankAggregatorRepository myBankAggregatorRepository;
    private final MessageSourceRepository messageSourceRepository;
    private final AccountRepository accountRepository;
    private final BigDecimal minKzt = BigDecimal.valueOf(100);
    private final BigDecimal minOther = BigDecimal.valueOf(1);

    public ValidateAmountFieldUseCaseImpl(MyBankAggregatorRepository myBankAggregatorRepository,
                                          MessageSourceRepository messageSourceRepository,
                                          AccountRepository accountRepository) {
        this.myBankAggregatorRepository = myBankAggregatorRepository;
        this.messageSourceRepository = messageSourceRepository;
        this.accountRepository = accountRepository;
    }

    @Override
    public List<FieldError> invoke(TransferValidate validate, List<FieldError> fieldErrors) {
        var lang = getCurrentLocale();
        var availableBalance = getAvailableBalance(validate.accountId(), validate.currency(), validate.accountType());
        if (isLessThanMin(validate.amount(), validate.currency())) {
            if (validate.currency().equals(KZT)) {
                return addFieldError(fieldErrors, SUM_FIELD_LESS_THAN_MIN, lang, minKzt, validate.currencySymbol());
            }
            return addFieldError(fieldErrors, SUM_FIELD_LESS_THAN_MIN, lang, minOther, validate.currencySymbol());
        }
        if (isAvailableBalanceLess(availableBalance, validate.amount())) {
            return addFieldError(fieldErrors, SUM_FIELD_LESS_THAN_AVAILABLE, lang);
        }
        return fieldErrors;
    }

    private List<FieldError> addFieldError(List<FieldError> fieldErrors, String errorCode, Locale lang, Object... args) {
        fieldErrors.add(new FieldError(SUM, messageSourceRepository.getMessage(errorCode, args, lang)));
        return fieldErrors;
    }
    private BigDecimal getAvailableBalance(Long accountId, String currency, String accountType) {
        var accountOutRefs = accountRepository.findAccountOutRefs(accountId);
        var accountOutRefOut = accountOutRefs.stream().map(AccountOutRefIIn::accountOutRef).collect(Collectors.toSet());
        var accountBalance = switch (accountType) {
            case CARD -> myBankAggregatorRepository.getCardAccountsBalance(accountOutRefOut);
            case CURR, SAVE -> myBankAggregatorRepository.getAccountsBalance(accountOutRefOut);
            default -> throw new AppException(E_LG_802, ": getAccountBalance no impl for type : " + accountType);
        };
        var availableBalanceOpt = accountBalance
                .stream()
                .filter(accountBalanceIn -> accountBalanceIn.getCurrency().equals(currency))
                .findFirst()
                .orElseThrow(() -> new AppException(E_EX_700, " : AccountBalanceRepository getCardAccountsBalance"));;
        return  availableBalanceOpt.getAmount();
    }
    private boolean isAvailableBalanceLess(BigDecimal availableBalance, BigDecimal operationAmount) {
        return availableBalance.compareTo(operationAmount) < 0;
    }
    private boolean isLessThanMin(BigDecimal amount, String currency) {
        if (currency.equals(KZT)) {
            return amount.compareTo(minKzt) < 0;
        }
        return amount.compareTo(minOther) < 0;
    }

}
