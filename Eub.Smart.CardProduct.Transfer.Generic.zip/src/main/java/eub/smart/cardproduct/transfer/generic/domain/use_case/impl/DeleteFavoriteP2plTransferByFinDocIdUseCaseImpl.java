package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteP2pTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.DeleteFavoriteTransferByFinDocIdUseCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.P2PL;

@Service
public class DeleteFavoriteP2plTransferByFinDocIdUseCaseImpl implements DeleteFavoriteTransferByFinDocIdUseCase {

    private final Logger log = LogManager.getLogger(getClass());
    private final FavoriteP2pTransferRepository favoriteP2pTransferRepository;
    private final FavoriteAcctTransferRepository favoriteAcctTransferRepository;

    public DeleteFavoriteP2plTransferByFinDocIdUseCaseImpl(FavoriteP2pTransferRepository favoriteP2pTransferRepository,
                                                           FavoriteAcctTransferRepository favoriteAcctTransferRepository) {
        this.favoriteP2pTransferRepository = favoriteP2pTransferRepository;
        this.favoriteAcctTransferRepository = favoriteAcctTransferRepository;
    }

    @Override
    public void invoke(Long id) {
        var optIn = favoriteP2pTransferRepository.findByFinDocId(id);
        if (optIn.isPresent()) {
            var favoriteP2plTransfer = optIn.get();
            var favoriteAccTransfer = new FavoriteAccTransferOut(favoriteP2plTransfer);
            favoriteAcctTransferRepository.delete(favoriteAccTransfer);
        }
        else log.error("FavoriteP2plTransfer is not found");
    }

    @Override
    public Set<String> keySet() {
        return Set.of(P2PL);
    }
}
