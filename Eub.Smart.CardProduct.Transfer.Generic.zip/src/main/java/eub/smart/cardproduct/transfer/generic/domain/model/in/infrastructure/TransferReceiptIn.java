package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import java.util.List;

public record TransferReceiptIn(
        Long id,
        String title,
        String subtitle,
        String image,
        String number,
        String accountType,
        Object amount,
        Object fee,
        Long date,
        Boolean isSaved,
        String type,
        String link,
        String status,
        String referenceId,
        List<Object> details
) {
}
