package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;

public record CreateFavoriteTransferDataIIn(
        FavoriteTransferType type,
        Long finDocId,
        String senderCurrency,
        String receiverCurrency
) {
    public CreateFavoriteTransferDataIIn(Long finDocId,
                                         String type,
                                         String senderCurrency,
                                         String receiverCurrency) {
        this(EnumUtil.valueOfOrException(FavoriteTransferType.class, type),
                finDocId,
                senderCurrency,
                receiverCurrency);
    }
}
