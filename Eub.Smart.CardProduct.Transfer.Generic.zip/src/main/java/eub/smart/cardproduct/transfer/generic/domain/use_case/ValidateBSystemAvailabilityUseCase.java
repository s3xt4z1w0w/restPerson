package eub.smart.cardproduct.transfer.generic.domain.use_case;

public interface ValidateBSystemAvailabilityUseCase {

    void invoke(String bSystem, String lang);
}
