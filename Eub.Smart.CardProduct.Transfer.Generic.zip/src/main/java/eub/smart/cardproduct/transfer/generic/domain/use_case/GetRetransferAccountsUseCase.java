package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferAccountsOut;

public interface GetRetransferAccountsUseCase {

    RetransferAccountsOut invoke(Long finDocId);
}
