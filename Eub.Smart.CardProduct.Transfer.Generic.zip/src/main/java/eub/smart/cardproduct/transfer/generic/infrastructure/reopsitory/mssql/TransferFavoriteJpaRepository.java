package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferFavoriteEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TransferFavoriteJpaRepository extends JpaRepository<TransferFavoriteEntity, Long> {

    @Query(value = """
            select tf.TransferFavorite_ID as id,
                   tf.Type                as type,
                   tf.Title               as title,
                   fd.Account_IDREF       as accountId
            from TransferFavorite tf
                     join FinDoc fd on tf.FinDoc_IDREF = fd.FinDoc_ID
            where tf.User_IDREF = :userId
            order by tf.CreatedDate desc
            """,
            nativeQuery = true)
    Page<FavoriteTransferDisplayIn> findAllByUserId(@Param("userId") Long userId,
                                                    Pageable pageable);

    @Modifying
    @Query(value = """
            update TransferFavorite
            set Title = :name
            where TransferFavorite_ID = :id
            and User_IDREF = :userId
            """,
            nativeQuery = true)
    void rename(@Param("id") Long id,
                @Param("userId") Long userId,
                @Param("name") String name);

    Optional<TransferFavoriteEntity> findByIdAndUserId(Long id, Long userId);
}
