package eub.smart.cardproduct.transfer.generic.core.util;

import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import org.slf4j.MDC;

import java.util.Locale;

import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;

public class LangUtil {

    public final static Locale KK = new Locale("kk", "KZ");
    public final static Locale RU = new Locale("ru", "RU");
    public final static Locale EN = new Locale("en", "EN");

    public static Locale get(LangKey langKey) {
        return switch (langKey) {
            case RU -> RU;
            case KK -> KK;
            case EN -> EN;
        };
    }

    public static Locale get(String lang) {
        var langKey = LangKey.valueOf(lang);
        return get(langKey);
    }

    public static String getCurrentLocaleString() {
        return MDC.get(LANG_KEY);
    }
}
