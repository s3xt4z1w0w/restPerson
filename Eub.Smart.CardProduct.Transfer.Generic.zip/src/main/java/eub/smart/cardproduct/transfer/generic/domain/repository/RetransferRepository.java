package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferSelfIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.LocalRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.RetransferAccountIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;

import java.math.BigDecimal;

public interface RetransferRepository {

    CreateRetransferSelfIn findSenderReceiverCardIdAndAccId(Long finDocId);

    RetransferAccountIn findRetransferAccount(Long finDocId);

    CreateRetransferDataIn findCreateRetransferData(Long finDocId, BigDecimal debitAmount, BigDecimal creditAmount);

    LocalRetransferDataIn getRetransferData(Long finDocId);
}
