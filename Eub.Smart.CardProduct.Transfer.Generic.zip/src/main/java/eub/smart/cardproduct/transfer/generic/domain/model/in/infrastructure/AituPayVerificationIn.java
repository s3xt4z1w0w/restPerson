package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record AituPayVerificationIn(
        String transactionId,
        String receiverName
) {
}
