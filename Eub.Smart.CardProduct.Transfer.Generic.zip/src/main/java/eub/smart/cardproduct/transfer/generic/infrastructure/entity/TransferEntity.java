package eub.smart.cardproduct.transfer.generic.infrastructure.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "Transfer")
public class TransferEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Transfer_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "FinDoc_IDREF", nullable = false)
    private FinDocEntity finDoc;

    @Column(name = "TransferType_IDREF")
    private String type;

    @Column(name = "Receiver_BIC", nullable = false)
    private String receiverBic;

    @Column(name = "Receiver_Account", nullable = false)
    private String receiverAccountNumber;

    @Column(name = "Receiver_Name", nullable = false)
    private String receiverName;

    @Column(name = "Receiver_IIN")
    private String receiverIin;

    @Column(name = "Receiver_IsResident", nullable = false)
    private Boolean flagReceiverResident;

    @Column(name = "SEco_IDREF", nullable = false)
    private String secoId;

    @Column(name = "KNP_IDREF", nullable = false)
    private String knpId;

    @Column(name = "KNP_Text")
    private String knpText;

    @Column(name = "Purpose_Type")
    private String purposeType;

    @Column(name = "Purpose_Number")
    private String purposeNumber;

    @Column(name = "Purpose_Date")
    private Date purposeDate;

    @Column(name = "Purpose_Text")
    private String purposeText;

    @Column(name = "Receiver_BIN")
    private String receiverBIN;

    @Column(name = "Receiver_Currency")
    private String receiverCurrency;

    @Column(name = "SubAccountCurrency")
    private String receiverSubAccountCurrency;

    @Column(name = "CurrencyRates", columnDefinition = "NVARCHAR(4000)")
    private String currencyRates;

    @Column(name = "SenderSubAccountCurrency")
    private String senderSubAccountCurrency;

    @Column(name = "TransferMethod_IDREF")
    private String transferMethod_IDREF;

    @Column(name = "MaskedNumber")
    private String maskedNumber;

    @Column(name = "CardNumberHash")
    private String cardNumberHash;

    @Column(name = "Receiver_Amount")
    private BigDecimal receiverAmount;

    @Column(name = "SenderCard_IDREF")
    private Long senderCardId;

    @Column(name = "ReceiverCard_IDREF")
    private Long receiverCardId;

    public Long getId() {
        return id;
    }

    public FinDocEntity getFinDoc() {
        return finDoc;
    }

    public String getType() {
        return type;
    }

    public String getReceiverBic() {
        return receiverBic;
    }

    public String getReceiverAccountNumber() {
        return receiverAccountNumber;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public String getReceiverIin() {
        return receiverIin;
    }

    public boolean getFlagReceiverResident() {
        return flagReceiverResident;
    }

    public String getSecoId() {
        return secoId;
    }

    public String getKnpId() {
        return knpId;
    }

    public String getKnpText() {
        return knpText;
    }

    public String getPurposeType() {
        return purposeType;
    }

    public String getPurposeNumber() {
        return purposeNumber;
    }

    public Date getPurposeDate() {
        return purposeDate;
    }

    public String getPurposeText() {
        return purposeText;
    }

    public String getReceiverBIN() {
        return receiverBIN;
    }

    public String getReceiverCurrency() {
        return receiverCurrency;
    }

    public String getReceiverSubAccountCurrency() {
        return receiverSubAccountCurrency;
    }

    public String getCurrencyRates() {
        return currencyRates;
    }

    public String getSenderSubAccountCurrency() {
        return senderSubAccountCurrency;
    }

    public String getTransferMethod_IDREF() {
        return transferMethod_IDREF;
    }

    public String getMaskedNumber() {
        return maskedNumber;
    }

    public String getCardNumberHash() {
        return cardNumberHash;
    }

    public BigDecimal getReceiverAmount() {
        return receiverAmount;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setFinDoc(FinDocEntity finDoc) {
        this.finDoc = finDoc;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setReceiverBic(String receiverBic) {
        this.receiverBic = receiverBic;
    }

    public void setReceiverAccountNumber(String receiverAccountNumber) {
        this.receiverAccountNumber = receiverAccountNumber;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public void setReceiverIin(String receiverIin) {
        this.receiverIin = receiverIin;
    }

    public void setFlagReceiverResident(boolean flagReceiverResident) {
        this.flagReceiverResident = flagReceiverResident;
    }

    public void setSecoId(String secoId) {
        this.secoId = secoId;
    }

    public void setKnpId(String knpId) {
        this.knpId = knpId;
    }

    public void setKnpText(String knpText) {
        this.knpText = knpText;
    }

    public void setPurposeType(String purposeType) {
        this.purposeType = purposeType;
    }

    public void setPurposeNumber(String purposeNumber) {
        this.purposeNumber = purposeNumber;
    }

    public void setPurposeDate(Date purposeDate) {
        this.purposeDate = purposeDate;
    }

    public void setPurposeText(String purposeText) {
        this.purposeText = purposeText;
    }

    public void setReceiverBIN(String receiverBIN) {
        this.receiverBIN = receiverBIN;
    }

    public void setReceiverCurrency(String receiverCurrency) {
        this.receiverCurrency = receiverCurrency;
    }

    public void setReceiverSubAccountCurrency(String receiverSubAccountCurrency) {
        this.receiverSubAccountCurrency = receiverSubAccountCurrency;
    }

    public void setCurrencyRates(String currencyRates) {
        this.currencyRates = currencyRates;
    }

    public void setSenderSubAccountCurrency(String senderSubAccountCurrency) {
        this.senderSubAccountCurrency = senderSubAccountCurrency;
    }

    public void setTransferMethod_IDREF(String transferMethod_IDREF) {
        this.transferMethod_IDREF = transferMethod_IDREF;
    }

    public void setMaskedNumber(String maskedNumber) {
        this.maskedNumber = maskedNumber;
    }

    public void setCardNumberHash(String cardNumberHash) {
        this.cardNumberHash = cardNumberHash;
    }

    public void setReceiverAmount(BigDecimal receiverAmount) {
        this.receiverAmount = receiverAmount;
    }

    public Long getSenderCardId() {
        return senderCardId;
    }

    public void setSenderCardId(Long senderCardId) {
        this.senderCardId = senderCardId;
    }

    public Long getReceiverCardId() {
        return receiverCardId;
    }

    public void setReceiverCardId(Long receiverCardId) {
        this.receiverCardId = receiverCardId;
    }
}
