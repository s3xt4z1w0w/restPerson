package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountOutRefIIn;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;

public class AccountOutRefMapper {

    public static AccountOutRefIIn toDomain(ResultSet resultSet, int i) {
        try {
            Long accountOutRef = resultSet.getLong("accountOutRef");
            return new AccountOutRefIIn(accountOutRef);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }
}
