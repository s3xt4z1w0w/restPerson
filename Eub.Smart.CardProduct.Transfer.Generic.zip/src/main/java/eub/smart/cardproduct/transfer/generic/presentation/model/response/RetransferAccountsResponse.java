package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public record RetransferAccountsResponse(
        @Schema(description = "Данные отправителя")
        AccountSourceResponse senderAccount,
        @Schema(description = "Данные получателя")
        AccountTargetResponse receiverAccount
) {
}
