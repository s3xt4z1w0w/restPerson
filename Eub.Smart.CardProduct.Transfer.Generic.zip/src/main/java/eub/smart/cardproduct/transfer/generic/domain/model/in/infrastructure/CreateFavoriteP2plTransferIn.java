package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteTransferOut;

public record CreateFavoriteP2plTransferIn(
        FavoriteTransferOut favoriteTransferOut,
        String accountNumber,
        String currency,
        String title,
        String imageTable,
        Long imageId) {

    public CreateFavoriteP2plTransferIn(Long finDocId,
                                        Long userId,
                                        String type,
                                        String accountNumber,
                                        String currency,
                                        String title,
                                        String imageTable,
                                        Long imageId) {
        this(new FavoriteTransferOut(finDocId, userId, type),
                accountNumber,
                currency,
                title,
                imageTable,
                imageId
        );
    }
}
