package eub.smart.cardproduct.transfer.generic.core.constant;

public interface BankBic {

    String EURASIAN_BIC = "EURIKZKA";
    String KASPI = "CASPKZKA";
    String HALYK = "HSBKKZKX";
}
