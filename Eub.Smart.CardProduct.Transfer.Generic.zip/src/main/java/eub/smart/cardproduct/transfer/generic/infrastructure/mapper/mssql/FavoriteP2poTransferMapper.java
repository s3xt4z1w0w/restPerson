package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.constant.AccountType;
import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.LocalizedText;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.core.util.StringUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteP2poTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUB_TITLE_LOCAL;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUB_TITLE_OUTGOING;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;

@Component
public class FavoriteP2poTransferMapper {

    private final LocalizedText subTitleLocal;
    private final LocalizedText subTitleOutgoing;

    public FavoriteP2poTransferMapper(MessageSourceRepositoryImpl messageSourceRepository) {
        String subTitleLocalRu = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.RU);
        String subTitleLocalKk = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.KK);
        String subTitleLocalEn = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.EN);
        String subTitleOutgoingRu = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.RU);
        String subTitleOutgoingKk = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.KK);
        String subTitleOutgoingEn = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.EN);
        this.subTitleLocal = new LocalizedText(subTitleLocalRu, subTitleLocalKk, subTitleLocalEn);
        this.subTitleOutgoing = new LocalizedText(subTitleOutgoingRu, subTitleOutgoingKk, subTitleOutgoingEn);
    }

    public CreateFavoriteP2poTransferIn toDomain(ResultSet resultSet, int i) {
        try {
            Long finDocId = resultSet.getLong("finDocId");
            Long userId = resultSet.getLong("userId");
            String type = FavoriteTransferType.P2PO.name();
            String title = resultSet.getString("title");
            String bin = resultSet.getString("bin");
            String token = resultSet.getString("token");
            return new CreateFavoriteP2poTransferIn(
                    finDocId,
                    userId,
                    type,
                    title,
                    bin,
                    token);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    public FavoriteTransferDisplayOut toDetailsDisplay(ResultSet resultSet, FavoriteTransferDisplayIn in, String s3Url, String langKey) {
        try {
            String title = resultSet.getString("title");
            String imageUid = resultSet.getString("imageUid");
            String imageUrl = imageUrl(s3Url, imageUid);
            String subTitle = subTitleOutgoing.text(langKey);
            String finDocType = EnumUtil.valueOfOrException(FavoriteTransferType.class, in.getType()).finDocType();

            return new FavoriteTransferDisplayOut(
                    in.getId(),
                    finDocType,
                    in.getTitle(),
                    title,
                    subTitle,
                    AccountType.BANK,
                    imageUrl,
                    null,
                    in.getAccountId(),
                    null);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private static String imageUrl(String s3Url, String uid) {
        if (StringUtil.isEmpty(uid)) return uid;
        return String.format("%s?fileUid=%s", s3Url, uid);
    }
}
