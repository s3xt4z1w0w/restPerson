package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.constant.BundleCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.Error;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldError;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.VisaTokenIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.IpsoReceiverDataOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.IpsRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.VisaAliasTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetVisaAliasReceiverUseCase;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.PHONE_FIELD_CLIENT_NOTFOUND;
import static eub.smart.cardproduct.transfer.generic.core.constant.Fields.TARGET;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_VD_402;
import static eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil.getCurrentLocale;

@Service
public class GetVisaAliasReceiverUseCaseImpl implements GetVisaAliasReceiverUseCase {

    private final IpsRepository ipsRepository;
    private final MessageSourceRepository messageSourceRepository;
    private final VisaAliasTransferRepository visaAliasTransferRepository;
    private final String HALYK_NAME = "Halyk Bank";

    public GetVisaAliasReceiverUseCaseImpl(IpsRepository ipsRepository,
                                           MessageSourceRepository messageSourceRepository,
                                           VisaAliasTransferRepository visaAliasTransferRepository) {
        this.ipsRepository = ipsRepository;
        this.messageSourceRepository = messageSourceRepository;
        this.visaAliasTransferRepository = visaAliasTransferRepository;
    }

    @Override
    public IpsoReceiverDataOut invoke(Long finDocId) {
        var receiverInfo = ipsRepository.findReceiverPhoneByFinDocId(finDocId);
        var visaReceiver = visaAliasTransferRepository.getResolveToken(receiverInfo.receiverPhone());
        validate(visaReceiver);
        return new IpsoReceiverDataOut(receiverInfo, visaReceiver);
    }

    private void validate(VisaTokenIIn receiverData) {
        List<FieldError> fieldErrors = new ArrayList<>();
        if (!receiverData.isSuccess()) {
            fieldErrors.add(new FieldError(TARGET, messageSourceRepository.getMessage(PHONE_FIELD_CLIENT_NOTFOUND, getCurrentLocale())));
        } else if (!receiverData.issuerName().equals(HALYK_NAME)) {
            fieldErrors.add(new FieldError(TARGET, messageSourceRepository.getMessage(PHONE_FIELD_CLIENT_NOTFOUND, getCurrentLocale())));
        }
        if(!fieldErrors.isEmpty()) {
            throw new AppException(E_VD_402, new FieldsValidationResponse(null, fieldErrors));
        }
    }
}
