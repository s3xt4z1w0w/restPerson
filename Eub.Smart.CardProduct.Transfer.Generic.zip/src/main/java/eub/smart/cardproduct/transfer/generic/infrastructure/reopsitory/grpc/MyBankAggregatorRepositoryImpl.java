package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.grpc;

import MyBankInfo.V1.EubAggregatorCoreMyBank;
import MyBankInfo.V1.MyBankInfoGrpc;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountBalanceIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MyBankAggregatorRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.*;

@Repository
public class MyBankAggregatorRepositoryImpl implements MyBankAggregatorRepository {

    @GrpcClient("aggregator-core-mybank")
    private MyBankInfoGrpc.MyBankInfoBlockingStub stub;
    private final MessageSourceRepository messageSourceRepository;
    private final InfrastructureMapper mapper;

    public MyBankAggregatorRepositoryImpl(MessageSourceRepository messageSourceRepository,
                                          InfrastructureMapper mapper) {
        this.messageSourceRepository = messageSourceRepository;
        this.mapper = mapper;
    }

    @Override
    public List<AccountBalanceIn> getCardAccountsBalance(Set<Long> accountOutRefs) {
        try {
            var request = EubAggregatorCoreMyBank.GetCardAccountBalanceRequest
                    .newBuilder()
                    .addAllAccountIds(accountOutRefs)
                    .build();
            var result = stub.getCardAccountBalance(request);
            return result.getBalancesList()
                    .stream()
                    .map(mapper::toDomain)
                    .toList();
        }catch (StatusRuntimeException e) {
            throw new AppException(E_EX_701, "AccountBalanceRepositoryImpl getBalance");
        }
    }

    @Override
    public List<AccountBalanceIn> getAccountsBalance(Set<Long> accountOutRefs) {
        try {
            var request = EubAggregatorCoreMyBank.GetCurrentAccountBalanceRequest
                    .newBuilder()
                    .addAllAccountIds(accountOutRefs)
                    .build();
            var result = stub.getCurrentAccountBalance(request);
            return result.getBalancesList()
                    .stream()
                    .map(mapper::toDomain)
                    .toList();
        }catch (StatusRuntimeException e) {
            throw new AppException(E_EX_701, "AccountBalanceRepositoryImpl getBalance");
        }
    }
}
