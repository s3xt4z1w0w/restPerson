package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FinDocStatusIn;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FinDocStatusRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.FinDocStatusJpaRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;

@Primary
@Component
public class FinDocStatusRepositoryImpl implements FinDocStatusRepository {

    private final FinDocStatusJpaRepository finDocStatusJpaRepository;
    private final InfrastructureMapper mapper;

    public FinDocStatusRepositoryImpl(FinDocStatusJpaRepository finDocStatusJpaRepository,
                                      InfrastructureMapper mapper) {
        this.finDocStatusJpaRepository = finDocStatusJpaRepository;
        this.mapper = mapper;
    }

    @Override
    public Optional<FinDocStatusIn> findByFinIdDoc(Long finDocId) {
        return finDocStatusJpaRepository.findByFinDocId(finDocId)
                .map(mapper::toDomain);
    }

    @Override
    public Optional<FinDocStatusIn> findById(String id) {
        return finDocStatusJpaRepository.findById(id)
                .map(mapper::toDomain);
    }

    @Override
    public FinDocStatusIn findByIdOrException(String id) {
        return findById(id)
                .orElseThrow(() -> new AppException(E_DB_600, ": FinDocStatusRepository findByIdOrException"));
    }

}
