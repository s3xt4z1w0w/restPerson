package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CurrencyRateOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CurrencyRatesOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.CurrencyTypeRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.RsbkInfoProtoRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CurrencyRatesUseCase;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.CURRENCY_RATE_ALERT;
import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I32A;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.constant.TargetTable.CURRENCY_TYPE;

@Service
public class CurrencyRatesUseCaseImpl implements CurrencyRatesUseCase {

    private final RsbkInfoProtoRepository rsbkInfoProtoRepository;
    private final MessageSourceRepository messageSourceRepository;
    private final CurrencyTypeRepository currencyTypeRepository;

    public CurrencyRatesUseCaseImpl(RsbkInfoProtoRepository rsbkInfoProtoRepository,
                                    MessageSourceRepository messageSourceRepository,
                                    CurrencyTypeRepository currencyTypeRepository) {
        this.rsbkInfoProtoRepository = rsbkInfoProtoRepository;
        this.messageSourceRepository = messageSourceRepository;
        this.currencyTypeRepository = currencyTypeRepository;
    }

    @Override
    public CurrencyRatesOut invoke() { //TODO spring cache
        var inList = rsbkInfoProtoRepository.findCurrencyRates();
        var outList = new ArrayList<CurrencyRateOut>();
        inList.forEach(in -> {
            var imageUrl = currencyTypeRepository.findImageUid(in.currency(), CURRENCY_TYPE, I32A).orElse(null);
            var out = new CurrencyRateOut(in, imageUrl);
            outList.add(out);
        });
        var alertTitle = messageSourceRepository.getMessage(CURRENCY_RATE_ALERT, LangUtil.get(MDC.get(LANG_KEY)));
        return new CurrencyRatesOut(alertTitle, outList);
    }
}
