package eub.smart.cardproduct.transfer.generic.core.constant;

public interface BundleCode {

    String ERROR_MESSAGE_EMPTY_HISTORY = "error.message.empty.history";

    String RECEIPT_SENDER = "receipt.sender";
    String RECEIPT_FROM = "receipt.from";
    String RECEIVER_PHONE_NUMBER = "receipt.receiver.phone.number";
    String RECEIPT_TO_TRANSFER = "receipt.to.transfer";
    String RECEIPT_EXCHANGE_RATE = "receipt.exchange.rate";
    String RECEIPT_STATUS = "receipt.status";
    String RECEIPT_DATE = "receipt.date";
    String RECEIPT_NO = "receipt.number";
    String RECEIPT_REFERENCE_ID = "receipt.reference.id";

    String SUB_TITLE_SELF = "sub.title.self";
    String SUB_TITLE_LOCAL = "sub.title.local";
    String SUB_TITLE_OUTGOING = "sub.title.outgoing";
    String SUB_TITLE_ACCOUNT = "sub.title.account";

    String CURRENCY_RATE_ALERT = "currency.rate.alert";
    String ERROR_TECHNICAL_TITLE = "error.technical.title";
    String ERROR_TECHNICAL_SUBTITLE = "error.technical.subtitle";
    String PHONE_NUMBER_OWNER_CHANGED = "error.phone.owner.changed";
    String PHONE_FIELD_CLIENT_NOTFOUND = "error.phone.field.client.notfound";
    String SUBTITLE_DELETE_FROM_FAVORITE = "subtitle.delete.from.favorite";
    String SUM_FIELD_LESS_THAN_MIN = "error.sum.field.less.min";
    String SUM_FIELD_LESS_THAN_AVAILABLE = "error.sum.field.less.available";

    String SUM_FIELD_MORE_THAN_LIMIT_FINDOC = "error.sum.field.less.limit.findoc";
    String SUM_FIELD_MORE_THAN_LIMIT_DAY = "error.sum.field.less.limit.day";
    String SUM_FIELD_MORE_THAN_LIMIT_MONTH = "error.sum.field.less.limit.month";
}
