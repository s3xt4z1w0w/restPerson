package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record FavoriteAccTransferIn(
        Long id,
        FavoriteTransferIn favoriteTransferIn,
        String accountNumber,
        String currency,
        String title,
        String transferType,
        String imageTable,
        Long imageId
) {
}
