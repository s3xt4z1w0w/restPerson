package eub.smart.cardproduct.transfer.generic.domain.use_case;

public interface FavoriteTransferRenameUseCase {

    void invoke(Long id, String name);
}
