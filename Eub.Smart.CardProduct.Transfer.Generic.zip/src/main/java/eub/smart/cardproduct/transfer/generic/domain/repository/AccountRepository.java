package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountOutRefIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.IpsoAccountDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.AccountOut;

import java.util.List;
import java.util.Optional;

public interface AccountRepository {

    Optional<AccountOut> findByNumber(String number);

    AccountOut findByNumberOrException(String number);

    Optional<String> getAccountStatus(String finDocId);

    String getAccountStatusOrException(String finDocId);

    AccountOut findByIdOrException(Long id);

    IpsoAccountDataIn findByCardId(Long cardId);
    List<AccountOutRefIIn> findAccountOutRefs(Long accountId);
}
