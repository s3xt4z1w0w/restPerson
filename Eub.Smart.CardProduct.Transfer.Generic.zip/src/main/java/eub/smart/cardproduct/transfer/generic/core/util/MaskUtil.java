package eub.smart.cardproduct.transfer.generic.core.util;

public class MaskUtil {

    public static String maskAccountNumber(String accountNumber) {
        if (StringUtil.isEmpty(accountNumber)) return accountNumber;
        int length = accountNumber.length();
        if (length < 8) return accountNumber;
        String substring1 = accountNumber.substring(0, 2);
        String substring2 = accountNumber.substring(length - 4, length);
        return substring1 + "**" + substring2;
    }


    public static String maskPhoneNumber(String phoneNumber) {
        if (phoneNumber.length() > 11) return phoneNumber;
        return phoneNumber.charAt(0) + " " +
                phoneNumber.substring(1, 4) + " " +
                phoneNumber.substring(4, 7) + " " +
                phoneNumber.substring(7, 9) + " " +
                phoneNumber.substring(9, 11);
    }
}
