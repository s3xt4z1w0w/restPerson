package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;


import eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;

import static eub.smart.cardproduct.transfer.generic.core.constant.CardTransferType.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.IpsTransferType.*;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

public record FindFavoriteTransferOperationTypeIn(

        String finDocType,
        String cardTransferType,
        String ipsTransferType,
        String transferType) {

    public String invoke() {
        return switch (finDocType) {
            case SLFT, SLFF, SLFR -> FavoriteTransferOperationType.SLFT;
            case P2PT -> switch (cardTransferType) {
                case P2PL -> FavoriteTransferOperationType.P2PL;
                case P2PO, P2PI -> FavoriteTransferOperationType.P2PX;
                default -> throw new AppException(E_LG_802, ": sub title " + finDocType + " " + cardTransferType);
            };
            case IPST -> switch (ipsTransferType) {
                case IPSL -> FavoriteTransferOperationType.IPSL;
                case IPSO -> FavoriteTransferOperationType.IPSO;
                default -> throw new AppException(E_LG_802, ": sub title " + finDocType + " " + ipsTransferType);
            };
            case P2PF, P2PR -> FavoriteTransferOperationType.P2PX;
            case IPSF, IPSR -> FavoriteTransferOperationType.IPSO;
            case ACCT, ACCF, ACCR -> FavoriteTransferOperationType.ACCT;
            case LOCF, LOCR -> FavoriteTransferOperationType.LOCT;
            default -> throw new AppException(E_LG_802, ": sub title " + finDocType);
        };
    }
}
