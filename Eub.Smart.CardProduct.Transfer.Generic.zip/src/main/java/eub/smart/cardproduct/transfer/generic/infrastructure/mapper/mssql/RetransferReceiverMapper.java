package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.LocalizedText;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.AccountTargetOut;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.constant.AccountType.BANK;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.CardTransferType.P2PL;
import static eub.smart.cardproduct.transfer.generic.core.constant.CardTransferType.P2PO;
import static eub.smart.cardproduct.transfer.generic.core.constant.IpsTransferType.IPSL;
import static eub.smart.cardproduct.transfer.generic.core.constant.IpsTransferType.IPSO;
import static eub.smart.cardproduct.transfer.generic.core.enums.LangKey.EN;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.generic.core.util.ImageUtil.formImageUrl;

@Component
public class RetransferReceiverMapper {

    private final LocalizedText subTitleAcc;
    private final LocalizedText subTitleLocal;
    private final LocalizedText subTitleOutgoing;

    public RetransferReceiverMapper(MessageSourceRepositoryImpl messageSourceRepository) {
        String subTitleAccRu = messageSourceRepository.getMessage(SUB_TITLE_ACCOUNT, LangUtil.RU);
        String subTitleAccKk = messageSourceRepository.getMessage(SUB_TITLE_ACCOUNT, LangUtil.KK);
        String subTitleAccEn = messageSourceRepository.getMessage(SUB_TITLE_ACCOUNT, LangUtil.EN);
        String subTitleLocalRu = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.RU);
        String subTitleLocalKk = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.KK);
        String subTitleLocalEn = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.EN);
        String subTitleOutgoingRu = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.RU);
        String subTitleOutgoingKk = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.KK);
        String subTitleOutgoingEn = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.EN);
        this.subTitleAcc = new LocalizedText(subTitleAccRu, subTitleAccKk, subTitleAccEn);
        this.subTitleLocal = new LocalizedText(subTitleLocalRu, subTitleLocalKk, subTitleLocalEn);
        this.subTitleOutgoing = new LocalizedText(subTitleOutgoingRu, subTitleOutgoingKk, subTitleOutgoingEn);
    }

    public AccountTargetOut toAcctDomain(ResultSet resultSet, String langKey) {
        try {
            return fillAcctData(resultSet, langKey);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private AccountTargetOut fillAcctData(ResultSet resultSet, String strLangKey) throws SQLException {
        String title = resultSet.getString("title");
        LangKey langKey = EnumUtil.valueOfOrDefault(LangKey.class, strLangKey, EN);
        String subtitle = subTitleAcc.text(langKey);
        String imageUID = resultSet.getString("imageUid");
        String imageUrl = formImageUrl(imageUID);

        return new AccountTargetOut(title, subtitle, imageUrl, BANK);
    }

    public AccountTargetOut toIpstDomain(ResultSet resultSet, String langKey) {
        try {
            return fillIpstData(resultSet, langKey);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private AccountTargetOut fillIpstData(ResultSet resultSet, String strLangKey) throws SQLException {
        String title = resultSet.getString("title");
        String transferType = resultSet.getString("transferType");
        LangKey langKey = EnumUtil.valueOfOrDefault(LangKey.class, strLangKey, EN);
        String subtitle = resultSet.getString("subtitle");
        if (IPSL.equals(transferType)) subtitle = subTitleLocal.text(langKey);
        String imageUID = resultSet.getString("imageUid");
        String imageUrl = formImageUrl(imageUID);

        return new AccountTargetOut(title, subtitle, imageUrl, BANK);
    }

    public AccountTargetOut toLoctDomain(ResultSet resultSet, String langKey) {
        try {
            return fillLoctData(resultSet, langKey);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private AccountTargetOut fillLoctData(ResultSet resultSet, String strLangKey) throws SQLException {
        String title = resultSet.getString("title");
        LangKey langKey = EnumUtil.valueOfOrDefault(LangKey.class, strLangKey, EN);
        String subtitle = subTitleLocal.text(langKey);
        String imageUID = resultSet.getString("imageUid");
        String imageUrl = formImageUrl(imageUID);

        return new AccountTargetOut(title, subtitle, imageUrl, BANK);
    }

    public AccountTargetOut toP2ptDomain(ResultSet resultSet, String langKey) {
        try {
            return fillP2ptData(resultSet, langKey);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private AccountTargetOut fillP2ptData(ResultSet resultSet, String strLangKey) throws SQLException {
        String title = resultSet.getString("title");
        LangKey langKey = EnumUtil.valueOfOrDefault(LangKey.class, strLangKey, EN);
        String transferType = resultSet.getString("transferType");
        String subtitle = p2ptSubTitle(transferType, langKey);
        String imageUID = resultSet.getString("imageUid");
        String imageUrl = formImageUrl(imageUID);

        return new AccountTargetOut(title, subtitle, imageUrl, BANK);
    }

    private String p2ptSubTitle(String transferType, LangKey langKey) {
        return switch (transferType) {
            case P2PL -> subTitleLocal.text(langKey);
            case P2PO -> subTitleOutgoing.text(langKey);
            default -> throw new AppException(E_LG_802, ": transfer type title " + transferType);
        };
    }

}
