package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferSelfIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.LocalRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.RetransferAccountIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.RetransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferEntity;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.CreateRetransferMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferJpaRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class RetransferRepositoryImpl implements RetransferRepository {

    private final NamedParameterJdbcTemplate template;
    private final TransferJpaRepository transferJpaRepository;

    public RetransferRepositoryImpl(NamedParameterJdbcTemplate template,
                                    TransferJpaRepository transferJpaRepository) {
        this.template = template;
        this.transferJpaRepository = transferJpaRepository;
    }

    @Override
    public CreateRetransferSelfIn findSenderReceiverCardIdAndAccId(Long finDocId) {
        return transferJpaRepository.findCreateRepeatSelfData(finDocId)
                .orElseThrow(() -> new AppException(E_DB_600, ": TransferRepository getSenderReceiverCardIdAndAccId"));
    }

    @Override
    public RetransferAccountIn findRetransferAccount(Long finDocId) {
        RowMapper<RetransferAccountIn> rowMapper = (rs, rowNum) -> new RetransferAccountIn(
                rs.getLong("accountId"),
                rs.getLong("cardId"),
                rs.getString("currency"));

        String sql = """ 
                select fd.Account_IDREF                                                      as accountId,
                       coalesce(t.SenderCard_IDREF, ct.DebitCard_IDREF, it.SenderCard_IDREF) as cardId,
                       fd.Currency                                                           as currency
                from FinDoc fd
                         left join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                         left join CardTransfer ct on fd.FinDoc_ID = ct.FinDoc_IDREF
                         left join IPSTransfer it on fd.FinDoc_ID = it.FinDoc_IDREF
                where fd.FinDoc_ID = :finDocId;
                """;

        List<RetransferAccountIn> queryResult = template.query(
                sql,
                Map.of("finDocId", finDocId),
                rowMapper);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, " RetransferRepository findRetransferAccount"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, " RetransferRepository findRetransferAccount");
        } else {
            throw new AppException(E_DB_601, ": RetransferRepository findRetransferAccount");
        }
    }

    @Override
    public CreateRetransferDataIn findCreateRetransferData(Long finDocId, BigDecimal debitAmount, BigDecimal creditAmount) {
        String sql = """ 
                select fd.Account_IDREF                                                           as senderAccountId,
                       coalesce(t.SenderCard_IDREF, ct.DebitCard_IDREF, it.SenderCard_IDREF)      as senderCardId,
                       fd.FinDoc_ID                                                               as finDocId,
                       fd.FinDocType_IDREF                                                        as finDocType,
                       coalesce(t.TransferType_IDREF, ct.CardTransferType_IDREF, it.TransferType) as transferType,
                       fd.Currency                                                                as senderCurrency,
                       t.Receiver_Currency                                                        as receiverCurrency
                from FinDoc fd
                         left join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                         left join CardTransfer ct on fd.FinDoc_ID = ct.FinDoc_IDREF
                         left join IPSTransfer it on fd.FinDoc_ID = it.FinDoc_IDREF
                where fd.FinDoc_ID = :finDocId
                """;

        List<CreateRetransferDataIn> queryResult = template.query(
                sql,
                Map.of("finDocId", finDocId),
                (rs, i) -> CreateRetransferMapper.map(rs, debitAmount, creditAmount));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, " RetransferRepository findCreateRetransferData"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, " RetransferRepository findCreateRetransferData");
        } else {
            throw new AppException(E_DB_601, ": RetransferRepository findCreateRetransferData");
        }
    }

    @Override
    public LocalRetransferDataIn getRetransferData(Long finDocId) {
        TransferEntity transfer = transferJpaRepository
                .findByFinDocId(finDocId)
                .orElseThrow(() -> new AppException(E_DB_600, ": RetransferRepository findByFinDocId"));
        return new LocalRetransferDataIn(
                transfer.getType(),
                transfer.getKnpId(),
                transfer.getReceiverAccountNumber(),
                transfer.getReceiverCardId()
        );
    }
}
