package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public class FavoriteTransferResponse<T> {
    @Schema(description = "Id сохраненного перевода")
    private Long id;
    @Schema(description = "Тип перевода")
    private String finDocType;
    @Schema(description = "Кастомный заголовок с проиоритетом для отображения в общем списке если null отображаем стандартный заголовок")
    private String pseudonym;
    @Schema(description = "Стандартный заголовок")
    private String title;
    @Schema(description = "Подзаголовок")
    private String subTitle;
    @Schema(description = "Тип аккаунта")
    private String accountType;
    @Schema(description = "Иконка")
    private String image;
    @Schema(description = "LINKKK")
    private String link;
    @Schema(description = "Id отправителя")
    private Long senderAccountId;
    @Schema(description = "Детали перевода для каждого типа они свой")
    private T details;

    @Override
    public String toString() {
        return "FavoriteTransferDisplay[" +
                "id=" + id + ", " +
                "finDocType=" + finDocType + ", " +
                "pseudonym=" + pseudonym + ", " +
                "title=" + title + ", " +
                "subTitle=" + subTitle + ", " +
                "accountType=" + accountType + ", " +
                "image=" + image + ", " +
                "link=" + link + ", " +
                "details=" + details + ']';
    }

}
