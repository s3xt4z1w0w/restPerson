package eub.smart.cardproduct.transfer.generic.core.util;

import java.util.List;

public class NameUtil {

    public static String getSenderDisplayName(String fullname) {
        if (StringUtil.isEmpty(fullname)) return fullname;
        StringBuilder displayName = new StringBuilder();
        List<String> nameList = StringUtil.split(fullname, " ");
        for (int i = 0; i < nameList.size(); i++) {
            if (i == 1) {
                String lastName = nameList.get(i);
                char upperCase = Character.toUpperCase(lastName.charAt(0));
                displayName.append(upperCase).append(".");
            } else if (i == 0) {
                String firstName = nameList.get(i).toLowerCase();
                String firstLetter = String.valueOf(firstName.charAt(0));
                String upperFirstLetter = String.valueOf(Character.toUpperCase(firstName.charAt(0)));
                firstName = firstName.replaceFirst(firstLetter, upperFirstLetter);
                displayName.insert(0, " ").insert(0, firstName);
            } else if (i == 2) {
                String lastName = nameList.get(i);
                char upperCase = Character.toUpperCase(lastName.charAt(0));
                displayName.append(" ").append(upperCase).append(".");
            } else {
                break;
            }
        }
        return displayName.toString();
    }

    public static String getDisplayName(String fullname) {
        StringBuilder displayName = new StringBuilder();
        if (StringUtil.isEmpty(fullname)) return fullname;
        List<String> nameList = StringUtil.split(fullname, " ");
        for (int i = 0; i < nameList.size(); i++) {
            if (i == 0) {
                String lastName = nameList.get(i);
                char upperCase = Character.toUpperCase(lastName.charAt(0));
                displayName.append(upperCase).append(".");
            } else if (i == 1) {
                String firstName = nameList.get(i).toLowerCase();
                String firstLetter = String.valueOf(firstName.charAt(0));
                String upperFirstLetter = String.valueOf(Character.toUpperCase(firstName.charAt(0)));
                firstName = firstName.replaceFirst(firstLetter, upperFirstLetter);
                displayName.insert(0, " ").insert(0, firstName);
            } else {
                break;
            }
        }
        return displayName.toString();
    }
}
