package eub.smart.cardproduct.transfer.generic.core.constant;

public interface Fields {
    String SUM = "sum";
    String SOURCE = "source";
    String TARGET = "target";
    String MESSAGE = "message";
    String CARD = "card";
    String PHONE = "phone";
}
