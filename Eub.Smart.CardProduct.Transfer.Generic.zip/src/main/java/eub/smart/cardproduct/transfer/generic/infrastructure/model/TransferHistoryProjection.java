package eub.smart.cardproduct.transfer.generic.infrastructure.model;


import java.math.BigDecimal;
import java.util.Date;

public interface TransferHistoryProjection {

    Long getId();
    String getFromm();
    String getFromSuffix();
    String getTitle();
    String getImageUid();
    String getNumber();
    String getMessage();
    BigDecimal getAmount();
    String getCurrency();
    Date getDateCreated();
    String getStatus();
    String getFinDocType();
    String getSubType();
    String getAccountType();
}
