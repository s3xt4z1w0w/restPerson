package eub.smart.cardproduct.transfer.generic.core.util;

import org.slf4j.MDC;

import java.util.Locale;

import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;

public class LocaleUtil {

    public static Locale getCurrentLocale() {
        return new Locale(MDC.get(LANG_KEY));
    }

    public static String getCurrentLocaleString() {
        return MDC.get(LANG_KEY);
    }
}
