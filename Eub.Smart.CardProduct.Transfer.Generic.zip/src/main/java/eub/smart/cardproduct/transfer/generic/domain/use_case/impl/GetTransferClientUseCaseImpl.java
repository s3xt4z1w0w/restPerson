package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientAdditionalDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.ClientOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.PersonRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.ClientRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetTransferClientUseCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_801;

@Service
public class GetTransferClientUseCaseImpl implements GetTransferClientUseCase {

    private final Logger log = LogManager.getLogger(getClass());
    private final PersonRepository personRepository;
    private final ClientRepository clientRepository;

    public GetTransferClientUseCaseImpl(PersonRepository personRepository,
                                        ClientRepository clientRepository) {
        this.personRepository = personRepository;
        this.clientRepository = clientRepository;
    }

    @Override
    public CreateTransferClientAdditionalDataIn invoke(String accountNumber) {
        var client = clientRepository.findByAccountNumberOrException(accountNumber);
        if (isPerson(client)) {
            return personRepository.findNewTransferClientOrException(client.getPersonId());
        } else {
            log.error("Client is not Person");
            throw new AppException(E_LG_801, ": Client is not person");
        }
    }

    private boolean isCorp(ClientOut client) {
        return Objects.nonNull(client.getCorporationId());
    }

    private boolean isPerson(ClientOut client) {
        return Objects.nonNull(client.getPersonId());
    }
}
