package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteLocalTransferIn;

import java.util.Optional;

public interface FavoriteLocalTransferRepository {

    CreateFavoriteLocalTransferIn findByFinDocIdOrException(Long id);
    Optional<CreateFavoriteLocalTransferIn> findByFinDocId(Long id);
}
