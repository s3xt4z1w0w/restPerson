package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateFinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.CardRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.VisaAliasTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFinDocUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateVisaTransferUseCase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CreateVisaTransferUseCaseImpl implements CreateVisaTransferUseCase {

    private final CreateFinDocUseCase createFinDocUseCase;
    private final VisaAliasTransferRepository visaAliasTransferRepository;
    private final CardRepository cardRepository;

    public CreateVisaTransferUseCaseImpl(CreateFinDocUseCase createFinDocUseCase,
                                         VisaAliasTransferRepository visaAliasTransferRepository,
                                         CardRepository cardRepository,
                                         @Value("${app.eubankBIC}") String eubankBIC) {
        this.createFinDocUseCase = createFinDocUseCase;
        this.visaAliasTransferRepository = visaAliasTransferRepository;
        this.cardRepository = cardRepository;
    }

    @Override
    public FinDocOut invoke(CreateRetransferDataIn in) {
        var createFinDoc = getFinDocData(in);
        return createFinDocUseCase.invoke(createFinDoc);
    }

    private CreateFinDocOut getFinDocData(CreateRetransferDataIn in) {
        var cardInfo = cardRepository.findByIdOrException(in.senderCardId(), in.senderAccountId());
        var amount = in.debitAmount();
        var fee = visaAliasTransferRepository.getFee(cardInfo.getCardOutRef(), amount);
        var feeAmount = fee.feeAmount();
        return new CreateFinDocOut(in, feeAmount);
    }
}
