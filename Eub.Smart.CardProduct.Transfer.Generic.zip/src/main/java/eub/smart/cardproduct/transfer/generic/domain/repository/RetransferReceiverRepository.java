package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.AccountTargetOut;

import java.util.Optional;
import java.util.Set;

public interface RetransferReceiverRepository {

    Optional<AccountTargetOut> findByFinDocId(Long finDocId);

    AccountTargetOut findByFinDocIdOrException(Long finDocId);

    Set<String> keys();
}
