package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;



import java.math.BigDecimal;


public class AccountBalanceIn {
    private Long accountOutRef;
    private BigDecimal amount;
    private String currency;

    public AccountBalanceIn(Long accountOutRef, BigDecimal amount, String currency) {
        this.accountOutRef = accountOutRef;
        this.amount = amount;
        this.currency = currency;
    }

    public Long getAccountOutRef() {
        return accountOutRef;
    }

    public void setAccountOutRef(Long accountOutRef) {
        this.accountOutRef = accountOutRef;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
