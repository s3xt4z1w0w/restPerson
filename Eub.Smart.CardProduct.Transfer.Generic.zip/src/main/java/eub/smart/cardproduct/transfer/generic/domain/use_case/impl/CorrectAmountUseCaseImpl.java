package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CurrencyRateIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CorrectAmountOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CurrencyExchangeOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.RsbkInfoProtoRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CorrectAmountUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CurrencyExchangeRateUseCase;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.KZT;

@Service
public class CorrectAmountUseCaseImpl implements CorrectAmountUseCase {

    private final RsbkInfoProtoRepository rsbkInfoProtoRepository;
    private final CurrencyExchangeRateUseCase currencyExchangeRateUseCase;
    private final CurrencyRateIn KZT_RATE = new CurrencyRateIn(new BigDecimal("1"), new BigDecimal("1"), KZT);
    private final BigDecimal LOWEST_SELL_RATE = new BigDecimal("0.01");
    private final Integer SCALE_RATE = 2;

    public CorrectAmountUseCaseImpl(RsbkInfoProtoRepository rsbkInfoProtoRepository,
                                    CurrencyExchangeRateUseCase currencyExchangeRateUseCase) {
        this.rsbkInfoProtoRepository = rsbkInfoProtoRepository;
        this.currencyExchangeRateUseCase = currencyExchangeRateUseCase;
    }

    @Override
    public CorrectAmountOut invoke(BigDecimal amount,
                                   String senderAccountCurrency,
                                   String receiverAccountCurrency) {
        var senderCurrencyRate = rsbkInfoProtoRepository.findCurrencyRate(senderAccountCurrency);
        var receiverCurrencyRate = rsbkInfoProtoRepository.findCurrencyRate(receiverAccountCurrency);
        return invoke(amount, senderCurrencyRate, receiverCurrencyRate);
    }

    @Override
    public CorrectAmountOut invoke(BigDecimal amount,
                                   CurrencyRateIn senderCurrencyRate,
                                   CurrencyRateIn receiverCurrencyRate) {
        var currencyExchange = currencyExchangeRateUseCase.invoke(senderCurrencyRate, receiverCurrencyRate);
        if (isSameCurrency(senderCurrencyRate.currency(), receiverCurrencyRate.currency())) {
            return new CorrectAmountOut(amount, amount, currencyExchange);
        } else if (isStraight(senderCurrencyRate.currency(), receiverCurrencyRate.currency())) {
            return calcStraightConversion(amount, senderCurrencyRate, receiverCurrencyRate, currencyExchange, LOWEST_SELL_RATE);
        } else {
            return calcCrossConversion(amount, senderCurrencyRate, receiverCurrencyRate, currencyExchange);
        }
    }

    private CorrectAmountOut calcStraightConversion(BigDecimal amount,
                                                    CurrencyRateIn senderCurrencyRate,
                                                    CurrencyRateIn receiverCurrencyRate,
                                                    CurrencyExchangeOut currencyExchange,
                                                    BigDecimal senderSellRate) {
        if (KZT.equals(senderCurrencyRate.currency())) {
            return calcSenderAccCurrencyKzt(amount, receiverCurrencyRate, senderSellRate, currencyExchange);
        } else {
            return calcReceiverAccCurrencyKzt(amount, senderCurrencyRate, currencyExchange);
        }
    }

    private CorrectAmountOut calcSenderAccCurrencyKzt(BigDecimal amount,
                                                      CurrencyRateIn receiverAccCurrencyRate,
                                                      BigDecimal senderSellRate,
                                                      CurrencyExchangeOut currencyExchange) {
        var receiverSellRate = receiverAccCurrencyRate.sellRate();
        var resDivideToReceiverSellRate = amount.divide(receiverSellRate, SCALE_RATE, RoundingMode.HALF_UP);
        if (isEqualZero(resDivideToReceiverSellRate)) resDivideToReceiverSellRate = LOWEST_SELL_RATE;
        if (isReceiverSellRateGreater(senderSellRate, receiverSellRate)) {
            amount = resDivideToReceiverSellRate.multiply(receiverSellRate).setScale(SCALE_RATE, RoundingMode.HALF_UP);
        }
        return new CorrectAmountOut(amount, resDivideToReceiverSellRate, currencyExchange);
    }

    private CorrectAmountOut calcReceiverAccCurrencyKzt(BigDecimal amount,
                                                        CurrencyRateIn senderAccCurrencyRate,
                                                        CurrencyExchangeOut currencyExchange) {
        var senderBuyRate = senderAccCurrencyRate.buyRate();
        var correctAmount = amount.setScale(SCALE_RATE, RoundingMode.HALF_DOWN);
        var receiverAmount = correctAmount.multiply(senderBuyRate).setScale(SCALE_RATE, RoundingMode.HALF_DOWN);
        return new CorrectAmountOut(correctAmount, receiverAmount, currencyExchange);
    }

    private CorrectAmountOut calcCrossConversion(BigDecimal amount,
                                                 CurrencyRateIn senderCurrencyRate,
                                                 CurrencyRateIn receiverCurrencyRate,
                                                 CurrencyExchangeOut currencyExchange) {
        if (amount.compareTo(new BigDecimal("1")) < 0) {
            amount = new BigDecimal("1");
        }
        var senderConvertingInfo = calcStraightConversion(amount, senderCurrencyRate, KZT_RATE, currencyExchange, LOWEST_SELL_RATE);
        var amountKzt = senderConvertingInfo.receiverAmount();
        var senderSellRate = senderCurrencyRate.sellRate();
        var senderBuyRate = senderCurrencyRate.buyRate();

        var receiverConvertingInfo = calcStraightConversion(amountKzt, KZT_RATE, receiverCurrencyRate, currencyExchange, senderSellRate);
        var correctAmountKzt = receiverConvertingInfo.correctAmount();
        var correctAmount = correctAmountKzt.divide(senderBuyRate, SCALE_RATE, RoundingMode.HALF_UP);

        return new CorrectAmountOut(correctAmount, receiverConvertingInfo.receiverAmount(), currencyExchange);
    }

    private boolean isEqualZero(BigDecimal resMultiplyToHundred) {
        resMultiplyToHundred = resMultiplyToHundred.setScale(SCALE_RATE, RoundingMode.HALF_DOWN);
        var zero = new BigDecimal(0);
        return resMultiplyToHundred.compareTo(zero) <= 0;
    }

    private boolean isStraight(String senderAccountCurrency, String receiverAccountCurrency) {
        return KZT.equals(senderAccountCurrency) || KZT.equals(receiverAccountCurrency);
    }

    private boolean isReceiverSellRateGreater(BigDecimal senderSellRate, BigDecimal receiverSellRate) {
        return senderSellRate.compareTo(receiverSellRate) < 0;
    }

    private boolean isSameCurrency(String senderAccountCurrency, String receiverAccountCurrency) {
        return senderAccountCurrency.equals(receiverAccountCurrency);
    }
}
