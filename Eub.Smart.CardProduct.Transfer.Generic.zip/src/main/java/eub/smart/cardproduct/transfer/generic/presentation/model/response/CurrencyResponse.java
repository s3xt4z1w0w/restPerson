package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public record CurrencyResponse(
        @Schema(description = "Код валюты")
        String code,

        @Schema(description = "Символ валюты")
        String symbol
) {
}
