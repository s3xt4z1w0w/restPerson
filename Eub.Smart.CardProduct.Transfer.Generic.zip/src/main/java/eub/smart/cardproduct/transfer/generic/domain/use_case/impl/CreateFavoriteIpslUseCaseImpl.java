package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteIpsTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFavoriteUseCase;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.IPSL;

@Service
public class CreateFavoriteIpslUseCaseImpl implements CreateFavoriteUseCase {

    private final FavoriteIpsTransferRepository favoriteIpsTransferRepository;
    private final FavoriteAcctTransferRepository favoriteAcctTransferRepository;

    public CreateFavoriteIpslUseCaseImpl(FavoriteIpsTransferRepository favoriteIpsTransferRepository, FavoriteAcctTransferRepository favoriteAcctTransferRepository) {
        this.favoriteIpsTransferRepository = favoriteIpsTransferRepository;
        this.favoriteAcctTransferRepository = favoriteAcctTransferRepository;
    }

    @Override
    public Long invoke(Long finDocId) {
        var favoriteIpsTransfer = favoriteIpsTransferRepository.findByFinDocIdOrException(finDocId);
        var favoriteAccTransfer = new FavoriteAccTransferOut(favoriteIpsTransfer);
        var saved = favoriteAcctTransferRepository.save(favoriteAccTransfer);
        return saved.favoriteTransferIn().id();
    }

    @Override
    public Set<String> keySet() {
        return Set.of(IPSL);
    }
}
