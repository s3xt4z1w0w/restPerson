package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldError;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FeeOutgoingIIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.*;
import eub.smart.cardproduct.transfer.generic.domain.use_case.ValidateLimitUseCase;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.DocTechStatus.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.Fields.SUM;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_VD_402;
import static eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil.getCurrentLocale;

@Service
public class ValidateLimitUseCaseImpl implements ValidateLimitUseCase {

    private final CardRepository cardRepository;
    private final AggregatorP2PTransferRepository aggregatorP2PTransferRepository;
    private final VisaAliasTransferRepository visaAliasTransferRepository;
    private final FinDocStateRepository finDocStateRepository;
    private final MessageSourceRepository messageSourceRepository;

    public ValidateLimitUseCaseImpl(CardRepository cardRepository,
                                    AggregatorP2PTransferRepository aggregatorP2PTransferRepository,
                                    VisaAliasTransferRepository visaAliasTransferRepository,
                                    FinDocStateRepository finDocStateRepository,
                                    MessageSourceRepository messageSourceRepository) {
        this.cardRepository = cardRepository;
        this.aggregatorP2PTransferRepository = aggregatorP2PTransferRepository;
        this.visaAliasTransferRepository = visaAliasTransferRepository;
        this.finDocStateRepository = finDocStateRepository;
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public void invoke(Long finDocId, String favTransferType, Long cardId, BigDecimal amount) {
        List<FieldError> fieldErrors = new ArrayList<>();
        var cardInfo = cardRepository.findByCardIdOrException(cardId);
        var fee = getFee(cardInfo.cardOutRef(), amount, favTransferType);
        var operationAmount = fee.feeAmount().add(amount);
        if (isLimitLess(operationAmount, fee.operationLimitAmount())) {
            finDocStateRepository.saveFinDocStatus(VLAL, finDocId);
            addFieldError(fieldErrors, SUM_FIELD_MORE_THAN_LIMIT_FINDOC, getCurrentLocale(), fee.operationLimitAmount());
        }
        if (isLimitLess(operationAmount, fee.dayLimitAmount())) {
            finDocStateRepository.saveFinDocStatus(VLDL, finDocId);
            addFieldError(fieldErrors, SUM_FIELD_MORE_THAN_LIMIT_DAY, getCurrentLocale(), fee.dayLimitAmount());
        }
        if (isLimitLess(operationAmount, fee.monthLimitAmount())) {
            finDocStateRepository.saveFinDocStatus(VLML, finDocId);
            addFieldError(fieldErrors, SUM_FIELD_MORE_THAN_LIMIT_MONTH, getCurrentLocale(), fee.monthLimitAmount());
        }
    }

    private boolean isLimitLess(BigDecimal operationAmount, BigDecimal limitAmount) {
        return limitAmount.compareTo(operationAmount) < 0;
    }

    private void addFieldError(List<FieldError> fieldErrors, String errorCode, Locale lang, Object... args) {
        fieldErrors.add(new FieldError(SUM, messageSourceRepository.getMessage(errorCode, args, lang)));
        throw new AppException(E_VD_402, new FieldsValidationResponse(null, fieldErrors));
    }

    private FeeOutgoingIIn getFee(Long cardOutRef, BigDecimal amount, String favTransferType) {
        if (favTransferType.equals(FavoriteTransferType.P2PO.name())) {
            return aggregatorP2PTransferRepository.getFee(cardOutRef, amount);
        } else {
            return visaAliasTransferRepository.getFee(cardOutRef, amount);
        }
    }
}
