package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

public record AmountResponse(
        @Schema(description = "Сумма перевода")
        BigDecimal value,

        @Schema(description = "Валюта")
        CurrencyResponse currency
) {
}
