package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.Error;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import eub.smart.cardproduct.transfer.generic.domain.repository.BSystemRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.ValidateBSystemAvailabilityUseCase;
import org.springframework.stereotype.Service;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.ERROR_TECHNICAL_SUBTITLE;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.ERROR_TECHNICAL_TITLE;
import static eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil.getCurrentLocale;

@Service
public class ValidateBSystemAvailabilityUseCaseImpl implements ValidateBSystemAvailabilityUseCase {

    private final BSystemRepository bSystemRepository;
    private final MessageSourceRepository messageSourceRepository;

    public ValidateBSystemAvailabilityUseCaseImpl(BSystemRepository bSystemRepository,
                                                  MessageSourceRepository messageSourceRepository) {
        this.bSystemRepository = bSystemRepository;
        this.messageSourceRepository = messageSourceRepository;
    }


    public void invoke(String bSystem, String lang) {
        var inactiveBSystemCount = bSystemRepository.findActiveBSystemCount(bSystem)
                .orElseThrow(() -> new AppException(AppErrorCode.E_DB_600, ": BSystemRepository findActiveBSystemCount"));
        if (inactiveBSystemCount != 0) {
            var locale = getCurrentLocale();
            var error = new Error(messageSourceRepository.getMessage(ERROR_TECHNICAL_TITLE, locale),
                    messageSourceRepository.getMessage(ERROR_TECHNICAL_SUBTITLE, locale));
            throw new AppException(AppErrorCode.E_EX_701, new FieldsValidationResponse(error, null));
        }
    }
}
