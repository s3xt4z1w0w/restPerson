package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteP2pTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFavoriteUseCase;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.P2PX;

@Service
public class CreateFavoriteP2poUseCaseImpl implements CreateFavoriteUseCase {

    private final FavoriteP2pTransferRepository favoriteP2pTransferRepository;

    public CreateFavoriteP2poUseCaseImpl(FavoriteP2pTransferRepository favoriteP2pTransferRepository) {
        this.favoriteP2pTransferRepository = favoriteP2pTransferRepository;
    }

    @Override
    public Long invoke(Long finDocId) {
        var favoriteP2pTransferOut = favoriteP2pTransferRepository.findP2poByFinDocIdOrException(finDocId);
        return favoriteP2pTransferRepository.save(favoriteP2pTransferOut);
    }

    @Override
    public Set<String> keySet() {
        return Set.of(P2PX);
    }
}
