package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountSourceIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferSelfIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferSelfAccountsOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.GetRetransferAccountsRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.RetransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetRetransferSelfAccountsUseCase;
import org.springframework.stereotype.Service;

import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_SM_500;
import static java.util.Objects.nonNull;

@Service
public class GetRetransferSelfAccountsUseCaseImpl implements GetRetransferSelfAccountsUseCase {

    private final RetransferRepository retransferRepository;
    private final GetRetransferAccountsRepository getRetransferAccountsRepository;

    public GetRetransferSelfAccountsUseCaseImpl(RetransferRepository retransferRepository,
                                                GetRetransferAccountsRepository getRetransferAccountsRepository) {
        this.retransferRepository = retransferRepository;
        this.getRetransferAccountsRepository = getRetransferAccountsRepository;
    }

    @Override
    public RetransferSelfAccountsOut invoke(Long finDocId) {
        var transfer = retransferRepository.findSenderReceiverCardIdAndAccId(finDocId);
        var accountList = getRetransferAccountsRepository.findAccountList();
        var senderAccount = defineSenderAccount(accountList, transfer);
        var receiverAccount = defineReceiverAccount(accountList, transfer);
        return new RetransferSelfAccountsOut(senderAccount, receiverAccount);
    }

    private AccountSourceIn defineSenderAccount(List<AccountSourceIn> accountList, CreateRetransferSelfIn transferData) {
        return defineAccount(accountList,
                transferData.getSenderAccountId(),
                transferData.getSenderCardId(),
                transferData.getSenderCurrency());
    }

    private AccountSourceIn defineReceiverAccount(List<AccountSourceIn> accountList, CreateRetransferSelfIn transferData) {
        return defineAccount(accountList,
                transferData.getReceiverAccountId(),
                transferData.getReceiverCardId(),
                transferData.getReceiverCurrency());
    }

    private AccountSourceIn defineAccount(List<AccountSourceIn> accountList, Long accountId, Long cardId, String currency) {
        return accountList
                .stream()
                .filter(acc -> nonNull(cardId) &&
                        cardId.equals(acc.cardId()) &&
                        accountId.equals(acc.accountId()) &&
                        currency.equals(acc.amount().currency().code()))
                .findFirst()
                .or(() -> accountList
                        .stream()
                        .filter(acc -> accountId.equals(acc.accountId()) &&
                                currency.equals(acc.amount().currency().code()))
                        .findFirst())
                .orElseThrow(() -> new AppException(E_SM_500, ": sender account not found"));
    }
}
