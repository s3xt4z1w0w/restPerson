package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.infrastructure.entity.FeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FeeJpaRepository extends JpaRepository<FeeEntity, Long> {

    @Query(nativeQuery = true, value = """
            SELECT f.*
            FROM map_Product_Operation mpo
                     JOIN Product p ON
                p.Product_ID = mpo.Product_IDREF
                     JOIN Account a ON
                a.Product_IDREF = p.Product_ID
                     Join Operation o ON
                o.Operation_ID = mpo.Operation_IDREF
                     JOIN TransferType tt ON
                tt.Operation_IDREF = o.Operation_ID
                     JOIN Fee f ON
                f.Fee_ID = mpo.Fee_IDREF
            WHERE tt.TransferType_ID = 'IPSO'
              and a.Account_ID = :accountId
            """)
    FeeEntity findFeeByAccountId(Long accountId);

}
