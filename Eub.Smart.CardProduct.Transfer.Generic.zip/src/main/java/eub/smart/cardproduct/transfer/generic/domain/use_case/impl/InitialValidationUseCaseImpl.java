package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldError;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocStateRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.InitialValidationUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.ValidateAmountFieldUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.ValidateBSystemAvailabilityUseCase;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_VD_402;
import static eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil.getCurrentLocaleString;

@Service
public class InitialValidationUseCaseImpl implements InitialValidationUseCase {

    private final ValidateAmountFieldUseCase validateAmountFieldUseCase;
    private final ValidateBSystemAvailabilityUseCase validateBSystemAvailabilityUseCase;
    private final FinDocRepository finDocRepository;

    public InitialValidationUseCaseImpl(ValidateAmountFieldUseCase validateAmountFieldUseCase,
                                        ValidateBSystemAvailabilityUseCase validateBSystemAvailabilityUseCase,
                                        FinDocRepository finDocRepository) {
        this.validateAmountFieldUseCase = validateAmountFieldUseCase;
        this.validateBSystemAvailabilityUseCase = validateBSystemAvailabilityUseCase;
        this.finDocRepository = finDocRepository;
    }

    @Override
    public void invoke(Long finDocId) {
        var transferValidate = finDocRepository.findTransferData(finDocId);
        List<FieldError> fieldErrors = new ArrayList<>();
        validateAmountFieldUseCase.invoke(transferValidate, fieldErrors);
        validateBSystemAvailabilityUseCase.invoke(transferValidate.bSystem(), getCurrentLocaleString());
        if(!fieldErrors.isEmpty()) {
            throw new AppException(E_VD_402, new FieldsValidationResponse(null, fieldErrors));
        }
    }
}
