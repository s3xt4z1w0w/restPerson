package eub.smart.cardproduct.transfer.generic.presentation.model.request;

import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public record CreateRepeatTransferRequest(

        @NotNull
        @Schema(description = "Id фин дока", required = true)
        Long finDocId,

        @NotNull
        @Schema(description = "Сумма списания", required = true)
        BigDecimal debitAmount,

        @NotNull
        @Schema(description = "Сумма зачисления", required = true)
        BigDecimal creditAmount
) {
}

