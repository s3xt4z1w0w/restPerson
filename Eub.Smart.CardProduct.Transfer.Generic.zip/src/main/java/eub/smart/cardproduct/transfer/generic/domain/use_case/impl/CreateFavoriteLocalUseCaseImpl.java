package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteLocalTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFavoriteUseCase;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.LOCT;

@Service
public class CreateFavoriteLocalUseCaseImpl implements CreateFavoriteUseCase {

    private final FavoriteLocalTransferRepository favoriteLocalTransferRepository;
    private final FavoriteAcctTransferRepository favoriteAcctTransferRepository;

    public CreateFavoriteLocalUseCaseImpl(FavoriteLocalTransferRepository favoriteLocalTransferRepository,
                                          FavoriteAcctTransferRepository favoriteAcctTransferRepository) {
        this.favoriteLocalTransferRepository = favoriteLocalTransferRepository;
        this.favoriteAcctTransferRepository = favoriteAcctTransferRepository;
    }

    @Override
    public Long invoke(Long finDocId) {
        var in = favoriteLocalTransferRepository.findByFinDocIdOrException(finDocId);
        var out = new FavoriteAccTransferOut(in);
        var saved = favoriteAcctTransferRepository.save(out);
        return saved.favoriteTransferIn().id();
    }

    @Override
    public Set<String> keySet() {
        return Set.of(LOCT);
    }
}
