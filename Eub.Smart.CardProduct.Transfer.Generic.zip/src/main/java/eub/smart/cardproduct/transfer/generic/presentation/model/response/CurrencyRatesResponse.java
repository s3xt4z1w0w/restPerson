package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import java.util.List;

public record CurrencyRatesResponse(
        String alertTitle,
        List<CurrencyRateResponse> currencies
) {
}
