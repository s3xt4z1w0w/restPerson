package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;

import java.util.Optional;
import java.util.Set;

public interface ReceiptRepository {

    Optional<TransferReceiptOut> findByFinDocId(Long finDocId);

    TransferReceiptOut findByFinDocIdOrException(Long finDocId);

    Set<String> keys();
}
