package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import lombok.Builder;
import lombok.Data;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import java.util.List;

@Data
@Builder
public class ReceiptDocumentIn {
    private String statusTitle;
    private String amount;
    private String receiver;
    private String transferType;
    private String image;
    private List<KeyValueIn> details;
    private List<KeyValueIn> mainDetails;
}
