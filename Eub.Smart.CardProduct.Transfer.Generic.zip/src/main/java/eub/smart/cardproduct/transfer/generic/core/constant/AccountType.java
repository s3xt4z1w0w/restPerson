package eub.smart.cardproduct.transfer.generic.core.constant;

public interface AccountType {

    String SAVE = "SAVE";
    String SAVS = "SAVS";
    String SAVL = "SAVL";
    String CURR = "CURR";
    String CARD = "CARD";
    String BONS = "BONS";
    String BANK = "BANK";


    static boolean isDeposit(String accountType) {
        return SAVE.equals(accountType);
    }
}
