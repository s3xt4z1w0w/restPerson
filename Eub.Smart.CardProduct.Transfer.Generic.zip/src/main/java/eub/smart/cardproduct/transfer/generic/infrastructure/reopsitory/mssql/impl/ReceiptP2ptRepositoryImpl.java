package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.ReceiptRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.ReceiptP2ptMapper;
import org.slf4j.MDC;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I13B;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.P2PF;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.P2PR;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.P2PT;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class ReceiptP2ptRepositoryImpl implements ReceiptRepository {

    private final NamedParameterJdbcTemplate template;
    private final ReceiptP2ptMapper receiptP2ptMapper;
    private final AuthToken authToken;

    public ReceiptP2ptRepositoryImpl(NamedParameterJdbcTemplate template,
                                     ReceiptP2ptMapper receiptP2ptMapper,
                                     AuthToken authToken) {
        this.template = template;
        this.receiptP2ptMapper = receiptP2ptMapper;
        this.authToken = authToken;
    }

    @Override
    public Optional<TransferReceiptOut> findByFinDocId(Long finDocId) {
        var langKey = MDC.get(LANG_KEY);
        var userDetails = UserDetails.build(authToken.getDecodedPayload());
        var userId = userDetails.getUserId();

        Map<String, Object> map = Map.of(
                "finDocId", finDocId,
                "userId", userId,
                "metaDocTypeBank", I13B,
                "langKey", langKey);

        String sql = """
                select fd.FinDoc_ID                                                as id,
                       case --find from by sender account product short name
                           when sacc_psn.ProductShortName_ID = 'DFCD' and p2pt.DebitCard_IDREF is not null then --Карточный счет
                               sct.CardType_Title
                           else
                               case
                                   when :langKey = 'KK' then trm_sacc_psn.Term_KZ
                                   when :langKey = 'RU' then trm_sacc_psn.Term_RU
                                   else trm_sacc_psn.Term_EN
                                   end
                           end                                                     as fromm,
                       case --find fromSuffix by sender account product short name
                           when sacc_psn.ProductShortName_ID = 'DFCD' and p2pt.DebitCard_IDREF is not null then --Карточный счет
                               (N' • ' + right(sc.MaskedNumber, 4))
                           else
                               (N' • ' + left(sacc.Number, 2) + right(sacc.Number, 4))
                           end                                                     as fromSuffix,
                       case --title
                           when p2pt.CardTransferType_IDREF = 'P2PL' then
                               p2pt.ReceiverName
                           when p2pt.CardTransferType_IDREF = 'P2PO' then
                               trm_b.Term_EN end                                   as title, --TODO title number
                       case --imageUid
                           when md.FileUid is not null then
                               md.FileUid
                           else
                               (select mdi.FileUid
                                from MetaDocument mdi with (nolock)
                                where mdi.Target_ID = 0
                                  and mdi.Target_Table = 'Bank'
                                  and mdi.DocumentType_IDREF = :metaDocTypeBank
                                  and mdi.LangKey = 'EN'
                                  and mdi.IsActive = 1) end                        as imageUid,
                       fd.Amount                                                   as amount,
                       fd.Currency                                                 as currency,
                       fd.DateCreated                                              as date,
                       fdss.FinDocStatus_ID                                        as status,
                       fd.Fee                                                      as feeAmount,
                       fd.FeeCurrency                                              as feeCurrency,
                       concat(sp.LastName, ' ', sp.FirstName, ' ', sp.FathersName) as senderFullName,
                       p2pt.CardTransferType_IDREF                                 as transferType,
                       tf.TransferFavorite_ID                                      as tfId
                from FinDoc fd with (nolock)
                         join dbo.[User] su with (nolock) on fd.User_IDREF = su.User_ID
                         join Person sp with (nolock) on su.Person_IDREF = sp.Person_ID
                         join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                         join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                         join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                         left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                         join CardTransfer p2pt with (nolock) on fd.FinDoc_ID = p2pt.FinDoc_IDREF
                         left join BinCard bc with (nolock) on bc.Bin = left(p2pt.CreditMaskedCardNumber, 6)
                         left join Bank b with (nolock) on bc.Bank_IDREF = b.Bank_ID
                         left join Term trm_b on trm_b.Term_ID = b.Term_OUTREF
                         left join MetaDocument md with (nolock)
                                   on md.Target_ID = b.Bank_ID
                                       and md.Target_Table = 'Bank'
                                       and md.DocumentType_IDREF = :metaDocTypeBank
                                       and md.LangKey = 'EN'
                                       and md.IsActive = 1
                         left join Card sc with (nolock) on p2pt.DebitCard_IDREF = sc.Card_ID --sender data start
                         left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                         join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                         left join map_User_Account mua with (nolock)
                                   on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                         left join AccountProduct sacc_ap with (nolock)
                                   on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                      sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join DepositProduct sacc_dp with (nolock)
                                   on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                      sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join CardAccountProduct sacc_cap with (nolock)
                                   on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                      sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join ProductShortName sacc_psn with (nolock)
                                   on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                      sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                      sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                         left join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                         left join TransferFavorite tf on tf.TransferFavorite_ID = (select top 1 tf.TransferFavorite_ID
                                                                                             from TransferFavorite tf
                                                                                                      join TransferAccFavorite taf with (nolock)
                                                                                                           on taf.TransferFavorite_IDREF = tf.TransferFavorite_ID
                                                                                             where tf.User_IDREF = fd.User_IDREF
                                                                                               and taf.AccountNumber = p2pt.AccountNumber)
                where fd.FinDoc_ID = :finDocId
                  and fd.User_IDREF = :userId
                  and dts.FinDocStatus_IDREF = 'DONE'
                  and p2pt.CardTransferType_IDREF in ('P2PL', 'P2PO')
                """;
        List<TransferReceiptOut> queryResult = template.query(sql, map, (resultSet, i) -> receiptP2ptMapper.toDomain(resultSet, langKey));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": ReceiptP2ptRepositoryImpl findByFinDocId");
        }
    }

    @Override
    public TransferReceiptOut findByFinDocIdOrException(Long finDocId) {
        return findByFinDocId(finDocId).
                orElseThrow(() -> new AppException(E_DB_600, ": ReceiptP2ptRepositoryImpl findByFinDocIdOrException"));
    }

    @Override
    public Set<String> keys() {
        return Set.of(P2PT, P2PF, P2PR);
    }
}
