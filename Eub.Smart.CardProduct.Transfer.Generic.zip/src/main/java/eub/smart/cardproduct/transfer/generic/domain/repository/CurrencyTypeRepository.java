package eub.smart.cardproduct.transfer.generic.domain.repository;

import java.util.Optional;

public interface CurrencyTypeRepository {

    Optional<String> findImageUid(String currency, String targetTable, String documentType);
}
