package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.constant.BundleCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.Error;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.AituPayVerificationOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.IpsoReceiverDataOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.IpsOrgRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.IpsRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.TransferIPSOutgoingAggregatorRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetAituPayVerificationUseCase;
import org.springframework.stereotype.Service;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.*;

@Service
public class GetAituPayVerificationUseCaseImpl implements GetAituPayVerificationUseCase {

    private final IpsRepository ipsRepository;
    private final IpsOrgRepository ipsOrgRepository;
    private final TransferIPSOutgoingAggregatorRepository transferIPSOutgoingAggregatorRepository;
    private final MessageSourceRepository messageSourceRepository;

    public GetAituPayVerificationUseCaseImpl(IpsRepository ipsRepository,
                                             IpsOrgRepository ipsOrgRepository,
                                             TransferIPSOutgoingAggregatorRepository transferIPSOutgoingAggregatorRepository,
                                             MessageSourceRepository messageSourceRepository) {
        this.ipsRepository = ipsRepository;
        this.ipsOrgRepository = ipsOrgRepository;
        this.transferIPSOutgoingAggregatorRepository = transferIPSOutgoingAggregatorRepository;
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public IpsoReceiverDataOut invoke(Long finDocId) {
        var receiverInfo = ipsRepository.findReceiverPhoneByFinDocId(finDocId);
        var reverseDomain = ipsOrgRepository.findReverseDomainByBic(receiverInfo.receiverBic())
                .orElseThrow(() -> new AppException(E_DB_600));
        var request = new AituPayVerificationOut(receiverInfo.receiverPhone(), reverseDomain);
        var response = transferIPSOutgoingAggregatorRepository.getVerification(request);
        isOwnerChanged(receiverInfo.receiverName(), response.receiverName());
        return new IpsoReceiverDataOut(receiverInfo, response);
    }

    private void isOwnerChanged(String favoriteReceiverName, String aituReceiverName) {
        if (!favoriteReceiverName.equals(aituReceiverName)) {
            var error = new Error(messageSourceRepository.getMessage(BundleCode.PHONE_NUMBER_OWNER_CHANGED, LocaleUtil.getCurrentLocale()),
                    messageSourceRepository.getMessage(BundleCode.SUBTITLE_DELETE_FROM_FAVORITE, LocaleUtil.getCurrentLocale()));
            throw new AppException(E_VD_402, new FieldsValidationResponse(error, null));
        }
    }
}
