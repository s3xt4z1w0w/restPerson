package eub.smart.cardproduct.transfer.generic.domain.model.in.presentation;

import java.time.LocalDate;

public record TransferHistoryIn(
        LocalDate from,

        LocalDate to
) {
}
