package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.constant.AccountType;
import eub.smart.cardproduct.transfer.generic.core.constant.TargetTable;
import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.LocalizedText;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteIpslTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteIpsoTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteIpsoTransferDetailsDisplayOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUB_TITLE_OUTGOING;
import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.KZT;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;
import static eub.smart.cardproduct.transfer.generic.core.util.ImageUtil.formImageUrl;

@Component
public class FavoriteIpsTransferMapper {

    private final LocalizedText subTitleOutgoing;

    public FavoriteIpsTransferMapper(MessageSourceRepositoryImpl messageSourceRepository) {
        String subTitleOutgoingRu = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.RU);
        String subTitleOutgoingKk = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.KK);
        String subTitleOutgoingEn = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.EN);
        this.subTitleOutgoing = new LocalizedText(subTitleOutgoingRu, subTitleOutgoingKk, subTitleOutgoingEn);
    }

    public CreateFavoriteIpslTransferIn toIpslDomain(ResultSet resultSet, int i) {
        try {
            Long finDocId = resultSet.getLong("finDocId");
            Long userId = resultSet.getLong("userId");
            String type = FavoriteTransferType.LOCT.name();
            String accountNumber = resultSet.getString("accountNumber");
            String title = resultSet.getString("title");
            Long imageId = resultSet.getLong("imageId");
            return new CreateFavoriteIpslTransferIn(
                    finDocId,
                    userId,
                    type,
                    accountNumber,
                    KZT,
                    title,
                    TargetTable.BANK,
                    imageId);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    public FavoriteTransferDisplayOut toDetailsDisplay(ResultSet resultSet, FavoriteTransferDisplayIn in, String langKey) {
        try {
            String title = resultSet.getString("title");
            String imageUid = resultSet.getString("imageUid");
            String organizationTitle = resultSet.getString("organizationTitle");
            String imageUrl = formImageUrl(imageUid);
            String subTitle = subTitleOutgoing.text(langKey);
            String finDocType = EnumUtil.valueOfOrException(FavoriteTransferType.class, in.getType()).finDocType();

            return new FavoriteTransferDisplayOut(
                    in.getId(),
                    finDocType,
                    in.getTitle(),
                    title,
                    subTitle,
                    AccountType.BANK,
                    imageUrl,
                    null,
                    in.getAccountId(),
                    new FavoriteIpsoTransferDetailsDisplayOut(organizationTitle));
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    public CreateFavoriteIpsoTransferIn toIpsoDomain(ResultSet resultSet, int i) {
        try {
            Long finDocId = resultSet.getLong("finDocId");
            Long userId = resultSet.getLong("userId");
            String type = FavoriteTransferType.IPSO.name();
            String receiverPhone = resultSet.getString("receiverPhone");
            String receiverName = resultSet.getString("receiverName");
            Long bankId = resultSet.getLong("bankId");
            return new CreateFavoriteIpsoTransferIn(
                    finDocId,
                    userId,
                    type,
                    receiverPhone,
                    KZT,
                    receiverName,
                    bankId);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }
}
