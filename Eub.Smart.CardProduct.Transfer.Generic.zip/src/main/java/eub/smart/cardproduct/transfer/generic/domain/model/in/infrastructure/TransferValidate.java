package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import java.math.BigDecimal;

public record TransferValidate(
        Long finDocId,
        Long accountId,
        String bSystem,
        String accountType,
        BigDecimal amount,
        String currency,
        String currencySymbol,
        Long accountOutRefId,
        BigDecimal feeAmount
) {
}
