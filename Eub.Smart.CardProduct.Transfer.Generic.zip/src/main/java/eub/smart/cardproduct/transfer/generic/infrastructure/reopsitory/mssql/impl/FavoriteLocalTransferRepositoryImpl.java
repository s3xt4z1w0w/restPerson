package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteLocalTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteLocalTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.FavoriteLocalTransferMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class FavoriteLocalTransferRepositoryImpl implements FavoriteLocalTransferRepository {

    private final Logger log = LogManager.getLogger(getClass());
    private final InfrastructureMapper mapper;
    private final FavoriteLocalTransferMapper favoriteLocalTransferMapper;
    private final String eubankBIC;
    private final NamedParameterJdbcTemplate template;
    private final AuthToken authToken;

    public FavoriteLocalTransferRepositoryImpl(InfrastructureMapper mapper,
                                               FavoriteLocalTransferMapper favoriteLocalTransferMapper,
                                               @Value("${app.eubankBIC}") String eubankBIC,
                                               NamedParameterJdbcTemplate template,
                                               AuthToken authToken) {
        this.mapper = mapper;
        this.favoriteLocalTransferMapper = favoriteLocalTransferMapper;
        this.eubankBIC = eubankBIC;
        this.template = template;
        this.authToken = authToken;
    }

    @Override
    public Optional<CreateFavoriteLocalTransferIn> findByFinDocId(Long id) {
        Long userId = UserDetails.build(authToken.getDecodedPayload()).getUserId();
        Map<String, Object> map = Map.of(
                "id", id,
                "userId", userId,
                "eubankBIC", eubankBIC);

        String sql = """
                select fd.FinDoc_ID       as finDocId,
                       fd.User_IDREF      as userId,
                       t.Receiver_Account as accountNumber,
                       b.Bank_ID          as imageId,
                       t.Receiver_Name    as title
                from FinDoc fd
                         join Transfer t with (nolock) on fd.FinDoc_ID = t.FinDoc_IDREF
                         left join Bank b with (nolock) on b.BIC = :eubankBIC
                where fd.FinDoc_ID = :id
                and fd.User_IDREF = :userId
                """;

        List<CreateFavoriteLocalTransferIn> queryResult = template.query(sql, map, favoriteLocalTransferMapper::toInDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else {
            throw new AppException(E_DB_601, ": FavoriteLocalTransferRepositoryImpl findByFinDocId");
        }
    }

    @Override
    public CreateFavoriteLocalTransferIn findByFinDocIdOrException(Long id) {
        return findByFinDocId(id)
                .orElseThrow(() -> new AppException(E_DB_600, ": FavoriteLocalTransferRepositoryImpl findByFinDocIdOrException"));
    }
}
