package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.TransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.TransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferEntity;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferJpaRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;

@Primary
@Repository
public class TransferRepositoryImpl implements TransferRepository {

    private final InfrastructureMapper mapper;
    private final TransferJpaRepository transferJpaRepository;

    public TransferRepositoryImpl(InfrastructureMapper mapper,
                                  TransferJpaRepository transferJpaRepository) {
        this.mapper = mapper;
        this.transferJpaRepository = transferJpaRepository;
    }

    @Override
    @Transactional
    public TransferOut save(TransferOut transferModel) {
        var transfer = mapper.toEntity(transferModel);
        var saved = transferJpaRepository.save(transfer);
        return mapper.toDomain(saved);
    }

    @Override
    public TransferOut findByFinDocId(Long finDocId) {
        TransferEntity transfer = transferJpaRepository
                .findByFinDocId(finDocId)
                .orElseThrow(() -> new AppException(E_DB_600, ": TransferRepository findByFinDocId"));
        return mapper.toDomain(transfer);
    }

}
