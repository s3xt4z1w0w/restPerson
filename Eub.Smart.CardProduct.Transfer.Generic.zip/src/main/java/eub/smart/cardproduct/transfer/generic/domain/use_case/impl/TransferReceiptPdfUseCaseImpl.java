package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;


import eub.smart.cardproduct.transfer.generic.core.enums.FinDocStatusDisplay;
import eub.smart.cardproduct.transfer.generic.core.util.DateTimeUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.KeyValueIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.ReceiptDocumentIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.GeneratePdfRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.TransferReceiptPdfUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.TransferReceiptUseCase;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.DetailResponse;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.OIPS;

@Service
public class TransferReceiptPdfUseCaseImpl implements TransferReceiptPdfUseCase {

    private final GeneratePdfRepository generatePdfRepository;
    private final TransferReceiptUseCase transferReceiptUseCase;

    private final MessageSourceRepository messageSourceRepository;

    public TransferReceiptPdfUseCaseImpl(GeneratePdfRepository generatePdfRepository, TransferReceiptUseCase transferReceiptUseCase, MessageSourceRepository messageSourceRepository) {
        this.generatePdfRepository = generatePdfRepository;
        this.transferReceiptUseCase = transferReceiptUseCase;
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public byte[] invoke(Long finDocId) {
        var receipt = transferReceiptUseCase.invoke(finDocId);
        DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.getDefault());
        symbols.setGroupingSeparator(' ');
        DecimalFormat df = new DecimalFormat("#,###.##", symbols);

        String amountString = df.format(receipt.amount().value().stripTrailingZeros());

        var receiptData = ReceiptDocumentIn.builder()
                .statusTitle(getStatusTitle(receipt.status()))
                .image(receipt.image())
                .amount(receipt.amount().value().stripTrailingZeros() + " " + receipt.amount().currency().symbol())
                .receiver(receipt.title())
                .transferType(receipt.subtitle())
                .details(getDetails(receipt.details()))
                .mainDetails(getMainDetails(receipt))
                .build();

        return generatePdfRepository.generateReceipt(receiptData);
    }

    private List<KeyValueIn> getDetails(List<DetailResponse> detailResponses) {
        return detailResponses.stream().map(it -> new KeyValueIn(it.key(), it.value())).toList();
    }

    private List<KeyValueIn> getMainDetails(TransferReceiptOut transferReceiptOut) {
        var keyValues = new ArrayList<>(List.of(
                new KeyValueIn(messageSourceRepository.getMessage(RECEIPT_DATE), DateTimeUtil.toString(transferReceiptOut.date(), "dd.MM.yyyy HH:mm")),
                new KeyValueIn(messageSourceRepository.getMessage(RECEIPT_NO), transferReceiptOut.id().toString())
        ));
        if(OIPS.equals(transferReceiptOut.finDocType())) {
            keyValues.add(new KeyValueIn(messageSourceRepository.getMessage(RECEIPT_REFERENCE_ID), transferReceiptOut.referenceId()));
        }
        return keyValues;
    }

    private String getStatusTitle(String status) {
        if(FinDocStatusDisplay.DONE.value().equals(status)) {
            return messageSourceRepository.getMessage(RECEIPT_STATUS, LocaleUtil.getCurrentLocale());
        }
        return null;
    }
}
