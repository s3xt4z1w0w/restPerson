package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldError;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CardTransferIOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateFinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FeeP2pIOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.AggregatorP2PTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.CardRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.CardTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFinDocUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.RetransferUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.ValidateLimitUseCase;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.P2PF;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.P2PR;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType.P2PO;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_VD_402;

@Service
public class RetransferP2pUseCaseImpl implements RetransferUseCase {

    private final CardRepository cardRepository;
    private final CardTransferRepository cardTransferRepository;
    private final AggregatorP2PTransferRepository aggregatorP2PTransferRepository;
    private final CreateFinDocUseCase createFinDocUseCase;
    private final ValidateLimitUseCase validateLimitUseCase;

    public RetransferP2pUseCaseImpl(CardRepository cardRepository,
                                    CardTransferRepository cardTransferRepository,
                                    AggregatorP2PTransferRepository aggregatorP2PTransferRepository,
                                    CreateFinDocUseCase createFinDocUseCase,
                                    ValidateLimitUseCase validateLimitUseCase) {
        this.cardRepository = cardRepository;
        this.cardTransferRepository = cardTransferRepository;
        this.aggregatorP2PTransferRepository = aggregatorP2PTransferRepository;
        this.createFinDocUseCase = createFinDocUseCase;
        this.validateLimitUseCase = validateLimitUseCase;
    }

    @Transactional
    @Override
    public RetransferOut invoke(CreateRetransferDataIn in) {
        var senderCard = cardRepository.findByCardIdOrException(in.senderCardId());
        var receiverData = cardTransferRepository.findByFinDocIdOrException(in.finDocId());
        var fee = aggregatorP2PTransferRepository.getFee(senderCard.cardOutRef(), in.debitAmount());
        var finDocOut = new CreateFinDocOut(in, fee.feeAmount());
        var finDoc = createFinDocUseCase.invoke(finDocOut);
        var correlationId = MDC.get(CORRELATION_ID);
        var cardTransferOut = new CardTransferIOut(senderCard, correlationId, receiverData, finDoc);
        cardTransferRepository.save(cardTransferOut);
        validateLimitUseCase.invoke(finDoc.getId(), P2PO.name(), senderCard.cardId(), in.debitAmount());
        return new RetransferOut(finDoc.getId(), fee.feeAmount());
    }

    @Override
    public FavoriteTransferType favoriteTransferType() {
        return P2PO;
    }

    @Override
    public String finDocType() {
        return P2PR;
    }
}
