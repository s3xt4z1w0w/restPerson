package eub.smart.cardproduct.transfer.generic.core.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static java.util.Objects.isNull;

public class StringUtil {

    public static boolean isNotEmpty(String value) {
        return !isEmpty(value);
    }

    public static boolean isEmpty(String value) {
        int strLen;
        if (value == null || (strLen = value.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static boolean isAnyEmpty(String... values) {
        return CollectionUtil.isEmpty(values) || Stream.of(values).anyMatch(StringUtil::isEmpty);
    }

    public static List<String> split(String value, String delim) {
        List<String> list = new ArrayList<>();
        if (isNotEmpty(value)) {
            for (String s : value.split(delim)) {
                list.add(s.trim());
            }
        }
        return list;
    }

    public static String emptyString() {
        return "";
    }

    public static String removeAllLineBreakers(String message){
        return message.replaceAll("[\\r\\n]+", "");
    }

    public static String removeAllLineBreakers(Object obj) {
        if (isNull(obj)) return null;
        return removeAllLineBreakers(obj.toString());
    }

    public static String last4(String message) {
        if(isEmpty(message)) return  null;
        return message.substring(message.length() - 4);
    }
}
