package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.TransferOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateTransferDataOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.TransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateTransferUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetTransferClientUseCase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CreateTransferUseCaseImpl implements CreateTransferUseCase {

    private final GetTransferClientUseCase getTransferClientUseCase;
    private final TransferRepository transferRepository;
    private final String receiverBIC;
    private final String seco; //economic sector

    public CreateTransferUseCaseImpl(GetTransferClientUseCase getTransferClientUseCase,
                                     TransferRepository transferRepository,
                                     @Value("${app.eubankBIC}") String receiverBIC,
                                     @Value("${app.seco}") String seco) {
        this.getTransferClientUseCase = getTransferClientUseCase;
        this.transferRepository = transferRepository;
        this.receiverBIC = receiverBIC;
        this.seco = seco;
    }

    @Override
    public TransferOut invoke(FinDocOut finDoc,
                              CreateTransferClientDataIn senderAccount,
                              CreateTransferClientDataIn receiverAccount,
                              CreateTransferDataOut out) {
        var receiverAccountNumber = receiverAccount.getNumber();
        var receiverAccountCurrency = receiverAccount.getCurrency();
        var senderAccountCurrency = senderAccount.getCurrency();
        var receiver = getTransferClientUseCase.invoke(receiverAccountNumber);

        var transfer = new TransferOut(finDoc, out.transferType(), receiverBIC, receiverAccountNumber, receiver.getName(),
                receiver.getIin(), receiver.getFlagResident(), seco, out.knpCode(), null, null,
                null, null, null, receiver.getBin(), receiverAccountCurrency,
                receiverAccountCurrency, out.currencyRates(), senderAccountCurrency, null,
                null, null, out.receiverAmount(), senderAccount.getCardId(), receiverAccount.getCardId());
        return transferRepository.save(transfer);
    }
}
