package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.TransferHistoryIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferHistoryOut;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TransferHistoryUseCase {

    List<TransferHistoryOut> invoke(TransferHistoryIn in, Pageable pageable);
}
