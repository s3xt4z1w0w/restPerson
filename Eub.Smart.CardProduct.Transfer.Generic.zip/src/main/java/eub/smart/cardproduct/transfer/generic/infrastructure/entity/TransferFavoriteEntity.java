package eub.smart.cardproduct.transfer.generic.infrastructure.entity;

import org.springframework.data.annotation.CreatedDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "TransferFavorite")
public class TransferFavoriteEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TransferFavorite_ID")
    private Long id;

    @NotNull
    @Column(name = "FinDoc_IDREF", nullable = false)
    private Long finDocId;

    @NotNull
    @Column(name = "User_IDREF", nullable = false)
    private Long userId;

    @NotBlank
    @Column(name = "Type", nullable = false)
    private String type;

    @CreatedDate
    @Column(name = "CreatedDate", nullable = false)
    private Date createDate = new Date();

    @Column(name = "Title", nullable = true)
    private String title;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFinDocId() {
        return finDocId;
    }

    public void setFinDocId(Long finDocId) {
        this.finDocId = finDocId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "TransferFavoriteEntity{" +
                "id=" + id +
                ", userId=" + userId +
                ", finDocId=" + finDocId +
                ", type=" + type +
                ", createDate=" + createDate +
                ", title=" + title +
                '}';
    }
}
