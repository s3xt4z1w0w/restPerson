package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record CreateFavoriteLocalTransferIn(
        FavoriteTransferIn favoriteTransferIn,
        String accountNumber,
        String currency,
        String title,
        String imageTable,
        Long imageId
) {

    public CreateFavoriteLocalTransferIn(Long finDocId,
                                         Long userId,
                                         String type,
                                         String accountNumber,
                                         String currency,
                                         String title,
                                         String imageTable,
                                         Long imageId) {
        this(new FavoriteTransferIn(
                        null,
                        finDocId,
                        userId,
                        type,
                        null),
                accountNumber,
                currency,
                title,
                imageTable,
                imageId
        );
    }
}
