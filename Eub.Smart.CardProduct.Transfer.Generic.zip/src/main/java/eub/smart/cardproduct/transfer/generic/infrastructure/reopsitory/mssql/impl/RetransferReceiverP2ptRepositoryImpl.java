package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.AccountTargetOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.RetransferReceiverRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.RetransferReceiverMapper;
import org.slf4j.MDC;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I13B;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class RetransferReceiverP2ptRepositoryImpl implements RetransferReceiverRepository {

    private final NamedParameterJdbcTemplate template;
    private final RetransferReceiverMapper retransferReceiverMapper;
    private final AuthToken authToken;

    public RetransferReceiverP2ptRepositoryImpl(NamedParameterJdbcTemplate template,
                                                RetransferReceiverMapper retransferReceiverMapper,
                                                AuthToken authToken) {
        this.template = template;
        this.retransferReceiverMapper = retransferReceiverMapper;
        this.authToken = authToken;
    }

    @Override
    public Optional<AccountTargetOut> findByFinDocId(Long finDocId) {
        var langKey = MDC.get(LANG_KEY);
        var userDetails = UserDetails.build(authToken.getDecodedPayload());
        var userId = userDetails.getUserId();

        Map<String, Object> map = Map.of(
                "finDocId", finDocId,
                "userId", userId,
                "metaDocTypeBank", I13B);

        String sql = """
                select case --title
                           when p2pt.CardTransferType_IDREF = 'P2PL' then
                               p2pt.ReceiverName
                           when p2pt.CardTransferType_IDREF = 'P2PO' then
                               trm_b.Term_EN end            as title,
                       case --imageUid
                           when md.FileUid is not null then
                               md.FileUid
                           else
                               (select mdi.FileUid
                                from MetaDocument mdi with (nolock)
                                where mdi.Target_ID = 0
                                  and mdi.Target_Table = 'Bank'
                                  and mdi.DocumentType_IDREF = :metaDocTypeBank
                                  and mdi.LangKey = 'EN'
                                  and mdi.IsActive = 1) end as imageUid,
                       p2pt.CardTransferType_IDREF          as transferType
                from FinDoc fd with (nolock)
                         join CardTransfer p2pt with (nolock) on fd.FinDoc_ID = p2pt.FinDoc_IDREF
                         left join BinCard bc with (nolock) on bc.Bin = left(p2pt.CreditMaskedCardNumber, 6)
                         left join Bank b with (nolock) on bc.Bank_IDREF = b.Bank_ID
                         left join Term trm_b on trm_b.Term_ID = b.Term_OUTREF
                         left join MetaDocument md with (nolock)
                                   on md.Target_ID = b.Bank_ID
                                       and md.Target_Table = 'Bank'
                                       and md.DocumentType_IDREF = :metaDocTypeBank
                                       and md.LangKey = 'EN'
                                       and md.IsActive = 1
                where fd.FinDoc_ID = :finDocId
                  and fd.User_IDREF = :userId
                  and p2pt.CardTransferType_IDREF in ('P2PL', 'P2PO')
                """;
        List<AccountTargetOut> queryResult = template.query(sql, map, (resultSet, i) -> retransferReceiverMapper.toP2ptDomain(resultSet, langKey));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": ReceiptP2ptRepositoryImpl findByFinDocId");
        }
    }

    @Override
    public AccountTargetOut findByFinDocIdOrException(Long finDocId) {
        return findByFinDocId(finDocId).
                orElseThrow(() -> new AppException(E_DB_600, ": ReceiptP2ptRepositoryImpl findByFinDocIdOrException"));
    }

    @Override
    public Set<String> keys() {
        return Set.of(P2PT, P2PF, P2PR);
    }
}
