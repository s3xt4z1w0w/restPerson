package eub.smart.cardproduct.transfer.generic.core.constant;

public interface AccountStatus {

    String ACTV = "ACTV";
    String BLOC = "BLOC";
    String CLOS = "CLOS";
    String COLL = "COLL";
    String CRBA = "CRBA";
    String DLTD = "DLTD";
    String PRBL = "PRBL";
    String SUSP = "SUSP";
    String UNCL = "UNCL";
}
