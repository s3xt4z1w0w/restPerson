package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.constant.CardTransferType.P2PL;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.IpsTransferType.IPSL;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

public class CreateRetransferMapper {

    public static CreateRetransferDataIn map(ResultSet rs, BigDecimal debitAmount, BigDecimal creditAmount) {
        try {
            Long senderAccountId = rs.getLong("senderAccountId");
            Long finDocId = rs.getLong("finDocId");
            Long senderCardId = rs.getLong("senderCardId");
            String finDocType = rs.getString("finDocType");
            String transferType = rs.getString("transferType");
            String senderCurrency = rs.getString("senderCurrency");
            String receiverCurrency = rs.getString("receiverCurrency");
            String retransferFinDocType = getRetransferFinDocType(finDocType, transferType);

            return new CreateRetransferDataIn(
                    senderCardId,
                    senderAccountId,
                    finDocId,
                    debitAmount,
                    creditAmount,
                    retransferFinDocType,
                    senderCurrency,
                    receiverCurrency);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private static String getRetransferFinDocType(String finDocType, String transferType) {
        return switch (finDocType) {
            case SLFT, SLFF, SLFR -> SLFR;
            case P2PT, P2PF, P2PR -> switch (transferType) {
                case P2PL -> LOCR;
                default -> P2PR;
            };
            case IPST, IPSF, IPSR, OIPS -> switch (transferType) {
                case IPSL -> LOCR;
                default -> IPSR;
            };
            case LOCF, LOCR -> LOCR;
            case ACCT, ACCF, ACCR -> ACCR;
            default -> throw new AppException(E_LG_802, ": for finDocType " + finDocType);
        };
    }
}
