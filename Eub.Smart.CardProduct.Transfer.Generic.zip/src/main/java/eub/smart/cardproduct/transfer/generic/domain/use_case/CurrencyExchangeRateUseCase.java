package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CurrencyRateIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CurrencyExchangeOut;

public interface CurrencyExchangeRateUseCase {

    CurrencyExchangeOut invoke(String from, String to);

    CurrencyExchangeOut invoke(CurrencyRateIn senderCurrencyRate, CurrencyRateIn receiverCurrencyRate);
}
