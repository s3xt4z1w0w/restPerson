package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record CreateFavoriteSelfTransferIn(
        FavoriteTransferIn favoriteTransferIn,
        String accountNumber,
        String currency,
        String imageTable,
        Long imageId
) {

    public CreateFavoriteSelfTransferIn(Long finDocId,
                                        Long userId,
                                        String type,
                                        String accountNumber,
                                        String currency,
                                        String imageTable,
                                        Long imageId) {
        this(new FavoriteTransferIn(
                        null,
                        finDocId,
                        userId,
                        type,
                        null),
                accountNumber,
                currency,
                imageTable,
                imageId);
    }
}
