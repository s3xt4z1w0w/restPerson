package eub.smart.cardproduct.transfer.generic.core.constant;

public interface FinDocType {

    String TLOC = "TLOC";
    String OIPS = "OIPS";
    String IIPS = "IIPS";
    String TOUT = "TOUT";
    String TINT = "TINT";
    String CRCR = "CRCR";
    String SLFT = "TSLF";
    String P2PT = "P2PT";
    String IPST = "IPST";
    String ACCT = "ACCT";
    String SLFF = "SLFF";
    String LOCF = "LOCF";
    String ACCF = "ACCF";
    String P2PF = "P2PF";
    String IPSF = "IPSF";
    String SLFR = "SLFR";
    String LOCR = "LOCR";
    String ACCR = "ACCR";
    String P2PR = "P2PR";
    String IPSR = "IPSR";
}
