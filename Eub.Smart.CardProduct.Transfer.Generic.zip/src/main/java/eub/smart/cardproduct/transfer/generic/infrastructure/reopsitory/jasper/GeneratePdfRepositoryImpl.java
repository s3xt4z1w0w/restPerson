package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.jasper;

import eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.ReceiptDocumentIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.GeneratePdfRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Repository;

import java.io.InputStream;

import static eub.smart.cardproduct.transfer.generic.core.util.MapUtil.toMapOrException;
import static net.sf.jasperreports.engine.design.JRCompiler.COMPILER_TEMP_DIR;

@Repository
@RequiredArgsConstructor
@Slf4j
public class GeneratePdfRepositoryImpl implements GeneratePdfRepository {

    private final MessageSourceRepository messageSourceRepository;


    private final ResourceLoader resourceLoader;


    @Override
    public byte[] generateReceipt(ReceiptDocumentIn receiptDocumentIn) {
        JRPropertiesUtil.getInstance(DefaultJasperReportsContext.getInstance()).setProperty(COMPILER_TEMP_DIR, "app");
//        DefaultJasperReportsContext.getInstance().setProperty(COMPILER_TEMP_DIR, "/app/temp/");

        Resource resource = resourceLoader.getResource("classpath:jasper/receipt.jrxml");
        try (InputStream reportStream = resource.getInputStream()) {
            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

            var parameters = toMapOrException(receiptDocumentIn, ReceiptDocumentIn.class.toString());

            parameters.put("details", new JRBeanCollectionDataSource(receiptDocumentIn.getDetails()));
            parameters.put("mainDetails", new JRBeanCollectionDataSource(receiptDocumentIn.getMainDetails()));

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());

            return JasperExportManager.exportReportToPdf(jasperPrint);
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new AppException(AppErrorCode.E_SM_506, "GeneratePdfRepositoryImpl generateReceipt {}", e.getMessage());
        }
    }
}
