package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountBalanceIn;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

public interface MyBankAggregatorRepository {

    List<AccountBalanceIn> getCardAccountsBalance(Set<Long> accountOutRefs);

    List<AccountBalanceIn> getAccountsBalance(Set<Long> accountOutRefs);
}
