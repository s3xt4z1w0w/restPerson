package eub.smart.cardproduct.transfer.generic.domain.use_case;

public interface FabricDeleteFavoriteTransferUseCase {

    void invoke(Long finDocId);
}
