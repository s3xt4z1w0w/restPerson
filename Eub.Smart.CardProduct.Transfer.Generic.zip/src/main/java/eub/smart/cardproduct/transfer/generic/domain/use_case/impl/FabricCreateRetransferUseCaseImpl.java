package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.RetransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FabricCreateRetransferUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.RetransferUseCase;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Service
public class FabricCreateRetransferUseCaseImpl implements FabricCreateRetransferUseCase {

    private final Map<String, RetransferUseCase> useCaseMap = new HashMap<>();
    private final RetransferRepository retransferRepository;
    public final static String NON_REFUNDABLE_FINANCIAL_ASSISTANCE = "119";

    public FabricCreateRetransferUseCaseImpl(Set<RetransferUseCase> useCases,
                                             RetransferRepository retransferRepository) {
        this.retransferRepository = retransferRepository;
        fillMap(useCases);
    }

    @Override
    public RetransferOut invoke(CreateRetransferDataIn in) {
        var retransferData = retransferRepository.findCreateRetransferData(in.finDocId(), in.debitAmount(), in.creditAmount());
        var useCase = findUseCase(retransferData.finDocType())
                .orElseThrow(() -> new AppException(AppErrorCode.E_LG_802, ": for finDocType: " + retransferData.finDocType()));
        return useCase.invoke(retransferData);
    }

    private void fillMap(Set<RetransferUseCase> useCases) {
        useCases.forEach(useCase -> useCaseMap.put(useCase.finDocType(), useCase));
    }

    private Optional<RetransferUseCase> findUseCase(String finDocType) {
        var receiptRepository = useCaseMap.get(finDocType);
        return Optional.ofNullable(receiptRepository);
    }
}
