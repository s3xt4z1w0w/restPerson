package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.TransferHistoryIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferHistoryOut;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TransferHistoryRepository {
    List<TransferHistoryOut> findBy(TransferHistoryIn in, Pageable pageable);
}
