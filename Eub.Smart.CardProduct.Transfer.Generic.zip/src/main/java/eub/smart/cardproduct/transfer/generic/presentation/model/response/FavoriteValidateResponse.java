package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

public record FavoriteValidateResponse(
        @Schema(description = "Id response")
        Long id,
        @Schema(description = "Комиссия")
        BigDecimal feeAmount
) {
}
