package eub.smart.cardproduct.transfer.generic.core.constant;

public interface IpsTransferType {

    String IPSL =  "IPSL";
    String IPSO =  "IPSO";
    String IPSI =  "IPSI";
}
