package eub.smart.cardproduct.transfer.generic.infrastructure.entity;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "CardTransfer")
public class CardTransferEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CardTransfer_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "FinDoc_IDREF", nullable = false)
    private FinDocEntity finDoc;

    @Column(name = "CardTransferType_IDREF", nullable = false)
    private String cardTransferType;

    @Column(name = "DebitCard_IDREF")
    private Long debitCardId;

    @Column(name = "DebitMaskedCardNumber")
    private String debitMaskedCardNumber;

    @Column(name = "CreditCard_IDREF")
    private Long creditCardId;

    @Column(name = "CreditMaskedCardNumber")
    private String creditMaskedCardNumber;

    @Column(name = "SolarTransfer_ID")
    private String solarTransferId;

    @Column(name = "Trace_ID")
    private UUID traceId;

    @Column(name = "ReceiverName")
    private String receiverName;

    @Column(name = "Message")
    private String message;

    @Column(name = "AccountNumber")
    private String accountNumber;

    @Column(name = "ReceiverIin")
    private String receiverIin;

    @Column(name = "BankApi_ID")
    private UUID bankApiId;

    @Column(name = "AuthId")
    private String authId;

    @Column(name = "Token")
    private String token;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FinDocEntity getFinDoc() {
        return finDoc;
    }

    public void setFinDoc(FinDocEntity finDoc) {
        this.finDoc = finDoc;
    }

    public String getCardTransferType() {
        return cardTransferType;
    }

    public void setCardTransferType(String cardTransferType) {
        this.cardTransferType = cardTransferType;
    }

    public Long getDebitCardId() {
        return debitCardId;
    }

    public void setDebitCardId(Long debitCardId) {
        this.debitCardId = debitCardId;
    }

    public String getDebitMaskedCardNumber() {
        return debitMaskedCardNumber;
    }

    public void setDebitMaskedCardNumber(String debitMaskedCardNumber) {
        this.debitMaskedCardNumber = debitMaskedCardNumber;
    }

    public Long getCreditCardId() {
        return creditCardId;
    }

    public void setCreditCardId(Long creditCardId) {
        this.creditCardId = creditCardId;
    }

    public String getCreditMaskedCardNumber() {
        return creditMaskedCardNumber;
    }

    public void setCreditMaskedCardNumber(String creditMaskedCardNumber) {
        this.creditMaskedCardNumber = creditMaskedCardNumber;
    }

    public String getSolarTransferId() {
        return solarTransferId;
    }

    public void setSolarTransferId(String solarTransferId) {
        this.solarTransferId = solarTransferId;
    }

    public UUID getTraceId() {
        return traceId;
    }

    public void setTraceId(UUID traceId) {
        this.traceId = traceId;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getReceiverIin() {
        return receiverIin;
    }

    public void setReceiverIin(String receiverIin) {
        this.receiverIin = receiverIin;
    }

    public UUID getBankApiId() {
        return bankApiId;
    }

    public void setBankApiId(UUID bankApiId) {
        this.bankApiId = bankApiId;
    }

    public String getAuthId() {
        return authId;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "CardTransferEntity{" +
                "id=" + id +
                ", cardTransferType=" + cardTransferType +
                ", debitCardId=" + debitCardId +
                ", debitMaskedCardNumber=" + debitMaskedCardNumber +
                ", creditCardId=" + creditCardId +
                ", creditMaskedCardNumber=" + creditMaskedCardNumber +
                ", solarTransferId=" + solarTransferId +
                ", traceId=" + traceId +
                ", receiverName=" + receiverName +
                ", message=" + message +
                ", accountNumber=" + accountNumber +
                ", receiverIin=" + receiverIin +
                ", bankApiId=" + bankApiId +
                ", authId=" + authId +
                ", token=" + token +
                '}';
    }
}
