package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.infrastructure.entity.FinDocStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FinDocStatusJpaRepository extends JpaRepository<FinDocStatusEntity, String> {

    @Query(value = """
            select FDSS.*
            from FinDocStatus FDSS
                     join DocTechStatus DTS on FDSS.FinDocStatus_ID = DTS.FinDocStatus_IDREF
                     join FinDocState FDS on DTS.DocTechStatus_ID = FDS.DocTechStatus_IDREF
            where FDS.FinDoc_IDREF = :finDocId
            """, nativeQuery = true)
    Optional<FinDocStatusEntity> findByFinDocId(@Param("finDocId") Long finDocId);

}
