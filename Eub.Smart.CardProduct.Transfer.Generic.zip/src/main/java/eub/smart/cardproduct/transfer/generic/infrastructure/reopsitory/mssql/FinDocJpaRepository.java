package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.infrastructure.entity.FinDocEntity;
import eub.smart.cardproduct.transfer.generic.infrastructure.model.TransferHistoryProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public interface FinDocJpaRepository extends JpaRepository<FinDocEntity, Long> {

    @Query(value = """
            --TSLF
            select fd.FinDoc_ID                         as id,
                   case --find fromm
                       when muas.Pseudonym is not null then
                           muas.Pseudonym
                       else
                           case
                               when sacc_psn.ProductShortName_ID = 'DFCD' and t.SenderCard_IDREF is not null then --Карточный счет
                                   sct.CardType_Title
                               else
                                   case
                                       when :langKey = 'KK' then trm_sacc_psn.Term_KZ
                                       when :langKey = 'RU' then trm_sacc_psn.Term_RU
                                       else trm_sacc_psn.Term_EN
                                       end
                               end
                       end                              as fromm,
                   case --find fromSuffix by sender account product short name
                       when sacc_psn.ProductShortName_ID = 'DFCD' and t.SenderCard_IDREF is not null then --Карточный счет
                           (N' • ' + right(sc.MaskedNumber, 4))
                       else
                           (N' • ' + left(sacc.Number, 2) + right(sacc.Number, 4))
                       end                              as fromSuffix,
                   case --find title
                       when muar.Pseudonym is not null then
                           muar.Pseudonym
                       else
                           case --find title by receiver account product short name
                               when racc_psn.ProductShortName_ID = 'DFCD' and t.ReceiverCard_IDREF is not null then --Карточный счет
                                   rct.CardType_Title
                               else
                                   case
                                       when :langKey = 'KK' then trm_racc_psn.Term_KZ
                                       when :langKey = 'RU' then trm_racc_psn.Term_RU
                                       else trm_racc_psn.Term_EN
                                       end
                               end
                       end                              as title,
                   case --imageUid
                       when rct.CardType_ID is not null then
                           case
                               when md_ct.FileUid is not null then
                                   md_ct.FileUid
                               else
                                   (select mdi.FileUid
                                    from MetaDocument mdi with (nolock)
                                    where mdi.Target_ID = 0
                                      and mdi.Target_Table = 'CardType'
                                      and mdi.DocumentType_IDREF = :metaDocType
                                      and mdi.LangKey = 'RU'
                                      and mdi.IsActive = 1
                                      and mdi.Screen = 'mybank')
                               end
                       when md_at.FileUid is not null then
                           md_at.FileUid
                       else
                           (select mdi.FileUid
                            from MetaDocument mdi with (nolock)
                            where mdi.Target_ID = 0
                              and mdi.Target_Table = 'AccountType'
                              and mdi.DocumentType_IDREF = :metaDocType
                              and mdi.LangKey = 'RU'
                              and mdi.IsActive = 1
                              and mdi.Screen = 'mybank')
                       end                       as imageUid,
                   rc.MaskedNumber                      as number,
                   null                                 as message,
                   fd.Amount                            as amount,
                   fd.Currency                          as currency,
                   fd.DateCreated                       as dateCreated,
                   fdss.FinDocStatus_ID                 as status,
                   fd.FinDocType_IDREF                  as finDocType,
                   t.TransferType_IDREF                 as subType,
                   racct.AccountType_ID                 as accountType
            from FinDoc fd with (nolock)
                     join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                     join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                     join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                     join Transfer t with (nolock) on fd.FinDoc_ID = t.FinDoc_IDREF
                     join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                     left join Card sc with (nolock) on t.SenderCard_IDREF = sc.Card_ID --sender data start
                     left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                     join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                     left join map_User_Account muas with (nolock)
                               on muas.User_IDREF = fd.User_IDREF and muas.Account_IDREF = sacc.Account_ID
                     left join AccountProduct sacc_ap with (nolock)
                               on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                  sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join DepositProduct sacc_dp with (nolock)
                               on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                  sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join CardAccountProduct sacc_cap with (nolock)
                               on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                  sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join ProductShortName sacc_psn with (nolock)
                               on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                  sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                  sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                     join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                     left join Card rc with (nolock) on t.ReceiverCard_IDREF = rc.Card_ID --receiver data start
                     left join CardType rct with (nolock) on rct.CardType_ID = rc.CardType_IDREF
                     join Account racc with (nolock) on t.Receiver_Account = racc.Number
                     left join AccountType racct with (nolock) on racc.AccountType_IDREF = racct.AccountType_ID
                     left join map_User_Account muar with (nolock)
                               on muar.User_IDREF = fd.User_IDREF and muar.Account_IDREF = racc.Account_ID
                     left join AccountProduct racc_ap with (nolock)
                               on racc_ap.Product_IDREF = racc.Product_IDREF and
                                  racc_ap.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                     left join DepositProduct racc_dp with (nolock)
                               on racc_dp.Product_IDREF = racc.Product_IDREF and
                                  racc_dp.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                     left join CardAccountProduct racc_cap with (nolock)
                               on racc_cap.Product_IDREF = racc.Product_IDREF and
                                  racc_cap.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                     left join ProductShortName racc_psn with (nolock)
                               on racc_ap.ProductShortName_IDREF = racc_psn.ProductShortName_ID or
                                  racc_dp.ProductShortName_IDREF = racc_psn.ProductShortName_ID or
                                  racc_cap.ProductShortName_IDREF = racc_psn.ProductShortName_ID
                     join Term trm_racc_psn with (nolock) on trm_racc_psn.Term_ID = racc_psn.Term_OUTREF --receiver data end
                     left join MetaDocument md_ct with (nolock)
                               on md_ct.Target_ID = rct.Target_ID
                                   and md_ct.Target_Table = 'CardType'
                                   and md_ct.DocumentType_IDREF = :metaDocType
                                   and md_ct.LangKey = 'RU'
                                   and md_ct.IsActive = 1
                                   and md_ct.Screen = 'mybank'
                     left join MetaDocument md_at with (nolock)
                               on md_at.Target_ID = racct.Target_ID
                                   and md_at.Target_Table = 'AccountType'
                                   and md_at.DocumentType_IDREF = :metaDocType
                                   and md_at.LangKey = 'RU'
                                   and md_at.IsActive = 1
                                   and md_at.Screen = 'mybank'
            where FinDocType_ID in ('TSLF', 'SLFF', 'SLFR')
              and fd.User_IDREF = :userId
              and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
              and fd.DateCreated >= :dateFrom
              and fd.DateCreated <= :dateTill
            union
            --IPST
            select fd.FinDoc_ID                         as id,
                   case --find fromm
                       when mua.Pseudonym is not null then
                           mua.Pseudonym
                       else
                           case --find fromm by sender account product short name
                               when sacc_psn.ProductShortName_ID = 'DFCD' and ipst.SenderCard_IDREF is not null then --Карточный счет
                               sct.CardType_Title
                           else
                               case
                                   when :langKey = 'KK' then trm_sacc_psn.Term_KZ
                                   when :langKey = 'RU' then trm_sacc_psn.Term_RU
                                   else trm_sacc_psn.Term_EN
                                   end
                           end
                       end                              as fromm,
                   case --find fromSuffix by sender account product short name
                           when sacc_psn.ProductShortName_ID = 'DFCD' and ipst.SenderCard_IDREF is not null then --Карточный счет
                               (N' • ' + right(sc.MaskedNumber, 4))
                           else
                               (N' • ' + left(sacc.Number, 2) + right(sacc.Number, 4))
                           end                          as fromSuffix,
                   ipst.USER_ReceiverName               as title,
                   case --imageUid
                       when md.FileUid is not null then
                           md.FileUid
                       else
                           (select mdi.FileUid
                            from MetaDocument mdi with (nolock)
                            where mdi.Target_ID = 0
                              and mdi.Target_Table = 'Bank'
                              and mdi.DocumentType_IDREF = :metaDocTypeBank
                              and mdi.LangKey = 'EN'
                              and mdi.IsActive = 1) end as imageUid,
                   null                                 as number,
                   ipst.USER_Message                    as message,
                   fd.Amount                            as amount,
                   fd.Currency                          as currency,
                   fd.DateCreated                       as dateCreated,
                   fdss.FinDocStatus_ID                 as status,
                   fd.FinDocType_IDREF                  as finDocType,
                   ipst.TransferType                    as subType,
                   null                                 as accountType
            from FinDoc fd with (nolock)
                     join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                     join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                     join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                     left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                     left join IPSTransfer ipst with (nolock) on fd.FinDoc_ID = ipst.FinDoc_IDREF
                     left join SMPOrganization so with (nolock) on so.BIC = ipst.BANK_ReceiverBic
                     left join MetaDocument md with (nolock)
                               on md.Target_ID = so.Target_ID
                                   and md.Target_Table = 'Bank'
                                   and md.DocumentType_IDREF = :metaDocTypeBank
                                   and md.LangKey = 'EN'
                                   and md.IsActive = 1
                     left join Card sc with (nolock) on ipst.SenderCard_IDREF = sc.Card_ID --sender data start
                     left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                     join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                     left join map_User_Account mua with (nolock)
                               on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                     left join AccountProduct sacc_ap with (nolock)
                               on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                  sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join DepositProduct sacc_dp with (nolock)
                               on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                  sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join CardAccountProduct sacc_cap with (nolock)
                               on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                  sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join ProductShortName sacc_psn with (nolock)
                               on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                  sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                  sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                     left join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
            where fdt.FinDocType_ID in ('IPST', 'IPSF', 'IPSR')
              and ipst.TransferType in ('IPSL', 'IPSO')
              and fd.User_IDREF = :userId
              and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT', 'RTRN')
              and fd.DateCreated >= :dateFrom
              and fd.DateCreated <= :dateTill
            union
            --P2PT
            select fd.FinDoc_ID                         as id,
                   case --find fromm
                       when mua.Pseudonym is not null then
                           mua.Pseudonym
                       else
                           case
                               when sacc_psn.ProductShortName_ID = 'DFCD' and p2pt.DebitCard_IDREF is not null then --Карточный счет
                               sct.CardType_Title
                           else
                               case
                                   when :langKey = 'KK' then trm_sacc_psn.Term_KZ
                                   when :langKey = 'RU' then trm_sacc_psn.Term_RU
                                   else trm_sacc_psn.Term_EN
                                   end
                           end
                       end                              as fromm,
                   case --find fromSuffix by sender account product short name
                       when sacc_psn.ProductShortName_ID = 'DFCD' and p2pt.DebitCard_IDREF is not null then --Карточный счет
                               (N' • ' + right(sc.MaskedNumber, 4))
                           else
                               (N' • ' + left(sacc.Number, 2) + right(sacc.Number, 4))
                           end                          as fromSuffix,
                   case --title
                       when p2pt.CardTransferType_IDREF = 'P2PL' then
                           p2pt.ReceiverName
                       when p2pt.CardTransferType_IDREF = 'P2PO' then
                           trm_b.Term_EN end            as title,
                   case --imageUid
                       when md.FileUid is not null then
                           md.FileUid
                       else
                           (select mdi.FileUid
                            from MetaDocument mdi with (nolock)
                            where mdi.Target_ID = 0
                              and mdi.Target_Table = 'Bank'
                              and mdi.DocumentType_IDREF = :metaDocTypeBank
                              and mdi.LangKey = 'EN'
                              and mdi.IsActive = 1) end as imageUid,
                   null                                 as number,
                   p2pt.Message                         as message,
                   fd.Amount                            as amount,
                   fd.Currency                          as currency,
                   fd.DateCreated                       as dateCreated,
                   fdss.FinDocStatus_ID                 as status,
                   fd.FinDocType_IDREF                  as finDocType,
                   p2pt.CardTransferType_IDREF          as subType,
                   null                                 as accountType
            from FinDoc fd with (nolock)
                     join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                     join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                     join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                     left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                     join CardTransfer p2pt with (nolock) on fd.FinDoc_ID = p2pt.FinDoc_IDREF
                     left join BinCard bc with (nolock) on bc.Bin = left(p2pt.CreditMaskedCardNumber, 6)
                     left join Bank b with (nolock) on bc.Bank_IDREF = b.Bank_ID
                     left join Term trm_b on trm_b.Term_ID = b.Term_OUTREF
                     left join MetaDocument md with (nolock)
                               on md.Target_ID = b.Bank_ID
                                   and md.Target_Table = 'Bank'
                                   and md.DocumentType_IDREF = :metaDocTypeBank
                                   and md.LangKey = 'EN'
                                   and md.IsActive = 1
                     left join Card sc with (nolock) on p2pt.DebitCard_IDREF = sc.Card_ID --sender data start
                     left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                     join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                     left join map_User_Account mua with (nolock)
                               on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                     left join AccountProduct sacc_ap with (nolock)
                               on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                  sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join DepositProduct sacc_dp with (nolock)
                               on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                  sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join CardAccountProduct sacc_cap with (nolock)
                               on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                  sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join ProductShortName sacc_psn with (nolock)
                               on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                  sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                  sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                     left join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
            where fdt.FinDocType_ID in ('P2PT', 'P2PF', 'P2PR')
              and p2pt.CardTransferType_IDREF in ('P2PL', 'P2PO')
              and fd.User_IDREF = :userId
              and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
              and fd.DateCreated >= :dateFrom
              and fd.DateCreated <= :dateTill
            union
            --ACCT
            select fd.FinDoc_ID                         as id,
                   case --find fromm
                       when sacc_psn.ProductShortName_ID = 'DFCD' and acct.SenderCard_IDREF is not null then --Карточный счет
                               sct.CardType_Title
                           else
                               case
                                   when :langKey = 'KK' then trm_sacc_psn.Term_KZ
                                   when :langKey = 'RU' then trm_sacc_psn.Term_RU
                                   else trm_sacc_psn.Term_EN
                                   end
                           end                          as fromm,
                   case --find fromSuffix by sender account product short name
                       when sacc_psn.ProductShortName_ID = 'DFCD' and acct.SenderCard_IDREF is not null then --Карточный счет
                               (N' • ' + right(sc.MaskedNumber, 4))
                           else
                               (N' • ' + left(sacc.Number, 2) + right(sacc.Number, 4))
                           end                          as fromSuffix,
                   case --title
                       when acct.TransferType_IDREF in ('FVAT', 'ALKF', 'AOKF') then
                           acct.Receiver_Name
                       when acct.TransferType_IDREF in ('ALKU', 'AOKU') then
                           trm_b.Term_EN end            as title,
                   case --imageUid
                       when md.FileUid is not null then
                           md.FileUid
                       else
                           (select imd.FileUid
                            from MetaDocument imd with (nolock)
                            where imd.Target_ID = 0
                              and imd.Target_Table = 'Bank'
                              and imd.DocumentType_IDREF = :metaDocTypeBank
                              and imd.LangKey = 'EN'
                              and imd.IsActive = 1) end as imageUid,
                   null                                 as number,
                   null                                 as message,
                   fd.Amount                            as amount,
                   fd.Currency                          as currency,
                   fd.DateCreated                       as dateCreated,
                   fdss.FinDocStatus_ID                 as status,
                   fd.FinDocType_IDREF                  as finDocType,
                   acct.TransferType_IDREF              as subType,
                   null                                 as accountType
            from FinDoc fd with (nolock)
                     join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                     join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                     join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                     left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                     join Transfer acct with (nolock) on fd.FinDoc_ID = acct.FinDoc_IDREF
                     left join Bank b with (nolock) on b.Code = SUBSTRING(acct.Receiver_Account, 5, 3)
                     left join Term trm_b with (nolock) on trm_b.Term_ID = b.Term_OUTREF
                     left join MetaDocument md with (nolock)
                               on md.Target_ID = b.Bank_ID
                                   and md.Target_Table = 'Bank'
                                   and md.DocumentType_IDREF = :metaDocTypeBank
                                   and md.LangKey = 'EN'
                                   and md.IsActive = 1
                     left join Card sc with (nolock) on acct.SenderCard_IDREF = sc.Card_ID --sender data start
                     left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                     join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                     left join map_User_Account mua with (nolock)
                               on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                     left join AccountProduct sacc_ap with (nolock)
                               on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                  sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join DepositProduct sacc_dp with (nolock)
                               on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                  sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join CardAccountProduct sacc_cap with (nolock)
                               on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                  sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                     left join ProductShortName sacc_psn with (nolock)
                               on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                  sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                  sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                     left join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                     join Account racc with (nolock) on acct.Receiver_Account = racc.Number --receiver date
            where fdt.FinDocType_ID in ('ACCT', 'ACCF', 'ACCR')
              and fd.User_IDREF = :userId
              and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
              and fd.DateCreated >= :dateFrom
              and fd.DateCreated <= :dateTill
            union
            --LOCT
            select fd.FinDoc_ID                         as id,
                       case --find fromm
                           when mua.Pseudonym is not null then
                               mua.Pseudonym
                           else
                               case
                                   when sacc_psn.ProductShortName_ID = 'DFCD' and acct.SenderCard_IDREF is not null then --Карточный счет
                                        sct.CardType_Title
                               else
                                   case
                                       when :langKey = 'KK' then trm_sacc_psn.Term_KZ
                                       when :langKey = 'RU' then trm_sacc_psn.Term_RU
                                       else trm_sacc_psn.Term_EN
                                       end
                               end
                           end                              as fromm,
                       case --find fromSuffix by sender account product short name
                           when mua.Pseudonym is null then
                               case
                                   when sacc_psn.ProductShortName_ID = 'DFCD' and acct.SenderCard_IDREF is not null then --Карточный счет
                                       (N' • ' + right(sc.MaskedNumber, 4))
                                   else
                                       (N' • ' + left(sacc.Number, 2) + right(sacc.Number, 4))
                                   end
                           end                              as fromSuffix,
                       acct.Receiver_Name                   as title,
                       case --imageUid
                           when md.FileUid is not null then
                               md.FileUid
                           else
                               (select imd.FileUid
                                from MetaDocument imd with (nolock)
                                where imd.Target_ID = 0
                                  and imd.Target_Table = 'Bank'
                                  and imd.DocumentType_IDREF = :metaDocTypeBank
                                  and imd.LangKey = 'EN'
                                  and imd.IsActive = 1) end as imageUid,
                       null                                 as number,
                       null                                 as message,
                       fd.Amount                            as amount,
                       fd.Currency                          as currency,
                       fd.DateCreated                       as dateCreated,
                       fdss.FinDocStatus_ID                 as status,
                       fd.FinDocType_IDREF                  as finDocType,
                       acct.TransferType_IDREF              as subType,
                       null                                 as accountType
            from FinDoc fd with (nolock)
                         join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                         join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                         join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                         left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                         join Transfer acct with (nolock) on fd.FinDoc_ID = acct.FinDoc_IDREF
                         left join Bank b with (nolock) on b.Code = SUBSTRING(acct.Receiver_Account, 5, 3)
                         left join Term trm_b with (nolock) on trm_b.Term_ID = b.Term_OUTREF
                         left join MetaDocument md with (nolock)
                                   on md.Target_ID = b.Bank_ID
                                       and md.Target_Table = 'Bank'
                                       and md.DocumentType_IDREF = :metaDocTypeBank
                                       and md.LangKey = 'EN'
                                       and md.IsActive = 1
                         left join Card sc with (nolock) on acct.SenderCard_IDREF = sc.Card_ID --sender data start
                         left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                         join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                         left join map_User_Account mua with (nolock)
                                   on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                         left join AccountProduct sacc_ap with (nolock)
                                   on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                      sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join DepositProduct sacc_dp with (nolock)
                                   on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                      sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join CardAccountProduct sacc_cap with (nolock)
                                   on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                      sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join ProductShortName sacc_psn with (nolock)
                                   on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                      sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                      sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                         left join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                         join Account racc with (nolock) on acct.Receiver_Account = racc.Number --receiver date
            where fdt.FinDocType_ID in ('LOCR', 'LOCF')
                  and fd.User_IDREF = :userId
                  and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                  and fd.DateCreated >= :dateFrom
                  and fd.DateCreated <= :dateTill
            order by dateCreated desc
            """,
            countQuery = """
                    select COUNT(*)
                    FROM (
                    --TSLF
                             select fd.FinDoc_ID as id,
                                    :metaDocType as metaDocType,
                                    :langKey as langKey
                             from FinDoc fd with (nolock)
                                      join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                                      join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                                      join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                                      join Transfer t with (nolock) on fd.FinDoc_ID = t.FinDoc_IDREF
                                      join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                      left join Card sc with (nolock) on t.SenderCard_IDREF = sc.Card_ID --sender data start
                                      left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                                      join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                                      left join map_User_Account muas with (nolock)
                                                on muas.User_IDREF = fd.User_IDREF and muas.Account_IDREF = sacc.Account_ID
                                      left join AccountProduct sacc_ap with (nolock)
                                                on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join DepositProduct sacc_dp with (nolock)
                                                on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join CardAccountProduct sacc_cap with (nolock)
                                                on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join ProductShortName sacc_psn with (nolock)
                                                on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                   sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                   sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                                      join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                                      left join Card rc with (nolock) on t.ReceiverCard_IDREF = rc.Card_ID --receiver data start
                                      left join CardType rct with (nolock) on rct.CardType_ID = rc.CardType_IDREF
                                      join Account racc with (nolock) on t.Receiver_Account = racc.Number
                                      left join AccountType racct with (nolock) on racc.AccountType_IDREF = racct.AccountType_ID
                                      left join map_User_Account muar with (nolock)
                                                on muar.User_IDREF = fd.User_IDREF and muar.Account_IDREF = racc.Account_ID
                                      left join AccountProduct racc_ap with (nolock)
                                                on racc_ap.Product_IDREF = racc.Product_IDREF and
                                                   racc_ap.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                                      left join DepositProduct racc_dp with (nolock)
                                                on racc_dp.Product_IDREF = racc.Product_IDREF and
                                                   racc_dp.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                                      left join CardAccountProduct racc_cap with (nolock)
                                                on racc_cap.Product_IDREF = racc.Product_IDREF and
                                                   racc_cap.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                                      left join ProductShortName racc_psn with (nolock)
                                                on racc_ap.ProductShortName_IDREF = racc_psn.ProductShortName_ID or
                                                   racc_dp.ProductShortName_IDREF = racc_psn.ProductShortName_ID or
                                                   racc_cap.ProductShortName_IDREF = racc_psn.ProductShortName_ID
                                      join Term trm_racc_psn with (nolock)
                                           on trm_racc_psn.Term_ID = racc_psn.Term_OUTREF --receiver data end
                             where FinDocType_ID = 'TSLF'
                               and fd.User_IDREF = :userId
                               and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                               and fd.DateCreated >= :dateFrom
                               and fd.DateCreated <= :dateTill
                             union
                    --IPST
                             select fd.FinDoc_ID as id,
                                    :metaDocType as metaDocType,
                                    :langKey as langKey
                             from FinDoc fd with (nolock)
                                      join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                                      join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                                      join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                                      left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                      left join IPSTransfer ipst with (nolock) on fd.FinDoc_ID = ipst.FinDoc_IDREF
                                      left join SMPOrganization so with (nolock) on so.BIC = ipst.BANK_ReceiverBic
                                      left join Card sc with (nolock) on ipst.SenderCard_IDREF = sc.Card_ID --sender data start
                                      left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                                      join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                                      left join map_User_Account mua with (nolock)
                                                on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                                      left join AccountProduct sacc_ap with (nolock)
                                                on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join DepositProduct sacc_dp with (nolock)
                                                on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join CardAccountProduct sacc_cap with (nolock)
                                                on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join ProductShortName sacc_psn with (nolock)
                                                on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                   sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                   sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                                      left join Term trm_sacc_psn with (nolock)
                                                on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                             where fdt.FinDocType_ID = 'IPST'
                               and ipst.TransferType in ('IPSL', 'IPSO')
                               and fd.User_IDREF = :userId
                               and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT', 'RTRN')
                               and fd.DateCreated >= :dateFrom
                               and fd.DateCreated <= :dateTill
                             union
                    --P2PT
                             select fd.FinDoc_ID as id,
                                    :metaDocType as metaDocType,
                                    :langKey as langKey
                             from FinDoc fd with (nolock)
                                      join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                                      join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                                      join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                                      left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                      join CardTransfer p2pt with (nolock) on fd.FinDoc_ID = p2pt.FinDoc_IDREF
                                      left join BinCard bc with (nolock) on bc.Bin = left(p2pt.CreditMaskedCardNumber, 6)
                                      left join Bank b with (nolock) on bc.Bank_IDREF = b.Bank_ID
                                      left join Term trm_b on trm_b.Term_ID = b.Term_OUTREF
                                      left join Card sc with (nolock) on p2pt.DebitCard_IDREF = sc.Card_ID --sender data start
                                      left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                                      join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                                      left join map_User_Account mua with (nolock)
                                                on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                                      left join AccountProduct sacc_ap with (nolock)
                                                on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join DepositProduct sacc_dp with (nolock)
                                                on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join CardAccountProduct sacc_cap with (nolock)
                                                on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join ProductShortName sacc_psn with (nolock)
                                                on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                   sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                   sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                                      left join Term trm_sacc_psn with (nolock)
                                                on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                             where fdt.FinDocType_ID = 'P2PT'
                               and p2pt.CardTransferType_IDREF in ('P2PL', 'P2PO')
                               and fd.User_IDREF = :userId
                               and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                               and fd.DateCreated >= :dateFrom
                               and fd.DateCreated <= :dateTill
                             union
                    --ACCT
                             select fd.FinDoc_ID as id,
                                    :metaDocType as metaDocType,
                                    :langKey as langKey
                             from FinDoc fd with (nolock)
                                      join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                                      join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                                      join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                                      left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                      join Transfer acct with (nolock) on fd.FinDoc_ID = acct.FinDoc_IDREF
                                      left join Bank b with (nolock) on b.Code = SUBSTRING(acct.Receiver_Account, 5, 3)
                                      left join Term trm_b with (nolock) on trm_b.Term_ID = b.Term_OUTREF
                                      left join Card sc with (nolock) on acct.SenderCard_IDREF = sc.Card_ID --sender data start
                                      left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                                      join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                                      left join map_User_Account mua with (nolock)
                                                on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                                      left join AccountProduct sacc_ap with (nolock)
                                                on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join DepositProduct sacc_dp with (nolock)
                                                on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join CardAccountProduct sacc_cap with (nolock)
                                                on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                                   sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                      left join ProductShortName sacc_psn with (nolock)
                                                on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                   sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                   sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                                      left join Term trm_sacc_psn with (nolock)
                                                on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                             where fdt.FinDocType_ID = 'ACCT'
                               and fd.User_IDREF = :userId
                               and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                               and fd.DateCreated >= :dateFrom
                               and fd.DateCreated <= :dateTill
                             union 
                    --LOCT
                             select fd.FinDoc_ID as id,
                                    :metaDocType as metaDocType,
                                    :langKey as langKey
                             from FinDoc fd with (nolock)
                                          join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                                          join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                                          join FinDocStatus fdss with (nolock) on dts.FinDocStatus_IDREF = fdss.FinDocStatus_ID
                                          left join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                                          join Transfer acct with (nolock) on fd.FinDoc_ID = acct.FinDoc_IDREF
                                          left join Bank b with (nolock) on b.Code = SUBSTRING(acct.Receiver_Account, 5, 3)
                                          left join Term trm_b with (nolock) on trm_b.Term_ID = b.Term_OUTREF
                                          left join MetaDocument md with (nolock)
                                                    on md.Target_ID = b.Bank_ID
                                                        and md.Target_Table = 'Bank'
                                                        and md.DocumentType_IDREF = :metaDocTypeBank
                                                        and md.LangKey = 'EN'
                                                        and md.IsActive = 1
                                          left join Card sc with (nolock) on acct.SenderCard_IDREF = sc.Card_ID --sender data start
                                          left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                                          join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                                          left join map_User_Account mua with (nolock)
                                                    on mua.User_IDREF = fd.User_IDREF and mua.Account_IDREF = sacc.Account_ID
                                          left join AccountProduct sacc_ap with (nolock)
                                                    on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                                       sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                          left join DepositProduct sacc_dp with (nolock)
                                                    on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                                       sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                          left join CardAccountProduct sacc_cap with (nolock)
                                                    on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                                       sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                                          left join ProductShortName sacc_psn with (nolock)
                                                    on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                       sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                                       sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                                          left join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                                          join Account racc with (nolock) on acct.Receiver_Account = racc.Number --receiver date
                             where fdt.FinDocType_ID in ('LOCR', 'LOCF')
                                   and fd.User_IDREF = :userId
                                   and dts.FinDocStatus_IDREF in ('DONE', 'PROC', 'EROR', 'RJCT')
                                   and fd.DateCreated >= :dateFrom
                                   and fd.DateCreated <= :dateTill
                    ) as historyCount;
            """,
            nativeQuery = true)
    Page<TransferHistoryProjection> findByDatePeriodAndUserId(@Param("dateFrom") LocalDate from,
                                                              @Param("dateTill") LocalDate to,
                                                              @Param("userId") Long userId,
                                                              @Param("langKey") String langKey,
                                                              @Param("metaDocType") String metaDocType,
                                                              @Param("metaDocTypeBank") String metaDocTypeBank,
                                                              Pageable pageable);

    @Query("select fd.docType from FinDocEntity fd where fd.id = :id")
    Optional<String> findDocType(Long id);
}
