package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FeeOut;

import java.math.BigDecimal;

public interface GetFeeAmountUseCase {

    BigDecimal invoke(BigDecimal amount, FeeOut fee);
}
