package eub.smart.cardproduct.transfer.generic.core.constant;

public interface HeaderName {

    String CORRELATION_ID = "X-Correlation-Id";
    String LANG_KEY = "Accept-Language";
    String FRONT_END_ID = "Front-End-Id";
}
