package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public class CreateTransferCardDataIn {
    private Long id;
    private Long accId;
    private String accType;
    private String currency;
    private String accNumber;
    private Boolean flagMultiCurrency;
    private Long accIdRef;
    private Long cardOutRef;

    public CreateTransferCardDataIn(Long id,
                                    Long accId,
                                    String accType,
                                    String currency,
                                    String accNumber,
                                    Boolean flagMultiCurrency,
                                    Long accIdRef,
                                    Long cardOutRef) {
        this.id = id;
        this.accId = accId;
        this.accType = accType;
        this.currency = currency;
        this.accNumber = accNumber;
        this.flagMultiCurrency = flagMultiCurrency;
        this.accIdRef = accIdRef;
        this.cardOutRef = cardOutRef;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAccId() {
        return accId;
    }

    public void setAccId(Long accId) {
        this.accId = accId;
    }

    public String getAccType() {
        return accType;
    }

    public void setAccType(String accType) {
        this.accType = accType;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAccNumber() {
        return accNumber;
    }

    public void setAccNumber(String accNumber) {
        this.accNumber = accNumber;
    }

    public Boolean getFlagMultiCurrency() {
        return flagMultiCurrency;
    }

    public void setFlagMultiCurrency(Boolean flagMultiCurrency) {
        this.flagMultiCurrency = flagMultiCurrency;
    }

    public Long getAccIdRef() {
        return accIdRef;
    }

    public void setAccIdRef(Long accIdRef) {
        this.accIdRef = accIdRef;
    }

    public Long getCardOutRef() {
        return cardOutRef;
    }

    public void setCardOutRef(Long cardOutRef) {
        this.cardOutRef = cardOutRef;
    }

    @Override
    public String toString() {
        return "CreateTransferCardInfo{" +
                "id=" + id +
                ", accId=" + accId +
                ", accType=" + accType +
                ", currency=" + currency +
                ", accNumber=" + accNumber +
                ", flagMultiCurrency=" + flagMultiCurrency +
                ", accIdRef=" + accIdRef +
                ", cardOutRef=" + cardOutRef +
                '}';
    }
}
