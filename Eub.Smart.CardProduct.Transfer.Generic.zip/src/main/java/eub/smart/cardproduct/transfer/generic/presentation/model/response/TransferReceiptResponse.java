package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import java.util.List;

public record TransferReceiptResponse(

        Long id,
        String title,
        String subtitle,
        String image,
        String number,
        String accountType,
        String finDocType,
        AmountResponse amount,
        AmountResponse fee,
        Long date,
        Boolean isSaved,
        String type,
        String link,
        String status,
        String referenceId,
        List<DetailResponse> details
) {
}
