package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteP2plTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteP2poTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteP2pTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferP2pFavoriteEntity;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.FavoriteP2pTransferMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.FavoriteP2poTransferMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferFavoriteJpaRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferP2PFavoriteJpaRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I13B;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class FavoriteP2pTransferRepositoryImpl implements FavoriteP2pTransferRepository {

    private final Logger log = LogManager.getLogger(getClass());
    private final NamedParameterJdbcTemplate template;
    private final FavoriteP2pTransferMapper favoriteP2pTransferMapper;
    private final FavoriteP2poTransferMapper favoriteP2poTransferMapper;
    private final TransferP2PFavoriteJpaRepository transferP2PFavoriteJpaRepository;
    private final AuthToken authToken;
    private final String s3Url;
    private final InfrastructureMapper mapper;
    private final TransferFavoriteJpaRepository transferFavoriteJpaRepository;

    public FavoriteP2pTransferRepositoryImpl(NamedParameterJdbcTemplate template,
                                             FavoriteP2pTransferMapper favoriteP2pTransferMapper,
                                             FavoriteP2poTransferMapper favoriteP2poTransferMapper,
                                             @Value("${app.s3-download-address}") String s3Url,
                                             TransferP2PFavoriteJpaRepository transferP2PFavoriteJpaRepository,
                                             AuthToken authToken,
                                             InfrastructureMapper mapper,
                                             TransferFavoriteJpaRepository transferFavoriteJpaRepository) {
        this.template = template;
        this.favoriteP2pTransferMapper = favoriteP2pTransferMapper;
        this.favoriteP2poTransferMapper = favoriteP2poTransferMapper;
        this.s3Url = s3Url;
        this.transferP2PFavoriteJpaRepository = transferP2PFavoriteJpaRepository;
        this.authToken = authToken;
        this.mapper = mapper;
        this.transferFavoriteJpaRepository = transferFavoriteJpaRepository;
    }


    @Override
    public Optional<CreateFavoriteP2plTransferIn> findByFinDocId(Long sourceId) {
        Long userId = UserDetails.build(authToken.getDecodedPayload()).getUserId();
        Map<String, Object> map = Map.of(
                "id", sourceId,
                "userId", userId);

        String sql = """
                select fd.FinDoc_ID             as finDocId,
                       fd.User_IDREF            as userId,
                       fd.FinDocType_IDREF      as docType,
                       t.CardTransferType_IDREF as transferType,
                       t.AccountNumber          as accountNumber,
                       case
                           when t.CardTransferType_IDREF = 'P2PL' then
                               t.ReceiverName
                           else (bt.Term_EN + ' • ' + right(t.CreditMaskedCardNumber, 4))
                           end                  as title,
                       b.Bank_ID                as imageId
                from CardTransfer t
                         join FinDoc fd with (nolock) on t.FinDoc_IDREF = fd.FinDoc_ID
                         left join BinCard bc with (nolock) on left(t.CreditMaskedCardNumber, 6) = bc.Bin
                         left join Bank b with (nolock) on bc.Bank_IDREF = b.Bank_ID
                         left join Term bt on bt.Term_ID = b.Term_OUTREF
                where t.FinDoc_IDREF = :id
                and fd.User_IDREF = :userId
                """;

        List<CreateFavoriteP2plTransferIn> queryResult = template.query(sql, map, favoriteP2pTransferMapper::toDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else {
            throw new AppException(E_DB_601, ": FavoriteP2pTransferRepository findByFinDocId");
        }
    }

    @Override
    public CreateFavoriteP2plTransferIn findByFinDocIdOrException(Long finDocId) {
        return findByFinDocId(finDocId)
                .orElseThrow(() -> new AppException(E_DB_600, ": FavoriteP2pTransferRepository findByFinDocIdOrException"));
    }

    @Override
    public Optional<CreateFavoriteP2poTransferIn> findP2poByFinDocId(Long finDocId) {
        Long userId = UserDetails.build(authToken.getDecodedPayload()).getUserId();
        Map<String, Object> map = Map.of(
                "id", finDocId,
                "userId", userId);

        String sql = """
                SELECT fd.FinDoc_ID                                             AS finDocId,
                       fd.User_IDREF                                            AS userId,
                       fd.FinDocType_IDREF                                      AS docType,
                       ct.CardTransferType_IDREF                                AS transferType,
                       ct.Token                                                 AS token,
                       bt.Term_EN + ' • ' + right(ct.CreditMaskedCardNumber, 4) AS title,
                       bc.Bin                                                   AS bin
                FROM CardTransfer ct
                JOIN FinDoc fd ON fd.FinDoc_ID = ct.FinDoc_IDREF\s
                LEFT JOIN BinCard bc WITH (nolock) ON LEFT (ct.CreditMaskedCardNumber, 6) = bc.Bin
                LEFT JOIN Bank b WITH (nolock) ON bc.Bank_IDREF = b.Bank_ID
                LEFT JOIN Term bt ON bt.Term_ID = b.Term_OUTREF
                WHERE ct.FinDoc_IDREF = :id
                  AND fd.User_IDREF = :userId
                """;

        List<CreateFavoriteP2poTransferIn> queryResult = template.query(sql, map, favoriteP2poTransferMapper::toDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else {
            throw new AppException(E_DB_601, ": FavoriteP2pTransferRepository findP2poByFinDocId");
        }
    }

    @Override
    public CreateFavoriteP2poTransferIn findP2poByFinDocIdOrException(Long finDocId) {
        return findP2poByFinDocId(finDocId)
                .orElseThrow(() -> new AppException(E_DB_600, ": FavoriteP2pTransferRepository findP2poByFinDocIdOrException"));
    }

    @Transactional
    @Override
    public Long save(CreateFavoriteP2poTransferIn out) {
        var optExist = exist(out);
        if (optExist.isPresent()) {
            return optExist.get().getTransferFavorite().getId();
        } else {
            var transferP2pFavorite = mapper.toEntity(out);
            var transferFavorite = transferP2pFavorite.getTransferFavorite();
            var savedTransferFavorite = transferFavoriteJpaRepository.save(transferFavorite);
            transferP2pFavorite.setTransferFavorite(savedTransferFavorite);
            var res = transferP2PFavoriteJpaRepository.save(transferP2pFavorite);
            return res.getTransferFavorite().getId();
        }
    }

    @Override
    public FavoriteTransferDisplayOut fillDetailsDisplay(FavoriteTransferDisplayIn in) {
        var langKey = MDC.get(LANG_KEY);
        String sql = """
                SELECT tpp.Title  as title,
                       md.FileUid as imageUid
                FROM TransferP2PFavorite tpp
                         LEFT JOIN BinCard bc ON bc.Bin = tpp.BinCard
                         LEFT JOIN Bank b ON b.Bank_ID = bc.Bank_IDREF
                         LEFT JOIN MetaDocument md ON md.Target_ID = b.Bank_ID
                    AND md.Target_Table = 'Bank'
                    AND md.IsActive = 1
                    AND md.LangKey = 'EN'
                    AND md.DocumentType_IDREF = :metaDocType
                WHERE tpp.TransferFavorite_IDREF = :transferFavoriteId
                """;

        List<FavoriteTransferDisplayOut> queryResult = template.query(sql,
                Map.of("transferFavoriteId", in.getId(), "langKey", langKey, "metaDocType", I13B),
                (resultSet, i) -> favoriteP2poTransferMapper.toDetailsDisplay(resultSet, in, s3Url, langKey));
        return queryResult
                .stream()
                .findFirst()
                .orElseThrow(() -> new AppException(E_DB_601, ": FavoriteAccTransferRepository fillDetailsDisplay"));
    }

    @Transactional
    @Override
    public void delete(CreateFavoriteP2poTransferIn in) {
        var optExist = exist(in);
        if (optExist.isPresent()) {
            var transferP2pFavorite = optExist.get();
            var transferFavorite = transferP2pFavorite.getTransferFavorite();
            transferP2PFavoriteJpaRepository.deleteByTransferFavoriteId(transferFavorite.getId());
            transferFavoriteJpaRepository.deleteById(transferFavorite.getId());
        } else {
            log.warn("TransferFavoriteId is not found");
        }
    }

    public Optional<TransferP2pFavoriteEntity> exist(CreateFavoriteP2poTransferIn out) {
        var senderUserId = out.favoriteTransferOut().userId();
        var token = out.token();
        return transferP2PFavoriteJpaRepository
                .findByParam(senderUserId, token);
    }

}
