package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FeeOut;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetFeeAmountUseCase;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class GetFeeAmountUseCaseImpl implements GetFeeAmountUseCase {

    @Override
    public BigDecimal invoke(BigDecimal amount, FeeOut fee) {
        if (isFixedFee(fee)) {
            return fee.getFeeFixed();
        } else if (isPercentFee(fee)) {
            return getPercentAmount(amount, fee);
        } else if (isMinFixedFee(fee)) {
            return fee.getFeePercentMin();
        } else {
            return new BigDecimal(0);
        }
    }

    private boolean isMinFixedFee(FeeOut fee) {
        var zero = BigDecimal.ZERO;
        return fee.getFeePercent().compareTo(zero) <= 0 && fee.getFeePercentMin().compareTo(zero) > 0;
    }

    private BigDecimal getPercentAmount(BigDecimal amount, FeeOut fee) {
        var feeByPercent = amount.multiply(fee.getFeePercent());
        if (isMinFee(fee, feeByPercent)) {
            return fee.getFeePercentMin();
        } else if (isMaxFee(fee, feeByPercent)) {
            return fee.getFeePercentMax();
        } else {
            return feeByPercent;
        }
    }

    private boolean isFixedFee(FeeOut fee) {
        var zero = new BigDecimal(0);
        return fee.getFeeFixed().compareTo(zero) > 0;
    }

    private boolean isPercentFee(FeeOut fee) {
        var zero = new BigDecimal(0);
        var feePercent = fee.getFeePercent();
        if (feePercent == null) return false;
        return feePercent.compareTo(zero) > 0;
    }

    private boolean isMinFee(FeeOut fee, BigDecimal feeByPercent) {
        return feeByPercent.compareTo(fee.getFeePercentMin()) < 0;
    }
    private boolean isMaxFee(FeeOut fee, BigDecimal feeByPercent) {
        return feeByPercent.compareTo(fee.getFeePercentMax()) > 0;
    }

}
