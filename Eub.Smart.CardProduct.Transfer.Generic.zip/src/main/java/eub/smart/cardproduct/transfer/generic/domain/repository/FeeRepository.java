package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FeeOut;

import java.util.Optional;

public interface FeeRepository {

    Optional<FeeOut> findById(Long id);

    FeeOut findByIdOrException(Long id);

    FeeOut findFeeByAccountId(Long accountId);
}
