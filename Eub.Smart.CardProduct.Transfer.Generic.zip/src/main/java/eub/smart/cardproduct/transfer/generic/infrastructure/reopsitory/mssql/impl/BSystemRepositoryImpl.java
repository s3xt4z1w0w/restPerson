package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.repository.BSystemRepository;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class BSystemRepositoryImpl implements BSystemRepository {

    private final NamedParameterJdbcTemplate template;

    public BSystemRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }


    @Override
    public Optional<Integer> findActiveBSystemCount(String bSystem) {
        RowMapper<Integer> rowMapper = (rs, rowNum) -> rs.getInt("activeSystemsCount");

        String query = ("""
                SELECT count(1) as activeSystemsCount
                            FROM [dbo].[AccessibilityAccSystems]
                            WHERE AnnouncementStatus_IdRef = 'ACTV'
                              and BSystem_IdRef = :bSystem
                              and GetDate() BETWEEN StartDate AND EndDate
                """);
        List<Integer> queryResult = template.query(query, Map.of("bSystem", bSystem), rowMapper);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": BSystemRepositoryImpl findInactiveBSystemCount");
        }
    }
}
