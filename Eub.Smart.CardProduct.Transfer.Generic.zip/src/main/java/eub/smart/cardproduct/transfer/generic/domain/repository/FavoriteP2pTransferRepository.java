package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteP2plTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteP2poTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;

import java.util.Optional;

public interface FavoriteP2pTransferRepository {

    Optional<CreateFavoriteP2plTransferIn> findByFinDocId(Long id);

    CreateFavoriteP2plTransferIn findByFinDocIdOrException(Long finDocId);

    Optional<CreateFavoriteP2poTransferIn> findP2poByFinDocId(Long finDocId);
    CreateFavoriteP2poTransferIn findP2poByFinDocIdOrException(Long finDocId);

    Long save(CreateFavoriteP2poTransferIn out);
    FavoriteTransferDisplayOut fillDetailsDisplay(FavoriteTransferDisplayIn in);
    void delete(CreateFavoriteP2poTransferIn in);
}
