package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record RetransferAccountIn(
        Long accountId,
        Long cardId,
        String currency
) {
}
