package eub.smart.cardproduct.transfer.generic.domain.model.in.presentation;

import java.math.BigDecimal;

public record CreateRetransferDataIn(

        Long finDocId,
        BigDecimal debitAmount,
        BigDecimal creditAmount
) {
}

