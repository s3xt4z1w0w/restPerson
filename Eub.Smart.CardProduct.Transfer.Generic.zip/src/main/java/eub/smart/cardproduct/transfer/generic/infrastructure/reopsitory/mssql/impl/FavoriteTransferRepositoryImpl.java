package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteTransferDataIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferFavoriteEntity;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferAccFavoriteJpaRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferFavoriteJpaRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferIpsFavoriteJpaRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferP2PFavoriteJpaRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.*;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class FavoriteTransferRepositoryImpl implements FavoriteTransferRepository {

    private final NamedParameterJdbcTemplate template;
    private final TransferFavoriteJpaRepository transferFavoriteJpaRepository;
    private final TransferAccFavoriteJpaRepository transferAccFavoriteJpaRepository;
    private final TransferIpsFavoriteJpaRepository transferIpsFavoriteJpaRepository;
    private final TransferP2PFavoriteJpaRepository transferP2PFavoriteJpaRepository;
    private final AuthToken authToken;

    public FavoriteTransferRepositoryImpl(NamedParameterJdbcTemplate template,
                                          TransferFavoriteJpaRepository transferFavoriteJpaRepository,
                                          TransferAccFavoriteJpaRepository transferAccFavoriteJpaRepository,
                                          TransferIpsFavoriteJpaRepository transferIpsFavoriteJpaRepository,
                                          TransferP2PFavoriteJpaRepository transferP2PFavoriteJpaRepository,
                                          AuthToken authToken) {
        this.template = template;
        this.transferFavoriteJpaRepository = transferFavoriteJpaRepository;
        this.transferAccFavoriteJpaRepository = transferAccFavoriteJpaRepository;
        this.transferIpsFavoriteJpaRepository = transferIpsFavoriteJpaRepository;
        this.transferP2PFavoriteJpaRepository = transferP2PFavoriteJpaRepository;
        this.authToken = authToken;
    }

    @Override
    public Page<FavoriteTransferDisplayIn> getAll(Pageable pageable) {
        var userDetails = UserDetails.build(authToken.getDecodedPayload());
        var userId = userDetails.getUserId();
        return transferFavoriteJpaRepository
                .findAllByUserId(userId, pageable);
    }

    @Override
    public void delete(Long id) {
        transferFavoriteJpaRepository.deleteById(id);
    }

    @Transactional
    @Override
    public void rename(Long id, String name) {
        var userId = UserDetails
                .build(authToken.getDecodedPayload())
                .getUserId();
        transferFavoriteJpaRepository.rename(id, userId, name);
    }

    @Transactional
    @Override
    public void fullDelete(Long id) {
        var userId = UserDetails
                .build(authToken.getDecodedPayload())
                .getUserId();
        transferFavoriteJpaRepository
                .findByIdAndUserId(id, userId)
                .ifPresent(this::fullDelete);
    }

    private void fullDelete(TransferFavoriteEntity entity) {
        var type = entity.getType();
        var favoriteTransferType = EnumUtil.valueOfOrException(FavoriteTransferType.class, type);
        switch (favoriteTransferType) {
            case ACCT, LOCT, SLFT -> transferAccFavoriteJpaRepository.deleteByTransferFavoriteId(entity.getId());
            case IPSO -> transferIpsFavoriteJpaRepository.deleteByTransferFavoriteId(entity.getId());
            case P2PO -> transferP2PFavoriteJpaRepository.deleteByTransferFavoriteId(entity.getId());
            default -> throw new AppException(E_LG_802, ": FavoriteTransferRepository fullDelete: " + type);
        }
        transferFavoriteJpaRepository.deleteById(entity.getId());
    }

    @Override
    public CreateFavoriteTransferDataIIn getRetransferData(Long id) {
        var userId = UserDetails
                .build(authToken.getDecodedPayload())
                .getUserId();

        RowMapper<CreateFavoriteTransferDataIIn> rowMapper = (rs, rowNum) -> new CreateFavoriteTransferDataIIn(
                rs.getLong("finDocId"),
                rs.getString("type"),
                rs.getString("senderCurrency"),
                rs.getString("receiverCurrency"));

        String sql = """
                select fd.FinDoc_ID        as finDocId,
                       tf.Type             as type,
                       fd.Currency         as senderCurrency,
                       t.Receiver_Currency as receiverCurrency
                from TransferFavorite tf
                         join FinDoc fd on tf.FinDoc_IDREF = fd.FinDoc_ID
                         join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                where tf.User_IDREF = :userId
                  and tf.TransferFavorite_ID = :id
                """;

        List<CreateFavoriteTransferDataIIn> queryResult = template.query(
                sql,
                Map.of("id", id, "userId", userId),
                rowMapper);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, " FavoriteTransferRepository findRetransferAccount"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, " FavoriteTransferRepository getRetransferData");
        } else {
            throw new AppException(E_DB_601, ": FavoriteTransferRepository getRetransferData");
        }
    }
}
