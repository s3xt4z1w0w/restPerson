package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import java.math.BigDecimal;

public record CurrencyExchangeResponse(
        BigDecimal exchangeCoefficient,
        AmountResponse fromAmount,
        AmountResponse toAmount
) {
}
