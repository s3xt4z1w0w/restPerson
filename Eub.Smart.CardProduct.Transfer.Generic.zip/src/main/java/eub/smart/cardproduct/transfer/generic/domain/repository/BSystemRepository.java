package eub.smart.cardproduct.transfer.generic.domain.repository;

import java.util.Optional;

public interface BSystemRepository {

    Optional<Integer> findActiveBSystemCount(String bSystem);
}
