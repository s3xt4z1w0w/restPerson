package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteIpslTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteIpsoTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteIpsRetransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteIpsTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;

import java.util.Optional;

public interface FavoriteIpsTransferRepository {

    Optional<CreateFavoriteIpslTransferIn> findByFinDocId(Long sourceId);

    CreateFavoriteIpslTransferIn findByFinDocIdOrException(Long sourceId);

    FavoriteIpsRetransferIn getFavorite(Long favoriteTransferId, Long userId);

    Optional<CreateFavoriteIpsoTransferIn> findIpsoByFinDocId(Long finDocId);

    CreateFavoriteIpsoTransferIn findIpsoByFinDocIdOrException(Long finDocId);

    FavoriteTransferDisplayOut fillDetailsDisplay(FavoriteTransferDisplayIn in);

    FavoriteIpsTransferIn save(CreateFavoriteIpsoTransferIn out);

    void delete(CreateFavoriteIpsoTransferIn out);

}
