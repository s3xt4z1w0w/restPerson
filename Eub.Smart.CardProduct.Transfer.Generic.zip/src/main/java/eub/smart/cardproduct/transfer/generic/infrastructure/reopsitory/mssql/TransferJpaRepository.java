package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferSelfIn;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TransferJpaRepository extends JpaRepository<TransferEntity, Long> {

    @Query(value = """
            select FD.Account_IDREF     as senderAccountId,
                   RA.Account_ID        as receiverAccountId,
                   T.SenderCard_IDREF   as senderCardId,
                   T.ReceiverCard_IDREF as receiverCardId,
                   FD.Currency          as senderCurrency,
                   T.Receiver_Currency  as receiverCurrency
            from Transfer T
                     join FinDoc FD on T.FinDoc_IDREF = FD.FinDoc_ID
                     join Account RA on T.Receiver_Account = RA.Number
            where FD.FinDocType_IDREF in ('TSLF', 'SLFF', 'SLFR')
              and FD.FinDoc_ID = :finDocId
            """, nativeQuery = true)
    Optional<CreateRetransferSelfIn> findCreateRepeatSelfData(Long finDocId);

    Optional<TransferEntity> findByFinDocId(Long finDocId);
}
