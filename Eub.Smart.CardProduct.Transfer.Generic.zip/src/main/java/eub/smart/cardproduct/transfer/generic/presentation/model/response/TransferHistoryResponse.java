package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public record TransferHistoryResponse(
        @Schema(description = "FinDoc Id")
        Long id,
        @Schema(description = "Откуда")
        String from,
        @Schema(description = "Куда")
        String title,
        @Schema(description = "Доп инфа по виду перевода")
        String subtitle,
        @Schema(description = "Ссылка на иконку")
        String image,
        @Schema(description = "Номер карты")
        String number,
        @Schema(description = "Сообщение")
        String message,
        @Schema(description = "Инфа о сумме перевода")
        AmountResponse amount,
        @Schema(description = "Дата совершения перевода")
        Long date,
        @Schema(description = "Статус перевода")
        String status,
        @Schema(description = "Тип аккаунта")
        String accountType,
        @Schema(description = "Тип финдока")
        String finDocType
) {
}
