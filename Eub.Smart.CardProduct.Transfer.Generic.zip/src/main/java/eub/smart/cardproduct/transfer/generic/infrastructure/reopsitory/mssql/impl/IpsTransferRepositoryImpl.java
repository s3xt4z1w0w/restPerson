package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateIpsoTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.IpsTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.IpsTransferJpaRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.CommonMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class IpsTransferRepositoryImpl implements IpsTransferRepository {

    private final InfrastructureMapper mapper;
    private final IpsTransferJpaRepository ipsTransferJpaRepository;
    private final NamedParameterJdbcTemplate template;

    public IpsTransferRepositoryImpl(InfrastructureMapper mapper,
                                     IpsTransferJpaRepository ipsTransferJpaRepository,
                                     NamedParameterJdbcTemplate template) {
        this.mapper = mapper;
        this.ipsTransferJpaRepository = ipsTransferJpaRepository;
        this.template = template;
    }

    @Override
    public Long save(CreateIpsoTransferOut out) {
        var entity = mapper.toEntity(out);
        var saved = ipsTransferJpaRepository.save(entity);
        return saved.getIpsTransferId();
    }

    @Override
    public String findReceiverBankByFinDocId(Long finDocId) {
        RowMapper<String> rowMapper = (rs, rowNum) -> rs.getString("bic");
        String sql = """ 
                SELECT i.BANK_ReceiverBic as bic
                FROM IPSTransfer i
                WHERE i.FinDoc_IDREF = :finDocId
                """;

        List<String> queryResult = template.query(
                sql,
                Map.of("finDocId", finDocId),
                rowMapper);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, " :IpsTransferRepository findReceiverBankByFinDocId"));
        } else {
            throw new AppException(E_DB_601, ": IpsTransferRepository findReceiverBankByFinDocId");
        }
    }
}
