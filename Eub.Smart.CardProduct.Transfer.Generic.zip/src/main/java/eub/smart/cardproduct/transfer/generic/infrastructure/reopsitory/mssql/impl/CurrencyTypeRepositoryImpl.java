package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.util.StringUtil;
import eub.smart.cardproduct.transfer.generic.domain.repository.CurrencyTypeRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class CurrencyTypeRepositoryImpl implements CurrencyTypeRepository {

    private final NamedParameterJdbcTemplate template;
    private final String s3Url;

    public CurrencyTypeRepositoryImpl(NamedParameterJdbcTemplate template,
                                      @Value("${app.s3-download-address}") String s3Url) {
        this.template = template;
        this.s3Url = s3Url;
    }

    @Override
    public Optional<String> findImageUid(String currency, String targetTable, String documentType) {
        RowMapper<String> rowMapper = (rs, rowNum) -> imageUrl(s3Url, rs.getString("fileUid"));

        String sql = """
                select d.FileUid as fileUid
                from CurrencyType c
                         join MetaDocument d on c.Target_ID = d.Target_ID
                    and d.IsActive = 1
                    and d.LangKey = 'EN'
                    and d.Target_Table = :targetTable
                    and d.DocumentType_IDREF = :documentType
                where c.Currency_Code = :currency;
                """;
        List<String> queryResult = template.query(
                sql,
                Map.of("targetTable", targetTable, "currency", currency, "documentType", documentType),
                rowMapper);

        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": MetaDocumentRepository find uid");
        }
    }

    private static String imageUrl(String s3Url, String uid) {
        if (StringUtil.isEmpty(uid)) return uid;
        return String.format("%s?fileUid=%s", s3Url, uid);
    }
}
