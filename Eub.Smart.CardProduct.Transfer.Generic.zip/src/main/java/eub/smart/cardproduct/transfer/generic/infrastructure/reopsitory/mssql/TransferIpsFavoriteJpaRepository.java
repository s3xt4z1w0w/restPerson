package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteIpsRetransferIn;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferIpsFavoriteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TransferIpsFavoriteJpaRepository extends JpaRepository<TransferIpsFavoriteEntity, Long> {

    @Query(value = """
        SELECT TIF.ReceiverPhoneNumber as phoneNumber,
                MD.FileUid as fileUid,
                COALESCE(TF.Title, TIF.ReceiverName) as receiverName,
        		MD.Screen
        FROM TransferFavorite TF
        JOIN TransferIpsFavorite TIF ON TIF.TransferFavorite_IDREF = TF.TransferFavorite_ID
        JOIN Bank B on B.Bank_ID = TIF.ReceiverBank_IDREF
        JOIN MetaDocument MD ON MD.Target_Table = 'Bank' and
        						MD.Target_ID =	B.Bank_ID and
        						MD.IsActive = 1 and
        						md.LangKey = :lang
        WHERE TF.TransferFavorite_ID = :favoriteTransferId and TF.User_IDREF = :userId
    """, nativeQuery = true)
    Optional<FavoriteIpsRetransferIn> findFavorite(Long favoriteTransferId, Long userId, String lang);

    @Query(value = """
        SELECT tif.*
        FROM TransferFavorite tf
                 JOIN TransferIpsFavorite tif ON tif.TransferFavorite_IDREF = tf.TransferFavorite_ID
        WHERE tf.User_IDREF = :userId
          AND tif.ReceiverPhoneNumber = :receiverPhone
          AND tif.ReceiverBank_IDREF = :bankId
    """, nativeQuery = true)
    Optional<TransferIpsFavoriteEntity> findByParam(Long userId, String receiverPhone, Long bankId);

    void deleteByTransferFavoriteId(Long transferFavoriteId);
}
