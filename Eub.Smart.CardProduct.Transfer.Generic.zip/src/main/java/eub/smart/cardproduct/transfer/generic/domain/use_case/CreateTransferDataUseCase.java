package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateTransferDataOut;

public interface CreateTransferDataUseCase {

    CreateTransferDataIn invoke(CreateTransferDataOut createTransferDataOut, CreateTransferClientDataIn senderAccount, CreateTransferClientDataIn receiverAccount);
}
