package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;

public class CommonMapper {

    public static Long getLong(ResultSet resultSet, int i) {
        try {
            return resultSet.getLong("id");
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    public static String getType(ResultSet resultSet, int i) {
        try {
            return resultSet.getString("type");
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }
}
