package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CurrencyRateIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CurrencyExchangeOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.RsbkInfoProtoRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CurrencyExchangeRateUseCase;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;

import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.KZT;

@Service
public class CurrencyExchangeRateUseCaseImpl implements CurrencyExchangeRateUseCase {

    private final RsbkInfoProtoRepository rsbkInfoProtoRepository;

    public CurrencyExchangeRateUseCaseImpl(RsbkInfoProtoRepository rsbkInfoProtoRepository) {
        this.rsbkInfoProtoRepository = rsbkInfoProtoRepository;
    }

    @Override
    public CurrencyExchangeOut invoke(String from, String to) {
        var fromRate = rsbkInfoProtoRepository.findCurrencyRate(from);
        var toRate = rsbkInfoProtoRepository.findCurrencyRate(to);
        return invoke(fromRate, toRate);
    }

    @Override
    public CurrencyExchangeOut invoke(CurrencyRateIn fromRate, CurrencyRateIn toRate) {
        if (isSameCurrency(fromRate.currency(), toRate.currency())) {
            return new CurrencyExchangeOut(fromRate);
        } else if (isStraight(fromRate.currency(), toRate.currency())) {
            return calcStraightConversion(fromRate, toRate);
        } else {
            return calcCrossConversion(fromRate, toRate);
        }
    }

    private CurrencyExchangeOut calcStraightConversion(CurrencyRateIn fromRate, CurrencyRateIn toRate) {
        if (KZT.equals(fromRate.currency())) {
            return calcKztToCur(fromRate, toRate);
        } else {
            return calcCurToKzt(fromRate, toRate);
        }
    }

    private CurrencyExchangeOut calcCrossConversion(CurrencyRateIn fromRate, CurrencyRateIn toRate) {
        if (fromRate.sellRate().compareTo(toRate.sellRate()) >= 0) {
            return calcCrossFromHighToLow(fromRate, toRate);
        } else {
            return calcCrossFromLowToHigh(fromRate, toRate);
        }
    }

    private CurrencyExchangeOut calcKztToCur(CurrencyRateIn kzt, CurrencyRateIn cur) {
        var exchangeCoefficient = kzt.sellRate().divide(cur.sellRate(), 10, RoundingMode.DOWN);
        return new CurrencyExchangeOut(exchangeCoefficient, cur.sellRate(), cur.currency(), kzt.currency());
    }

    private CurrencyExchangeOut calcCurToKzt(CurrencyRateIn cur, CurrencyRateIn kzt) {
        return new CurrencyExchangeOut(cur.buyRate(), cur.buyRate(), cur.currency(), kzt.currency());
    }

    private CurrencyExchangeOut calcCrossFromHighToLow(CurrencyRateIn fromRate, CurrencyRateIn toRate) {
        var exchangeCoefficient = fromRate.buyRate().divide(toRate.sellRate(), 10, RoundingMode.DOWN);
        var sellRate = exchangeCoefficient.setScale(4, RoundingMode.HALF_UP);
        return new CurrencyExchangeOut(exchangeCoefficient, sellRate, fromRate.currency(), toRate.currency());
    }

    private CurrencyExchangeOut calcCrossFromLowToHigh(CurrencyRateIn fromRate, CurrencyRateIn toRate) {
        var exchangeCoefficient = fromRate.buyRate().divide(toRate.sellRate(), 10, RoundingMode.DOWN);
        var sellRate = toRate.sellRate().divide(fromRate.buyRate(), 4, RoundingMode.HALF_UP);
        return new CurrencyExchangeOut(exchangeCoefficient, sellRate, toRate.currency(), fromRate.currency());
    }

    private boolean isStraight(String senderAccountCurrency, String receiverAccountCurrency) {
        return KZT.equals(senderAccountCurrency) || KZT.equals(receiverAccountCurrency);
    }

    private boolean isSameCurrency(String senderAccountCurrency, String receiverAccountCurrency) {
        return senderAccountCurrency.equals(receiverAccountCurrency);
    }
}
