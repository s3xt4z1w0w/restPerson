package eub.smart.cardproduct.transfer.generic.core.constant;

public interface MdcConstants {

    String X_FORWARDED_FOR = "X-Forwarded-For";
}
