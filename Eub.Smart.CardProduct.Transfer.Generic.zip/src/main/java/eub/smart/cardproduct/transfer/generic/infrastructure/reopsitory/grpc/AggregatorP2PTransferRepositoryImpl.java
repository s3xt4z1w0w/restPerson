package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.grpc;

import eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.Error;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FeeOutgoingIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FeeP2pIin;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FeeP2pIOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.AggregatorP2PTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.checkerframework.checker.units.qual.A;
import org.springframework.stereotype.Repository;
import p2p.EubAggregatorCardProductTransferP2P;
import p2p.P2PGrpc;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.ERROR_TECHNICAL_SUBTITLE;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.ERROR_TECHNICAL_TITLE;
import static eub.smart.cardproduct.transfer.generic.core.util.GrpcUtil.toDecimalValue;
import static eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil.getCurrentLocale;

@Repository
public class AggregatorP2PTransferRepositoryImpl implements AggregatorP2PTransferRepository {

    @GrpcClient("aggregator-transfer-p2p")
    private P2PGrpc.P2PBlockingStub stub;
    private final InfrastructureMapper mapper;
    private final MessageSourceRepository messageSourceRepository;

    public AggregatorP2PTransferRepositoryImpl(InfrastructureMapper mapper, MessageSourceRepository messageSourceRepository) {
        this.mapper = mapper;
        this.messageSourceRepository = messageSourceRepository;
    }

    @Override
    public FeeOutgoingIIn getFee(Long cardOutRef, BigDecimal amount) {
        try {
            var request = EubAggregatorCardProductTransferP2P.GetFeeRequest.newBuilder()
                    .setCardId(cardOutRef)
                    .setAmount(toDecimalValue(amount))
                    .build();
            var response = stub.getFee(request);
            return mapper.toDomain(response);
        } catch (StatusRuntimeException e) {
            var error = new Error(messageSourceRepository.getMessage(ERROR_TECHNICAL_TITLE, getCurrentLocale()),
                    messageSourceRepository.getMessage(ERROR_TECHNICAL_SUBTITLE, getCurrentLocale()));
            throw new AppException(AppErrorCode.E_EX_701, new FieldsValidationResponse(error, null));
        }
    }
}
