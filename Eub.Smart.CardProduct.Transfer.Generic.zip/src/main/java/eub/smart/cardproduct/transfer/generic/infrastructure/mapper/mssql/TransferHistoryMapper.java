package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.enums.FinDocStatusDisplay;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.LocalizedText;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferHistoryOut;
import eub.smart.cardproduct.transfer.generic.infrastructure.model.TransferHistoryProjection;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import org.springframework.stereotype.Component;

import static eub.smart.cardproduct.transfer.generic.core.constant.AccountType.BANK;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.CardTransferType.P2PL;
import static eub.smart.cardproduct.transfer.generic.core.constant.CardTransferType.P2PO;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.IpsTransferType.IPSL;
import static eub.smart.cardproduct.transfer.generic.core.constant.IpsTransferType.IPSO;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.generic.core.util.ImageUtil.formImageUrl;
import static eub.smart.cardproduct.transfer.generic.core.util.StringUtil.last4;
import static java.util.Objects.isNull;

@Component
public class TransferHistoryMapper {

    private final LocalizedText subTitleSelf;
    private final LocalizedText subTitleLocal;
    private final LocalizedText subTitleOutgoing;
    private final LocalizedText subTitleAccount;

    public TransferHistoryMapper(MessageSourceRepositoryImpl messageSourceRepository) {
        String subTitleSelfRu = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.RU);
        String subTitleSelfKk = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.KK);
        String subTitleSelfEn = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.EN);
        String subTitleLocalRu = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.RU);
        String subTitleLocalKk = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.KK);
        String subTitleLocalEn = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.EN);
        String subTitleOutgoingRu = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.RU);
        String subTitleOutgoingKk = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.KK);
        String subTitleOutgoingEn = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.EN);
        String subTitleAccountRu = messageSourceRepository.getMessage(SUB_TITLE_ACCOUNT, LangUtil.RU);
        String subTitleAccountKk = messageSourceRepository.getMessage(SUB_TITLE_ACCOUNT, LangUtil.KK);
        String subTitleAccountEn = messageSourceRepository.getMessage(SUB_TITLE_ACCOUNT, LangUtil.EN);
        this.subTitleSelf = new LocalizedText(subTitleSelfRu, subTitleSelfKk, subTitleSelfEn);
        this.subTitleLocal = new LocalizedText(subTitleLocalRu, subTitleLocalKk, subTitleLocalEn);
        this.subTitleOutgoing = new LocalizedText(subTitleOutgoingRu, subTitleOutgoingKk, subTitleOutgoingEn);
        this.subTitleAccount = new LocalizedText(subTitleAccountRu, subTitleAccountKk, subTitleAccountEn);
    }

    public TransferHistoryOut toDomain(TransferHistoryProjection transferHistoryProjection, String langKey) {
        var imageUid = formImageUrl(transferHistoryProjection.getImageUid());
        var status = EnumUtil.valueOfOrException(FinDocStatusDisplay.class, transferHistoryProjection.getStatus());
        var number = last4(transferHistoryProjection.getNumber());
        var fromSuffix = transferHistoryProjection.getFromSuffix();
        if (isNull(fromSuffix)) fromSuffix = "";
        var subTitle = subTitle(transferHistoryProjection.getFinDocType(), transferHistoryProjection.getSubType(), langKey);

        return new TransferHistoryOut(transferHistoryProjection.getId(),
                transferHistoryProjection.getFromm() + fromSuffix,
                transferHistoryProjection.getTitle(),
                subTitle,
                imageUid,
                number,
                transferHistoryProjection.getMessage(),
                transferHistoryProjection.getAmount(),
                transferHistoryProjection.getCurrency(),
                transferHistoryProjection.getDateCreated().getTime(),
                status.value(),
                defineAccountType(transferHistoryProjection),
                transferHistoryProjection.getFinDocType());
    }

    private String subTitle(String finDocType, String subType, String langKey) {
        return switch (finDocType) {
            case SLFT, SLFF, SLFR -> subTitleSelf.text(langKey);
            case P2PT -> switch (subType) {
                case P2PL -> subTitleLocal.text(langKey);
                case P2PO -> subTitleOutgoing.text(langKey);
                default -> throw new AppException(E_LG_802, ": sub title " + finDocType + " " + subType);
            };
            case IPST -> switch (subType) {
                case IPSL -> subTitleLocal.text(langKey);
                case IPSO -> subTitleOutgoing.text(langKey);
                default -> throw new AppException(E_LG_802, ": sub title " + finDocType + " " + subType);
            };
            case P2PF, P2PR, IPSF, IPSR -> subTitleOutgoing.text(langKey);
            case ACCT, ACCF, ACCR -> subTitleAccount.text(langKey);
            case LOCF, LOCR -> subTitleLocal.text(langKey);
            default -> throw new AppException(E_LG_802, ": sub title " + finDocType + " " + subType);
        };
    }

    private static String defineAccountType(TransferHistoryProjection transferHistoryProjection) {
        return switch (transferHistoryProjection.getFinDocType()) {
            case SLFT, SLFF, SLFR -> transferHistoryProjection.getAccountType();
            default -> BANK;
        };
    }

}
