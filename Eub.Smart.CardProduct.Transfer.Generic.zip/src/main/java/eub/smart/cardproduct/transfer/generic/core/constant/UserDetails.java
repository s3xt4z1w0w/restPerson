package eub.smart.cardproduct.transfer.generic.core.constant;

public interface UserDetails {

    String PREFERRED_USERNAME = "phoneNumber";
    String USER_ID = "userId";
    String CLIENT_ID = "clientId";
    String IIN = "iin";
}
