package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.rest;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountSourceIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.GetRetransferAccountsRepository;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Repository
public class GetRetransferAccountsRepositoryImpl implements GetRetransferAccountsRepository {

    private final HttpServletRequest request;
    private final RestTemplate restTemplate;
    @Value("${app.mybank-address}")
    private String myBankAddress;

    public GetRetransferAccountsRepositoryImpl(HttpServletRequest request,
                                               RestTemplateBuilder restTemplateBuilder) {
        this.request = request;
        this.restTemplate = restTemplateBuilder.build();
    }

    @Override
    public List<AccountSourceIn> findAccountList() {
        String url = myBankAddress + "/mybank/transfer-self";
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(CORRELATION_ID, MDC.get(CORRELATION_ID));
        httpHeaders.add(LANG_KEY, MDC.get(LANG_KEY));
        httpHeaders.add(AUTHORIZATION, request.getHeader(AUTHORIZATION));
        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);

        ResponseEntity<List<AccountSourceIn>> response = restTemplate.exchange(
                url,
                HttpMethod.GET,
                httpEntity,
                new ParameterizedTypeReference<>() {});
        return response.getBody();
    }
}
