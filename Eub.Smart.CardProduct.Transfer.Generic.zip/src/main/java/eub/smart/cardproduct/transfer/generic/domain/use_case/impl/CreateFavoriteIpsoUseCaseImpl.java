package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteIpsTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFavoriteUseCase;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.IPSO;

@Service
public class CreateFavoriteIpsoUseCaseImpl implements CreateFavoriteUseCase {

    private final FavoriteIpsTransferRepository favoriteIpsTransferRepository;

    public CreateFavoriteIpsoUseCaseImpl(FavoriteIpsTransferRepository favoriteIpsTransferRepository) {
        this.favoriteIpsTransferRepository = favoriteIpsTransferRepository;
    }

    @Override
    public Long invoke(Long finDocId) {
        var favoriteIpsTransfer = favoriteIpsTransferRepository.findIpsoByFinDocIdOrException(finDocId);
        var saved = favoriteIpsTransferRepository.save(favoriteIpsTransfer);
        return saved.favoriteTransferIn().id();
    }

    @Override
    public Set<String> keySet() {
        return Set.of(IPSO);
    }
}
