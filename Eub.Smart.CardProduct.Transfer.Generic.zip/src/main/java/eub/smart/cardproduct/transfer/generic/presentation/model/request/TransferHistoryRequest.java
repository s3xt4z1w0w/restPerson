package eub.smart.cardproduct.transfer.generic.presentation.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

public record TransferHistoryRequest(
        @NotNull
        @JsonProperty("from")
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        @Schema(description = "Истории переводов дата с")
        LocalDate from,

        @NotNull
        @JsonProperty("to")
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        @Schema(description = "Истории переводов дата по")
        LocalDate to
) {
    public static TransferHistoryRequest oneMonth() {
        var from = LocalDate.now().minusMonths(1);
        var to = LocalDate.now();
        return new TransferHistoryRequest(from, to);
    }
}
