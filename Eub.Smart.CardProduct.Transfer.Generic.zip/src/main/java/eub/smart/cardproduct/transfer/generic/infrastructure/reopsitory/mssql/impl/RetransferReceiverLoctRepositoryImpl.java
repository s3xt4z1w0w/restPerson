package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.AccountTargetOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.RetransferReceiverRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.RetransferReceiverMapper;
import org.slf4j.MDC;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I13B;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.LOCF;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.LOCR;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class RetransferReceiverLoctRepositoryImpl implements RetransferReceiverRepository {

    private final NamedParameterJdbcTemplate template;
    private final RetransferReceiverMapper retransferReceiverMapper;
    private final AuthToken authToken;

    public RetransferReceiverLoctRepositoryImpl(NamedParameterJdbcTemplate template,
                                                RetransferReceiverMapper retransferReceiverMapper,
                                                AuthToken authToken) {
        this.template = template;
        this.retransferReceiverMapper = retransferReceiverMapper;
        this.authToken = authToken;
    }

    @Override
    public Optional<AccountTargetOut> findByFinDocId(Long finDocId) {
        var langKey = MDC.get(LANG_KEY);
        var userDetails = UserDetails.build(authToken.getDecodedPayload());
        var userId = userDetails.getUserId();

        Map<String, Object> map = Map.of(
                "finDocId", finDocId,
                "userId", userId,
                "metaDocTypeBank", I13B);

        String sql = """
                select acct.Receiver_Name                   as title,
                       case --imageUid
                           when md.FileUid is not null then
                               md.FileUid
                           else
                               (select imd.FileUid
                                from MetaDocument imd with (nolock)
                                where imd.Target_ID = 0
                                  and imd.Target_Table = 'Bank'
                                  and imd.DocumentType_IDREF = :metaDocTypeBank
                                  and imd.LangKey = 'EN'
                                  and imd.IsActive = 1) end as imageUid
                from FinDoc fd with (nolock)
                         join Transfer acct with (nolock) on fd.FinDoc_ID = acct.FinDoc_IDREF
                         left join Bank b with (nolock) on b.Code = SUBSTRING(acct.Receiver_Account, 5, 3)
                         left join Term trm_b with (nolock) on trm_b.Term_ID = b.Term_OUTREF
                         left join MetaDocument md with (nolock)
                                   on md.Target_ID = b.Bank_ID
                                       and md.Target_Table = 'Bank'
                                       and md.DocumentType_IDREF = :metaDocTypeBank
                                       and md.LangKey = 'EN'
                                       and md.IsActive = 1
                where fd.User_IDREF = :userId
                  and fd.FinDoc_ID = :finDocId
                """;
        List<AccountTargetOut> queryResult = template.query(sql, map, (resultSet, i) -> retransferReceiverMapper.toLoctDomain(resultSet, langKey));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": RetransferReceiverLoctRepositoryImpl findByFinDocId");
        }
    }

    @Override
    public AccountTargetOut findByFinDocIdOrException(Long finDocId) {
        return findByFinDocId(finDocId).
                orElseThrow(() -> new AppException(E_DB_600, ": RetransferReceiverLoctRepositoryImpl findByFinDocIdOrException"));
    }

    @Override
    public Set<String> keys() {
        return Set.of(LOCF, LOCR);
    }
}
