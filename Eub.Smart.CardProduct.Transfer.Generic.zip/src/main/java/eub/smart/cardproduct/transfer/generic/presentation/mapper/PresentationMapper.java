package eub.smart.cardproduct.transfer.generic.presentation.mapper;

import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.CreateFavoriteTransferDataPIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.TransferHistoryIn;
import eub.smart.cardproduct.transfer.generic.presentation.model.request.CreateFavoriteTransferRequest;
import eub.smart.cardproduct.transfer.generic.presentation.model.request.CreateRepeatTransferRequest;
import eub.smart.cardproduct.transfer.generic.presentation.model.request.TransferHistoryRequest;
import org.mapstruct.Mapper;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING)
public interface PresentationMapper {

    TransferHistoryIn toDomain(TransferHistoryRequest request);

    CreateRetransferDataIn toDomain(CreateRepeatTransferRequest request);

    CreateFavoriteTransferDataPIn toDomain(CreateFavoriteTransferRequest request);
}
