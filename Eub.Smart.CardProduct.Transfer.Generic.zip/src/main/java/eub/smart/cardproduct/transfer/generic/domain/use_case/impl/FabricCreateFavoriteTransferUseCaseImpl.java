package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.CreateFavoriteTransferDataPIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateFavoriteOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FabricCreateFavoriteTransferUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.RetransferUseCase;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

@Service
public class FabricCreateFavoriteTransferUseCaseImpl implements FabricCreateFavoriteTransferUseCase {

    private final FavoriteTransferRepository favoriteTransferRepository;

    private final Map<FavoriteTransferType, RetransferUseCase> useCaseMap = new HashMap<>();

    public FabricCreateFavoriteTransferUseCaseImpl(Set<RetransferUseCase> useCases,
                                                   FavoriteTransferRepository favoriteTransferRepository) {
        fillMap(useCases);
        this.favoriteTransferRepository = favoriteTransferRepository;
    }

    @Override
    public CreateFavoriteOut invoke(CreateFavoriteTransferDataPIn in) {
        var favoriteTransferData = favoriteTransferRepository.getRetransferData(in.favoriteTransferId());
        var useCase = findUseCase(favoriteTransferData.type())
                .orElseThrow(() -> new AppException(E_LG_802, ": for favoriteTransferType: " + favoriteTransferData.type()));
        var retransferData = new CreateRetransferDataIn(in, favoriteTransferData, useCase.favoriteTransferType().finDocType());
        var transferOut = useCase.invoke(retransferData);
        return new CreateFavoriteOut(
                transferOut.id(),
                useCase.favoriteTransferType().finDocType(),
                transferOut.feeAmount());
    }

    private void fillMap(Set<RetransferUseCase> useCases) {
        useCases.forEach(repo -> useCaseMap.put(repo.favoriteTransferType(), repo));
    }

    private Optional<RetransferUseCase> findUseCase(FavoriteTransferType favoriteTransferType) {
        var receiptRepository = useCaseMap.get(favoriteTransferType);
        return Optional.ofNullable(receiptRepository);
    }
}
