package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFavoriteUseCase;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.ACCT;

@Service
public class CreateFavoriteAcctUseCaseImpl implements CreateFavoriteUseCase {

    private final FavoriteAcctTransferRepository favoriteAccTransferRepository;

    public CreateFavoriteAcctUseCaseImpl(FavoriteAcctTransferRepository favoriteAccTransferRepository) {
        this.favoriteAccTransferRepository = favoriteAccTransferRepository;
    }

    @Override
    public Long invoke(Long finDocId) {
        var in = favoriteAccTransferRepository.getCreateFavoriteAcctDataOrException(finDocId);
        var out = new FavoriteAccTransferOut(in);
        var saved = favoriteAccTransferRepository.save(out);
        return saved.favoriteTransferIn().id();
    }

    @Override
    public Set<String> keySet() {
        return Set.of(ACCT);
    }
}
