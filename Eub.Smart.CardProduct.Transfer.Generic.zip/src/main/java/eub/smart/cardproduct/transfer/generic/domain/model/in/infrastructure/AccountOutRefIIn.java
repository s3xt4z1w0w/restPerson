package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record AccountOutRefIIn(
        Long accountOutRef
) {
}
