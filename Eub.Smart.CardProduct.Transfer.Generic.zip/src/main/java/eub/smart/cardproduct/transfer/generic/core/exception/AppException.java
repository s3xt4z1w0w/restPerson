package eub.smart.cardproduct.transfer.generic.core.exception;

import java.util.List;

public class AppException extends RuntimeException {

    private final AppErrorCode errorCode;

    private String errorMessage;
    private FieldsValidationResponse fieldsValidationResponse;



    public AppException(AppErrorCode errorCode, List<ErrorDto> errorDtos) {
        super(errorDtos.toString());
        this.errorCode = errorCode;
    }


    public AppException(AppErrorCode errorCode) {
        super(errorCode.message());
        this.errorCode = errorCode;
    }


    public AppException(AppErrorCode errorCode, String additionalMessage) {
        super(errorCode.message() + additionalMessage);
        this.errorCode = errorCode;
    }

    public AppException(AppErrorCode errorCode, String additionalMessage, String errorMessage) {
        super(errorCode.message() + additionalMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }


    public AppException(AppErrorCode errorCode, Throwable throwable) {
        super(throwable);
        if (throwable.getCause() instanceof AppException se) {
            this.errorCode = se.getCode();
            this.errorMessage = se.getErrorMessage();
        } else {
            this.errorCode = errorCode;
        }
    }

    public AppException(AppErrorCode errorCode, FieldsValidationResponse fieldsValidationResponse) {
        super();
        this.fieldsValidationResponse = fieldsValidationResponse;
        this.errorCode = errorCode;
    }

    public AppErrorCode getCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
    public FieldsValidationResponse getFieldsValidationResponse() {
        return fieldsValidationResponse;
    }

    public void setFieldsValidationResponse(FieldsValidationResponse fieldsValidationResponse) {
        this.fieldsValidationResponse = fieldsValidationResponse;
    }
}
