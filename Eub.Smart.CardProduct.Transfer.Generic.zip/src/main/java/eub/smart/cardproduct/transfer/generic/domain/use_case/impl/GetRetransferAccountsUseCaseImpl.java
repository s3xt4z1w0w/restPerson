package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountSourceIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.RetransferAccountIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.AccountTargetOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferAccountsOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.GetRetransferAccountsRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.RetransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetRetransferAccountsUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.RetransferReceiverDataUseCase;
import org.springframework.stereotype.Service;

import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_SM_500;
import static java.util.Objects.nonNull;

@Service
public class GetRetransferAccountsUseCaseImpl implements GetRetransferAccountsUseCase {

    private final RetransferRepository retransferRepository;
    private final GetRetransferAccountsRepository getRetransferAccountsRepository;
    private final RetransferReceiverDataUseCase retransferReceiverDataUseCase;

    public GetRetransferAccountsUseCaseImpl(RetransferRepository retransferRepository,
                                            GetRetransferAccountsRepository getRetransferAccountsRepository,
                                            RetransferReceiverDataUseCase retransferReceiverDataUseCase) {
        this.retransferRepository = retransferRepository;
        this.getRetransferAccountsRepository = getRetransferAccountsRepository;
        this.retransferReceiverDataUseCase = retransferReceiverDataUseCase;
    }

    @Override
    public RetransferAccountsOut invoke(Long finDocId) {
        var transferData = retransferRepository.findRetransferAccount(finDocId);
        var senderAccountList = getRetransferAccountsRepository.findAccountList();
        var senderAccount = defineSenderAccount(senderAccountList, transferData);
        var receiverAccount = retransferReceiverDataUseCase.invoke(finDocId);
        return new RetransferAccountsOut(senderAccount, receiverAccount);
    }

    private AccountSourceIn defineSenderAccount(List<AccountSourceIn> senderAccountList, RetransferAccountIn transferData) {
        var accountId = transferData.accountId();
        var cardId = transferData.cardId();
        var currency = transferData.currency();

        return senderAccountList
                .stream()
                .filter(acc -> nonNull(cardId) &&
                        cardId.equals(acc.cardId()) &&
                        accountId.equals(acc.accountId()) &&
                        currency.equals(acc.amount().currency().code()))
                .findFirst()
                .or(() -> senderAccountList
                        .stream()
                        .filter(acc -> accountId.equals(acc.accountId()) &&
                                currency.equals(acc.amount().currency().code()))
                        .findFirst())
                .orElseThrow(() -> new AppException(E_SM_500, ": sender account not found"));
    }
}
