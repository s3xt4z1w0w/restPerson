package eub.smart.cardproduct.transfer.generic.core.constant;

public interface TransferKNPConvertType {

    String NONE = "NONE";
}
