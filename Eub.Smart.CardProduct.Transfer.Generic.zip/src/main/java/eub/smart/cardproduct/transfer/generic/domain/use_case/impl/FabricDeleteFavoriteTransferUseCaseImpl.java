package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.DeleteFavoriteTransferByFinDocIdUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FabricDeleteFavoriteTransferUseCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

@Service
public class FabricDeleteFavoriteTransferUseCaseImpl implements FabricDeleteFavoriteTransferUseCase {

    private final Logger log = LogManager.getLogger(getClass());

    private final Map<String, DeleteFavoriteTransferByFinDocIdUseCase> useCaseMap = new HashMap<>();
    private final FinDocRepository finDocRepository;

    public FabricDeleteFavoriteTransferUseCaseImpl(Set<DeleteFavoriteTransferByFinDocIdUseCase> useCases,
                                                   FinDocRepository finDocRepository) {
        this.finDocRepository = finDocRepository;
        fillMap(useCases);
    }

    @Override
    public void invoke(Long finDocId) {
        var operationType = finDocRepository.findOperationTypeOrException(finDocId);
        var finDocType = operationType.invoke();
        var deleteUseCase = findUseCase(finDocType)
                .orElseThrow(() -> new AppException(E_LG_802, ": for operation type: " + operationType.invoke()));
        deleteUseCase.invoke(finDocId);
    }

    private void fillMap(Set<DeleteFavoriteTransferByFinDocIdUseCase> useCases) {
        useCases.forEach(repo -> repo.keySet()
                .forEach(key -> useCaseMap.put(key, repo))
        );
    }

    private Optional<DeleteFavoriteTransferByFinDocIdUseCase> findUseCase(String finDocType) {
        var receiptRepository = useCaseMap.get(finDocType);
        return Optional.ofNullable(receiptRepository);
    }
}
