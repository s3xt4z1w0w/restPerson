package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;

public interface GetAccountInfoByNumberUseCase {

    CreateTransferClientDataIn invoke(String number, String currency);

    CreateTransferClientDataIn invoke(Long accId, Long cardId, String currency);

}
