package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.grpc;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CurrencyRateIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.RsbkInfoProtoRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.grpc.GetCurrencyRatesListMapper;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Component;
import rsbkinfo.V1.RsbkInfoGrpc;

import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_EX_700;

@Component
public class RsbkInfoProtoRepositoryImpl implements RsbkInfoProtoRepository {

    @GrpcClient("adapter-rsbk-info")
    private RsbkInfoGrpc.RsbkInfoBlockingStub stub;

    @Override
    public CurrencyRateIn findCurrencyRate(String currency) {
        try {
            var request = GetCurrencyRatesListMapper.toGrpcModel(currency);
            var response = stub
                    .getCurrencyRatesList(request);
            return GetCurrencyRatesListMapper.toDomainModel(response);
        } catch (StatusRuntimeException e) {
            throw new AppException(E_EX_700, ": getCurrencyRatesList " + e.getStatus().getCode().name());
        }
    }

    @Override
    public List<CurrencyRateIn> findCurrencyRates() {
        try {
            var request = GetCurrencyRatesListMapper.toGrpcModel();
            var response = stub
                    .getCurrencyRatesList(request);
            return GetCurrencyRatesListMapper.toDomainModels(response);
        } catch (StatusRuntimeException e) {
            throw new AppException(E_EX_700, ": getCurrencyRatesList " + e.getStatus().getCode().name());
        }
    }

}
