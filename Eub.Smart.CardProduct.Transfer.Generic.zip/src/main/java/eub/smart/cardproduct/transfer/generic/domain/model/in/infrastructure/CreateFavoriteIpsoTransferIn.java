package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteTransferOut;

public record CreateFavoriteIpsoTransferIn(
        FavoriteTransferOut favoriteTransferOut,
        String receiverPhone,
        String receiverName,
        String currency,
        Long bankId
) {
    public CreateFavoriteIpsoTransferIn(Long finDocId,
                                        Long userId,
                                        String type,
                                        String receiverPhone,
                                        String currency,
                                        String receiverName,
                                        Long bankId) {
        this(new FavoriteTransferOut(finDocId, userId, type),
                receiverPhone,
                receiverName,
                currency,
                bankId);
    }
}
