package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.LocalizedText;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.core.util.StringUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteSelfTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteSelfTransferDetailsDisplayOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUB_TITLE_SELF;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;
import static eub.smart.cardproduct.transfer.generic.core.util.StringUtil.last4;

@Component
public class FavoriteSelfTransferMapper {

    private final LocalizedText subTitleSelf;

    public FavoriteSelfTransferMapper(MessageSourceRepositoryImpl messageSourceRepository) {
        String subTitleSelfRu = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.RU);
        String subTitleSelfKk = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.KK);
        String subTitleSelfEn = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.EN);
        this.subTitleSelf = new LocalizedText(subTitleSelfRu, subTitleSelfKk, subTitleSelfEn);
    }

    public CreateFavoriteSelfTransferIn toInDomain(ResultSet resultSet, int i) {
        try {
            Long finDocId = resultSet.getLong("finDocId");
            Long userId = resultSet.getLong("userId");
            String type = FavoriteTransferType.SLFT.name();
            String accountNumber = resultSet.getString("accountNumber");
            String currency = resultSet.getString("currency");
            String imageTable = resultSet.getString("imageTable");
            Long imageId = resultSet.getLong("imageId");
            return new CreateFavoriteSelfTransferIn(
                    finDocId,
                    userId,
                    type,
                    accountNumber,
                    currency,
                    imageTable,
                    imageId);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    public FavoriteTransferDisplayOut toDetailsDisplay(ResultSet resultSet, FavoriteTransferDisplayIn in, String s3Url, String langKey) {
        try {
            String title = resultSet.getString("title");
            String number = last4(resultSet.getString("number"));
            String imageUid = resultSet.getString("imageUid");
            String imageUrl = imageUrl(s3Url, imageUid);
            String subTitle = subTitleSelf.text(langKey);
            String currency = resultSet.getString("currency");
            String accountType = resultSet.getString("accountType");
            Long accountId = resultSet.getLong("accountId");
            String finDocType = EnumUtil.valueOfOrException(FavoriteTransferType.class, in.getType()).finDocType();

            return new FavoriteTransferDisplayOut(
                    in.getId(),
                    finDocType,
                    in.getTitle(),
                    title,
                    subTitle,
                    accountType,
                    imageUrl,
                    null,
                    in.getAccountId(),
                    new FavoriteSelfTransferDetailsDisplayOut(currency, accountId, number));
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private static String imageUrl(String s3Url, String uid) {
        if (StringUtil.isEmpty(uid)) return uid;
        return String.format("%s?fileUid=%s", s3Url, uid);
    }
}
