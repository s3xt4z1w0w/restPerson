package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FindFavoriteTransferOperationTypeIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.TransferValidate;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.ReceiverAccountNumberMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.FinDocJpaRepository;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class FinDocRepositoryImpl implements FinDocRepository {

    private final NamedParameterJdbcTemplate template;
    private final FinDocJpaRepository finDocJpaRepository;
    private final InfrastructureMapper mapper;

    public FinDocRepositoryImpl(NamedParameterJdbcTemplate template,
                                FinDocJpaRepository finDocJpaRepository,
                                InfrastructureMapper mapper) {
        this.template = template;
        this.finDocJpaRepository = finDocJpaRepository;
        this.mapper = mapper;
    }

    @Override
    public String findTypeOrException(Long finDocId) {
        return finDocJpaRepository.findDocType(finDocId)
                .orElseThrow(() -> new AppException(E_DB_600, ": FinDocRepository findTypeOrException"));
    }

    @Override
    public FinDocOut save(FinDocOut finDoc) {
        var entity = mapper.toEntity(finDoc);
        var saved = finDocJpaRepository.save(entity);
        return mapper.toDomain(saved);
    }

    @Override
    public String findReceiverAccountNumber(Long finDocId) {
        String sql = """ 
                select t.Receiver_Account   as transferAccNumber,
                       ct.AccountNumber     as cardTransferAccNumber,
                       it.Receiver_IBAN     as ipsTransferAccNumber
                from FinDoc fd
                         left join Transfer t on fd.FinDoc_ID = t.FinDoc_IDREF
                         left join CardTransfer ct on fd.FinDoc_ID = ct.FinDoc_IDREF
                         left join IPSTransfer it on fd.FinDoc_ID = it.FinDoc_IDREF
                where fd.FinDoc_ID = :finDocId
                """;

        List<String> queryResult = template.query(sql, Map.of("finDocId", finDocId), ReceiverAccountNumberMapper::map);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, " FinDocRepository findReceiverAccountNumber"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, " FinDocRepository findReceiverAccountNumber");
        } else {
            throw new AppException(E_DB_601, ": FinDocRepository findReceiverAccountNumber");
        }
    }

    @Override
    public FindFavoriteTransferOperationTypeIn findOperationTypeOrException(Long finDocId) {
        RowMapper<FindFavoriteTransferOperationTypeIn> rowMapper = (rs, rowNum) -> new FindFavoriteTransferOperationTypeIn(
                rs.getString("finDocType"),
                rs.getString("cardTransferType"),
                rs.getString("ipsTransferType"),
                rs.getString("transferType"));

        String sql = """ 
                select FD.FinDocType_IDREF       as finDocType,
                       CT.CardTransferType_IDREF as cardTransferType,
                       IT.TransferType           as ipsTransferType,
                       T.TransferType_IDREF      as transferType
                from FinDoc FD
                         left join CardTransfer CT on FD.FinDoc_ID = CT.FinDoc_IDREF
                         left join IPSTransfer IT on FD.FinDoc_ID = IT.FinDoc_IDREF
                         left join Transfer T on FD.FinDoc_ID = T.FinDoc_IDREF
                where FD.FinDoc_ID = :finDocId
                """;

        List<FindFavoriteTransferOperationTypeIn> queryResult = template.query(sql, Map.of("finDocId", finDocId), rowMapper);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, " FinDocRepository findOperationTypeOrException"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, " FinDocRepository findOperationTypeOrException");
        } else {
            throw new AppException(E_DB_601, ": FinDocRepository findOperationTypeOrException");
        }
    }

    @Override
    public TransferValidate findTransferData(Long finDocId) {
        RowMapper<TransferValidate> rowMapper = (rs, rowNum) -> new TransferValidate(
                rs.getLong("finDocId"),
                rs.getLong("accountId"),
                rs.getString("bSystem"),
                rs.getString("accountType"),
                rs.getBigDecimal("amount"),
                rs.getString("currency"),
                rs.getString("currencySymbol"),
                rs.getLong("accountOutRefId"),
                rs.getBigDecimal("feeAmount")
        );
        String sql = """
               SELECT fd.FinDoc_ID        as finDocId,
                      fd.Account_IDREF    as accountId,
                      bc.BSystem_IDREF    as bSystem,
                      a.AccountType_IDREF as accountType,
                      fd.Amount           as amount,
                      fd.Currency         as currency,
                      ct.Symbol           as currencySymbol,
                      fd.Fee              as feeAmount,
                      a.Account_OUTREF    as accountOutRefId
               FROM FinDoc fd
                        JOIN CurrencyType ct ON ct.Currency_Code = fd.Currency
                        JOIN Account a ON a.Account_ID = fd.Account_IDREF
                        JOIN BSystemClient bc ON bc.BSystemClient_ID = a.BSystemClient_IDREF
               WHERE fd.FinDoc_ID = :finDocId
                """;

        List<TransferValidate> queryResult = template.query(sql, Map.of("finDocId", finDocId), rowMapper);

        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": FinDocRepository findTransferDataByFinDocId"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": FinDocRepository findTransferDataByFinDocId");
        } else {
            throw new AppException(E_DB_601, ": FinDocRepository findTransferDataByFinDocId");
        }
    }
}
