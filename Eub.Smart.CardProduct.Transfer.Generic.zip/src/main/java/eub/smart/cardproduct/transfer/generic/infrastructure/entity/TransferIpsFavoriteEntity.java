package eub.smart.cardproduct.transfer.generic.infrastructure.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "TransferIpsFavorite")
public class TransferIpsFavoriteEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TransferIpsFavorite_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "TransferFavorite_IDREF", nullable = false)
    private TransferFavoriteEntity transferFavorite;

    @NotNull
    @Column(name = "ReceiverBank_IDREF", nullable = false)
    private Long bankId;

    @NotBlank
    @Column(name = "ReceiverPhoneNumber", nullable = false)
    private String receiverPhone;

    @NotBlank
    @Column(name = "ReceiverName", nullable = false)
    private String receiverName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TransferFavoriteEntity getTransferFavorite() {
        return transferFavorite;
    }

    public void setTransferFavorite(TransferFavoriteEntity transferFavorite) {
        this.transferFavorite = transferFavorite;
    }

    public Long getBankId() {
        return bankId;
    }

    public void setBankId(Long bankId) {
        this.bankId = bankId;
    }

    public String getReceiverPhone() {
        return receiverPhone;
    }

    public void setReceiverPhone(String receiverPhone) {
        this.receiverPhone = receiverPhone;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }


    @Override
    public String toString() {
        return "TransferIpsFavoriteEntity{" +
                "id=" + id +
                ", transferFavorite=" + transferFavorite +
                ", bankId=" + bankId +
                ", phoneNumber=" + receiverPhone +
                ", name=" + receiverName +
                '}';
    }
}
