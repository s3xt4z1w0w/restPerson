package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateTransferDataOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FeeOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.RetransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateTransferDataUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetAccountInfoByNumberUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.RetransferUseCase;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.KZT;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.ACCR;
import static eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType.ACCT;

@Service
public class RetransferAccUseCaseImpl implements RetransferUseCase {

    private final CreateTransferDataUseCase createTransferDataUseCase;
    private final GetAccountInfoByNumberUseCase getAccountInfoUseCase;
    private final RetransferRepository retransferRepository;

    public RetransferAccUseCaseImpl(CreateTransferDataUseCase createTransferDataUseCase,
                                    GetAccountInfoByNumberUseCase getAccountInfoUseCase,
                                    RetransferRepository retransferRepository) {
        this.createTransferDataUseCase = createTransferDataUseCase;
        this.getAccountInfoUseCase = getAccountInfoUseCase;
        this.retransferRepository = retransferRepository;
    }

    @Override
    public RetransferOut invoke(CreateRetransferDataIn in) {
        var retransferData = retransferRepository.getRetransferData(in.finDocId());
        var senderData = getAccountInfoUseCase.invoke(in.senderAccountId(), in.senderCardId(), in.senderCurrency());
        var receiverData = new CreateTransferClientDataIn(retransferData, in.receiverCurrency());
        var fee = new FeeOut(BigDecimal.ZERO, KZT); //TODO calculate fee
        var createTransferData = new CreateTransferDataOut(in, senderData, retransferData, fee);
        var transfer = createTransferDataUseCase.invoke(createTransferData, senderData, receiverData);
        return new RetransferOut(transfer.getTransfer().getFinDoc().getId(), fee.getAmount());
    }

    @Override
    public FavoriteTransferType favoriteTransferType() {
        return ACCT;
    }

    @Override
    public String finDocType() {
        return ACCR;
    }
}
