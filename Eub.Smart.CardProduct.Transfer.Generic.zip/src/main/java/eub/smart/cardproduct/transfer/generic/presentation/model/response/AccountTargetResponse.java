package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public record AccountTargetResponse(
        @Schema(description = "Данные заголовка")
        String title,
        @Schema(description = "Данные под заголовок")
        String subtitle,
        @Schema(description = "Изображение")
        String image,
        @Schema(description = "Тип аккаунта")
        String accountType
) {
}
