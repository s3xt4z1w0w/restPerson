package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.LocalizedText;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.core.util.StringUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteP2plTransferIn;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUB_TITLE_LOCAL;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUB_TITLE_OUTGOING;
import static eub.smart.cardproduct.transfer.generic.core.constant.CardTransferType.P2PL;
import static eub.smart.cardproduct.transfer.generic.core.constant.CardTransferType.P2PO;
import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.KZT;
import static eub.smart.cardproduct.transfer.generic.core.constant.TargetTable.BANK;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

@Component
public class FavoriteP2pTransferMapper {

    private final LocalizedText subTitleLocal;
    private final LocalizedText subTitleOutgoing;

    public FavoriteP2pTransferMapper(MessageSourceRepositoryImpl messageSourceRepository) {
        String subTitleLocalRu = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.RU);
        String subTitleLocalKk = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.KK);
        String subTitleLocalEn = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.EN);
        String subTitleOutgoingRu = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.RU);
        String subTitleOutgoingKk = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.KK);
        String subTitleOutgoingEn = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.EN);
        this.subTitleLocal = new LocalizedText(subTitleLocalRu, subTitleLocalKk, subTitleLocalEn);
        this.subTitleOutgoing = new LocalizedText(subTitleOutgoingRu, subTitleOutgoingKk, subTitleOutgoingEn);
    }

    public CreateFavoriteP2plTransferIn toDomain(ResultSet resultSet, int i) {
        try {
            Long finDocId = resultSet.getLong("finDocId");
            Long userId = resultSet.getLong("userId");
            String type = FavoriteTransferType.LOCT.name();
            String accountNumber = resultSet.getString("accountNumber");
            String title = resultSet.getString("title");
            Long imageId = resultSet.getLong("imageId");
            return new CreateFavoriteP2plTransferIn(
                    finDocId,
                    userId,
                    type,
                    accountNumber,
                    KZT,
                    title,
                    BANK,
                    imageId);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private String subTitle(String transferType, String langKey) {
        return switch (transferType) {
            case P2PO -> subTitleOutgoing.text(langKey);
            case P2PL -> subTitleLocal.text(langKey);
            default -> throw new AppException(E_LG_802, ": card transfer type " + transferType);
        };
    }

    private static String imageUrl(String s3Url, String uid) {
        if (StringUtil.isEmpty(uid)) return uid;
        return String.format("%s?fileUid=%s", s3Url, uid);
    }
}
