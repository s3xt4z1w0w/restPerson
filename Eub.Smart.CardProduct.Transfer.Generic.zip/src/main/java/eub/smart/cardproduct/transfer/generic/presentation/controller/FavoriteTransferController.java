package eub.smart.cardproduct.transfer.generic.presentation.controller;

import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.*;
import eub.smart.cardproduct.transfer.generic.presentation.mapper.PresentationMapper;
import eub.smart.cardproduct.transfer.generic.presentation.model.request.CreateFavoriteTransferRequest;
import eub.smart.cardproduct.transfer.generic.presentation.model.request.SetPseudonymRequest;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.FavoriteTransferResponse;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.FavoriteValidateResponse;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.IdResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;

@Tag(name = "FavoriteTransferController", description = "API работы с сохраненными переводами")
@RestController
@SecurityRequirement(name = "Bearer Authentication")
@RequestMapping("/transfer-generic/api/saved-transfers")
public class FavoriteTransferController {

    private final PresentationMapper mapper;
    private final FabricCreateFavoriteTransferUseCase fabricCreateFavoriteTransferUseCase;
    private final FabricCreateFavoriteUseCase fabricCreateFavoriteUseCase;
    private final FavoriteTransferDisplayUseCase favoriteTransferDisplayUseCase;
    private final FabricDeleteFavoriteTransferUseCase fabricDeleteFavoriteTransferUseCase;
    private final FavoriteTransferRenameUseCase favoriteTransferRenameUseCase;
    private final FavoriteTransferRepository favoriteTransferRepository;
    private final InitialValidationUseCase initialValidationUseCase;

    public FavoriteTransferController(PresentationMapper mapper,
                                      FabricCreateFavoriteTransferUseCase fabricCreateFavoriteTransferUseCase,
                                      FabricCreateFavoriteUseCase fabricCreateFavoriteUseCase,
                                      FavoriteTransferDisplayUseCase favoriteTransferDisplayUseCase,
                                      FabricDeleteFavoriteTransferUseCase fabricDeleteFavoriteTransferUseCase,
                                      FavoriteTransferRenameUseCase favoriteTransferRenameUseCase,
                                      FavoriteTransferRepository favoriteTransferRepository,
                                      InitialValidationUseCase initialValidationUseCase) {
        this.mapper = mapper;
        this.fabricCreateFavoriteTransferUseCase = fabricCreateFavoriteTransferUseCase;
        this.fabricCreateFavoriteUseCase = fabricCreateFavoriteUseCase;
        this.favoriteTransferDisplayUseCase = favoriteTransferDisplayUseCase;
        this.fabricDeleteFavoriteTransferUseCase = fabricDeleteFavoriteTransferUseCase;
        this.favoriteTransferRenameUseCase = favoriteTransferRenameUseCase;
        this.favoriteTransferRepository = favoriteTransferRepository;
        this.initialValidationUseCase = initialValidationUseCase;
    }

    @Operation(description = "Валидация для повторного перевода", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = FavoriteValidateResponse.class))})})
    @PostMapping("/validate")
    public ResponseEntity<?> createFavoriteTransfer(@RequestHeader(CORRELATION_ID) String correlationId,
                                                    @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                                    @Valid @RequestBody CreateFavoriteTransferRequest request) {
        var in = mapper.toDomain(request);
        var createFavorite = fabricCreateFavoriteTransferUseCase.invoke(in);
        initialValidationUseCase.invoke(createFavorite.finDocId());
        return new ResponseEntity<>(new FavoriteValidateResponse(createFavorite.finDocId(), createFavorite.feeAmount()), CREATED);
    }

    @Operation(description = "Получение всех", responses = {
            @ApiResponse(content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = FavoriteTransferResponse.class))})})
    @GetMapping
    public ResponseEntity<?> getFavoriteTransfers(@RequestHeader(CORRELATION_ID) String correlationId,
                                                  @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                                  @PageableDefault(page = 0, size = 30) Pageable pageable) {
        var savedTransfers = favoriteTransferDisplayUseCase.invoke(pageable);
        return ResponseEntity.ok(savedTransfers);
    }

    @Operation(description = "Удаление из сохраненных по id")
    @DeleteMapping("/finDoc/{finDocId}")
    public ResponseEntity<?> removeByFindoc(@RequestHeader(CORRELATION_ID) String correlationId,
                                            @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                            @PathVariable Long finDocId) {
        fabricDeleteFavoriteTransferUseCase.invoke(finDocId);
        return new ResponseEntity<>(NO_CONTENT);
    }

    @Operation(description = "Удаление из сохраненных по id")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> remove(@RequestHeader(CORRELATION_ID) String correlationId,
                                    @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                    @PathVariable Long id) {
        favoriteTransferRepository.fullDelete(id);
        return new ResponseEntity<>(NO_CONTENT);
    }

    @Operation(description = "Переименовать")
    @PutMapping("/{id}")
    public ResponseEntity<?> renameTitle(@RequestHeader(CORRELATION_ID) String correlationId,
                                         @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                         @PathVariable Long id,
                                         @RequestBody SetPseudonymRequest request) {
        favoriteTransferRenameUseCase.invoke(id, request.pseudonym());
        return new ResponseEntity<>(NO_CONTENT);
    }

    @Operation(description = "Сохранить", responses = {
            @ApiResponse(
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = IdResponse.class))})})
    @PostMapping("/finDoc/{finDocId}")
    public ResponseEntity<?> saveFavorite(@RequestHeader(CORRELATION_ID) String correlationId,
                                          @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                          @PathVariable Long finDocId) {
        var out = fabricCreateFavoriteUseCase.invoke(finDocId);
        return new ResponseEntity<>(new IdResponse(out), CREATED);
    }
}
