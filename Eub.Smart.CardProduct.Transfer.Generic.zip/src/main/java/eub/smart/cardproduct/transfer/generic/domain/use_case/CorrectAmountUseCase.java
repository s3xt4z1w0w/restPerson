package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CurrencyRateIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CorrectAmountOut;

import java.math.BigDecimal;

public interface CorrectAmountUseCase {

    CorrectAmountOut invoke(BigDecimal amount, String senderAccountCurrency, String receiverAccountCurrency);

    CorrectAmountOut invoke(BigDecimal amount, CurrencyRateIn senderCurrencyRate, CurrencyRateIn receiverCurrencyRate);

}
