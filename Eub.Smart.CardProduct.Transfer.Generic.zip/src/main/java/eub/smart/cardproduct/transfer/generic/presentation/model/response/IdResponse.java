package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public record IdResponse(

        @Schema(description = "Id response")
        Long id
) {
}
