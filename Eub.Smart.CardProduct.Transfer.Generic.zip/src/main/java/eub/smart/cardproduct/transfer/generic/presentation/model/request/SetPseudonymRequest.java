package eub.smart.cardproduct.transfer.generic.presentation.model.request;

public record SetPseudonymRequest(
        String pseudonym
) {
}
