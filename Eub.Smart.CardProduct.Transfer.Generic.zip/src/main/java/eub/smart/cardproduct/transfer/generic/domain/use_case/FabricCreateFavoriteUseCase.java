package eub.smart.cardproduct.transfer.generic.domain.use_case;

public interface FabricCreateFavoriteUseCase {

    Long invoke(Long sourceId);
}
