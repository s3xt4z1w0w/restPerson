package eub.smart.cardproduct.transfer.generic.core.exception;

import java.util.List;

public record FieldsValidationResponse(
        Error error,
        List<FieldError> fields
) {
    public FieldsValidationResponse(AppException exception) {
        this(exception.getFieldsValidationResponse().error(),
                exception.getFieldsValidationResponse().fields());
    }
}
