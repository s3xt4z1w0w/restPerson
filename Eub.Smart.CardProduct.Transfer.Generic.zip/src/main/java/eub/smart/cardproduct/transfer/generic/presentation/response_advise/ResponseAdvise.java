package eub.smart.cardproduct.transfer.generic.presentation.response_advise;

import eub.smart.cardproduct.transfer.generic.presentation.model.ErrorResponse;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.springframework.http.HttpStatus.*;

@ControllerAdvice
public class ResponseAdvise extends ResponseEntityExceptionHandler {

    private final Logger log = LogManager.getLogger(getClass());

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        List<String> errors = new ArrayList<>();
        ex.getBindingResult().getFieldErrors().forEach(fieldError -> {
            String defaultMessage = fieldError.getDefaultMessage();
            String fieldName = fieldError.getField();
            errors.add(String.format("Field: %s %s", fieldName, defaultMessage));
        });
        log.error("Request validate error: {}", errors);
        ErrorResponse responseBody = new ErrorResponse();
        responseBody.errorResponse(new AppException(AppErrorCode.E_VD_401, ": " + errors));
        return new ResponseEntity<>(responseBody, BAD_REQUEST);
    }

    @ExceptionHandler(value = RuntimeException.class)
    protected ResponseEntity<Object> handleConflict(RuntimeException exception) {

        if (exception instanceof AppException) {
            ErrorResponse responseBody = new ErrorResponse();
            responseBody.errorResponse((AppException) exception);
            log.error("Event-Type=REST, Error: [code={}, message={}, stackTrace={}]",
                    ((AppException) exception).getCode(),
                    exception.getMessage(),
                    exception.getStackTrace());

            switch (((AppException) exception).getCode()) {
                case E_DB_605:
                    Page<Object> emptyPage = new PageImpl<>(Collections.emptyList(), Pageable.ofSize(20), 0);
                    return new ResponseEntity<>(emptyPage , OK);
                case E_EX_701:
                    return new ResponseEntity<>(responseBody.getFieldsValidationResponse(), SERVICE_UNAVAILABLE);
                case E_VD_402:
                    return new ResponseEntity<>(responseBody.getFieldsValidationResponse(), BAD_REQUEST);
                default:
                    return new ResponseEntity<>(responseBody, INTERNAL_SERVER_ERROR);
            }
        } else {
            log.error("Event-Type=REST, Error: [code={}, message={}, stackTrace={}]",
                    -1,
                    exception.getMessage(),
                    exception.getStackTrace());

            return new ResponseEntity<>(exception, INTERNAL_SERVER_ERROR);
        }
    }
}
