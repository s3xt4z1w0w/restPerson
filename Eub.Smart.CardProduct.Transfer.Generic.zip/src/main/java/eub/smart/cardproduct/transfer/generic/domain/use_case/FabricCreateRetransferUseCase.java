package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferOut;

public interface FabricCreateRetransferUseCase {

    RetransferOut invoke(CreateRetransferDataIn in);
}
