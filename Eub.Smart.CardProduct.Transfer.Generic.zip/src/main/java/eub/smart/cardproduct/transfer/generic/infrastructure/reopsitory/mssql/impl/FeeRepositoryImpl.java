package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FeeOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FeeRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.FeeJpaRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;

@Primary
@Component
public class FeeRepositoryImpl implements FeeRepository {

    private final FeeJpaRepository feeJpaRepository;
    private final InfrastructureMapper mapper;

    public FeeRepositoryImpl(FeeJpaRepository feeJpaRepository,
                             InfrastructureMapper mapper) {
        this.feeJpaRepository = feeJpaRepository;
        this.mapper = mapper;
    }

    @Override
    public Optional<FeeOut> findById(Long id) {
        return feeJpaRepository.findById(id)
                .map(mapper::toDomain);
    }

    @Override
    public FeeOut findByIdOrException(Long id) {
        return findById(id)
                .orElseThrow(() -> new AppException(E_DB_600, ": FeeRepository findByIdOrException"));
    }

    @Override
    public FeeOut findFeeByAccountId(Long accountId) {
        var fee = feeJpaRepository.findFeeByAccountId(accountId);
        return mapper.toDomain(fee);
    }
}
