package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;

public interface CreateVisaTransferUseCase {

    FinDocOut invoke(CreateRetransferDataIn in);
}
