package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.ReceiverP2pIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CardTransferIOut;

public interface CardTransferRepository {

    void save(CardTransferIOut cardTransfer);

    ReceiverP2pIIn findByFinDocIdOrException(Long finDocId);
}
