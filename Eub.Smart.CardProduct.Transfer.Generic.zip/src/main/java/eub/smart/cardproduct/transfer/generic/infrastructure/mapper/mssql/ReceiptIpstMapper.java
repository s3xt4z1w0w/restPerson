package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.enums.FinDocStatusDisplay;
import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import eub.smart.cardproduct.transfer.generic.core.enums.ReceiptTypeDisplay;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.LocalizedText;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.core.util.NameUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.DetailResponse;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.IpsTransferType.IPSL;
import static eub.smart.cardproduct.transfer.generic.core.constant.IpsTransferType.IPSO;
import static eub.smart.cardproduct.transfer.generic.core.enums.LangKey.EN;
import static eub.smart.cardproduct.transfer.generic.core.enums.ReceiptTypeDisplay.DEFT;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;
import static eub.smart.cardproduct.transfer.generic.core.util.ImageUtil.formImageUrl;
import static eub.smart.cardproduct.transfer.generic.core.util.MaskUtil.maskPhoneNumber;
import static java.util.Objects.isNull;

@Component
public class ReceiptIpstMapper {

    private final LocalizedText subTitleLocal;
    private final LocalizedText subTitleOutgoing;
    private final LocalizedText senderKey;
    private final LocalizedText fromKey;
    private final LocalizedText receiverPhoneNumber;

    public ReceiptIpstMapper(MessageSourceRepositoryImpl messageSourceRepository) {
        String subTitleLocalRu = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.RU);
        String subTitleLocalKk = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.KK);
        String subTitleLocalEn = messageSourceRepository.getMessage(SUB_TITLE_LOCAL, LangUtil.EN);
        String subTitleOutgoingRu = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.RU);
        String subTitleOutgoingKk = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.KK);
        String subTitleOutgoingEn = messageSourceRepository.getMessage(SUB_TITLE_OUTGOING, LangUtil.EN);
        String senderRu = messageSourceRepository.getMessage(RECEIPT_SENDER, LangUtil.RU);
        String senderKk = messageSourceRepository.getMessage(RECEIPT_SENDER, LangUtil.KK);
        String senderEn = messageSourceRepository.getMessage(RECEIPT_SENDER, LangUtil.EN);
        String fromRu = messageSourceRepository.getMessage(RECEIPT_FROM, LangUtil.RU);
        String fromKk = messageSourceRepository.getMessage(RECEIPT_FROM, LangUtil.KK);
        String fromEn = messageSourceRepository.getMessage(RECEIPT_FROM, LangUtil.EN);
        String receiverPhoneNumberRu = messageSourceRepository.getMessage(RECEIVER_PHONE_NUMBER, LangUtil.RU);
        String receiverPhoneNumberKk = messageSourceRepository.getMessage(RECEIVER_PHONE_NUMBER, LangUtil.KK);
        String receiverPhoneNumberEn = messageSourceRepository.getMessage(RECEIVER_PHONE_NUMBER, LangUtil.EN);
        this.subTitleLocal = new LocalizedText(subTitleLocalRu, subTitleLocalKk, subTitleLocalEn);
        this.subTitleOutgoing = new LocalizedText(subTitleOutgoingRu, subTitleOutgoingKk, subTitleOutgoingEn);
        this.senderKey = new LocalizedText(senderRu, senderKk, senderEn);
        this.fromKey = new LocalizedText(fromRu, fromKk, fromEn);
        this.receiverPhoneNumber = new LocalizedText(receiverPhoneNumberRu, receiverPhoneNumberKk, receiverPhoneNumberEn);
    }

    public TransferReceiptOut toDomain(ResultSet resultSet, String langKey) {
        try {
            return fillTransferReceiptOut(resultSet, langKey);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private TransferReceiptOut fillTransferReceiptOut(ResultSet resultSet, String strLangKey) throws SQLException {
        Long id = resultSet.getLong("id");
        String fromSuffix = resultSet.getString("fromSuffix");
        if (isNull(fromSuffix)) fromSuffix = "";
        String from = resultSet.getString("fromm") + fromSuffix;
        String title = resultSet.getString("title");
        LangKey langKey = EnumUtil.valueOfOrDefault(LangKey.class, strLangKey, EN);
        String transferType = resultSet.getString("transferType");
        String subtitle = subTitle(transferType, langKey);
        String imageUID = resultSet.getString("imageUid");
        String imageUrl = formImageUrl(imageUID);
        BigDecimal amount = resultSet.getBigDecimal("amount");
        String currency = resultSet.getString("currency");
        Date date = resultSet.getTimestamp("date");
        Long timestampDate = date.getTime();
        String status = resultSet.getString("status");
        String statusDisplay = EnumUtil.valueOfOrException(FinDocStatusDisplay.class, status).value();
        BigDecimal feeAmount = resultSet.getBigDecimal("feeAmount");
        String feeCurrency = resultSet.getString("feeCurrency");
        String senderFullName = NameUtil.getSenderDisplayName(resultSet.getString("senderFullName"));
        String receiverPhone = resultSet.getString("receiverPhone");
        String maskPhoneNumber = maskPhoneNumber(receiverPhone);
        List<DetailResponse> detailResponses = List.of(
                new DetailResponse(senderKey.text(langKey), senderFullName),
                new DetailResponse(fromKey.text(langKey), from),
                new DetailResponse(receiverPhoneNumber.text(langKey), maskPhoneNumber));
        String referenceOutRef = resultSet.getString("referenceOutRef");
        long tfId = resultSet.getLong("tfId");
        Boolean isSaved = tfId != 0;
        String typeDisplay = EnumUtil.valueOfOrDefault(ReceiptTypeDisplay.class, transferType, DEFT).value();

        return new TransferReceiptOut(
                id,
                title,
                subtitle,
                imageUrl,
                null,
                transferType,
                amount,
                currency,
                feeAmount,
                feeCurrency,
                timestampDate,
                isSaved,
                typeDisplay,
                statusDisplay,
                referenceOutRef,
                detailResponses);
    }

    private String subTitle(String transferType, LangKey langKey) {
        return switch (transferType) {
            case IPSL -> subTitleLocal.text(langKey);
            case IPSO -> subTitleOutgoing.text(langKey);
            default -> throw new AppException(E_LG_802, ": transfer type title " + transferType);
        };
    }

}
