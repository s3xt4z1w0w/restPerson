package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.core.exception.FieldError;

import java.math.BigDecimal;
import java.util.List;

public interface ValidateLimitUseCase {

    void invoke(Long finDocId, String favTransferType, Long cardId, BigDecimal amount);
}
