package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteLocalTransferIn;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.KZT;
import static eub.smart.cardproduct.transfer.generic.core.constant.TargetTable.BANK;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;

@Component
public class FavoriteLocalTransferMapper {

    public CreateFavoriteLocalTransferIn toInDomain(ResultSet resultSet, int i) {
        try {
            Long finDocId = resultSet.getLong("finDocId");
            Long userId = resultSet.getLong("userId");
            String type = FavoriteTransferType.LOCT.name();
            String accountNumber = resultSet.getString("accountNumber");
            String title = resultSet.getString("title");
            Long imageId = resultSet.getLong("imageId");
            return new CreateFavoriteLocalTransferIn(
                    finDocId,
                    userId,
                    type,
                    accountNumber,
                    KZT,
                    title,
                    BANK,
                    imageId);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }
}
