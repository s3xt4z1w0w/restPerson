package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.util.NameUtil;
import eub.smart.cardproduct.transfer.generic.core.util.StringUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.IpsAccDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.IpsoReceiverDataIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.IpsRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I13B;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class IpsRepositoryImpl implements IpsRepository {

    private final NamedParameterJdbcTemplate template;
    private final String s3Url;

    public IpsRepositoryImpl(NamedParameterJdbcTemplate template,
                             @Value("${app.s3-download-address}") String s3Url) {
        this.template = template;
        this.s3Url = s3Url;
    }

    @Override
    public IpsAccDataIn findAccInfo(String phoneNumber) {
        RowMapper<IpsAccDataIn> rowMapper = (rs, rowNum) -> new IpsAccDataIn(
                NameUtil.getDisplayName(rs.getString("name")),
                imageUrl(s3Url, rs.getString("imageUid"))
        );

        String sql = """
                select a.Account_ID                                             as id,
                       concat(p.LastName, ' ', p.FirstName, ' ', p.FathersName) as name,
                       md.FileUid                                               as imageUid
                from MobilePhone mp
                         join AuthSMS ats on mp.MobilePhone_ID = ats.MobilePhone_IDREF
                         join AuthTool att on ats.AuthTool_IDREF = att.AuthTool_ID
                         join map_User_AuthTool mua on att.AuthTool_ID = mua.AuthTool_IDREF
                         join [User] u on u.User_ID = mua.User_IDREF
                         join Person p on u.Person_IDREF = p.Person_ID
                         join NewPasscode np on np.User_IDREF = u.User_ID
                         join map_IpsAccount_User map_iu on map_iu.User_IDREF = u.User_ID
                         join Account a on a.Account_ID = map_iu.Account_IDREF
                         left join MetaDocument md
                          on md.Target_ID = (select b.Bank_ID from Bank b where b.BIC = 'EURIKZKA')
                    and md.Target_Table = 'Bank'
                    and md.DocumentType_IDREF = :metaDocType
                    and md.LangKey = 'EN'
                    and md.IsActive = 1
                where mp.MobilePhone = :phoneNumber
                  and att.AuthToolStatus_IDREF = 'ACTV'
                  and a.Currency = 'KZT'
                  and u.UserStatus_IDREF = 'ACTV'
                  and p.PersonStatus_IDREF = 'ACTV'
                  and mp.MobilePhoneStatus_IDREF = 'ACTV'
                  and np.PasscodeStatus_IDREF = 'ACTV'
                """;
        List<IpsAccDataIn> queryResult = template.query(
                sql,
                Map.of("phoneNumber", phoneNumber, "metaDocType", I13B),
                rowMapper);

        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": IpsRepository findAccInfo"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": IpsRepository findAccInfo");
        } else {
            throw new AppException(E_DB_601, ": IpsRepository findAccInfo");
        }
    }

    @Override
    public IpsoReceiverDataIn findReceiverPhoneByFinDocId(Long finDocId) {
        RowMapper<IpsoReceiverDataIn> rowMapper = (rs, rowNum) -> new IpsoReceiverDataIn(
                rs.getString("receiverPhone"),
                rs.getString("receiverBic"),
                rs.getString("receiverName")
        );

        String sql = """
                SELECT i.USER_ReceiverPhone as receiverPhone,
                       i.BANK_ReceiverBic   as receiverBic,
                       i.USER_ReceiverName  as receiverName
                FROM IPSTransfer i
                WHERE i.FinDoc_IDREF = :finDocId
                """;

        List<IpsoReceiverDataIn> queryResult = template.query(
                sql,
                Map.of("finDocId", finDocId),
                rowMapper);

        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": IpsRepository findReceiverPhoneByFinDocId"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": IpsRepository findReceiverPhoneByFinDocId");
        } else {
            throw new AppException(E_DB_601, ": IpsRepository findReceiverPhoneByFinDocId");
        }
    }

    private static String imageUrl(String s3Url, String uid) {
        if (StringUtil.isEmpty(uid)) return uid;
        return String.format("%s?fileUid=%s", s3Url, uid);
    }

}
