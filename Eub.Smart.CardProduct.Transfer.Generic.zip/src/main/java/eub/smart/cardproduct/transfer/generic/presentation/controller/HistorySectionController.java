package eub.smart.cardproduct.transfer.generic.presentation.controller;

import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import eub.smart.cardproduct.transfer.generic.domain.use_case.TransferHistoryUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.TransferReceiptPdfUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.TransferReceiptUseCase;
import eub.smart.cardproduct.transfer.generic.presentation.mapper.PresentationMapper;
import eub.smart.cardproduct.transfer.generic.presentation.model.request.TransferHistoryRequest;
import eub.smart.cardproduct.transfer.generic.presentation.model.request.TransferReceiptRequest;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.TransferHistoryResponse;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.TransferReceiptResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static java.util.Objects.isNull;
import static org.springframework.http.HttpStatus.OK;

@SecurityRequirement(name = "Bearer Authentication")
@Tag(name = "HistorySectionController", description = "API для истории и квитанции")
@RestController
@RequestMapping("/transfer-generic/api")
public class HistorySectionController {

    private final PresentationMapper mapper;
    private final TransferHistoryUseCase transferHistoryUseCase;
    private final TransferReceiptUseCase transferReceiptUseCase;
    private final TransferReceiptPdfUseCase transferReceiptPdfUseCase;

    public HistorySectionController(PresentationMapper mapper,
                                    TransferHistoryUseCase transferHistoryUseCase,
                                    TransferReceiptUseCase transferReceiptUseCase, TransferReceiptPdfUseCase transferReceiptPdfUseCase) {
        this.mapper = mapper;
        this.transferHistoryUseCase = transferHistoryUseCase;
        this.transferReceiptUseCase = transferReceiptUseCase;
        this.transferReceiptPdfUseCase = transferReceiptPdfUseCase;
    }

    @Operation(description = "История переводов", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = TransferHistoryResponse.class, type = "List"))})})
    @PostMapping("/history")
    public ResponseEntity<?> history(@RequestHeader(CORRELATION_ID) String correlationId,
                                     @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                     @Valid @RequestBody(required = false) TransferHistoryRequest request,
                                     @PageableDefault(page = 0, size = 20) Pageable pageable) {
        if (isNull(request)) request = TransferHistoryRequest.oneMonth();
        var in = mapper.toDomain(request);
        var historyResponses = transferHistoryUseCase.invoke(in, pageable);
        return new ResponseEntity<>(historyResponses, OK);
    }

    @Operation(description = "Квитанция по переводу", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = TransferReceiptResponse.class))})})
    @GetMapping("/receipt/{finDocId}")
    public ResponseEntity<?> receipt(@RequestHeader(CORRELATION_ID) String correlationId,
                                     @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                     @PathVariable Long finDocId) {
        var receiptResponses = transferReceiptUseCase.invoke(finDocId);
        return new ResponseEntity<>(receiptResponses, OK);
    }

    @Operation(description = "Квитанция по переводу", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = TransferReceiptResponse.class))})})
    @GetMapping(value = "/receipt/{finDocId}/pdf", produces = {"application/pdf"})
    public ResponseEntity<?> receiptPdf(@RequestHeader(CORRELATION_ID) String correlationId,
                                     @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                     @PathVariable Long finDocId) {
        var receiptResponses = transferReceiptPdfUseCase.invoke(finDocId);
        return new ResponseEntity<>(receiptResponses, OK);
    }

}
