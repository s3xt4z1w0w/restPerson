package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateIpsoTransferOut;

public interface IpsTransferRepository {

    Long save(CreateIpsoTransferOut out);
    String findReceiverBankByFinDocId(Long finDocId);
}
