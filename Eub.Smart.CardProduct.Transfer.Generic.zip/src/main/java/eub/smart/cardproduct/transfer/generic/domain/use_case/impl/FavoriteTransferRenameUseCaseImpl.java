package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FavoriteTransferRenameUseCase;
import org.springframework.stereotype.Service;

@Service
public class FavoriteTransferRenameUseCaseImpl implements FavoriteTransferRenameUseCase {

    private final FavoriteTransferRepository favoriteTransferRepository;

    public FavoriteTransferRenameUseCaseImpl(FavoriteTransferRepository favoriteTransferRepository) {
        this.favoriteTransferRepository = favoriteTransferRepository;
    }

    @Override
    public void invoke(Long id, String name) {
        favoriteTransferRepository.rename(id, name);
    }
}
