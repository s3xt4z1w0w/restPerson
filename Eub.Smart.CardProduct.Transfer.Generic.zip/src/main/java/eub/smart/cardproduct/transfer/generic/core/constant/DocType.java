package eub.smart.cardproduct.transfer.generic.core.constant;

public interface DocType {

    String I92A = "I92A";
    String I92B = "I92B";
    String I13A = "I13A";
    String I13B = "I13B";
    String I32A = "I32A";
}
