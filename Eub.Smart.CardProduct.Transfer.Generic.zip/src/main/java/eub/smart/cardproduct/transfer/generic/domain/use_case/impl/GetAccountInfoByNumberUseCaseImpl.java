package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferCardDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.AccountOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.AccountRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.CardRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetAccountInfoByNumberUseCase;
import org.springframework.stereotype.Service;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_800;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_VD_400;
import static eub.smart.cardproduct.transfer.generic.core.util.NumUtil.nonBlank;
import static java.util.Objects.isNull;

@Service
public class GetAccountInfoByNumberUseCaseImpl implements GetAccountInfoByNumberUseCase {

    private final AccountRepository accountRepository;
    public final CardRepository cardRepository;

    public GetAccountInfoByNumberUseCaseImpl(AccountRepository accountRepository,
                                             CardRepository cardRepository) {
        this.accountRepository = accountRepository;
        this.cardRepository = cardRepository;
    }

    @Override
    public CreateTransferClientDataIn invoke(String number, String currency) {
        var accountInfo = accountRepository.findByNumberOrException(number);
        if (isOldMultiCurrency(accountInfo)) {
            accountInfo.setCurrency(currency);
        } else if (!accountInfo.getCurrency().equals(currency)) {
            throw new AppException(E_LG_800, ": invalid currency by account number: " + number);
        }
        return new CreateTransferClientDataIn(accountInfo);
    }

    @Override
    public CreateTransferClientDataIn invoke(Long accId, Long cardId, String currency) {
        CreateTransferClientDataIn createTransferClientInfo;
        if (nonBlank(cardId)) {
            var cardInfo = cardRepository.findByIdOrException(cardId, accId);
            if (isOldMultiCurrency(cardInfo)) cardInfo.setCurrency(currency);
            createTransferClientInfo = new CreateTransferClientDataIn(cardInfo);
        } else if (nonBlank(accId)) {
            var accountInfo = accountRepository.findByIdOrException(accId);
            if (isOldMultiCurrency(accountInfo)) accountInfo.setCurrency(currency);
            createTransferClientInfo = new CreateTransferClientDataIn(accountInfo);
        } else {
            throw new AppException(E_VD_400, ": acc id and card id is null");
        }
        return createTransferClientInfo;
    }

    private boolean isOldMultiCurrency(CreateTransferCardDataIn cardInfo) {
        return cardInfo.getFlagMultiCurrency() && isNull(cardInfo.getAccIdRef());
    }

    /**
     * It can be simple account or new multi currency
     *
     * @param accountInfo short account info
     * @return flag is olf multi currency
     */
    private boolean isOldMultiCurrency(AccountOut accountInfo) {
        return accountInfo.getFlagMultiCurrency() && isNull(accountInfo.getIdRef());
    }
}
