package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteIpslTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteIpsoTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteIpsRetransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteIpsTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteIpsTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferIpsFavoriteEntity;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.FavoriteIpsTransferMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferFavoriteJpaRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferIpsFavoriteJpaRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I13B;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class FavoriteIpsTransferRepositoryImpl implements FavoriteIpsTransferRepository {

    private final Logger log = LogManager.getLogger(getClass());
    private final FavoriteIpsTransferMapper favoriteIpsTransferMapper;
    private final NamedParameterJdbcTemplate template;
    private final TransferIpsFavoriteJpaRepository transferIpsFavoriteJpaRepository;
    private final TransferFavoriteJpaRepository transferFavoriteJpaRepository;
    private final InfrastructureMapper mapper;
    private final AuthToken authToken;

    public FavoriteIpsTransferRepositoryImpl(FavoriteIpsTransferMapper favoriteIpsTransferMapper,
                                             NamedParameterJdbcTemplate template,
                                             TransferIpsFavoriteJpaRepository transferIpsFavoriteJpaRepository,
                                             TransferFavoriteJpaRepository transferFavoriteJpaRepository,
                                             InfrastructureMapper mapper,
                                             AuthToken authToken) {
        this.favoriteIpsTransferMapper = favoriteIpsTransferMapper;
        this.template = template;
        this.transferIpsFavoriteJpaRepository = transferIpsFavoriteJpaRepository;
        this.transferFavoriteJpaRepository = transferFavoriteJpaRepository;
        this.mapper = mapper;
        this.authToken = authToken;
    }

    @Override
    public Optional<CreateFavoriteIpslTransferIn> findByFinDocId(Long sourceId) {
        Long userId = UserDetails.build(authToken.getDecodedPayload()).getUserId();
        Map<String, Object> map = Map.of(
                "id", sourceId,
                "userId", userId);

        String sql = """
                select fd.FinDoc_ID        as finDocId,
                       fd.User_IDREF       as userId,
                       t.Receiver_IBAN     as accountNumber,
                       t.USER_ReceiverName as title,
                       b.Bank_ID           as imageId
                from IPSTransfer t
                         join FinDoc fd with (nolock) on t.FinDoc_IDREF = fd.FinDoc_ID
                         left join Bank b with (nolock) on b.BIC = t.BANK_ReceiverBic
                where t.FinDoc_IDREF = :id
                and fd.User_IDREF = :userId
                """;

        List<CreateFavoriteIpslTransferIn> queryResult = template.query(sql, map, favoriteIpsTransferMapper::toIpslDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": FavoriteIpsTransferRepository findByFinDocId");
        }
    }

    @Override
    public CreateFavoriteIpslTransferIn findByFinDocIdOrException(Long sourceId) {
        return findByFinDocId(sourceId)
                .orElseThrow(() -> new AppException(E_DB_600, ": FavoriteIpsTransferRepository findByFinDocIdOrException"));
    }

    @Override
    public FavoriteIpsRetransferIn getFavorite(Long favoriteTransferId, Long userId) {
        return transferIpsFavoriteJpaRepository.findFavorite(favoriteTransferId, userId, LangUtil.getCurrentLocaleString())
                .orElseThrow(() -> new AppException(E_DB_600, ": FavoriteIpsTransferRepositoryImpl getFavorite"));
    }

    @Override
    public Optional<CreateFavoriteIpsoTransferIn> findIpsoByFinDocId(Long finDocId) {
        Long userId = UserDetails.build(authToken.getDecodedPayload()).getUserId();
        Map<String, Object> map = Map.of(
                "id", finDocId,
                "userId", userId);

        String sql = """
                select fd.FinDoc_ID         as finDocId,
                       fd.User_IDREF        as userId,
                       t.USER_ReceiverPhone as receiverPhone,
                       t.USER_ReceiverName  as receiverName,
                       s.SMPOrganization_ID as bankId
                from IPSTransfer t
                         join FinDoc fd with (nolock) on t.FinDoc_IDREF = fd.FinDoc_ID
                         left join SMPOrganization s with (nolock) on s.BIC = t.BANK_ReceiverBic
                where t.FinDoc_IDREF = :id
                  and fd.User_IDREF = :userId
                """;

        List<CreateFavoriteIpsoTransferIn> queryResult = template.query(sql, map, favoriteIpsTransferMapper::toIpsoDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": FavoriteIpsTransferRepository findByFinDocId");
        }
    }

    @Override
    public CreateFavoriteIpsoTransferIn findIpsoByFinDocIdOrException(Long finDocId) {
        return findIpsoByFinDocId(finDocId)
                .orElseThrow(() -> new AppException(E_DB_600, ": FavoriteIpsTransferRepositoryImpl findIpsoByFinDocIdOrException"));
    }

    @Override
    public FavoriteTransferDisplayOut fillDetailsDisplay(FavoriteTransferDisplayIn in) {
        var langKey = MDC.get(LANG_KEY);
        String sql = """
                SELECT tif.ReceiverName     as title,
                       md.FileUid           as imageUid,
                       s.Organization_Title as organizationTitle
                FROM TransferIpsFavorite tif
                         LEFT JOIN SMPOrganization s ON s.SMPOrganization_ID = tif.ReceiverBank_IDREF
                         LEFT JOIN MetaDocument md ON md.Target_ID = s.Target_ID
                    AND md.Target_Table = 'Bank'
                    AND md.IsActive = 1
                    AND md.LangKey = 'EN'
                    AND md.DocumentType_IDREF = :metaDocType
                WHERE tif.TransferFavorite_IDREF = :transferFavoriteId
                """;

        List<FavoriteTransferDisplayOut> queryResult = template.query(sql,
                Map.of("transferFavoriteId", in.getId(), "langKey", langKey, "metaDocType", I13B),
                (resultSet, i) -> favoriteIpsTransferMapper.toDetailsDisplay(resultSet, in, langKey));
        return queryResult
                .stream()
                .findFirst()
                .orElseThrow(() -> new AppException(E_DB_601, ": FavoriteAccTransferRepository fillDetailsDisplay"));
    }

    @Transactional
    @Override
    public FavoriteIpsTransferIn save(CreateFavoriteIpsoTransferIn out) {
        var optExist = exist(out);
        if (optExist.isPresent()) {
            return mapper.toDomain(optExist.get());
        } else {
            var transferIpsFavorite = mapper.toEntity(out);
            var transferFavorite = transferIpsFavorite.getTransferFavorite();
            var savedTransferFavorite = transferFavoriteJpaRepository.save(transferFavorite);
            transferIpsFavorite.setTransferFavorite(savedTransferFavorite);
            var res = transferIpsFavoriteJpaRepository.save(transferIpsFavorite);
            return mapper.toDomain(res);
        }
    }

    @Transactional
    @Override
    public void delete(CreateFavoriteIpsoTransferIn out) {
        var optExist = exist(out);
        if (optExist.isPresent()) {
            var transferIpsFavorite = optExist.get();
            var transferFavorite = transferIpsFavorite.getTransferFavorite();
            transferIpsFavoriteJpaRepository.deleteByTransferFavoriteId(transferFavorite.getId());
            transferFavoriteJpaRepository.deleteById(transferFavorite.getId());
        } else {
            log.warn("TransferFavoriteId is not found");
        }
    }

    public Optional<TransferIpsFavoriteEntity> exist(CreateFavoriteIpsoTransferIn out) {
        var senderUserId = out.favoriteTransferOut().userId();
        var receiverPhone = out.receiverPhone();
        var bankId = out.bankId();
        return transferIpsFavoriteJpaRepository
                .findByParam(senderUserId, receiverPhone, bankId);
    }
}
