package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.CreateFavoriteTransferDataPIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateFavoriteOut;

public interface FabricCreateFavoriteTransferUseCase {

    CreateFavoriteOut invoke(CreateFavoriteTransferDataPIn in);
}
