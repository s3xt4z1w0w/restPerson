package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.grpc;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CurrencyRateIn;
import rsbkinfo.V1.EubAdapterRsbkInfo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.BNS;
import static eub.smart.cardproduct.transfer.generic.core.util.GrpcUtil.toAdapterCurrencyCode;
import static eub.smart.cardproduct.transfer.generic.core.util.GrpcUtil.toBigDecimal;

public class GetCurrencyRatesListMapper {

    public static EubAdapterRsbkInfo.RsbkGetCurrencyRatesRequest toGrpcModel(String currency) {
        return EubAdapterRsbkInfo.RsbkGetCurrencyRatesRequest
                .newBuilder()
                .addCurrencyCodes(toAdapterCurrencyCode(currency))
                .build();
    }

    public static EubAdapterRsbkInfo.RsbkGetCurrencyRatesRequest toGrpcModel() {
        return EubAdapterRsbkInfo.RsbkGetCurrencyRatesRequest
                .newBuilder()
                .build();
    }

    public static CurrencyRateIn toDomainModel(EubAdapterRsbkInfo.RsbkGetCurrencyRatesReply response) {
        EubAdapterRsbkInfo.CurrencyRate currencyRate = response.getCurrencyRates(0);
        BigDecimal buyRate = toBigDecimal(currencyRate.getBuyRate());
        BigDecimal sellRate = toBigDecimal(currencyRate.getSellRate());
        String currency = currencyRate.getCurrency().name();
        return new CurrencyRateIn(buyRate, sellRate, currency);
    }

    public static List<CurrencyRateIn> toDomainModels(EubAdapterRsbkInfo.RsbkGetCurrencyRatesReply response) {
        List<EubAdapterRsbkInfo.CurrencyRate> currencyRateList = response.getCurrencyRatesList();
        List<CurrencyRateIn> currencyRateInList = new ArrayList<>();
        for (var currencyRate : currencyRateList) {
            if (BNS.equals(currencyRate.getCurrency().name())) continue;
            BigDecimal buyRate = toBigDecimal(currencyRate.getBuyRate());
            BigDecimal sellRate = toBigDecimal(currencyRate.getSellRate());
            String currency = currencyRate.getCurrency().name();
            CurrencyRateIn currencyRateIn = new CurrencyRateIn(buyRate, sellRate, currency);
            currencyRateInList.add(currencyRateIn);

        }
        return currencyRateInList;
    }
}
