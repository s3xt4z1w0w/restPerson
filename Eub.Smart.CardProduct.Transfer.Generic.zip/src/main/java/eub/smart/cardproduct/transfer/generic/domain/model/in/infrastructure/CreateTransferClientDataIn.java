package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.AccountOut;

public class CreateTransferClientDataIn {

    private Long accId;
    private String accountType;
    private String currency;
    private String number;
    private Long cardId;
    public Boolean flagMultiCurrency;

    public CreateTransferClientDataIn() {
    }

    public CreateTransferClientDataIn(AccountOut accountInfo) {
        this.accId = accountInfo.getId();
        this.accountType = accountInfo.getType();
        this.currency = accountInfo.getCurrency();
        this.number = accountInfo.getNumber();
        this.flagMultiCurrency = accountInfo.getFlagMultiCurrency();
    }

    public CreateTransferClientDataIn(CreateTransferCardDataIn cardInfo) {
        this.cardId = cardInfo.getId();
        this.accId = cardInfo.getAccId();
        this.accountType = cardInfo.getAccType();
        this.currency = cardInfo.getCurrency();
        this.number = cardInfo.getAccNumber();
        this.flagMultiCurrency = cardInfo.getFlagMultiCurrency();
    }

    public CreateTransferClientDataIn(Long accId, String accountType, String currency, String number, Boolean flagMultiCurrency) {
        this.accId = accId;
        this.accountType = accountType;
        this.currency = currency;
        this.number = number;
        this.flagMultiCurrency = flagMultiCurrency;
    }

    public CreateTransferClientDataIn(String receiverAccountNumber, String currency) {
        this.number = receiverAccountNumber;
        this.currency = currency;
    }

    public CreateTransferClientDataIn(LocalRetransferDataIn retransferDataIn, String currency) {
        this.number = retransferDataIn.receiverAccountNumber();
        this.currency = currency;
        this.cardId = retransferDataIn.receiverCardId();
    }

    public Long getAccId() {
        return accId;
    }

    public void setAccId(Long accId) {
        this.accId = accId;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Long getCardId() {
        return cardId;
    }

    public void setCardId(Long cardId) {
        this.cardId = cardId;
    }

    public Boolean getFlagMultiCurrency() {
        return flagMultiCurrency;
    }

    public void setFlagMultiCurrency(Boolean flagMultiCurrency) {
        this.flagMultiCurrency = flagMultiCurrency;
    }

    @Override
    public String toString() {
        return "NewTransferAccount{" +
                "accId=" + accId +
                ", cardId=" + cardId +
                ", accountType=" + accountType +
                ", currency=" + currency +
                ", number=" + number +
                ", cardId=" + cardId +
                ", flagMultiCurrency=" + flagMultiCurrency +
                '}';
    }
}
