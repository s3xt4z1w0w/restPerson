package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteAccTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteAccTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferAccFavoriteEntity;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.FavoriteAccTransferMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferAccFavoriteJpaRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.TransferFavoriteJpaRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I13B;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class FavoriteAccTransferRepositoryImpl implements FavoriteAcctTransferRepository {

    private final Logger log = LogManager.getLogger(getClass());
    private final InfrastructureMapper mapper;
    private final FavoriteAccTransferMapper favoriteAccTransferMapper;
    private final String s3Url;
    private final NamedParameterJdbcTemplate template;
    private final TransferFavoriteJpaRepository transferFavoriteJpaRepository;
    private final TransferAccFavoriteJpaRepository transferAccFavoriteJpaRepository;
    private final AuthToken authToken;

    public FavoriteAccTransferRepositoryImpl(InfrastructureMapper mapper,
                                             FavoriteAccTransferMapper favoriteAccTransferMapper,
                                             @Value("${app.s3-download-address}") String s3Url,
                                             NamedParameterJdbcTemplate template,
                                             TransferFavoriteJpaRepository transferFavoriteJpaRepository,
                                             TransferAccFavoriteJpaRepository transferAccFavoriteJpaRepository,
                                             AuthToken authToken) {
        this.mapper = mapper;
        this.favoriteAccTransferMapper = favoriteAccTransferMapper;
        this.s3Url = s3Url;
        this.template = template;
        this.transferFavoriteJpaRepository = transferFavoriteJpaRepository;
        this.transferAccFavoriteJpaRepository = transferAccFavoriteJpaRepository;
        this.authToken = authToken;
    }

    @Transactional
    @Override
    public FavoriteAccTransferIn save(FavoriteAccTransferOut out) {
        var optExist = exist(out);
        if (optExist.isPresent()) {
            return mapper.toDomain(optExist.get());
        } else {
            var transferAccFavorite = mapper.toEntity(out);
            var transferFavorite = transferAccFavorite.getTransferFavorite();
            var savedTransferFavorite = transferFavoriteJpaRepository.save(transferFavorite);
            transferAccFavorite.setTransferFavorite(savedTransferFavorite);
            var res = transferAccFavoriteJpaRepository.save(transferAccFavorite);
            return mapper.toDomain(res);
        }
    }

    @Override
    public Optional<FavoriteAccTransferOut> findByFinDocId(Long finDocId) {
        Map<String, Object> map = Map.of(
                "id", finDocId);

        String sql = """
                select fd.User_IDREF        as userId,
                       fd.FinDocType_IDREF  as docType,
                       t.Receiver_Account   as accountNumber,
                       t.Receiver_Currency  as receiverCurrency,
                       t.Receiver_IIN       as receiverIin,
                       t.Receiver_BIN       as receiverBin,
                       t.KNP_IDREF          as kmpId,
                       t.Receiver_Name      as receiverName,
                       t.TransferType_IDREF as transferType
                from Transfer t
                         join FinDoc fd with (nolock) on t.FinDoc_IDREF = fd.FinDoc_ID
                where t.FinDoc_IDREF = :id
                """;

        List<FavoriteAccTransferOut> queryResult = template.query(sql, map, favoriteAccTransferMapper::toOutDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": FavoriteLocalTransferRepository findTslfByFinDocId");
        }
    }

    @Override
    public CreateFavoriteAccTransferIn getCreateFavoriteAcctDataOrException(Long finDocId) {
        Long userId = UserDetails.build(authToken.getDecodedPayload()).getUserId();
        Map<String, Object> map = Map.of(
                "id", finDocId,
                "userId", userId);

        String sql = """
                select fd.FinDoc_ID        as finDocId,
                       fd.User_IDREF       as userId,
                       t.Receiver_Account  as accountNumber,
                       t.Receiver_Currency as currency,
                       t.Receiver_Name     as title,
                       b.Bank_ID           as imageId
                from Transfer t
                         join FinDoc fd with (nolock) on t.FinDoc_IDREF = fd.FinDoc_ID
                         left join Bank b on b.Code = SUBSTRING(t.Receiver_Account, 5, 3)
                where fd.FinDocType_IDREF = 'ACCT'
                  and fd.FinDoc_ID = :id
                  and fd.User_IDREF = :userId
                """;

        List<CreateFavoriteAccTransferIn> queryResult = template.query(sql, map, favoriteAccTransferMapper::toInDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": FavoriteAccTransferRepository findAcctByFinDocId"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": FavoriteAccTransferRepository findAcctByFinDocId");
        } else {
            throw new AppException(E_DB_601, ": FavoriteAccTransferRepository findAcctByFinDocId");
        }
    }

    @Transactional
    @Override
    public void delete(FavoriteAccTransferOut out) {
        var optTransferAppFavorite = exist(out);
        if (optTransferAppFavorite.isPresent()) {
            var transferAppFavorite = optTransferAppFavorite.get();
            var transferFavorite = transferAppFavorite.getTransferFavorite();
            transferAccFavoriteJpaRepository.deleteByTransferFavoriteId(transferFavorite.getId());
            transferFavoriteJpaRepository.deleteById(transferFavorite.getId());
        } else {
            log.warn("TransferFavoriteId is not found");
        }
    }

    public Optional<TransferAccFavoriteEntity> exist(FavoriteAccTransferOut out) {
        var senderUserId = out.favoriteTransferOut().userId();
        var receiverAccountNumber = out.accountNumber();
        return transferAccFavoriteJpaRepository
                .findByParams(senderUserId, receiverAccountNumber);
    }

    @Override
    public FavoriteTransferDisplayOut fillDetailsDisplay(FavoriteTransferDisplayIn in) {
        var langKey = MDC.get(LANG_KEY);

        String sql = """
                select taf.Title           as title,
                       md.FileUid          as imageUid
                from TransferAccFavorite taf
                         left join MetaDocument md with (nolock)
                                   on md.Target_ID = taf.ImageId
                                       and md.Target_Table = taf.ImageTable
                                       and md.DocumentType_IDREF = :metaDocType
                                       and md.LangKey = 'EN'
                                       and md.IsActive = 1
                where taf.TransferFavorite_IDREF = :id
                """;

        List<FavoriteTransferDisplayOut> queryResult = template.query(sql,
                Map.of("id", in.getId(), "langKey", langKey, "metaDocType", I13B),
                (resultSet, i) -> favoriteAccTransferMapper.toDetailsDisplay(resultSet, in, s3Url, langKey));
        return queryResult
                .stream()
                .findFirst()
                .orElseThrow(() -> new AppException(E_DB_601, ": FavoriteAccTransferRepository fillDetailsDisplay"));
    }

    @Override
    public boolean isExist(Long senderUserId, String receiverAccountNumber) {
        return transferAccFavoriteJpaRepository
                .findByParams(senderUserId, receiverAccountNumber)
                .isPresent();
    }
}
