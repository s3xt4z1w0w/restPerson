package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferOut;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateIpsoTransferUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.RetransferUseCase;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.IPSR;
import static eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType.IPSO;

@Service
public class RetransferIpsUseCaseImpl implements RetransferUseCase {

    private final CreateIpsoTransferUseCase createIpsoTransferUseCase;

    public RetransferIpsUseCaseImpl(CreateIpsoTransferUseCase createIpsoTransferUseCase) {
        this.createIpsoTransferUseCase = createIpsoTransferUseCase;
    }

    @Override
    public RetransferOut invoke(CreateRetransferDataIn in) {
        return createIpsoTransferUseCase.invoke(in);
    }

    @Override
    public FavoriteTransferType favoriteTransferType() {
        return IPSO;
    }

    @Override
    public String finDocType() {
        return IPSR;
    }
}
