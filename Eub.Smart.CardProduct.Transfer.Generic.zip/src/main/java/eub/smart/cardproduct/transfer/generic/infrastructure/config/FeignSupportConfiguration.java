package eub.smart.cardproduct.transfer.generic.infrastructure.config;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode;
import feign.codec.ErrorDecoder;
import org.springframework.context.annotation.Bean;

public class FeignSupportConfiguration {

    private final ErrorDecoder errorDecoder = new ErrorDecoder.Default();

    @Bean
    public ErrorDecoder errorDecoder() {
        return (methodKey, response) -> switch (response.status()) {
            case 400, 404 -> new AppException(AppErrorCode.E_EX_702, response.reason());
            default -> errorDecoder.decode(methodKey, response);
        };
    }
}
