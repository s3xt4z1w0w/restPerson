package eub.smart.cardproduct.transfer.generic.core.exception;

public class Error {

    private String title;
    private String subtitle;

    public Error() {
    }

    public Error(String title, String subtitle) {
        this.title = title;
        this.subtitle = subtitle;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}
