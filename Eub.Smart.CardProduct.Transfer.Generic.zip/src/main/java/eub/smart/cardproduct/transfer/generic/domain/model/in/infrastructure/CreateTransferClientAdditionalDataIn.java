package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public class CreateTransferClientAdditionalDataIn {

    private String name;
    private Boolean flagResident;
    private Boolean flagCorporate;
    private String iin;
    private String bin;

    public CreateTransferClientAdditionalDataIn(String name, boolean flagResident, String iin) {
        this.name = name;
        this.flagResident = flagResident;
        this.flagCorporate = false;
        this.iin = iin;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getFlagResident() {
        return flagResident;
    }

    public void setFlagResident(Boolean flagResident) {
        this.flagResident = flagResident;
    }

    public Boolean getFlagCorporate() {
        return flagCorporate;
    }

    public void setFlagCorporate(Boolean flagCorporate) {
        this.flagCorporate = flagCorporate;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    @Override
    public String toString() {
        return "NewTransferClient{" +
                "name=" + name +
                ", flagResident=" + flagResident +
                ", flagCorporate=" + flagCorporate +
                ", iin=" + iin +
                ", bin=" + bin +
                '}';
    }
}
