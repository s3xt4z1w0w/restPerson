package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteSelfTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.DeleteFavoriteTransferByFinDocIdUseCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.SLFT;

@Service
public class DeleteFavoriteSelfTransferByFinDocIdUseCaseImpl implements DeleteFavoriteTransferByFinDocIdUseCase {

    private final Logger log = LogManager.getLogger(getClass());

    private final FavoriteSelfTransferRepository favoriteSelfTransferRepository;
    private final FavoriteAcctTransferRepository favoriteAcctTransferRepository;

    public DeleteFavoriteSelfTransferByFinDocIdUseCaseImpl(FavoriteSelfTransferRepository favoriteSelfTransferRepository,
                                                           FavoriteAcctTransferRepository favoriteAcctTransferRepository) {
        this.favoriteSelfTransferRepository = favoriteSelfTransferRepository;
        this.favoriteAcctTransferRepository = favoriteAcctTransferRepository;
    }

    @Override
    public void invoke(Long id) {
        var optIn = favoriteSelfTransferRepository.findByFinDocId(id);
        if (optIn.isPresent()) {
            var favoriteSelfTransfer = optIn.get();
            var favoriteAccTransfer = new FavoriteAccTransferOut(favoriteSelfTransfer);
            favoriteAcctTransferRepository.delete(favoriteAccTransfer);
        } else {
            log.error("FavoriteSelfTransfer is not found");
        }
    }

    @Override
    public Set<String> keySet() {
        return Set.of(SLFT);
    }
}
