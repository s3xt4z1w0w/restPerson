package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.ReceiptRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.TransferReceiptUseCase;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

@Service
public class FabricTransferReceiptUseCaseImpl implements TransferReceiptUseCase {

    private final Map<String, ReceiptRepository> repositoryMap = new HashMap<>();
    private final FinDocRepository finDocRepository;

    public FabricTransferReceiptUseCaseImpl(FinDocRepository finDocRepository, Set<ReceiptRepository> repositories) {
        this.finDocRepository = finDocRepository;
        fillMap(repositories);
    }

    @Override
    public TransferReceiptOut invoke(Long finDocId) {
        var finDocType = finDocRepository.findTypeOrException(finDocId);
        var receiptRepository = findRepository(finDocType)
                .orElseThrow(() -> new AppException(E_LG_802, ": for finDocType: " + finDocType));
        return receiptRepository.findByFinDocIdOrException(finDocId);
    }

    private void fillMap(Set<ReceiptRepository> repositories) {
        repositories.forEach(repo -> repo.keys()
                .forEach(key -> repositoryMap.put(key, repo)));
    }

    private Optional<ReceiptRepository> findRepository(String finDocType) {
        var receiptRepository = repositoryMap.get(finDocType);
        return Optional.ofNullable(receiptRepository);
    }
}
