package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.AmountOut;

public record AccountSourceIn(
        Long accountId,
        Long cardId,
        String title,
        String image,
        String number,
        String accountType,
        ProductStatusIn status,
        AmountOut amount,
        Boolean allowSource,
        Boolean allowTarget
) {
}
