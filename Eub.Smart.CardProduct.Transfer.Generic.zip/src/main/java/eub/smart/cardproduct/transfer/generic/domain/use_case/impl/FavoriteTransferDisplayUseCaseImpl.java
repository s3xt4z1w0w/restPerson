package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.*;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FavoriteTransferDisplayUseCase;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

@Service
public class FavoriteTransferDisplayUseCaseImpl implements FavoriteTransferDisplayUseCase {

    private final FavoriteTransferRepository favoriteTransferRepository;
    private final FavoriteSelfTransferRepository favoriteSelfTransferRepository;
    private final FavoriteAcctTransferRepository favoriteAcctTransferRepository;
    private final FavoriteIpsTransferRepository favoriteIpsTransferRepository;
    private final FavoriteP2pTransferRepository favoriteP2pTransferRepository;

    public FavoriteTransferDisplayUseCaseImpl(FavoriteTransferRepository favoriteTransferRepository,
                                              FavoriteSelfTransferRepository favoriteSelfTransferRepository,
                                              FavoriteAcctTransferRepository favoriteAcctTransferRepository,
                                              FavoriteIpsTransferRepository favoriteIpsTransferRepository,
                                              FavoriteP2pTransferRepository favoriteP2pTransferRepository) {
        this.favoriteTransferRepository = favoriteTransferRepository;
        this.favoriteSelfTransferRepository = favoriteSelfTransferRepository;
        this.favoriteAcctTransferRepository = favoriteAcctTransferRepository;
        this.favoriteIpsTransferRepository = favoriteIpsTransferRepository;
        this.favoriteP2pTransferRepository = favoriteP2pTransferRepository;
    }

    @Override
    public List<FavoriteTransferDisplayOut> invoke(Pageable pageable) {
        return favoriteTransferRepository
                .getAll(pageable)
                .getContent()
                .stream()
                .map(this::fillByFinDocType)
                .toList();
    }

    private FavoriteTransferDisplayOut fillByFinDocType(FavoriteTransferDisplayIn in) {
        var type = in.getType();
        var favoriteTransferType = EnumUtil.valueOfOrException(FavoriteTransferType.class, type);

        return switch (favoriteTransferType) {
            case SLFT -> favoriteSelfTransferRepository.fillDetailsDisplay(in);
            case ACCT, LOCT -> favoriteAcctTransferRepository.fillDetailsDisplay(in);
            case IPSO -> favoriteIpsTransferRepository.fillDetailsDisplay(in);
            case P2PO -> favoriteP2pTransferRepository.fillDetailsDisplay(in);
            default -> throw new AppException(E_LG_802, ": fin doc type " + type);
        };
    }
}
