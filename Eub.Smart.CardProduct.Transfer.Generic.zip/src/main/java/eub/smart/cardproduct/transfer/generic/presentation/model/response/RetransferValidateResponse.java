package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;

public record RetransferValidateResponse(
        @Schema(description = "Id response")
        Long id,
        @Schema(description = "Комиссия")
        BigDecimal feeAmount
) {
}
