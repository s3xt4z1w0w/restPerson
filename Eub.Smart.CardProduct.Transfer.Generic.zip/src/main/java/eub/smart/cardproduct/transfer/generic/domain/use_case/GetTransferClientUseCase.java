package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientAdditionalDataIn;

public interface GetTransferClientUseCase {

    CreateTransferClientAdditionalDataIn invoke(String accountNumber);
}
