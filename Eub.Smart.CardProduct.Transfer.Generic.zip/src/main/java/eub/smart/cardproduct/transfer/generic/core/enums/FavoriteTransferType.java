package eub.smart.cardproduct.transfer.generic.core.enums;

import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.ACCF;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.IPSF;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.LOCF;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.P2PF;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.SLFF;

public enum FavoriteTransferType {
    SLFT(SLFF),
    LOCT(LOCF),
    ACCT(ACCF),
    P2PO(P2PF),
    IPSO(IPSF);

    private final String finDocType;

    private FavoriteTransferType(String finDocType) {
        this.finDocType = finDocType;
    }

    public String finDocType() {
        return finDocType;
    }
}
