package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CardInfoIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferCardDataIn;

public interface CardRepository {

    CreateTransferCardDataIn findByIdOrException(Long cardId, Long accId);
    CardInfoIIn findByCardIdOrException(Long cardId);
}
