package eub.smart.cardproduct.transfer.generic.infrastructure.mapper;

import MyBankInfo.V1.EubAggregatorCoreMyBank;
import Transfer.IPS.Outgoing.V1.EubAggregatorTransferIPSOutgoing;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.*;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.*;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.*;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.uses.CustomTypeDecimalValueToBigDecimal;
import kz.eubank.grpc.EubAggregatorCardProductTransferVisaAlias;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import p2p.EubAggregatorCardProductTransferP2P;

import static org.mapstruct.MappingConstants.ComponentModel.SPRING;

@Mapper(componentModel = SPRING, uses = {CustomTypeDecimalValueToBigDecimal.class})
public interface InfrastructureMapper {

    TransferEntity toEntity(TransferOut transferModel);

    TransferOut toDomain(TransferEntity saved);

    FinDocEntity toEntity(FinDocOut model);

    FinDocOut toDomain(FinDocEntity entity);

    ClientOut toDomain(ClientEntity entity);

    FinDocStatusIn toDomain(FinDocStatusEntity finDocStatusEntity);

    @Mappings({
            @Mapping(target = "transactionId", source = "txId")
    })
    AituPayVerificationIn toDomain(EubAggregatorTransferIPSOutgoing.GetVerificationAitupayReply response);

    @Mappings({
            @Mapping(target = "ipsTransferId", ignore = true)
    })
    IpsTransferEntity toEntity(CreateIpsoTransferOut out);

    FeeOut toDomain(FeeEntity entity);

    @Mappings({
            @Mapping(target = "favoriteTransferIn", source = "transferFavorite"),
            @Mapping(target = "transferType", ignore = true)
    })
    FavoriteAccTransferIn toDomain(TransferAccFavoriteEntity transferAccFavoriteEntity);

    @Mappings({
            @Mapping(target = "id", ignore = true),
            @Mapping(target = "transferFavorite.id", ignore = true),
            @Mapping(target = "transferFavorite.finDocId", source = "favoriteTransferOut.finDocId"),
            @Mapping(target = "transferFavorite.userId", source = "favoriteTransferOut.userId"),
            @Mapping(target = "transferFavorite.type", source = "favoriteTransferOut.type"),
            @Mapping(target = "transferFavorite.title", source = "favoriteTransferOut.title")
    })
    TransferAccFavoriteEntity toEntity(FavoriteAccTransferOut out);

    @Mappings({
            @Mapping(target = "favoriteTransferIn", source = "transferFavorite"),
            @Mapping(target = "phoneNumber", source = "receiverPhone")
    })
    FavoriteIpsTransferIn toDomain(TransferIpsFavoriteEntity entity);

    @Mappings({
            @Mapping(target = "id", ignore = true),
            @Mapping(target = "transferFavorite.id", ignore = true),
            @Mapping(target = "transferFavorite.finDocId", source = "favoriteTransferOut.finDocId"),
            @Mapping(target = "transferFavorite.userId", source = "favoriteTransferOut.userId"),
            @Mapping(target = "transferFavorite.type", source = "favoriteTransferOut.type"),
            @Mapping(target = "transferFavorite.title", source = "favoriteTransferOut.title")
    })
    TransferIpsFavoriteEntity toEntity(CreateFavoriteIpsoTransferIn out);

    @Mappings({
            @Mapping(target = "accountOutRef", source = "accountId"),
            @Mapping(target = "amount", source = "availableBalance"),
            @Mapping(target = "currency", source = "currency")
    })
    AccountBalanceIn toDomain(EubAggregatorCoreMyBank.CardAccountBalance accountBalance);

    @Mappings({
            @Mapping(target = "accountOutRef", source = "accountId"),
            @Mapping(target = "amount", source = "availableBalance"),
            @Mapping(target = "currency", source = "currency")
    })
    AccountBalanceIn toDomain(EubAggregatorCoreMyBank.CurrentAccountBalance balance);

    @Mappings({
            @Mapping(target = "id", ignore = true),
            @Mapping(target = "transferFavorite.id", ignore = true),
            @Mapping(target = "transferFavorite.finDocId", source = "favoriteTransferOut.finDocId"),
            @Mapping(target = "transferFavorite.userId", source = "favoriteTransferOut.userId"),
            @Mapping(target = "transferFavorite.type", source = "favoriteTransferOut.type"),
            @Mapping(target = "transferFavorite.title", source = "favoriteTransferOut.title")
    })
    TransferP2pFavoriteEntity toEntity(CreateFavoriteP2poTransferIn out);

    CardTransferEntity toEntity(CardTransferIOut cardTransfer);

    FeeOutgoingIIn toDomain(EubAggregatorCardProductTransferP2P.GetFeeReply response);

    FeeOutgoingIIn toDomain(EubAggregatorCardProductTransferVisaAlias.GetFeeResponse response);
    @Mappings({
            @Mapping(target = "isSuccess", source = "isSuccess"),
            @Mapping(target = "issuerName", source = "issuerName"),
            @Mapping(target = "clientFullName", source = "clientFullName")
    })
    VisaTokenIIn toDomain(EubAggregatorCardProductTransferVisaAlias.ResolveTokenResponse response);
}
