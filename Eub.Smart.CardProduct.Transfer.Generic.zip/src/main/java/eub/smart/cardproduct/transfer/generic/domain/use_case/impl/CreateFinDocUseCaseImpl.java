package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateFinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateTransferDataOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FeeOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFinDocUseCase;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;

import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.CRCR;

@Service
public class CreateFinDocUseCaseImpl implements CreateFinDocUseCase {

    private final FinDocRepository finDocRepository;
    private final AuthToken authToken;

    public CreateFinDocUseCaseImpl(FinDocRepository finDocRepository,
                                   AuthToken authToken) {
        this.finDocRepository = finDocRepository;
        this.authToken = authToken;
    }

    @Override
    public FinDocOut invoke(CreateTransferDataOut out,
                            CreateTransferClientDataIn senderAccount) {
        var type = out.finDocType();
        var amount = out.senderAmount();
        var senderCurrency = senderAccount.getCurrency();
        var accountId = senderAccount.getAccId();
        var fee = out.fee();
        var feeAmount = fee.getAmount();
        var feeCurrency = fee.getCurrency();
        var payload = authToken.getDecodedPayload();
        var userDetails = UserDetails.build(payload);
        var userId = userDetails.getUserId();
        var dateScheduled = new Date();
        var dateCreated = new Date();

        var finDoc = new FinDocOut(
                type, userId, null, accountId, senderCurrency,
                amount, feeAmount, feeCurrency, dateCreated,
                dateScheduled, null, false, false,
                null, null, 0, null);
        return finDocRepository.save(finDoc);
    }

    @Override
    public FinDocOut invoke(BigDecimal amount, String currency, FeeOut fee) {
        var feeAmount = fee.getAmount();
        var feeCurrency = fee.getCurrency();
        var payload = authToken.getDecodedPayload();
        var userDetails = UserDetails.build(payload);
        var userId = userDetails.getUserId();
        var dateScheduled = new Date();
        var dateCreated = new Date();

        var finDoc = new FinDocOut(
                CRCR, userId, null, null, currency,
                amount, feeAmount, feeCurrency, dateCreated,
                dateScheduled, null, false, false,
                null, null, 0, null);
        return finDocRepository.save(finDoc);
    }

    @Override
    public FinDocOut invoke(CreateFinDocOut out) {
        var type = out.type();
        var amount = out.amount();
        var currency = out.currency();
        var fee = out.fee();
        var accountId = out.accountId();
        var feeAmount = fee.getAmount();
        var feeCurrency = fee.getCurrency();
        var payload = authToken.getDecodedPayload();
        var userDetails = UserDetails.build(payload);
        var userId = userDetails.getUserId();
        var dateScheduled = new Date();
        var dateCreated = new Date();

        var finDoc = new FinDocOut(
                type, userId, null, accountId, currency,
                amount, feeAmount, feeCurrency, dateCreated,
                dateScheduled, null, false, false,
                null, null, 0, null);
        return finDocRepository.save(finDoc);
    }
}
