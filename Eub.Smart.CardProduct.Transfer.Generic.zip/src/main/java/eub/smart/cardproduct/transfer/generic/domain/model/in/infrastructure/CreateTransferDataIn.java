package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public class CreateTransferDataIn {

    private CreatedTransferDataIn transfer;
    private CreateTransferClientDataIn account;
    private FinDocStatusIn finDocStatus;

    public CreateTransferDataIn() {
    }

    public CreateTransferDataIn(CreatedTransferDataIn transfer, CreateTransferClientDataIn account, FinDocStatusIn finDocStatus) {
        this.transfer = transfer;
        this.account = account;
        this.finDocStatus = finDocStatus;
    }

    public CreatedTransferDataIn getTransfer() {
        return transfer;
    }

    public void setTransfer(CreatedTransferDataIn transfer) {
        this.transfer = transfer;
    }

    public CreateTransferClientDataIn getAccount() {
        return account;
    }

    public void setAccount(CreateTransferClientDataIn account) {
        this.account = account;
    }

    public FinDocStatusIn getFinDocStatus() {
        return finDocStatus;
    }

    public void setFinDocStatus(FinDocStatusIn finDocStatus) {
        this.finDocStatus = finDocStatus;
    }
}
