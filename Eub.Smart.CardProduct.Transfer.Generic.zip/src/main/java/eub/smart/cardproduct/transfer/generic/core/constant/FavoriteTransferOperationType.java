package eub.smart.cardproduct.transfer.generic.core.constant;

public interface FavoriteTransferOperationType {

    String SLFT = "SLFT";
    String P2PL = "P2PL";
    String P2PX = "P2PX";
    String P2PO = "P2PO";
    String IPSL = "IPSL";
    String IPSO = "IPSO";
    String ACCT = "ACCT";
    String LOCT = "LOCT";
}
