package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AccountOutRefIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.IpsoAccountDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.AccountOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.AccountRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.AccountOutRefMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.CommonMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.AccountMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class AccountRepositoryImpl implements AccountRepository {

    private final NamedParameterJdbcTemplate template;

    public AccountRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<AccountOut> findByNumber(String number) {
        String sql = """ 
                select a.Account_ID        as accountId,
                       a.AccountType_IDREF as accountType,
                       a.Currency          as currency,
                       a.Number            as number,
                       a.IsMultiCurrency   as multiCurrencyFlag,
                       a.Account_IDREF     as accountIdRef
                from Account a
                where A.Number = :number
                """;

        List<AccountOut> queryResult = template.query(sql, Map.of("number", number), AccountMapper::toDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": AccountRepository findByNumber");
        }
    }

    @Override
    public AccountOut findByNumberOrException(String accountNumber) {
        return findByNumber(accountNumber)
                .orElseThrow(() -> new AppException(E_DB_600, ": AccountRepository findByNumberOrException"));
    }

    @Override
    public Optional<String> getAccountStatus(String accountNumber) {
        String sql = """ 
                select A.AccountStatus_IDREF as type
                from Account A
                where A.Number = :accountNumber
                """;

        List<String> queryResult = template.query(sql, Map.of("accountNumber", accountNumber), CommonMapper::getType);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": AccountRepository getAccountStatus");
        }
    }

    @Override
    public String getAccountStatusOrException(String accountNumber) {
        return getAccountStatus(accountNumber)
                .orElseThrow(() -> new AppException(E_DB_600, ": AccountRepository getAccountStatusOrException"));
    }

    @Override
    public AccountOut findByIdOrException(Long id) {
        String sql = """ 
                select a.Account_ID        as accountId,
                       a.AccountType_IDREF as accountType,
                       a.Currency          as currency,
                       a.Number            as number,
                       a.IsMultiCurrency   as multiCurrencyFlag,
                       a.Account_IDREF     as accountIdRef
                from Account a
                where A.Account_ID = :id
                """;

        List<AccountOut> queryResult = template.query(sql, Map.of("id", id), AccountMapper::toDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": AccountRepository findByIdOrException"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": AccountRepository findByIdOrException");
        } else {
            throw new AppException(E_DB_601, ": AccountRepository findByNumber");
        }
    }

    @Override
    public IpsoAccountDataIn findByCardId(Long cardId) {
        RowMapper<IpsoAccountDataIn> rowMapper = (rs, rowNum) -> new IpsoAccountDataIn(
                rs.getString("accountNumber"),
                rs.getLong("accountOutRefId"),
                rs.getString("accountStatus"),
                rs.getString("bSystem")
        );
        String sql = """
                SELECT 
                   a.Number              as accountNumber,
                   a.Account_OUTREF      as accountOutRefId,
                   a.AccountStatus_IDREF as accountStatus,
                   bc.BSystem_IDREF      as bSystem
            FROM Card c
                     JOIN Account a ON a.Account_ID = c.Account_IDREF
                     JOIN BSystemClient bc ON bc.BSystemClient_ID = a.BSystemClient_IDREF
            WHERE c.Card_ID = :cardId
                """;

        List<IpsoAccountDataIn> queryResult = template.query(sql, Map.of("cardId", cardId), rowMapper);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": AccountRepository findByCardId"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": AccountRepository findByCardId");
        } else {
            throw new AppException(E_DB_601, ": AccountRepository findByCardId");
        }
    }

    @Override
    public List<AccountOutRefIIn> findAccountOutRefs(Long accountId) {
        String sql = """
                select case
                           when a.IsMultiCurrency = 1 and a.Account_IDREF is not null
                               then a2.Account_OUTREF
                           else a.Account_OUTREF
                           end as accountOutRef
                from Account a
                         join CurrencyType ct on ct.Currency_Code = a.Currency
                         left join Account a2 on a2.Account_IDREF = a.Account_IDREF
                         left join CurrencyType ct2 on ct2.Currency_Code = a2.Currency
                where a.Account_ID = :accountId
                """;
        List<AccountOutRefIIn> queryResult = template.query(sql,
                Map.of("accountId", accountId),
                AccountOutRefMapper::toDomain);
        if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": AccountRepository findAccountOutRefs");
        }
        return new ArrayList<>(queryResult);
    }
}
