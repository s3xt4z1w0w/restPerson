package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public record ProductStatusResponse(
        @Schema(description = "Тип")
        String type,
        @Schema(description = "Заголовок")
        String title
) {
}
