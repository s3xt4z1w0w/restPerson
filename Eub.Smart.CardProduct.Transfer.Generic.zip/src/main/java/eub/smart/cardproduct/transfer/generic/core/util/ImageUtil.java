package eub.smart.cardproduct.transfer.generic.core.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ImageUtil {

    private static String s3Url;

    public ImageUtil(@Value("${app.s3-download-address}") String s3Url) {
        ImageUtil.s3Url = s3Url;
    }

    public static String formImageUrl(String uid) {
        if (StringUtil.isEmpty(uid)) return uid;
        return String.format("%s?fileUid=%s", s3Url, uid);
    }

}
