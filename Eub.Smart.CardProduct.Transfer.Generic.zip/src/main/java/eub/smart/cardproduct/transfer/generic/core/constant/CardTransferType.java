package eub.smart.cardproduct.transfer.generic.core.constant;

public interface CardTransferType {

    String P2PL =  "P2PL";
    String P2PO =  "P2PO";
    String P2PI =  "P2PI";
}
