package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.grpc;

import Transfer.IPS.Outgoing.V1.EubAggregatorTransferIPSOutgoing;
import Transfer.IPS.Outgoing.V1.IpsOutgoingGrpc;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.AituPayVerificationIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.AituPayVerificationOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.TransferIPSOutgoingAggregatorRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Repository;

import static Transfer.IPS.Outgoing.V1.EubAggregatorTransferIPSOutgoing.IdentifierTypeCreditorAitupay.MOBN;
import static Transfer.IPS.Outgoing.V1.EubAggregatorTransferIPSOutgoing.TransferType.IPSO;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_EX_700;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_EX_701;

@Repository
public class TransferIPSOutgoingAggregatorRepositoryImpl implements TransferIPSOutgoingAggregatorRepository {

    @GrpcClient("aggregator-transfer-ipso")
    private IpsOutgoingGrpc.IpsOutgoingBlockingStub stub;
    private final InfrastructureMapper mapper;

    public TransferIPSOutgoingAggregatorRepositoryImpl(InfrastructureMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public AituPayVerificationIn getVerification(AituPayVerificationOut out) {
        try {
            var request = EubAggregatorTransferIPSOutgoing.GetVerificationAitupayRequest.newBuilder()
                    .setTransferType(IPSO)
                    .setReceiverId(out.phoneNumber())
                    .setReceiverIdType(MOBN)
                    .setReceiverReverseDomain(out.reverseDomain())
                    .build();
            var response = stub.getVerificationAitupay(request);
            if (!response.getVerificationSucceeded()) {
                throw new AppException(E_EX_700, ": TransferIPSOutgoingAggregatorRepository getVerification");
            }
            return mapper.toDomain(response);
        } catch (StatusRuntimeException e) {
            throw new AppException(E_EX_701, ": TransferIPSOutgoingAggregatorRepository getVerification");
        }
    }
}
