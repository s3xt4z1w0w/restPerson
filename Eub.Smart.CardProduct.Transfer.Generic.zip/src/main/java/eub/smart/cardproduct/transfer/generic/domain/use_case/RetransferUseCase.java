package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferOut;

import java.util.Set;


public interface RetransferUseCase {

    RetransferOut invoke(CreateRetransferDataIn in);

    FavoriteTransferType favoriteTransferType();

    String finDocType();
}
