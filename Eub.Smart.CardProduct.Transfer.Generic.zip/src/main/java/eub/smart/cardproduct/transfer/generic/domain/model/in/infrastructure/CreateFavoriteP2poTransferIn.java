package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteTransferOut;

public record CreateFavoriteP2poTransferIn(
        FavoriteTransferOut favoriteTransferOut,
        String title,
        String token,
        String bin
) {
    public CreateFavoriteP2poTransferIn(Long finDocId,
                                        Long userId,
                                        String type,
                                        String title,
                                        String bin,
                                        String token) {
        this(new FavoriteTransferOut(finDocId, userId, type),
                title,
                token,
                bin);
    }
}
