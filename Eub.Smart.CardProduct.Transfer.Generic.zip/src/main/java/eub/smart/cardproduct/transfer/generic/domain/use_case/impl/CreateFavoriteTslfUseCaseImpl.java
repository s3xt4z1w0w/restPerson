package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteSelfTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFavoriteUseCase;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.SLFT;

@Service
public class CreateFavoriteTslfUseCaseImpl implements CreateFavoriteUseCase {

    private final FavoriteSelfTransferRepository favoriteSelfTransferRepository;
    private final FavoriteAcctTransferRepository favoriteAcctTransferRepository;

    public CreateFavoriteTslfUseCaseImpl(FavoriteSelfTransferRepository favoriteSelfTransferRepository,
                                         FavoriteAcctTransferRepository favoriteAcctTransferRepository) {
        this.favoriteSelfTransferRepository = favoriteSelfTransferRepository;
        this.favoriteAcctTransferRepository = favoriteAcctTransferRepository;
    }

    @Override
    public Long invoke(Long finDocId) {
        var in = favoriteSelfTransferRepository.findByFinDocIdOrException(finDocId);
        var out = new FavoriteAccTransferOut(in);
        var saved = favoriteAcctTransferRepository.save(out);
        return saved.favoriteTransferIn().id();
    }

    @Override
    public Set<String> keySet() {
        return Set.of(SLFT);
    }
}
