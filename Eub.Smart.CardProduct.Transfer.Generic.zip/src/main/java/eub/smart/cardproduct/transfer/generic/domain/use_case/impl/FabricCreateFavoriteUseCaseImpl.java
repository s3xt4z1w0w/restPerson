package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFavoriteUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FabricCreateFavoriteUseCase;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

@Service
public class FabricCreateFavoriteUseCaseImpl implements FabricCreateFavoriteUseCase {

    private final FinDocRepository finDocRepository;
    private final Map<String, CreateFavoriteUseCase> useCaseMap = new HashMap<>();

    public FabricCreateFavoriteUseCaseImpl(Set<CreateFavoriteUseCase> useCases,
                                           FinDocRepository finDocRepository) {
        this.finDocRepository = finDocRepository;
        fillMap(useCases);
    }

    @Override
    public Long invoke(Long finDocId) {
        var operationType = finDocRepository.findOperationTypeOrException(finDocId);
        var createFavoriteTransfer = findUseCase(operationType.invoke())
                .orElseThrow(() -> new AppException(E_LG_802, ": for operation type: " + operationType.invoke()));
        return createFavoriteTransfer.invoke(finDocId);
    }

    private void fillMap(Set<CreateFavoriteUseCase> useCases) {
        useCases.forEach(repo -> repo.keySet()
                .forEach(key -> useCaseMap.put(key, repo))
        );
    }

    private Optional<CreateFavoriteUseCase> findUseCase(String finDocType) {
        var receiptRepository = useCaseMap.get(finDocType);
        return Optional.ofNullable(receiptRepository);
    }
}
