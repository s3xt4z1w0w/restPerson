package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRepeatIpslIn;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.IpsTransferEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface IpsTransferJpaRepository extends JpaRepository<IpsTransferEntity, Long> {


    @Query(value = """
            select T.SenderCard_IDREF   as senderCardId,
                   T.USER_ReceiverPhone as receiverPhone
            from IPSTransfer T
                     join FinDoc FD on T.FinDoc_IDREF = FD.FinDoc_ID
            where T.TransferType = 'IPSL'
              and FD.FinDoc_ID = :finDocId
            """, nativeQuery = true)
    Optional<CreateRepeatIpslIn> findCreateRepeatIpslData(Long finDocId);
}
