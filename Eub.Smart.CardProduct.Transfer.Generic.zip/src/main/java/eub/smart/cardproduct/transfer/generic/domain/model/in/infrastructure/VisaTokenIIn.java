package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record VisaTokenIIn(
        Boolean isSuccess,
        String issuerName,
        String clientFullName
) {
}
