package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.AccountTargetOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.RetransferReceiverRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.RetransferReceiverDataUseCase;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;

@Service
public class RetransferReceiverDataUseCaseImpl implements RetransferReceiverDataUseCase {

    private final Map<String, RetransferReceiverRepository> repositoryMap = new HashMap<>();
    private final FinDocRepository finDocRepository;

    public RetransferReceiverDataUseCaseImpl(FinDocRepository finDocRepository, Set<RetransferReceiverRepository> repositories) {
        this.finDocRepository = finDocRepository;
        fillMap(repositories);
    }

    @Override
    public AccountTargetOut invoke(Long finDocId) {
        var finDocType = finDocRepository.findTypeOrException(finDocId);
        var receiptRepository = findRepository(finDocType)
                .orElseThrow(() -> new AppException(E_LG_802, ": for finDocType: " + finDocType));
        return receiptRepository.findByFinDocIdOrException(finDocId);
    }

    private void fillMap(Set<RetransferReceiverRepository> repositories) {
        repositories.forEach(repo -> repo.keys()
                .forEach(key -> repositoryMap.put(key, repo)));
    }

    private Optional<RetransferReceiverRepository> findRepository(String finDocType) {
        var receiptRepository = repositoryMap.get(finDocType);
        return Optional.ofNullable(receiptRepository);
    }
}
