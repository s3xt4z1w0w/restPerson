package eub.smart.cardproduct.transfer.generic.domain.repository;

public interface FinDocStateRepository {

    void saveFinDocStatus(String status, Long finDocId);
}
