package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.IpsAccDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.IpsoReceiverDataIn;

public interface IpsRepository {

    IpsAccDataIn findAccInfo(String phoneNumber);

    IpsoReceiverDataIn findReceiverPhoneByFinDocId(Long finDocId);

}
