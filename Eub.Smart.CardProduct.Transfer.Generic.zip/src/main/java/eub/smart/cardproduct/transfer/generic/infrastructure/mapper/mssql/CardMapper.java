package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferCardDataIn;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;

public class CardMapper {

    public static CreateTransferCardDataIn toDomain(ResultSet resultSet, int i) {
        try {
            Long cardId = resultSet.getLong("cardId");
            Long accountId = resultSet.getLong("accountId");
            String accountType = resultSet.getString("accountType");
            String number = resultSet.getString("number");
            String currency = resultSet.getString("currency");
            Boolean multiCurrencyFlag = resultSet.getBoolean("multiCurrencyFlag");
            Long accountIdRef = resultSet.getLong("accountIdRef");
            Long cardOutRef = resultSet.getLong("cardOutRef");
            return new CreateTransferCardDataIn(cardId,
                    accountId,
                    accountType,
                    currency,
                    number,
                    multiCurrencyFlag,
                    accountIdRef,
                    cardOutRef);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }
}
