package eub.smart.cardproduct.transfer.generic.domain.use_case;

import java.util.Set;

public interface CreateFavoriteUseCase {

    Long invoke(Long finDocId);

    Set<String> keySet();
}
