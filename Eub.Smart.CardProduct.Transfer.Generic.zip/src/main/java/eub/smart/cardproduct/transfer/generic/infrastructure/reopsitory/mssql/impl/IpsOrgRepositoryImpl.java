package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.repository.IpsOrgRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.CommonMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class IpsOrgRepositoryImpl implements IpsOrgRepository {

    private final NamedParameterJdbcTemplate template;

    public IpsOrgRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public Optional<Long> findTargetIdByBic(String bic) {
        String sql = """ 
                select o.IPSOrg_ID as id
                from IPSOrg o
                where o.BIC = :bic;
                """;

        List<Long> queryResult = template.query(
                sql,
                Map.of("bic", bic),
                CommonMapper::getLong);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": IpsOrgRepositoryImpl findTargetIdByBic");
        }
    }

    @Override
    public Optional<String> findReverseDomainByBic(String bic) {
        String sql = """
            SELECT i.DomainName as type
            FROM IPSOrg i
            WHERE i.isActiv = 1
              AND i.BIC = :bic
                """;
        List<String> queryResult = template.query(
                sql,
                Map.of("bic", bic),
                CommonMapper::getType);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": IpsOrgRepositoryImpl findTargetIdByBic");
        }
    }


}
