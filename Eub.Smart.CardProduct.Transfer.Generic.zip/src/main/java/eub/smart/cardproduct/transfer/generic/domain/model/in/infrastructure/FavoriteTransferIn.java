package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record FavoriteTransferIn(
        Long id,
        Long finDocId,
        Long userId,
        String type,
        String title
) {
}
