package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.AccountOut;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;

public class AccountMapper {

    public static AccountOut toDomain(ResultSet resultSet, int i) {
        try {
            AccountOut model = new AccountOut();
            model.setId(resultSet.getLong("accountId"));
            model.setType(resultSet.getString("accountType"));
            model.setNumber(resultSet.getString("number"));
            model.setCurrency(resultSet.getString("currency"));
            model.setFlagMultiCurrency(resultSet.getBoolean("multiCurrencyFlag"));
            model.setIdRef(resultSet.getLong("accountIdRef"));
            return model;
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }
}
