package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreatedTransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.TransferOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateTransferDataOut;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFinDocUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateTransferDataUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateTransferUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FinDocStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocTechStatus.DRFT;

@Service
public class CreateTransferDataUseCaseImpl implements CreateTransferDataUseCase {

    private final CreateFinDocUseCase createFinDocUseCase;
    private final CreateTransferUseCase createTransferUseCase;
    private final FinDocStatusRepository finDocStatusRepository;

    public CreateTransferDataUseCaseImpl(CreateFinDocUseCase createFinDocUseCase,
                                         CreateTransferUseCase createTransferUseCase,
                                         FinDocStatusRepository finDocStatusRepository) {
        this.createFinDocUseCase = createFinDocUseCase;
        this.createTransferUseCase = createTransferUseCase;
        this.finDocStatusRepository = finDocStatusRepository;
    }

    @Transactional
    @Override
    public CreateTransferDataIn invoke(CreateTransferDataOut out,
                                       CreateTransferClientDataIn senderAccount,
                                       CreateTransferClientDataIn receiverAccount) {
        var savedTransfer = saveTransfer(out, senderAccount, receiverAccount);
        var transfer = new CreatedTransferDataIn(savedTransfer);
        var finDocStatus = finDocStatusRepository.findByIdOrException(DRFT);
        return new CreateTransferDataIn(transfer, senderAccount, finDocStatus);
    }

    private TransferOut saveTransfer(CreateTransferDataOut out,
                                     CreateTransferClientDataIn senderAccount,
                                     CreateTransferClientDataIn receiverAccount) {
        var finDoc = createFinDocUseCase.invoke(
                out,
                senderAccount);
        return createTransferUseCase.invoke(
                finDoc,
                senderAccount,
                receiverAccount,
                out);
    }
}
