package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateFinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.AccountRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.CardRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FeeRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.IpsTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateAituTransferUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFinDocUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetAituPayVerificationUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetFeeAmountUseCase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import static eub.smart.cardproduct.transfer.generic.core.constant.BankBic.HALYK;

@Service
public class CreateAituTransferUseCaseImpl implements CreateAituTransferUseCase {

    private final CreateFinDocUseCase createFinDocUseCase;
    private final GetFeeAmountUseCase getFeeAmountUseCase;
    private final FeeRepository feeRepository;
    private final CardRepository cardRepository;

    public CreateAituTransferUseCaseImpl(CreateFinDocUseCase createFinDocUseCase,
                                         GetFeeAmountUseCase getFeeAmountUseCase,
                                         FeeRepository feeRepository,
                                         CardRepository cardRepository) {
        this.createFinDocUseCase = createFinDocUseCase;
        this.getFeeAmountUseCase = getFeeAmountUseCase;
        this.feeRepository = feeRepository;
        this.cardRepository = cardRepository;
    }

    @Override
    public FinDocOut invoke(CreateRetransferDataIn in) {
        var createFinDoc = getFinDocData(in);
        return createFinDocUseCase.invoke(createFinDoc);
    }

    private CreateFinDocOut getFinDocData(CreateRetransferDataIn in) {
        var amount = in.debitAmount();
        var fee = feeRepository.findFeeByAccountId(in.senderAccountId());
        var feeAmount = getFeeAmountUseCase.invoke(amount, fee);
        return new CreateFinDocOut(in, feeAmount);
    }
}
