package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.enums.FinDocStatusDisplay;
import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.LocalizedText;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.core.util.NameUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.AmountOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.DetailResponse;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.SUB_TITLE_SELF;
import static eub.smart.cardproduct.transfer.generic.core.enums.LangKey.EN;
import static eub.smart.cardproduct.transfer.generic.core.enums.ReceiptTypeDisplay.DEFT;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;
import static eub.smart.cardproduct.transfer.generic.core.util.ImageUtil.formImageUrl;
import static eub.smart.cardproduct.transfer.generic.core.util.StringUtil.last4;
import static java.util.Objects.isNull;

@Component
public class ReceiptTslfMapper {

    private final LocalizedText subTitleSelf;
    private final LocalizedText senderKey;
    private final LocalizedText fromKey;
    private final LocalizedText toTransfer;
    private final LocalizedText exchangeRate;

    public ReceiptTslfMapper(MessageSourceRepositoryImpl messageSourceRepository) {
        String subTitleSelfRu = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.RU);
        String subTitleSelfKk = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.KK);
        String subTitleSelfEn = messageSourceRepository.getMessage(SUB_TITLE_SELF, LangUtil.EN);
        String senderRu = messageSourceRepository.getMessage(RECEIPT_SENDER, LangUtil.RU);
        String senderKk = messageSourceRepository.getMessage(RECEIPT_SENDER, LangUtil.KK);
        String senderEn = messageSourceRepository.getMessage(RECEIPT_SENDER, LangUtil.EN);
        String fromRu = messageSourceRepository.getMessage(RECEIPT_FROM, LangUtil.RU);
        String fromKk = messageSourceRepository.getMessage(RECEIPT_FROM, LangUtil.KK);
        String fromEn = messageSourceRepository.getMessage(RECEIPT_FROM, LangUtil.EN);
        String toTransferRu = messageSourceRepository.getMessage(RECEIPT_TO_TRANSFER, LangUtil.RU);
        String toTransferKk = messageSourceRepository.getMessage(RECEIPT_TO_TRANSFER, LangUtil.KK);
        String toTransferEn = messageSourceRepository.getMessage(RECEIPT_TO_TRANSFER, LangUtil.EN);
        String exchangeRateRu = messageSourceRepository.getMessage(RECEIPT_EXCHANGE_RATE, LangUtil.RU);
        String exchangeRateKk = messageSourceRepository.getMessage(RECEIPT_EXCHANGE_RATE, LangUtil.KK);
        String exchangeRateEn = messageSourceRepository.getMessage(RECEIPT_EXCHANGE_RATE, LangUtil.EN);
        this.subTitleSelf = new LocalizedText(subTitleSelfRu, subTitleSelfKk, subTitleSelfEn);
        this.senderKey = new LocalizedText(senderRu, senderKk, senderEn);
        this.fromKey = new LocalizedText(fromRu, fromKk, fromEn);
        this.toTransfer = new LocalizedText(toTransferRu, toTransferKk, toTransferEn);
        this.exchangeRate = new LocalizedText(exchangeRateRu, exchangeRateKk, exchangeRateEn);
    }

    public TransferReceiptOut toDomain(ResultSet resultSet, String langKey) {
        try {
            return fillTransferReceiptOut(resultSet, langKey);
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }

    private TransferReceiptOut fillTransferReceiptOut(ResultSet resultSet, String strLangKey) throws SQLException {
        Long id = resultSet.getLong("id");
        String titleSuffix = resultSet.getString("titleSuffix");
        if (isNull(titleSuffix)) titleSuffix = "";
        String title = resultSet.getString("title") + titleSuffix;
        LangKey langKey = EnumUtil.valueOfOrDefault(LangKey.class, strLangKey, EN);
        String imageUid = resultSet.getString("imageUid");
        String imageUrl = formImageUrl(imageUid);
        String number = last4(resultSet.getString("number"));
        String accountType = resultSet.getString("accountType");
        String finDocType = resultSet.getString("finDocType");
        BigDecimal amount = resultSet.getBigDecimal("amount");
        String senderCurrency = resultSet.getString("currency");
        Date date = resultSet.getTimestamp("date");
        Long timestampDate = date.getTime();
        String status = resultSet.getString("status");
        String statusDisplay = EnumUtil.valueOfOrException(FinDocStatusDisplay.class, status).value();
        BigDecimal feeAmount = resultSet.getBigDecimal("feeAmount");
        String feeCurrency = resultSet.getString("feeCurrency");
        long tfId = resultSet.getLong("tfId");
        Boolean isSaved = tfId != 0;
        String subtitle = subTitleSelf.text(langKey);
        List<DetailResponse> detailResponses = fillDetails(resultSet, langKey);

        return new TransferReceiptOut(
                id,
                title,
                subtitle,
                imageUrl,
                number,
                accountType,
                finDocType,
                amount,
                senderCurrency,
                feeAmount,
                feeCurrency,
                timestampDate,
                isSaved,
                DEFT.value(),
                statusDisplay,
                detailResponses);
    }

    private List<DetailResponse> fillDetails(ResultSet resultSet, LangKey langKey) throws SQLException {
        String fromSuffix = resultSet.getString("fromSuffix");
        if (isNull(fromSuffix)) fromSuffix = "";
        String from = resultSet.getString("fromm") + fromSuffix;
        String senderFullName = NameUtil.getSenderDisplayName(resultSet.getString("senderFullName"));
        String senderCurrency = resultSet.getString("currency");
        String receiverCurrency = resultSet.getString("receiverCurrency");
        String currencyRates = resultSet.getString("currencyRates");
        BigDecimal receiverAmount = resultSet.getBigDecimal("receiverAmount");

        if (senderCurrency.equals(receiverCurrency) || isNull(receiverCurrency)) {
            return List.of(
                    new DetailResponse(senderKey.text(langKey), senderFullName),
                    new DetailResponse(fromKey.text(langKey), from));
        } else {
            BigDecimal stripedReceiverAmount = receiverAmount.stripTrailingZeros();
            String receiverAmountDisplay = new AmountOut(stripedReceiverAmount, receiverCurrency).display();
            return List.of(
                    new DetailResponse(senderKey.text(langKey), senderFullName),
                    new DetailResponse(fromKey.text(langKey), from),
                    new DetailResponse(toTransfer.text(langKey), receiverAmountDisplay),
                    new DetailResponse(exchangeRate.text(langKey), currencyRates));
        }
    }

}
