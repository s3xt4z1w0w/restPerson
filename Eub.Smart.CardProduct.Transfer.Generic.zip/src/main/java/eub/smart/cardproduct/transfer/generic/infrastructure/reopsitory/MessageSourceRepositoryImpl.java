package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory;

import eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class MessageSourceRepositoryImpl implements MessageSourceRepository {

    private final MessageSource messageSource;

    public MessageSourceRepositoryImpl(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    @Override
    public String getMessage(String bundleCode, Object[] args, Locale locale) {
        return messageSource.getMessage(bundleCode, args, locale);
    }

    @Override
    public String getMessage(String bundleCode, Locale locale) {
        return getMessage(bundleCode, null, locale);
    }

    @Override
    public String getMessage(String bundleCode) {
        return getMessage(bundleCode, null, LocaleUtil.getCurrentLocale());
    }
}
