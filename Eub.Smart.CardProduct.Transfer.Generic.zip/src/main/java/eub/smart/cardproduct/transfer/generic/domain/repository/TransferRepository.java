package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.TransferOut;

public interface TransferRepository {

    TransferOut save(TransferOut finDoc);

    TransferOut findByFinDocId(Long finDocId);

}
