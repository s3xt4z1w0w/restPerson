package eub.smart.cardproduct.transfer.generic.domain.use_case;

import java.util.Set;

public interface DeleteFavoriteTransferByFinDocIdUseCase {

    void invoke(Long id);

    Set<String> keySet();

}
