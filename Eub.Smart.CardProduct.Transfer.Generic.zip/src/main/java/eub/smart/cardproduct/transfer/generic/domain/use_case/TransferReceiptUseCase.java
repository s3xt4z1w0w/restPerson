package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;

public interface TransferReceiptUseCase {

    TransferReceiptOut invoke(Long finDocId);
}
