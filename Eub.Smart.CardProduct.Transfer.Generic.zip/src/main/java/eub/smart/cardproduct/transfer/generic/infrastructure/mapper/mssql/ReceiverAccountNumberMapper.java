package eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;

import java.sql.ResultSet;
import java.sql.SQLException;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_603;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_LG_802;
import static java.util.Objects.nonNull;

public class ReceiverAccountNumberMapper {

    public static String map(ResultSet rs, int i) {
        try {
            String transferAccNumber = rs.getString("transferAccNumber");
            String cardTransferAccNumber = rs.getString("cardTransferAccNumber");
            String ipsTransferAccNumber = rs.getString("ipsTransferAccNumber");

            if (nonNull(transferAccNumber)) return transferAccNumber;
            else if (nonNull(cardTransferAccNumber)) return cardTransferAccNumber;
            else if (nonNull(ipsTransferAccNumber)) return ipsTransferAccNumber;
            else throw new AppException(E_LG_802, ": receiver acc number not found");
        } catch (SQLException e) {
            throw new AppException(E_DB_603, e);
        }
    }
}
