package eub.smart.cardproduct.transfer.generic.infrastructure.entity;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CreateIpstCardTransferOut;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;

import static eub.smart.cardproduct.transfer.generic.domain.use_case.impl.FabricCreateRetransferUseCaseImpl.NON_REFUNDABLE_FINANCIAL_ASSISTANCE;

@Entity
@Table(name = "IPSTransfer")
public class IpsTransferEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "IpsTransfer_ID")
    private Long ipsTransferId;
    @Basic
    @Column(name = "FinDoc_IDREF")
    private Long finDocId;
    @Basic
    @Column(name = "TransferType")
    private String transferType;
    @Basic
    @Column(name = "Knp_IDREF")
    private String knpIdref;
    @Basic
    @Column(name = "BANK_ReceiverBic")
    private String bankReceiverBic;
    @Basic
    @Column(name = "USER_ReceiverPhone")
    private String userReceiverPhone;
    @Basic
    @Column(name = "Reference_OUTREF")
    private String referenceOutref;
    @Basic
    @Column(name = "TransferAmount")
    private BigDecimal transferAmount;
    @Basic
    @Column(name = "TransferAmountFee")
    private BigDecimal transferAmountFee;
    @Basic
    @Column(name = "USER_SenderName")
    private String userSenderName;
    @Basic
    @Column(name = "USER_SenderMobilePhone")
    private String userSenderMobilePhone;
    @Basic
    @Column(name = "IncomingTransferDate")
    private Date incomingTransferDate;
    @Basic
    @Column(name = "DateCreate")
    private Date dateCreate;
    @Basic
    @Column(name = "BANK_SenderBic")
    private String bankSenderBic;
    @Basic
    @Column(name = "USER_SenderIBAN")
    private String userSenderIban;
    @Basic
    @Column(name = "USER_SenderIIN")
    private String userSenderIin;
    @Basic
    @Column(name = "USER_Sender_SEco_IDREF")
    private String userSenderSEcoIdref;
    @Basic
    @Column(name = "MessageIDREF")
    private Integer messageIdref;
    @Basic
    @Column(name = "BANK_Sender_IsResident")
    private Boolean bankSenderIsResident;
    @Basic
    @Column(name = "BANK_Receiver_IsResident")
    private Boolean bankReceiverIsResident;
    @Basic
    @Column(name = "USER_ReceiverName")
    private String userReceiverName;
    @Basic
    @Column(name = "USER_Message")
    private String userMessage;
    @Basic
    @Column(name = "Receiver_IBAN")
    private String receiverIban;
    @Basic
    @Column(name = "Receiver_IIN")
    private String receiverIin;
    @Basic
    @Column(name = "RawQr")
    private String rawQr;
    @Basic
    @Column(name = "SenderCard_IDREF")
    private Long senderCardIdref;

    public IpsTransferEntity() {
    }

    public IpsTransferEntity(CreateIpstCardTransferOut createCardTransfer) {
        this.dateCreate = new Date();
        this.knpIdref = NON_REFUNDABLE_FINANCIAL_ASSISTANCE;
        this.bankSenderBic = "EURIKZKA";
        this.bankReceiverBic = "EURIKZKA";
        this.transferType = createCardTransfer.transferType();
        this.finDocId =  createCardTransfer.finDocId();
        this.userReceiverPhone =  createCardTransfer.userReceiverPhone();
        this.bankSenderIsResident =  createCardTransfer.bankSenderIsResident();
        this.bankReceiverIsResident =  createCardTransfer.bankReceiverIsResident();
        this.userReceiverName =  createCardTransfer.userReceiverName();
        this.userMessage =  createCardTransfer.userMessage();
        this.senderCardIdref =  createCardTransfer.senderCardIdref();
        this.receiverIban = createCardTransfer.receiverIban();
    }

    public Long getIpsTransferId() {
        return ipsTransferId;
    }

    public void setIpsTransferId(Long ipsTransferId) {
        this.ipsTransferId = ipsTransferId;
    }

    public Boolean getBankSenderIsResident() {
        return bankSenderIsResident;
    }

    public void setBankSenderIsResident(Boolean bankSenderIsResident) {
        this.bankSenderIsResident = bankSenderIsResident;
    }

    public Long getFinDocId() {
        return finDocId;
    }

    public void setFinDocId(Long finDocIdref) {
        this.finDocId = finDocIdref;
    }

    public String getTransferType() {
        return transferType;
    }

    public void setTransferType(String transferType) {
        this.transferType = transferType;
    }

    public String getKnpIdref() {
        return knpIdref;
    }

    public void setKnpIdref(String knpIdref) {
        this.knpIdref = knpIdref;
    }

    public String getBankReceiverBic() {
        return bankReceiverBic;
    }

    public void setBankReceiverBic(String bankReceiverBic) {
        this.bankReceiverBic = bankReceiverBic;
    }

    public String getUserReceiverPhone() {
        return userReceiverPhone;
    }

    public void setUserReceiverPhone(String userReceiverPhone) {
        this.userReceiverPhone = userReceiverPhone;
    }

    public String getReferenceOutref() {
        return referenceOutref;
    }

    public void setReferenceOutref(String referenceOutref) {
        this.referenceOutref = referenceOutref;
    }

    public BigDecimal getTransferAmount() {
        return transferAmount;
    }

    public void setTransferAmount(BigDecimal transferAmount) {
        this.transferAmount = transferAmount;
    }

    public BigDecimal getTransferAmountFee() {
        return transferAmountFee;
    }

    public void setTransferAmountFee(BigDecimal transferAmountFee) {
        this.transferAmountFee = transferAmountFee;
    }

    public String getUserSenderName() {
        return userSenderName;
    }

    public void setUserSenderName(String userSenderName) {
        this.userSenderName = userSenderName;
    }

    public String getUserSenderMobilePhone() {
        return userSenderMobilePhone;
    }

    public void setUserSenderMobilePhone(String userSenderMobilePhone) {
        this.userSenderMobilePhone = userSenderMobilePhone;
    }

    public Date getIncomingTransferDate() {
        return incomingTransferDate;
    }

    public void setIncomingTransferDate(Date incomingTransferDate) {
        this.incomingTransferDate = incomingTransferDate;
    }

    public Date getDateCreate() {
        return dateCreate;
    }

    public void setDateCreate(Date dateCreate) {
        this.dateCreate = dateCreate;
    }

    public String getBankSenderBic() {
        return bankSenderBic;
    }

    public void setBankSenderBic(String bankSenderBic) {
        this.bankSenderBic = bankSenderBic;
    }

    public String getUserSenderIban() {
        return userSenderIban;
    }

    public void setUserSenderIban(String userSenderIban) {
        this.userSenderIban = userSenderIban;
    }

    public String getUserSenderIin() {
        return userSenderIin;
    }

    public void setUserSenderIin(String userSenderIin) {
        this.userSenderIin = userSenderIin;
    }

    public String getUserSenderSEcoIdref() {
        return userSenderSEcoIdref;
    }

    public void setUserSenderSEcoIdref(String userSenderSEcoIdref) {
        this.userSenderSEcoIdref = userSenderSEcoIdref;
    }

    public Integer getMessageIdref() {
        return messageIdref;
    }

    public void setMessageIdref(Integer messageIdref) {
        this.messageIdref = messageIdref;
    }

    public boolean isBankSenderIsResident() {
        return bankSenderIsResident;
    }

    public void setBankSenderIsResident(boolean bankSenderIsResident) {
        this.bankSenderIsResident = bankSenderIsResident;
    }

    public Boolean getBankReceiverIsResident() {
        return bankReceiverIsResident;
    }

    public void setBankReceiverIsResident(Boolean bankReceiverIsResident) {
        this.bankReceiverIsResident = bankReceiverIsResident;
    }

    public String getUserReceiverName() {
        return userReceiverName;
    }

    public void setUserReceiverName(String userReceiverName) {
        this.userReceiverName = userReceiverName;
    }

    public String getUserMessage() {
        return userMessage;
    }

    public void setUserMessage(String userMessage) {
        this.userMessage = userMessage;
    }

    public String getReceiverIban() {
        return receiverIban;
    }

    public void setReceiverIban(String receiverIban) {
        this.receiverIban = receiverIban;
    }

    public String getReceiverIin() {
        return receiverIin;
    }

    public void setReceiverIin(String receiverIin) {
        this.receiverIin = receiverIin;
    }

    public String getRawQr() {
        return rawQr;
    }

    public void setRawQr(String rawQr) {
        this.rawQr = rawQr;
    }

    public Long getSenderCardIdref() {
        return senderCardIdref;
    }

    public void setSenderCardIdref(Long senderCardIdref) {
        this.senderCardIdref = senderCardIdref;
    }

    @Override
    public String toString() {
        return "IpsTransferEntity{" +
                "ipsTransferId=" + ipsTransferId +
                ", finDocIdref=" + finDocId +
                ", transferType='" + transferType +
                ", knpIdref='" + knpIdref +
                ", bankReceiverBic='" + bankReceiverBic +
                ", userReceiverPhone='" + userReceiverPhone +
                ", referenceOutref='" + referenceOutref +
                ", transferAmount=" + transferAmount +
                ", transferAmountFee=" + transferAmountFee +
                ", userSenderName='" + userSenderName +
                ", userSenderMobilePhone='" + userSenderMobilePhone +
                ", incomingTransferDate=" + incomingTransferDate +
                ", dateCreate=" + dateCreate +
                ", bankSenderBic='" + bankSenderBic +
                ", userSenderIban='" + userSenderIban +
                ", userSenderIin='" + userSenderIin +
                ", userSenderSEcoIdref='" + userSenderSEcoIdref +
                ", messageIdref=" + messageIdref +
                ", bankSenderIsResident=" + bankSenderIsResident +
                ", bankReceiverIsResident=" + bankReceiverIsResident +
                ", userReceiverName='" + userReceiverName +
                ", userMessage='" + userMessage +
                ", receiverIban='" + receiverIban +
                ", receiverIin='" + receiverIin +
                ", rawQr='" + rawQr +
                ", senderCardIdref=" + senderCardIdref +
                '}';
    }
}
