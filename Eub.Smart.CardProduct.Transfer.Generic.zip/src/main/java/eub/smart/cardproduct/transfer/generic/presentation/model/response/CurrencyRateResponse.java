package eub.smart.cardproduct.transfer.generic.presentation.model.response;

public record CurrencyRateResponse(
        String title,
        String imageUrl,
        AmountResponse saleAmount,
        AmountResponse buyAmount

) {
}
