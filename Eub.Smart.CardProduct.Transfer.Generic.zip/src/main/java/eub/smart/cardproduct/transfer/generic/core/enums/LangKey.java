package eub.smart.cardproduct.transfer.generic.core.enums;

public enum LangKey {
    RU,
    KK,
    EN
}
