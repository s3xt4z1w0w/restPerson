package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public interface CreateRetransferSelfIn {

    Long getSenderAccountId();
    Long getReceiverAccountId();
    Long getSenderCardId();
    Long getReceiverCardId();
    String getSenderCurrency();
    String getReceiverCurrency();
}
