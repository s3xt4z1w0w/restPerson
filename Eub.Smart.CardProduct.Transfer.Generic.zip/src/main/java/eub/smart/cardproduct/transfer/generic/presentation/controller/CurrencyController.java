package eub.smart.cardproduct.transfer.generic.presentation.controller;

import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CorrectAmountUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CurrencyExchangeRateUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CurrencyRatesUseCase;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.CorrectAmountResponse;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.CurrencyExchangeResponse;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.CurrencyRatesResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static org.springframework.http.HttpStatus.OK;

@Tag(name = "CurrencyController", description = "API для валют и конвертаций")
@SecurityRequirement(name = "Bearer Authentication")
@RestController
@RequestMapping("/transfer-generic/api/currency")
public class CurrencyController {

    private final CurrencyRatesUseCase currencyRatesUseCase;
    private final CurrencyExchangeRateUseCase currencyExchangeRateUseCase;
    private final CorrectAmountUseCase correctAmountUseCase;

    public CurrencyController(CurrencyRatesUseCase currencyRatesUseCase,
                              CurrencyExchangeRateUseCase currencyExchangeRateUseCase,
                              CorrectAmountUseCase correctAmountUseCase) {
        this.currencyRatesUseCase = currencyRatesUseCase;
        this.currencyExchangeRateUseCase = currencyExchangeRateUseCase;
        this.correctAmountUseCase = correctAmountUseCase;
    }

    @Operation(description = "Получение списка с курсами валют", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = CurrencyRatesResponse.class))})})
    @GetMapping("/rates")
    public ResponseEntity<?> rates(@RequestHeader(CORRELATION_ID) String correlationId,
                                   @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang) {
        var response = currencyRatesUseCase.invoke();
        return new ResponseEntity<>(response, OK);
    }

    @Operation(description = "Получение курса валют для обмена", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = CurrencyExchangeResponse.class))})})
    @GetMapping("/exchange/rate")
    public ResponseEntity<?> exchangeRate(@RequestHeader(CORRELATION_ID) String correlationId,
                                          @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                          @RequestParam("from") String from,
                                          @RequestParam("to") String to) {
        var response = currencyExchangeRateUseCase.invoke(from, to);
        return new ResponseEntity<>(response, OK);
    }

    @Operation(description = "Получение правильной суммы перевода", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = CorrectAmountResponse.class))})})
    @GetMapping("/correct-amount")
    public ResponseEntity<?> correctAmount(@RequestHeader(CORRELATION_ID) String correlationId,
                                           @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                           @RequestParam("amount") BigDecimal amount,
                                           @RequestParam("from") String from,
                                           @RequestParam("to") String to) {
        var response = correctAmountUseCase.invoke(amount, from, to);
        return new ResponseEntity<>(response, OK);
    }
}
