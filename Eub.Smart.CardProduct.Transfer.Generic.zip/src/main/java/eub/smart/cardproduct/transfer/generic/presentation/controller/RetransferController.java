package eub.smart.cardproduct.transfer.generic.presentation.controller;

import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import eub.smart.cardproduct.transfer.generic.domain.use_case.FabricCreateRetransferUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetRetransferAccountsUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetRetransferSelfAccountsUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.InitialValidationUseCase;
import eub.smart.cardproduct.transfer.generic.presentation.mapper.PresentationMapper;
import eub.smart.cardproduct.transfer.generic.presentation.model.request.CreateRepeatTransferRequest;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.RetransferValidateResponse;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.RetransferAccountsResponse;
import eub.smart.cardproduct.transfer.generic.presentation.model.response.RetransferSelfAccountsResponse;
import eub.smart.cardproduct.transfer.generic.presentation.response_advise.ResponseBinding;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.CORRELATION_ID;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

@Tag(name = "RetransferController", description = "API для повторных переводов")
@ResponseBinding
@RestController
@SecurityRequirement(name = "Bearer Authentication")
@RequestMapping("/transfer-generic/api/retransfer")
public class RetransferController {

    private final PresentationMapper mapper;
    private final GetRetransferAccountsUseCase getRetransferAccountsUseCase;
    private final GetRetransferSelfAccountsUseCase getRetransferSelfAccountsUseCase;
    private final FabricCreateRetransferUseCase fabricCreateRetransferUseCase;
    private final InitialValidationUseCase initialValidationUseCase;

    public RetransferController(PresentationMapper mapper,
                                GetRetransferAccountsUseCase getRetransferAccountsUseCase,
                                GetRetransferSelfAccountsUseCase getRetransferSelfAccountsUseCase,
                                FabricCreateRetransferUseCase fabricCreateRetransferUseCase,
                                InitialValidationUseCase initialValidationUseCase) {
        this.mapper = mapper;
        this.getRetransferAccountsUseCase = getRetransferAccountsUseCase;
        this.getRetransferSelfAccountsUseCase = getRetransferSelfAccountsUseCase;
        this.fabricCreateRetransferUseCase = fabricCreateRetransferUseCase;
        this.initialValidationUseCase = initialValidationUseCase;
    }

    @Operation(description = "Получение данных о карте и счету двух сторон для переводов между своими", responses = {
            @ApiResponse(content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = RetransferSelfAccountsResponse.class))})})
    @GetMapping("/self/accounts/{finDocId}")
    public ResponseEntity<?> getSelfAccounts(@RequestHeader(CORRELATION_ID) String correlationId,
                                             @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                             @PathVariable Long finDocId) {
        var out = getRetransferSelfAccountsUseCase.invoke(finDocId);
        return new ResponseEntity<>(out, OK);
    }

    @Operation(description = "Получение данных о карте и счету двух сторон", responses = {
            @ApiResponse(content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = RetransferAccountsResponse.class))})})
    @GetMapping("/accounts/{finDocId}")
    public ResponseEntity<?> getAccounts(@RequestHeader(CORRELATION_ID) String correlationId,
                                         @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                         @PathVariable Long finDocId) {
        var out = getRetransferAccountsUseCase.invoke(finDocId);
        return new ResponseEntity<>(out, OK);
    }

    @Operation(description = "Создание повторного перевода", responses = {
            @ApiResponse(content = {
                    @Content(schema = @Schema(implementation = RetransferValidateResponse.class))})})
    @PostMapping("/validate")
    public ResponseEntity<?> createRepeatTransfer(@RequestHeader(CORRELATION_ID) String correlationId,
                                                  @RequestHeader(value = LANG_KEY, defaultValue = "EN") LangKey lang,
                                                  @Valid @RequestBody CreateRepeatTransferRequest request) {
        var in = mapper.toDomain(request);
        var retransfer = fabricCreateRetransferUseCase.invoke(in);
        initialValidationUseCase.invoke(retransfer.id());
        return new ResponseEntity<>(retransfer, CREATED);
    }
}
