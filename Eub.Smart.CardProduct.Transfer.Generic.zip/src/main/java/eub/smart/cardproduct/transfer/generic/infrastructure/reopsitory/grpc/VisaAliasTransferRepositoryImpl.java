package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.grpc;


import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.exception.Error;
import eub.smart.cardproduct.transfer.generic.core.exception.FieldsValidationResponse;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FeeOutgoingIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.VisaTokenIIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.VisaAliasTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import io.grpc.StatusRuntimeException;
import kz.eubank.grpc.EubAggregatorCardProductTransferVisaAlias;
import kz.eubank.grpc.VisaAliasGrpc;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.ERROR_TECHNICAL_SUBTITLE;
import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.ERROR_TECHNICAL_TITLE;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_EX_701;
import static eub.smart.cardproduct.transfer.generic.core.util.GrpcUtil.toDecimalValue;
import static eub.smart.cardproduct.transfer.generic.core.util.LocaleUtil.getCurrentLocale;

@Repository
public class VisaAliasTransferRepositoryImpl implements VisaAliasTransferRepository {
    @GrpcClient("aggregator-transfer-visa-alias")
    private VisaAliasGrpc.VisaAliasBlockingStub stub;
    private final MessageSourceRepository messageSourceRepository;
    private final InfrastructureMapper mapper;

    public VisaAliasTransferRepositoryImpl(MessageSourceRepository messageSourceRepository,
                                           InfrastructureMapper mapper) {
        this.messageSourceRepository = messageSourceRepository;
        this.mapper = mapper;
    }

    @Override
    public FeeOutgoingIIn getFee(Long cardOutRef, BigDecimal amount) {
        try {
            var request = EubAggregatorCardProductTransferVisaAlias.GetFeeRequest
                    .newBuilder()
                    .setCardId(cardOutRef)
                    .setTransactionAmount(toDecimalValue(amount))
                    .build();
            var response = stub.getFee(request);
            return mapper.toDomain(response);
        } catch (StatusRuntimeException e) {
            var error = new Error(messageSourceRepository.getMessage(ERROR_TECHNICAL_TITLE, getCurrentLocale()),
                    messageSourceRepository.getMessage(ERROR_TECHNICAL_SUBTITLE, getCurrentLocale()));
            throw new AppException(E_EX_701, new FieldsValidationResponse(error, null));
        }
    }

    @Override
    public VisaTokenIIn getResolveToken(String phoneNumber) {
        try {
            var request = EubAggregatorCardProductTransferVisaAlias.ResolveTokenRequest
                    .newBuilder()
                    .setPhoneNumber(phoneNumber)
                    .build();
            var response = stub.resolveToken(request);
            return mapper.toDomain(response);
        } catch (StatusRuntimeException e) {
            var error = new Error(messageSourceRepository.getMessage(ERROR_TECHNICAL_TITLE, getCurrentLocale()),
                    messageSourceRepository.getMessage(ERROR_TECHNICAL_SUBTITLE, getCurrentLocale()));
            throw new AppException(E_EX_701, new FieldsValidationResponse(error, null));
        }
    }
}
