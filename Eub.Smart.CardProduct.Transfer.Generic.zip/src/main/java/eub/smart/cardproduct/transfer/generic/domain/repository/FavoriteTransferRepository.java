package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteTransferDataIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface FavoriteTransferRepository {

    Page<FavoriteTransferDisplayIn> getAll(Pageable pageable);

    void delete(Long id);

    void rename(Long id, String name);

    void fullDelete(Long id);

    CreateFavoriteTransferDataIIn getRetransferData(Long id);
}
