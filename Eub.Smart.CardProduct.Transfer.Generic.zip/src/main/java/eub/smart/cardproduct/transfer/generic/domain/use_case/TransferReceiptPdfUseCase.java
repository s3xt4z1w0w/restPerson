package eub.smart.cardproduct.transfer.generic.domain.use_case;

public interface TransferReceiptPdfUseCase {
    byte[] invoke(Long finDocId);
}
