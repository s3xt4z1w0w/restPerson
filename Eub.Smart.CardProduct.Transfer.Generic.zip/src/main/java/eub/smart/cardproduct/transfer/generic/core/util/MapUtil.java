package eub.smart.cardproduct.transfer.generic.core.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.LinkedHashMap;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_SM_501;

public class MapUtil {

    private static final Logger log = LogManager.getLogger(JsonUtil.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static Optional<LinkedHashMap> toMap(Object object) {
        try {
            var result = objectMapper.convertValue(object, LinkedHashMap.class);
            return Optional.of(result);
        } catch (Exception e) {
            log.error("ObjectMapper convertValue to Map error: {}", e.getMessage());
            return Optional.empty();
        }
    }

    public static LinkedHashMap toMapOrException(Object object, String clazz) {
        return toMap(object)
                .orElseThrow(() -> new AppException(E_SM_501, ": " + clazz));
    }
}
