package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteSelfTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteSelfTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.FavoriteSelfTransferMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I92A;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Primary
@Repository
public class FavoriteSelfTransferRepositoryImpl implements FavoriteSelfTransferRepository {

    private final Logger log = LogManager.getLogger(getClass());
    private final FavoriteSelfTransferMapper favoriteSelfTransferMapper;
    private final String s3Url;
    private final NamedParameterJdbcTemplate template;
    private final AuthToken authToken;

    public FavoriteSelfTransferRepositoryImpl(FavoriteSelfTransferMapper favoriteSelfTransferMapper,
                                              @Value("${app.s3-download-address}") String s3Url,
                                              NamedParameterJdbcTemplate template,
                                              AuthToken authToken) {
        this.favoriteSelfTransferMapper = favoriteSelfTransferMapper;
        this.s3Url = s3Url;
        this.template = template;
        this.authToken = authToken;
    }

    @Override
    public Optional<CreateFavoriteSelfTransferIn> findByFinDocId(Long id) {
        Long userId = UserDetails.build(authToken.getDecodedPayload()).getUserId();
        Map<String, Object> map = Map.of(
                "id", id,
                "userId", userId);

        String sql = """
                select fd.FinDoc_ID         as finDocId,
                       fd.User_IDREF        as userId,
                       t.Receiver_Account   as accountNumber,
                       t.Receiver_Currency  as currency,
                       case --imageTable
                           when ct.CardType_ID is not null then
                               'CardType'
                           else 'AccountType'
                           end              as imageTable,
                       case --imageId
                           when ct.CardType_ID is not null then
                               ct.Target_ID
                           when at.Target_ID is not null then
                               at.Target_ID
                           else 0
                           end              as imageId
                from Transfer t
                         join FinDoc fd with (nolock) on t.FinDoc_IDREF = fd.FinDoc_ID
                         left join Account ra with (nolock) on t.Receiver_Account = ra.Number
                         left join AccountType at with (nolock) on ra.AccountType_IDREF = at.AccountType_ID
                         left join Card c with (nolock) on t.ReceiverCard_IDREF = c.Card_ID
                         left join CardType ct with (nolock) on c.CardType_IDREF = ct.CardType_ID
                where fd.FinDoc_ID = :id
                and fd.User_IDREF = :userId
                """;

        List<CreateFavoriteSelfTransferIn> queryResult = template.query(sql, map, favoriteSelfTransferMapper::toInDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else {
            throw new AppException(E_DB_601, ": FavoriteAccTransferRepository findByFinDocId");
        }
    }

    @Override
    public CreateFavoriteSelfTransferIn findByFinDocIdOrException(Long id) {
        return findByFinDocId(id)
                .orElseThrow(() -> new AppException(E_DB_600, ": FavoriteAccTransferRepository findByFinDocIdOrException"));
    }


    @Override
    public FavoriteTransferDisplayOut fillDetailsDisplay(FavoriteTransferDisplayIn in) {
        var langKey = MDC.get(LANG_KEY);

        String sql = """
                select case
                           when t.ReceiverCard_IDREF is not null then
                               ct.CardType_Title
                           when 'RU' = :langKey then
                               trm_sacc_psn.Term_RU
                           when 'KK' = :langKey then
                               trm_sacc_psn.Term_KZ
                           else trm_sacc_psn.Term_EN end as title,
                       c.MaskedNumber                    as number,
                       md.FileUid                        as imageUid,
                       taf.Currency                      as currency,
                       at.AccountType_ID                 as accountType,
                       ra.Account_ID                     as accountId
                from TransferFavorite tf
                         join Transfer t on t.FinDoc_IDREF = tf.FinDoc_IDREF
                         left join TransferAccFavorite taf with (nolock) on tf.TransferFavorite_ID = taf.TransferFavorite_IDREF
                         left join Account ra with (nolock) on taf.AccountNumber = ra.Number
                         left join AccountType at with (nolock) on ra.AccountType_IDREF = at.AccountType_ID
                         left join AccountProduct ra_ap with (nolock)
                                   on ra_ap.Product_IDREF = ra.Product_IDREF and
                                      ra_ap.ProductCompound_OUTREF = ra.ProductCompound_OUTREF
                         left join DepositProduct ra_dp with (nolock)
                                   on ra_dp.Product_IDREF = ra.Product_IDREF and
                                      ra_dp.ProductCompound_OUTREF = ra.ProductCompound_OUTREF
                         left join CardAccountProduct ra_cap with (nolock)
                                   on ra_cap.Product_IDREF = ra.Product_IDREF and
                                      ra_cap.ProductCompound_OUTREF = ra.ProductCompound_OUTREF
                         left join ProductShortName sacc_psn with (nolock)
                                   on ra_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                      ra_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                      ra_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                         left join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF
                         left join Card c with (nolock) on t.ReceiverCard_IDREF = c.Card_ID
                         left join CardType ct with (nolock) on c.CardType_IDREF = ct.CardType_ID
                         left join MetaDocument md with (nolock)
                                   on md.Target_ID = taf.ImageId
                                       and md.Target_Table = taf.ImageTable
                                       and md.DocumentType_IDREF = :metaDocType
                                       and md.LangKey = 'RU'
                                       and md.IsActive = 1
                                       and md.Screen = 'mybank'
                where taf.TransferFavorite_IDREF = :id
                """;

        List<FavoriteTransferDisplayOut> queryResult = template.query(sql,
                Map.of("id", in.getId(), "langKey", langKey, "metaDocType", I92A),
                (resultSet, i) -> favoriteSelfTransferMapper.toDetailsDisplay(resultSet, in, s3Url, langKey));
        return queryResult
                .stream()
                .findFirst()
                .orElseThrow(() -> new AppException(E_DB_601, ": FavoriteSelfTransferRepository fillDetailsDisplay"));
    }
}
