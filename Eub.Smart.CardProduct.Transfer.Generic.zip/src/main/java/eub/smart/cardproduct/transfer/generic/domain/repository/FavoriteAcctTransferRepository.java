package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteAccTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteAccTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;

import java.util.Optional;

public interface FavoriteAcctTransferRepository {

    FavoriteAccTransferIn save(FavoriteAccTransferOut out);

    Optional<FavoriteAccTransferOut> findByFinDocId(Long sourceId);

    CreateFavoriteAccTransferIn getCreateFavoriteAcctDataOrException(Long sourceId);

    void delete(FavoriteAccTransferOut out);

    FavoriteTransferDisplayOut fillDetailsDisplay(FavoriteTransferDisplayIn in);

    boolean isExist(Long userId, String accountNumber);
}
