package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import io.swagger.v3.oas.annotations.media.Schema;

public record AccountSourceResponse(
        @Schema(description = "Id счета")
        Long accountId,
        @Schema(description = "Id карты")
        Long cardId,
        @Schema(description = "Данные заголовка")
        String title,
        @Schema(description = "Изображение")
        String image,
        @Schema(description = "Номер карты для продукта евраза")
        String number,
        @Schema(description = "Тип аккаунта")
        String accountType,
        @Schema(description = "Статус по продукту")
        ProductStatusResponse status,
        @Schema(description = "Сумма на счету")
        AmountResponse amount,
        @Schema(description = "Флаг возможности списания")
        Boolean allowSource,
        @Schema(description = "Флаг возможности зачисления")
        Boolean allowTarget
) {
}
