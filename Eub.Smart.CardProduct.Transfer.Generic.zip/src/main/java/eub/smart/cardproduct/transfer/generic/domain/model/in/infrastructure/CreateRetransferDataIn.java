package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.CreateFavoriteTransferDataPIn;

import java.math.BigDecimal;

public record CreateRetransferDataIn(
        Long senderCardId,
        Long senderAccountId,
        Long finDocId,
        BigDecimal debitAmount,
        BigDecimal creditAmount,
        String finDocType,
        String senderCurrency,
        String receiverCurrency
) {
    public CreateRetransferDataIn(CreateFavoriteTransferDataPIn createDataPIn, CreateFavoriteTransferDataIIn createDataIIn, String finDocType) {
        this(createDataPIn.senderCardId(),
                createDataPIn.senderAccountId(),
                createDataIIn.finDocId(),
                createDataPIn.debitAmount(),
                createDataPIn.creditAmount(),
                finDocType,
                createDataIIn.senderCurrency(),
                createDataIIn.receiverCurrency()
        );
    }
}
