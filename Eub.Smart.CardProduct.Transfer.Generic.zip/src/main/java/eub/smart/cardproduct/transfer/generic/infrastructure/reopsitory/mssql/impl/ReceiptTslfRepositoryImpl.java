package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.ReceiptRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.ReceiptTslfMapper;
import org.slf4j.MDC;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.I92A;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.SLFF;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.SLFR;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.SLFT;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class ReceiptTslfRepositoryImpl implements ReceiptRepository {

    private final NamedParameterJdbcTemplate template;
    private final ReceiptTslfMapper receiptTslfMapper;
    private final AuthToken authToken;

    public ReceiptTslfRepositoryImpl(NamedParameterJdbcTemplate template,
                                     ReceiptTslfMapper receiptTslfMapper,
                                     AuthToken authToken) {
        this.template = template;
        this.receiptTslfMapper = receiptTslfMapper;
        this.authToken = authToken;
    }

    @Override
    public Optional<TransferReceiptOut> findByFinDocId(Long finDocId) {
        var langKey = MDC.get(LANG_KEY);
        var userDetails = UserDetails.build(authToken.getDecodedPayload());
        var userId = userDetails.getUserId();

        Map<String, Object> map = Map.of(
                "finDocId", finDocId,
                "metaDocType", I92A,
                "langKey", langKey,
                "userId", userId);

        String sql = """
                select fd.FinDoc_ID                                                as id,
                       case --find from by sender account product short name
                           when sacc_psn.ProductShortName_ID = 'DFCD' and t.SenderCard_IDREF is not null then --Карточный счет
                               sct.CardType_Title
                           else
                               case
                                   when :langKey = 'KK' then trm_sacc_psn.Term_KZ
                                   when :langKey = 'RU' then trm_sacc_psn.Term_RU
                                   else trm_sacc_psn.Term_EN
                                   end
                           end                                                     as fromm,
                       case --find fromSuffix by sender account product short name
                           when sacc_psn.ProductShortName_ID = 'DFCD' and t.SenderCard_IDREF is not null then --Карточный счет
                               (N' • ' + right(sc.MaskedNumber, 4))
                           else
                               (N' • ' + left(sacc.Number, 2) + right(sacc.Number, 4))
                           end                                                     as fromSuffix,
                       case --find title by receiver account product short name
                           when racc_psn.ProductShortName_ID = 'DFCD' and t.ReceiverCard_IDREF is not null then --Карточный счет
                               rct.CardType_Title
                           else
                               case
                                   when :langKey = 'KK' then trm_racc_psn.Term_KZ
                                   when :langKey = 'RU' then trm_racc_psn.Term_RU
                                   else trm_racc_psn.Term_EN
                                   end
                           end                                                     as title,
                       case --find titleSuffix by receiver account product short name
                           when racc_psn.ProductShortName_ID = 'DFCD' and t.ReceiverCard_IDREF is not null then --Карточный счет
                               (N' • ' + right(rc.MaskedNumber, 4))
                           else
                               (N' • ' + left(racc.Number, 2) + right(racc.Number, 4))
                           end                                                     as titleSuffix,
                       case --imageUid
                           when rct.CardType_ID is not null then
                               case
                                   when md_ct.FileUid is not null then
                                       md_ct.FileUid
                                   else
                                       (select mdi.FileUid
                                        from MetaDocument mdi with (nolock)
                                        where mdi.Target_ID = 0
                                          and mdi.Target_Table = 'CardType'
                                          and mdi.DocumentType_IDREF = :metaDocType
                                          and mdi.LangKey = 'RU'
                                          and mdi.IsActive = 1
                                          and mdi.Screen = 'mybank')
                                   end
                           when md_at.FileUid is not null then
                               md_at.FileUid
                           else
                               (select mdi.FileUid
                                from MetaDocument mdi with (nolock)
                                where mdi.Target_ID = 0
                                  and mdi.Target_Table = 'AccountType'
                                  and mdi.DocumentType_IDREF = :metaDocType
                                  and mdi.LangKey = 'RU'
                                  and mdi.IsActive = 1
                                  and mdi.Screen = 'mybank')
                           end                                                     as imageUid,
                       rc.MaskedNumber                                             as number,
                       fd.Amount                                                   as amount,
                       fd.Currency                                                 as currency,
                       fd.DateCreated                                              as date,
                       dts.FinDocStatus_IDREF                                      as status,
                       fd.Fee                                                      as feeAmount,
                       fd.FeeCurrency                                              as feeCurrency,
                       concat(sp.LastName, ' ', sp.FirstName, ' ', sp.FathersName) as senderFullName,
                       racct.AccountType_ID                                        as accountType,
                       tf.TransferFavorite_ID                                      as tfId,
                       fd.FinDocType_IDREF                                         as finDocType,
                       t.CurrencyRates                                             as currencyRates,
                       t.Receiver_Currency                                         as receiverCurrency,
                       t.Receiver_Amount                                           as receiverAmount
                from FinDoc fd with (nolock)
                         join FinDocState fds with (nolock) on fd.FinDoc_ID = fds.FinDoc_IDREF
                         join DocTechStatus dts with (nolock) on dts.DocTechStatus_ID = fds.DocTechStatus_IDREF
                         join Transfer t with (nolock) on fd.FinDoc_ID = t.FinDoc_IDREF
                         join FinDocType fdt with (nolock) on fdt.FinDocType_ID = fd.FinDocType_IDREF
                         left join Card sc with (nolock) on t.SenderCard_IDREF = sc.Card_ID --sender data start
                         join dbo.[User] su with (nolock) on fd.User_IDREF = su.User_ID
                         join Person sp with (nolock) on su.Person_IDREF = sp.Person_ID
                         left join CardType sct with (nolock) on sct.CardType_ID = sc.CardType_IDREF
                         join Account sacc with (nolock) on fd.Account_IDREF = sacc.Account_ID
                         left join AccountProduct sacc_ap with (nolock)
                                   on sacc_ap.Product_IDREF = sacc.Product_IDREF and
                                      sacc_ap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join DepositProduct sacc_dp with (nolock)
                                   on sacc_dp.Product_IDREF = sacc.Product_IDREF and
                                      sacc_dp.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join CardAccountProduct sacc_cap with (nolock)
                                   on sacc_cap.Product_IDREF = sacc.Product_IDREF and
                                      sacc_cap.ProductCompound_OUTREF = sacc.ProductCompound_OUTREF
                         left join ProductShortName sacc_psn with (nolock)
                                   on sacc_ap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                      sacc_dp.ProductShortName_IDREF = sacc_psn.ProductShortName_ID or
                                      sacc_cap.ProductShortName_IDREF = sacc_psn.ProductShortName_ID
                         left join Term trm_sacc_psn with (nolock) on trm_sacc_psn.Term_ID = sacc_psn.Term_OUTREF --sender data end
                         left join Card rc with (nolock) on t.ReceiverCard_IDREF = rc.Card_ID --receiver data start
                         left join CardType rct with (nolock) on rct.CardType_ID = rc.CardType_IDREF
                         join Account racc with (nolock) on t.Receiver_Account = racc.Number
                         join AccountType racct with (nolock) on racc.AccountType_IDREF = racct.AccountType_ID
                         left join AccountProduct racc_ap with (nolock)
                                   on racc_ap.Product_IDREF = racc.Product_IDREF and
                                      racc_ap.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                         left join DepositProduct racc_dp with (nolock)
                                   on racc_dp.Product_IDREF = racc.Product_IDREF and
                                      racc_dp.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                         left join CardAccountProduct racc_cap with (nolock)
                                   on racc_cap.Product_IDREF = racc.Product_IDREF and
                                      racc_cap.ProductCompound_OUTREF = racc.ProductCompound_OUTREF
                         left join ProductShortName racc_psn with (nolock)
                                   on racc_ap.ProductShortName_IDREF = racc_psn.ProductShortName_ID or
                                      racc_dp.ProductShortName_IDREF = racc_psn.ProductShortName_ID or
                                      racc_cap.ProductShortName_IDREF = racc_psn.ProductShortName_ID
                         left join Term trm_racc_psn with (nolock) on trm_racc_psn.Term_ID = racc_psn.Term_OUTREF --receiver data end
                         left join TransferFavorite tf on tf.TransferFavorite_ID = (select top 1 tf.TransferFavorite_ID
                                                                                             from TransferFavorite tf
                                                                                                      join TransferAccFavorite taf with (nolock)
                                                                                                           on taf.TransferFavorite_IDREF = tf.TransferFavorite_ID
                                                                                             where tf.User_IDREF = fd.User_IDREF
                                                                                               and taf.AccountNumber = t.Receiver_Account)
                         left join MetaDocument md_ct with (nolock)
                                   on md_ct.Target_ID = rct.Target_ID
                                       and md_ct.Target_Table = 'CardType'
                                       and md_ct.DocumentType_IDREF = :metaDocType
                                       and md_ct.LangKey = 'RU'
                                       and md_ct.IsActive = 1
                                       and md_ct.Screen = 'mybank'
                         left join MetaDocument md_at with (nolock)
                                   on md_at.Target_ID = racct.Target_ID
                                       and md_at.Target_Table = 'AccountType'
                                       and md_at.DocumentType_IDREF = :metaDocType
                                       and md_at.LangKey = 'RU'
                                       and md_at.IsActive = 1
                                       and md_at.Screen = 'mybank'
                where fd.FinDoc_ID = :finDocId
                  and fd.User_IDREF = :userId
                  and dts.FinDocStatus_IDREF = 'DONE'
                """;
        List<TransferReceiptOut> queryResult = template.query(sql, map, (resultSet, i) -> receiptTslfMapper.toDomain(resultSet, langKey));
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst();
        } else if (queryResult.isEmpty()) {
            return Optional.empty();
        } else {
            throw new AppException(E_DB_601, ": ReceiptTslfRepositoryImpl findByFinDocId");
        }
    }

    @Override
    public TransferReceiptOut findByFinDocIdOrException(Long finDocId) {
        return findByFinDocId(finDocId).
                orElseThrow(() -> new AppException(E_DB_600, ": ReceiptTslfRepositoryImpl findByFinDocIdOrException"));
    }

    @Override
    public Set<String> keys() {
        return Set.of(SLFT, SLFF, SLFR);
    }

}
