package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CardInfoIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.ReceiverP2pIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.CardTransferIOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.CardTransferRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.CardTransferHiberRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;


@Primary
@Repository
public class CardTransferRepositoryImpl implements CardTransferRepository {

    private final CardTransferHiberRepository cardTransferHiberRepository;
    private final InfrastructureMapper mapper;
    private final NamedParameterJdbcTemplate template;


    public CardTransferRepositoryImpl(CardTransferHiberRepository cardTransferHiberRepository,
                                      InfrastructureMapper mapper,
                                      NamedParameterJdbcTemplate template) {
        this.cardTransferHiberRepository = cardTransferHiberRepository;
        this.mapper = mapper;
        this.template = template;
    }

    @Override
    public void save(CardTransferIOut cardTransfer) {
        var entity = mapper.toEntity(cardTransfer);
        cardTransferHiberRepository.save(entity);
    }

    @Override
    public ReceiverP2pIIn findByFinDocIdOrException(Long finDocId) {
        RowMapper<ReceiverP2pIIn> rowMapper = (rs, rowNum) -> new ReceiverP2pIIn(
                rs.getString("maskedNumber"),
                rs.getString("token")
        );
        String sql = """
                SELECT ct.CreditMaskedCardNumber as maskedNumber,
                       ct.Token                  as token
                FROM CardTransfer ct
                WHERE ct.FinDoc_IDREF = :finDocId
                """;
        List<ReceiverP2pIIn> queryResult = template.query(sql, Map.of("finDocId", finDocId), rowMapper);

        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": CardTransferRepository findByFinDocIdOrException"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": CardTransferRepository findByFinDocIdOrException");
        } else {
            throw new AppException(E_DB_601, ": CardTransferRepository findByFinDocIdOrException");
        }
    }


}
