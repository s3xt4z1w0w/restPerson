package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocStateRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.model.FinDocState;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.FinDocStateHiberRepository;
import org.springframework.stereotype.Repository;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;


@Repository
public class FinDocStateRepositoryImpl implements FinDocStateRepository {

    private final FinDocStateHiberRepository finDocStateHiberRepository;

    public FinDocStateRepositoryImpl(FinDocStateHiberRepository finDocStateHiberRepository) {
        this.finDocStateHiberRepository = finDocStateHiberRepository;
    }

    @Override
    public void saveFinDocStatus(String status, Long finDocId) {
        FinDocState finDocState = finDocStateHiberRepository.findByFinDocId(finDocId)
                .orElseThrow(() -> new AppException(E_DB_600, ": FinDocStateRepositoryImpl findByFinDocId"));
        finDocState.setDocTechStatus(status);
        finDocStateHiberRepository.save(finDocState);
    }
}

