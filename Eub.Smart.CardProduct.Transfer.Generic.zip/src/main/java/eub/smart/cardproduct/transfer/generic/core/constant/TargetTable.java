package eub.smart.cardproduct.transfer.generic.core.constant;

public interface TargetTable {

    String FIN_DOC_TYPE = "FinDocType";
    String BANK = "Bank";
    String IPS_ORG = "IPSOrg";
    String CURRENCY_TYPE = "CurrencyType";
}
