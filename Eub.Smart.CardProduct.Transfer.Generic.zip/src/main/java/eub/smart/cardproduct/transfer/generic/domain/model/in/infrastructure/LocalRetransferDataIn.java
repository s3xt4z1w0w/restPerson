package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

public record LocalRetransferDataIn(
        String transferType,
        String knpCode,
        String receiverAccountNumber,
        Long receiverCardId
) {
}
