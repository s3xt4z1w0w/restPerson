package eub.smart.cardproduct.transfer.generic.presentation.model.response;

import java.math.BigDecimal;

public record CorrectAmountResponse(
        BigDecimal correctAmount,
        BigDecimal receiverAmount,
        AmountResponse fromAmount,
        AmountResponse toAmount
) {
}
