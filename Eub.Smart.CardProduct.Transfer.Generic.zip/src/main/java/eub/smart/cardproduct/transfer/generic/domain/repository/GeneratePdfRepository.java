package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.ReceiptDocumentIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferReceiptOut;

public interface GeneratePdfRepository {

    byte[] generateReceipt(ReceiptDocumentIn receiptDocumentIn);
}
