package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferAccFavoriteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TransferAccFavoriteJpaRepository extends JpaRepository<TransferAccFavoriteEntity, Long> {

    @Query(value = """
            select TAF
            from TransferFavoriteEntity TF
                     join TransferAccFavoriteEntity TAF on TF.id = TAF.transferFavorite.id
            where TF.userId = :senderUserId
              and TAF.accountNumber = :receiverAccountNumber
            """)
    Optional<TransferAccFavoriteEntity> findByParams(Long senderUserId, String receiverAccountNumber);

    void deleteByTransferFavoriteId(Long transferFavoriteId);

    @Query(value = """
            select TAF
            from TransferFavoriteEntity TF
                     join TransferAccFavoriteEntity TAF on TF.id = TAF.transferFavorite.id
            where TF.userId = :senderUserId
              and TF.id = :transferFavoriteId
            """)
    Optional<TransferAccFavoriteEntity> findByParams(Long senderUserId, Long transferFavoriteId);

}
