package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FavoriteAccTransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteAcctTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.FavoriteP2pTransferRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateFavoriteUseCase;
import org.springframework.stereotype.Service;

import java.util.Set;

import static eub.smart.cardproduct.transfer.generic.core.constant.FavoriteTransferOperationType.P2PL;

@Service
public class CreateFavoriteP2plUseCaseImpl implements CreateFavoriteUseCase {

    private final FavoriteP2pTransferRepository favoriteP2pTransferRepository;
    private final FavoriteAcctTransferRepository favoriteAcctTransferRepository;

    public CreateFavoriteP2plUseCaseImpl(FavoriteP2pTransferRepository favoriteP2pTransferRepository,
                                         FavoriteAcctTransferRepository favoriteAcctTransferRepository) {
        this.favoriteP2pTransferRepository = favoriteP2pTransferRepository;
        this.favoriteAcctTransferRepository = favoriteAcctTransferRepository;
    }

    @Override
    public Long invoke(Long finDocId) {
        var favoriteP2pTransfer = favoriteP2pTransferRepository.findByFinDocIdOrException(finDocId);
        var favoriteAccTransfer = new FavoriteAccTransferOut(favoriteP2pTransfer);
        var saved = favoriteAcctTransferRepository.save(favoriteAccTransfer);
        return saved.favoriteTransferIn().id();
    }

    @Override
    public Set<String> keySet() {
        return Set.of(P2PL);
    }
}
