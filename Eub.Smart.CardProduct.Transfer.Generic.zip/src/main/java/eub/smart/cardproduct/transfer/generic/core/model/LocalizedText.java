package eub.smart.cardproduct.transfer.generic.core.model;

import eub.smart.cardproduct.transfer.generic.core.enums.LangKey;
import eub.smart.cardproduct.transfer.generic.core.util.EnumUtil;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;

import java.util.Locale;

import static eub.smart.cardproduct.transfer.generic.core.enums.LangKey.EN;
import static java.util.Objects.isNull;

public record LocalizedText(
        String textRu,
        String textKk,
        String textEn
) {

    public String text(LangKey langKey) {
        return switch (langKey) {
            case RU -> textRu;
            case KK -> textKk;
            case EN -> textEn;
        };
    }

    public String text(Locale locale) {
        return LangUtil.RU.equals(locale) ? textRu :
                LangUtil.KK.equals(locale) ? textKk :
                        LangUtil.EN.equals(locale) ? textEn :
                                textRu;
    }

    public String text(String strLangKey) {
        LangKey langKey = EnumUtil.valueOfOrDefault(LangKey.class, strLangKey, EN);
        return switch (langKey) {
            case RU -> textRu;
            case KK -> textKk;
            case EN -> textEn;
        };
    }
}
