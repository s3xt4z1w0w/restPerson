package eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure;

import java.math.BigDecimal;

public record CurrencyRateIn(BigDecimal buyRate,
                             BigDecimal sellRate,
                             String currency
                             ) {
}
