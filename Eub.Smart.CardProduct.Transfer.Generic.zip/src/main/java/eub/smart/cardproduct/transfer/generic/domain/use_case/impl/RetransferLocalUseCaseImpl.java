package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.core.enums.FavoriteTransferType;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateRetransferDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateTransferDataOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FeeOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.RetransferOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.FinDocRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.CreateTransferDataUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.GetAccountInfoByNumberUseCase;
import eub.smart.cardproduct.transfer.generic.domain.use_case.RetransferUseCase;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

import static eub.smart.cardproduct.transfer.generic.core.constant.CurrencyCode.KZT;
import static eub.smart.cardproduct.transfer.generic.core.constant.FinDocType.LOCR;

@Service
public class RetransferLocalUseCaseImpl implements RetransferUseCase {

    private final CreateTransferDataUseCase createTransferDataUseCase;
    private final GetAccountInfoByNumberUseCase getAccountInfoUseCase;
    private final FinDocRepository finDocRepository;

    public RetransferLocalUseCaseImpl(CreateTransferDataUseCase createTransferDataUseCase,
                                      GetAccountInfoByNumberUseCase getAccountInfoUseCase,
                                      FinDocRepository finDocRepository) {
        this.createTransferDataUseCase = createTransferDataUseCase;
        this.getAccountInfoUseCase = getAccountInfoUseCase;
        this.finDocRepository = finDocRepository;
    }

    @Override
    public RetransferOut invoke(CreateRetransferDataIn in) {
        var receiverAccountNumber = finDocRepository.findReceiverAccountNumber(in.finDocId());
        var senderData = getAccountInfoUseCase.invoke(in.senderAccountId(), in.senderCardId(), in.senderCurrency());
        var receiverData = new CreateTransferClientDataIn(receiverAccountNumber, in.receiverCurrency());
        var fee = new FeeOut(BigDecimal.ZERO, KZT);
        var createTransferDataOut = new CreateTransferDataOut(in, senderData, fee);
        var transfer = createTransferDataUseCase.invoke(createTransferDataOut, senderData, receiverData);
        return new RetransferOut(transfer.getTransfer().getFinDoc().getId(), fee.getAmount());
    }

    @Override
    public FavoriteTransferType favoriteTransferType() {
        return FavoriteTransferType.LOCT;
    }

    @Override
    public String finDocType() {
        return LOCR;
    }
}
