package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.ClientOut;
import eub.smart.cardproduct.transfer.generic.domain.use_case.ClientRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.InfrastructureMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.ClientJpaRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;

@Primary
@Component
public class ClientRepositoryImpl implements ClientRepository {

    private final ClientJpaRepository clientJpaRepository;
    private final InfrastructureMapper mapper;

    public ClientRepositoryImpl(ClientJpaRepository clientJpaRepository,
                                InfrastructureMapper mapper) {
        this.clientJpaRepository = clientJpaRepository;
        this.mapper = mapper;
    }

    @Override
    public Optional<ClientOut> findByAccountNumber(String accountNumber) {
        return clientJpaRepository.findByAccountNumber(accountNumber)
                .map(mapper::toDomain);
    }

    @Override
    public ClientOut findByAccountNumberOrException(String accountNumber) {
        return findByAccountNumber(accountNumber)
                .orElseThrow(() -> new AppException(E_DB_600,": Client findByAccountNumberOrException"));
    }
}
