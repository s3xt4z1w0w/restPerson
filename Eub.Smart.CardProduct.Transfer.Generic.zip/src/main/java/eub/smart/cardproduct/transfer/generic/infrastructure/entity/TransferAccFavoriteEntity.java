package eub.smart.cardproduct.transfer.generic.infrastructure.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "TransferAccFavorite")
public class TransferAccFavoriteEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TransferAccFavorite_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "TransferFavorite_IDREF", nullable = false)
    private TransferFavoriteEntity transferFavorite;

    @NotBlank
    @Column(name = "AccountNumber", nullable = false)
    private String accountNumber;

    @NotBlank
    @Column(name = "Currency", nullable = false)
    private String currency;

    @Column(name = "Title")
    private String title;

    @NotBlank
    @Column(name = "ImageTable", nullable = false)
    private String imageTable;

    @NotNull
    @Column(name = "ImageId")
    private Long imageId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TransferFavoriteEntity getTransferFavorite() {
        return transferFavorite;
    }

    public void setTransferFavorite(TransferFavoriteEntity transferFavorite) {
        this.transferFavorite = transferFavorite;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImageTable() {
        return imageTable;
    }

    public void setImageTable(String imageTable) {
        this.imageTable = imageTable;
    }

    public Long getImageId() {
        return imageId;
    }

    public void setImageId(Long imageId) {
        this.imageId = imageId;
    }

    @Override
    public String toString() {
        return "TransferAccFavoriteEntity{" +
                "id=" + id +
                ", transferFavorite=" + transferFavorite +
                ", accountNumber=" + accountNumber +
                ", currency=" + currency +
                ", title=" + title +
                ", imageTable=" + imageTable +
                ", imageId=" + imageId +
                '}';
    }
}
