package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CardInfoIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferCardDataIn;
import eub.smart.cardproduct.transfer.generic.domain.repository.CardRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.CardMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_600;
import static eub.smart.cardproduct.transfer.generic.core.exception.AppErrorCode.E_DB_601;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isOneResult;

@Repository
public class CardRepositoryImpl implements CardRepository {

    private final NamedParameterJdbcTemplate template;

    public CardRepositoryImpl(NamedParameterJdbcTemplate template) {
        this.template = template;
    }

    @Override
    public CreateTransferCardDataIn findByIdOrException(Long cardId, Long accId) {
        String sql = """ 
                select bsc_a.Account_ID        as accountId,
                       bsc_a.AccountType_IDREF as accountType,
                       bsc_a.Currency          as currency,
                       bsc_a.Number            as number,
                       bsc_a.IsMultiCurrency   as multiCurrencyFlag,
                       bsc_a.Account_IDREF     as accountIdRef,
                       c.Card_ID               as cardId,
                       c.Card_OUTREF 	       as cardOutRef
                from Card c
                         join Account a with (nolock) on c.Account_IDREF = a.Account_ID
                         join BSystemClient bsc with (nolock) on a.BSystemClient_IDREF = bsc.BSystemClient_ID
                         join Account bsc_a with (nolock) on bsc.BSystemClient_ID = bsc_a.BSystemClient_IDREF
                where c.Card_ID = :cardId
                and bsc_a.Account_ID = :accId
                """;

        List<CreateTransferCardDataIn> queryResult = template.query(sql,
                Map.of("cardId", cardId, "accId", accId),
                CardMapper::toDomain);
        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": CardRepository findByIdOrException"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": CardRepository findByIdOrException");
        } else {
            throw new AppException(E_DB_601, ": CardRepository findByNumber");
        }
    }

    @Override
    public CardInfoIIn findByCardIdOrException(Long cardId) {
        RowMapper<CardInfoIIn> rowMapper = (rs, rowNum) -> new CardInfoIIn(
                rs.getLong("cardId"),
                rs.getLong("cardOutRef"),
                rs.getLong("accountId"),
                rs.getString("maskedNumber"),
                rs.getString("name"),
                rs.getString("cardStatus"),
                rs.getLong("accountOutRefId")
        );
        String sql = """
                SELECT c.Card_ID          as cardId,
                       c.Card_OUTREF      as cardOutRef,
                       c.Account_IDREF    as accountId,
                       c.MaskedNumber     as maskedNumber,
                       c.NameEmbossed     as name,
                       c.CardStatus_IDREF as cardStatus,
                       a.Account_OUTREF   as accountOutRefId
                FROM Card c
                JOIN Account a ON a.Account_ID = c.Account_IDREF
                WHERE c.Card_ID = :cardId
                """;
        List<CardInfoIIn> queryResult = template.query(sql, Map.of("cardId", cardId), rowMapper);

        if (isOneResult(queryResult)) {
            return queryResult
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new AppException(E_DB_600, ": CardRepository findByCardIdOrException"));
        } else if (queryResult.isEmpty()) {
            throw new AppException(E_DB_600, ": CardRepository findByCardIdOrException");
        } else {
            throw new AppException(E_DB_601, ": CardRepository findByCardIdOrException");
        }
    }
}
