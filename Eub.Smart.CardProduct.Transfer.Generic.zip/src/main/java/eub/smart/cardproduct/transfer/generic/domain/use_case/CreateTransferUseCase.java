package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateTransferClientDataIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.TransferOut;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.CreateTransferDataOut;

public interface CreateTransferUseCase {

    TransferOut invoke(FinDocOut finDoc, CreateTransferClientDataIn senderAccount, CreateTransferClientDataIn receiverAccount, CreateTransferDataOut in);
}
