package eub.smart.cardproduct.transfer.generic.core.util;

import static java.util.Objects.nonNull;

public class NumUtil {

    public static boolean nonBlank(Long value) {
        return nonNull(value) && value != 0;
    }
}
