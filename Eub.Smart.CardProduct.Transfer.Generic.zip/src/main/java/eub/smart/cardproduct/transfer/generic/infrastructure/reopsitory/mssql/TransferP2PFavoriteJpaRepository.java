package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferIpsFavoriteEntity;
import eub.smart.cardproduct.transfer.generic.infrastructure.entity.TransferP2pFavoriteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface TransferP2PFavoriteJpaRepository extends JpaRepository<TransferP2pFavoriteEntity, Long> {

    @Query(value = """
        SELECT tpp.*
        FROM TransferFavorite tf
                 JOIN TransferP2PFavorite tpp ON tpp.TransferFavorite_IDREF = tf.TransferFavorite_ID
        WHERE tf.User_IDREF = :userId
          AND tpp.Token = :token
    """, nativeQuery = true)
    Optional<TransferP2pFavoriteEntity> findByParam(Long userId, String token);
    void deleteByTransferFavoriteId(Long transferFavoriteId);
}
