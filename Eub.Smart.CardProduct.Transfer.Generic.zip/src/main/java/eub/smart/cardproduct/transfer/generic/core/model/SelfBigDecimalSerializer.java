package eub.smart.cardproduct.transfer.generic.core.model;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import static java.util.Objects.nonNull;

public class SelfBigDecimalSerializer extends JsonSerializer<BigDecimal> {

    @Override
    public void serialize(BigDecimal bigDecimal, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        if (nonNull(bigDecimal)) {
            bigDecimal = bigDecimal.setScale(2, RoundingMode.HALF_UP);
            jsonGenerator.writeNumber(bigDecimal);
        } else {
            jsonGenerator.writeNull();
        }
    }
}
