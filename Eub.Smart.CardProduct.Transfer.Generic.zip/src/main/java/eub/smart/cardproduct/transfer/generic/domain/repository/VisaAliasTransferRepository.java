package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FeeOutgoingIIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.VisaTokenIIn;

import java.math.BigDecimal;

public interface VisaAliasTransferRepository {
    FeeOutgoingIIn getFee(Long cardOutRef, BigDecimal amount);

    VisaTokenIIn getResolveToken(String phoneNumber);
}
