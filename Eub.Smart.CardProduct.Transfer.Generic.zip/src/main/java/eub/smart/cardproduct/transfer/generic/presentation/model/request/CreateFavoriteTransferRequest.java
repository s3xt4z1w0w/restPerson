package eub.smart.cardproduct.transfer.generic.presentation.model.request;

import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public record CreateFavoriteTransferRequest(

        @Schema(description = "Id карты отправителя")
        Long senderCardId,

        @Schema(description = "Id счета отправителя", required = true)
        Long senderAccountId,

        @Schema(description = "Id сохраненного перевода", required = true)
        Long favoriteTransferId,

        @NotNull
        @Schema(description = "Сумма списания", required = true)
        BigDecimal debitAmount,

        @NotNull
        @Schema(description = "Сумма зачисления", required = true)
        BigDecimal creditAmount
) {
}

