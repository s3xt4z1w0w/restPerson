package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.impl;

import eub.smart.cardproduct.transfer.generic.core.component.AuthToken;
import eub.smart.cardproduct.transfer.generic.core.exception.AppException;
import eub.smart.cardproduct.transfer.generic.core.model.UserDetails;
import eub.smart.cardproduct.transfer.generic.core.util.LangUtil;
import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.TransferHistoryIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferHistoryOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.MessageSourceRepository;
import eub.smart.cardproduct.transfer.generic.domain.repository.TransferHistoryRepository;
import eub.smart.cardproduct.transfer.generic.infrastructure.mapper.mssql.TransferHistoryMapper;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.MessageSourceRepositoryImpl;
import eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql.FinDocJpaRepository;
import org.slf4j.MDC;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;

import static eub.smart.cardproduct.transfer.generic.core.constant.BundleCode.ERROR_MESSAGE_EMPTY_HISTORY;
import static eub.smart.cardproduct.transfer.generic.core.constant.DocType.*;
import static eub.smart.cardproduct.transfer.generic.core.constant.HeaderName.LANG_KEY;
import static eub.smart.cardproduct.transfer.generic.core.util.CollectionUtil.isEmpty;

@Repository
public class TransferHistoryRepositoryImpl implements TransferHistoryRepository {

    private final AuthToken authToken;
    private final FinDocJpaRepository finDocJpaRepository;
    private final MessageSourceRepository messageSourceRepository;
    private final TransferHistoryMapper transferHistoryMapper;

    public TransferHistoryRepositoryImpl(AuthToken authToken,
                                         FinDocJpaRepository finDocJpaRepository,
                                         MessageSourceRepository messageSourceRepository,
                                         TransferHistoryMapper transferHistoryMapper) {
        this.authToken = authToken;
        this.finDocJpaRepository = finDocJpaRepository;
        this.messageSourceRepository = messageSourceRepository;
        this.transferHistoryMapper = transferHistoryMapper;
    }

    @Override
    public List<TransferHistoryOut> findBy(TransferHistoryIn in, Pageable pageable) {
        var langKey = MDC.get(LANG_KEY);
        var userDetails = UserDetails.build(authToken.getDecodedPayload());
        var pageTransferHistoryProjection = finDocJpaRepository.findByDatePeriodAndUserId(in.from(), in.to().plusDays(1), userDetails.getUserId(), langKey, I92A, I13B, pageable);
        if (isEmpty(pageTransferHistoryProjection.getContent()))
            return Collections.emptyList();
        return pageTransferHistoryProjection.stream()
                .map(transferHistoryProjection -> transferHistoryMapper.toDomain(transferHistoryProjection, langKey))
                .toList();
    }

    private String formErrorMessage(String langKey) {
        var locale = LangUtil.get(langKey);
        return messageSourceRepository.getMessage(ERROR_MESSAGE_EMPTY_HISTORY, locale);
    }
}
