package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FinDocStatusIn;

import java.util.Optional;

public interface FinDocStatusRepository {

    Optional<FinDocStatusIn> findByFinIdDoc(Long finDocId);
    Optional<FinDocStatusIn> findById(String id);
    FinDocStatusIn findByIdOrException(String id);
}
