package eub.smart.cardproduct.transfer.generic.infrastructure.entity;

import javax.persistence.*;

@Entity
@Table(name = "TransferP2PFavorite")
public class TransferP2pFavoriteEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TransferP2PFavorite_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "TransferFavorite_IDREF", nullable = false)
    private TransferFavoriteEntity transferFavorite;

    @Column(name = "Title")
    private String title;

    @Column(name = "Token")
    private String token;

    @Column(name = "BinCard")
    private String bin;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TransferFavoriteEntity getTransferFavorite() {
        return transferFavorite;
    }

    public void setTransferFavorite(TransferFavoriteEntity transferFavorite) {
        this.transferFavorite = transferFavorite;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    @Override
    public String toString() {
        return "TransferP2pFavoriteEntity{" +
                "id=" + id +
                ", transferFavorite=" + transferFavorite +
                ", title='" + title +
                ", token='" + token +
                ", bin='" + bin +
                '}';
    }
}
