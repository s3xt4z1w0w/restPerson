package eub.smart.cardproduct.transfer.generic.core.enums;

public enum FinDocStatusDisplay {

    DRFT("draft"),
    DONE("success"),
    EROR("cancelled"),
    PROC("processing"),
    RJCT("cancelled"),
    RTRN("refunded");

    private final String value;

    private FinDocStatusDisplay(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
