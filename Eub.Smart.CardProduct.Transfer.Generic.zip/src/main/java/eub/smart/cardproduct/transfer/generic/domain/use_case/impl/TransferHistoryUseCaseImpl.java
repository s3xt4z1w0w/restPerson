package eub.smart.cardproduct.transfer.generic.domain.use_case.impl;

import eub.smart.cardproduct.transfer.generic.domain.model.in.presentation.TransferHistoryIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.TransferHistoryOut;
import eub.smart.cardproduct.transfer.generic.domain.repository.TransferHistoryRepository;
import eub.smart.cardproduct.transfer.generic.domain.use_case.TransferHistoryUseCase;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransferHistoryUseCaseImpl implements TransferHistoryUseCase {

    private final TransferHistoryRepository transferHistoryRepository;

    public TransferHistoryUseCaseImpl(TransferHistoryRepository transferHistoryRepository) {
        this.transferHistoryRepository = transferHistoryRepository;
    }

    @Override
    public List<TransferHistoryOut> invoke(TransferHistoryIn in, Pageable pageable) {
        return transferHistoryRepository.findBy(in, pageable);
    }
}
