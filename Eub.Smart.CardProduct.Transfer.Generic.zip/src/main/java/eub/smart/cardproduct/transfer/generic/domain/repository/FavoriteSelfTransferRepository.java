package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.CreateFavoriteSelfTransferIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FavoriteTransferDisplayIn;
import eub.smart.cardproduct.transfer.generic.domain.model.out.presentation.FavoriteTransferDisplayOut;

import java.util.Optional;

public interface FavoriteSelfTransferRepository {

    CreateFavoriteSelfTransferIn findByFinDocIdOrException(Long id);
    Optional<CreateFavoriteSelfTransferIn> findByFinDocId(Long id);
    FavoriteTransferDisplayOut fillDetailsDisplay(FavoriteTransferDisplayIn in);
}
