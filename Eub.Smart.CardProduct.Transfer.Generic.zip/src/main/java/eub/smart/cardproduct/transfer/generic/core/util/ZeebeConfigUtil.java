package eub.smart.cardproduct.transfer.generic.core.util;

public class ZeebeConfigUtil {

    public static final boolean WORKER_ENABLE = true;
}
