package eub.smart.cardproduct.transfer.generic.domain.use_case;

import eub.smart.cardproduct.transfer.generic.core.exception.FieldError;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.TransferValidate;

import java.math.BigDecimal;
import java.util.List;

public interface ValidateAmountFieldUseCase {
    List<FieldError> invoke(TransferValidate validate, List<FieldError> fieldErrors);
}
