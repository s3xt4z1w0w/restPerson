package eub.smart.cardproduct.transfer.generic.domain.repository;

import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.FindFavoriteTransferOperationTypeIn;
import eub.smart.cardproduct.transfer.generic.domain.model.in.infrastructure.TransferValidate;
import eub.smart.cardproduct.transfer.generic.domain.model.out.infrastucture.FinDocOut;

public interface FinDocRepository {

    String findTypeOrException(Long finDocId);

    FinDocOut save(FinDocOut finDoc);

    String findReceiverAccountNumber(Long finDocId);

    FindFavoriteTransferOperationTypeIn findOperationTypeOrException(Long finDocId);

    TransferValidate findTransferData(Long finDocId);
}
