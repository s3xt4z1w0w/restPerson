package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.infrastructure.model.FinDocState;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FinDocStateHiberRepository extends JpaRepository<FinDocState, Long> {

    Optional<FinDocState> findByFinDocId(Long id);
}
