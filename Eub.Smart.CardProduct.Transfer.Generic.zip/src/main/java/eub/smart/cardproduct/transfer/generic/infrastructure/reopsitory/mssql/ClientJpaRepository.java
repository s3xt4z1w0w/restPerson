package eub.smart.cardproduct.transfer.generic.infrastructure.reopsitory.mssql;

import eub.smart.cardproduct.transfer.generic.infrastructure.entity.ClientEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ClientJpaRepository extends JpaRepository<ClientEntity, Long> {

    @Query(value = "select C.*" +
            " from Client C" +
            " join BSystemClient BSC on c.Client_ID = BSC.Client_IDREF" +
            " join Account A on BSC.BSystemClient_ID = A.BSystemClient_IDREF" +
            " where A.Number = :accountNumber", nativeQuery = true)
    Optional<ClientEntity> findByAccountNumber(@Param("accountNumber") String accountNumber);
}
